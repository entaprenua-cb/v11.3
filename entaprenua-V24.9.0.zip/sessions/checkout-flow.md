Here's the end-to-end data flow:
1. Entry — GraphQL Mutation
CheckoutMutationResolver.checkout(dfe, input: CheckoutInput) maps the GQL input to CheckoutRequest and calls checkoutService.checkoutWithPayment(storeId, request).
2. Input Validation
CheckoutServiceImpl:52-64 — requires either cartId or lineItems; verifies the store exists and is not a template.
3. Item Resolution — Two Branches
Branch A: checkoutCart(cartId) (line 193)
1. cartRepository.lockCartForCheckout(cartId) — DB advisory lock
2. cartRepository.findByIdWithLock(cartId) — SELECT ... FOR UPDATE on the cart row
3. Rejects if cart.isLocked == true
4. cartRepository.findEnrichedItemsByCartIdWithLock(cartId) — joins cart_items → product_variants → products with FOR UPDATE on all tables, returns List<CartItemOutput> (enriched with name, price, image, stock, subtotal)
5. validateItems() — checks quantity > 0
6. For each enriched item: fetches the variant (for sku, optionValues), maps to OrderItem(productId, productName, price, quantity, subtotal, variantId, variantSku, variantOptions)
7. Returns CheckoutItemResult(items, subtotal=cart.subtotal, total=cart.total, currency=cart.currency)
Branch B: checkoutLineItems(lineItems, storeId) (line 236)
1. For each CheckoutLineItem:
- productRepository.findById(productId) — validates product exists
- If variantId: variantRepository.findById(variantId) — validates variant
- If no variantId: takes the first variant from variantRepository.findByProductId()
- Validates quantity > 0
- Computes itemSubtotal = variant.price * quantity
- Maps to OrderItem
2. Sums all subtotals → subtotal
3. total = subtotal (no tax/shipping/discount applied)
4. Currency hardcoded to "KES"
5. Returns CheckoutItemResult
4. Build & Persist Order
Order header (line 85):
Order(storeId, customerId?, email, name, phone, deliveryMethod, deliveryMethodId, 
      deliveryZoneId, deliveryCountry, deliveryCity, 
      orderNumber, status="pending_payment", currency, subtotal, total,
      billingAddress, shippingAddress, notes, items)
OrderRepository.save(order) — OrderRepository.kt:224-304:
- Generates UUID if no order.id
- INSERT INTO orders (...) VALUES (...) ON CONFLICT (id) DO UPDATE SET version = version + 1, ...
- DELETE FROM order_items WHERE order_id = ? (clears old items)
- batchInsert all OrderItems into order_items
- Returns order.copy(id = orderId)
5. Create Payment Record
OrderRepository.save() returns → then creates Payment(orderId, storeId, amount, currency, status=PENDING, provider) and paymentRepository.save(payment) into payments table.
6. Side Effects
- orderEventStream.publish(ORDER_CREATED)
- For each item: fetches variant, checks availableQuantity() >= item.quantity, increments reservedQuantity, saves variant, publishes STOCK_RESERVED
- If cart-based: cartRepository.deleteAllItemsByCartId(cartId) + recalculateTotals(cartId)
7. Return
CheckoutResultGraphQL(success=true, orderId, orderNumber, paymentId, total, currency, paymentMethod, status="pending_payment")
Cart item → OrderItem mapping happens in checkoutCart() at lines 213-225 and checkoutLineItems() at lines 260-269. The OrderItem is a flat snapshot of the product at time of purchase — it copies productName, price, subtotal, variantSku, variantOptions from the current product/variant state so the order is immune to future product changes.
