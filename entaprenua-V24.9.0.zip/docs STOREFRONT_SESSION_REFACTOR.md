# Storefront Session Refactoring Plan

## Problem

The storefront templates (`templates/electronics/**`) were using platform-specific authentication (`/auth/*`) which is managed in `user_sessions` table. This creates a mixed architecture where:

1. Storefront cart uses `store_customer_sessions` (per-store, cookie: `store_session_id`)
2. But the auth guards check platform auth (`/auth/*`, cookie: `access_token`)

This causes issues where platform auth state leaks into storefront templates.

## Solution (COMPLETED ✅)

Refactored frontend to use store-specific customer auth:
- `/{publicId}/customers/*` for store customer login/register
- `/{publicId}/sessions/*` for guest/customer session management
- Table: `store_customer_sessions` and `store_customers`
- No more platform auth (`/auth/*`) in storefront

## Architecture After Refactor

### Backend (No Changes Needed ✅)

| Table | Cookie | API Path | Purpose |
|-------|---------|---------|---------|
| `store_customer_sessions` | `store_session_id` | `/{publicId}/sessions` | Store-specific sessions |
| `store_customers` | - | `/{publicId}/customers/*` | Store-specific customers |
| `user_sessions` | `access_token` | `/auth/*` | Platform auth (NOT used in storefront) |

### Frontend - After Refactor

**templates/electronics/src/lib/**
- `sessions.ts` → Uses `/{publicId}/sessions` ✅
- `carts.ts` → Uses httpOnly cookie ✅
- `client.ts` → Simplified (no platform refresh) ✅
- `routes.ts` → Uses store-specific routes ✅
- `guards/auth.tsx` → Uses `/{publicId}/customers/*` ✅

**templates/electronics/src/components/ui/**
- `cart/cart-context.tsx` → Uses store session ✅
- `auth/login-form.tsx` → Uses store customer login ✅
- `auth/register-form.tsx` → Uses store customer register ✅

## Implementation Steps

### Step 1: Update sessions.ts

Add `logout` method (currently missing in backend but endpoint exists):

```typescript
// Add to exports
logout: async (publicId: string): Promise<void> => {
  return api.post<void>(`${SESSIONS_BASE(publicId)}/logout`, {});
}
```

### Step 2: Update cart-context.tsx

Replace `auth.user()` check with store session's `isAuthenticated`:

```typescript
// BEFORE
const ensureGuestSession = async (publicId: string): Promise<string | undefined> => {
  if (auth.user()) return undefined  // Platform auth check
  const session = await sessionsApi.getOrCreate(publicId)
  return session.sessionId
}

// AFTER  
const ensureGuestSession = async (publicId: string): Promise<string | undefined> => {
  const session = await sessionsApi.getCurrent(publicId)
  if (session.isAuthenticated) return undefined  // Store session has customerId linked
  const newSession = await sessionsApi.getOrCreate(publicId)
  return newSession.sessionId
}
```

### Step 3: Update client.ts

Remove platform auth refresh logic that's not needed for guest-only:

```typescript
// Remove or disable silent refresh for storefront
// Keep CSRF handling but remove token expiry checks
```

### Step 4: Clean up routes.ts

Keep only necessary routes, mark platform auth as not used:

```typescript
// Keep: these are used by backend
// Remove: platform auth routes since we're guest-only
```

### Step 5: Update guards/auth.tsx

Make a minimal guest-only version that doesn't call platform:

```typescript
// Remove all /auth/* calls
// Just provide stub methods that do nothing
// Keep the interface for compatibility
```

### Step 6: Disable login/register forms

Remove or disable the platform auth forms in UI components.

## Files to Modify

| File | Change |
|------|--------|
| `src/lib/api/sessions.ts` | Add logout method |
| `src/components/ui/cart/cart-context.tsx` | Use store session's isAuthenticated |
| `src/lib/api/client.ts` | Remove platform refresh logic |
| `src/lib/api/routes.ts` | Cleanup unused routes |
| `src/lib/guards/auth.tsx` | Make guest-only no-op |
| `src/components/ui/auth/login-form.tsx` | Remove or disable |
| `src/components/ui/auth/register-form.tsx` | Remove or disable |

## Backend Considerations

The backend already has all needed endpoints:

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/{publicId}/sessions` | GET | Get or create session |
| `/{publicId}/sessions/current` | GET | Get current session |
| `/{publicId}/sessions/refresh` | POST | Refresh session |
| `/{publicId}/sessions/logout` | POST | Logout session |

Note: The `logout` endpoint exists in backend but is not exposed - need to verify it's accessible.

## Post-Refactor State

- ✅ Storefront uses only `/{publicId}/sessions`
- ✅ Session cookie: `store_session_id` (httpOnly)
- ✅ Table: `store_customer_sessions`
- ✅ No platform auth calls from storefront
- ✅ Ready to enable customer login later via `/{publicId}/customers/*`

## Copy to templates/~/

After refactoring, copy the refactored `templates/electronics/src/lib/**` to `templates/~/lib/**`.