# Storefront Code Checker

**Last Updated**: 2026-03-31  
**Status**: 📋 Planned

---

## Overview

A lightweight, local CLI tool to validate storefront code before committing. Ensures code follows security rules and best practices.

**Key principle:** Works offline, fast, and friendly for both humans and AI coding models.

---

## Why a Pre-Commit Checker?

| Approach | Pros | Cons |
|---------|------|------|
| ESLint in CI | Works | Too late - after commit |
| VS Code Extension | Real-time | Not everyone uses VS Code |
| Custom Editor | Best UX | Lots of work |
| **Pre-commit checker** | ✅ Simple, fast, offline, AI-friendly | - |

### Benefits

- **Offline-first** — no internet required
- **Fast** — local validation, no network latency
- **Reliable** — no external service dependencies
- **AI-friendly** — JSON output, clear error messages
- **Simple** — one command to run

---

## Package

```
@entaprenua/storefront-check
```

A separate, lightweight package. Only install what you need.

---

## Installation

```bash
# Install as dev dependency
npm install -D @entaprenua/storefront-check

# Install pre-commit hook (optional)
npx storefront-check install
```

---

## Usage

### CLI

```bash
# Validate entire src directory
npx storefront-check ./src

# Validate specific files
npx storefront-check ./src/components/Banner.tsx

# Validate staged files (for pre-commit hook)
npx storefront-check --staged

# JSON output (for AI, CI, scripts)
npx storefront-check ./src --json
```

### Pre-Commit Hook

```bash
# Auto-install pre-commit hook
npx storefront-check install

# Or add manually to package.json
{
  "husky": {
    "hooks": {
      "pre-commit": "storefront-check --staged"
    }
  }
}
```

### CI/CD

```yaml
# GitHub Actions
name: Validate Storefront
on: [push, pull_request]

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - run: npm install
      - run: npx storefront-check ./src
```

---

## Output

### Human-Readable (Default)

```
✗ src/components/Banner.tsx:15
  Event handler not allowed: 'onClick'
  Fix: Use <Button variant="primary"/> for click actions

✗ src/routes/index.tsx:8
  Ternary operator not allowed
  Fix: Use <Switch>/<Match> for conditional rendering

✗ src/components/Product.tsx:12
  Variable declarations not allowed
  Fix: Move logic to platform components or lib/utils
```

### JSON Output (for AI/CI)

```json
{
  "valid": false,
  "errors": [
    {
      "file": "src/components/Banner.tsx",
      "line": 15,
      "column": 8,
      "rule": "no-event-handlers",
      "message": "Event handler not allowed: 'onClick'",
      "fix": "Replace with <Button variant=\"primary\"/> for click actions"
    },
    {
      "file": "src/routes/index.tsx",
      "line": 8,
      "column": 3,
      "rule": "no-ternary",
      "message": "Ternary operator not allowed",
      "fix": "Use <Switch>/<Match> for conditional rendering"
    }
  ]
}
```

---

## Rules

### Event Handlers

```
❌ Blocked
onClick, onChange, onSubmit, onInput, onMouseEnter, onMouseLeave,
onFocus, onBlur, onKeyDown, onKeyUp, onScroll, etc.

✅ Fix
Use platform components like <Button> for click actions.
```

### Reactive Primitives

```
❌ Blocked
createSignal, createEffect, createMemo, createResource,
createStore, createContext, useContext, batch, etc.

✅ Fix
Use platform components with built-in functionality.
```

### Operators

```
❌ Blocked
&& (use <Show> instead)
? : (use <Switch>/<Match> instead)

✅ Fix
<Show when={condition}>...</Show>
<Switch><Match when={...}>...</Match></Switch>
```

### Variables

```
❌ Blocked
const, let, var declarations

✅ Fix
Use props and platform components.
```

### Imports

```
❌ Blocked
solid-js (except: Show, Switch, Match, splitProps, mergeProps)
Any other npm package

✅ Fix
Use ~/components/*, ~/lib/utils
Import Show/Switch/Match directly from 'solid-js'
```

### Files

```
❌ Blocked
.ts, .js files (only .tsx and .jsx allowed)

✅ Fix
Rename to .tsx extension
```

---

## Error Messages

Each error includes:
- **What** is wrong
- **Where** it is (file, line, column)
- **How** to fix it

```
✗ src/components/Banner.tsx:15
  Event handler not allowed: 'onClick'
  Fix: Use <Button variant="primary"/> for click actions
```

---

## Design Principles

1. **Offline-first** — no internet required to run
2. **Fast** — validate in seconds
3. **Clear errors** — tell users how to fix issues
4. **AI-friendly** — JSON output for programmatic use
5. **Read-only** — no auto-fix, just detection

---

## Implementation

### CLI Structure

```bash
storefront-check
├── bin/
│   └── cli.js           # Entry point
├── src/
│   ├── index.ts         # Main logic
│   ├── validator.ts     # Rule validation
│   ├── formatter.ts     # Output formatters
│   └── rules/          # Individual rule implementations
├── package.json
└── README.md
```

### Key Dependencies

```json
{
  "dependencies": {
    "glob": "^10.0.0",
    "chalk": "^5.0.0"
  },
  "devDependencies": {
    "@types/node": "^20.0.0",
    "typescript": "^5.0.0"
  }
}
```

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | No errors |
| 1 | Validation errors found |
| 2 | File not found or other error |

---

## For AI Coding Models

AI coding models (Claude, Copilot, Cursor, etc.) can use this checker to validate generated code.

### Recommended Workflow

```
1. Read rules from docs/STOREFRONT_CODE_SECURITY.md
2. Write compliant code
3. Run: npx storefront-check ./src --json
4. If errors: fix based on error messages
5. Re-run to verify
6. Done
```

### JSON Output (with Fix Field)

```json
{
  "valid": false,
  "errors": [
    {
      "file": "src/components/Banner.tsx",
      "line": 15,
      "column": 8,
      "rule": "no-event-handlers",
      "message": "Event handler not allowed: 'onClick'",
      "fix": "Replace with platform components like <Button> for click actions"
    },
    {
      "file": "src/routes/index.tsx",
      "line": 8,
      "column": 3,
      "rule": "no-ternary",
      "message": "Ternary operator not allowed",
      "fix": "Use <Switch>/<Match> for conditional rendering"
    }
  ]
}
```

### Exit Codes

| Code | Meaning | Action |
|------|---------|--------|
| 0 | No errors | Proceed |
| 1 | Validation errors | Fix errors, re-run |
| 2 | File not found | Check paths |

### Example: Fix Loop

```bash
# Generate code
Me: "Create a ProductCard component"

# Validate
$ npx storefront-check ./src/components/ProductCard.tsx --json
{
  "valid": false,
  "errors": [
    {
      "file": "src/components/ProductCard.tsx",
      "line": 12,
      "rule": "no-ternary",
      "message": "Ternary operator not allowed",
      "fix": "Use <Switch>/<Match> for conditional rendering"
    }
  ]
}

# Fix the error
Me: Replace ternary with <Switch>/<Match>

# Verify
$ npx storefront-check ./src/components/ProductCard.tsx --json
{
  "valid": true,
  "errors": []
}

# Done - proceed with commit
```

### What AI Models Should Read First

1. `docs/STOREFRONT_CODE_SECURITY.md` — Security rules and allowed patterns
2. `docs/STOREFRONT_CHECKER.md` — This document
3. `src/components/examples/` — Working examples in the template

### Template Examples

The storefront template includes working examples:

```
src/components/examples/
├── Show.tsx          # <Show> usage
├── Switch.tsx        # <Switch>/<Match> usage
├── Props.tsx         # Typed props
└── splitProps.tsx   # splitProps usage
```

These examples show correct patterns that AI models should follow.

### JSON Fields for AI

| Field | Purpose |
|-------|---------|
| `valid` | Boolean — true if no errors |
| `errors[].file` | File path to fix |
| `errors[].line` | Line number to fix |
| `errors[].rule` | Rule name for reference |
| `errors[].message` | What is wrong |
| `errors[].fix` | How to fix it |

---

## Related Documentation

- [Storefront Code Security](STOREFRONT_CODE_SECURITY.md) — Security rules
- [VCS Integration](VCS_INTEGRATION.md) — Repository setup

---

## Future Enhancements

1. **GitHub App integration** — Comment errors on PRs
2. **VS Code extension** — Real-time validation
3. **Online mode** — Optional centralized rule updates
4. **Language support** — Spanish, French, etc. (localized errors)
