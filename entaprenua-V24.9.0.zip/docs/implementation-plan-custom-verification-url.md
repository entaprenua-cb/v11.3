# Custom Email Verification Redirect URL - Implementation Plan

## Overview
Allow store owners to configure a custom verification redirect URL for their store. The platform automatically handles appending the token to the URL.

## Requirements Confirmed

| Requirement | Decision |
|-------------|----------|
| Token format | Query param (`?token=xxx`) |
| URL validation | Validate format (HTTPS, valid URL) - NOT accessibility |
| Auto-append token | Platform adds `?token=xxx` automatically |
| Max length | 500 characters |
| HTTP allowed | No (HTTPS only) |
| Scope | Per-store |

## Implementation

### 1. Database Migration

**File:** `V30__Add_verification_redirect_url.sql`

```sql
ALTER TABLE stores ADD COLUMN IF NOT EXISTS verification_redirect_url VARCHAR(500);
```

### 2. Backend Changes

**Store Entity** - Add field `verificationRedirectUrl`

**Store Repository** - Update save/query

**Store Settings API** - Add validation:
- Must be HTTPS
- Must be valid URL format
- Max 500 characters
- Note: Does NOT validate if URL is accessible/real - that's user's responsibility

**Email Template** - Auto-append token:
- If URL has `?` already → append `&token=xxx`
- If URL doesn't have `?` → append `?token=xxx`

### 3. Token Appending Logic

```kotlin
fun buildVerificationUrl(customUrl: String?, baseUrl: String, token: String): String {
    val url = customUrl ?: "${baseUrl}/verify-email"
    return if (url.contains("?")) {
        "${url}&token=${token}"
    } else {
        "${url}?token=${token}"
    }
}
```

## Files to Modify

| File | Action |
|------|--------|
| `V30__Add_verification_redirect_url.sql` | Create |
| `Store.kt` | Add field |
| `StoreRepository.kt` | Update queries |
| Store settings endpoint | Add field with validation |
| `EmailTemplates.kt` | Use custom URL + auto-append token |

## Validation Rules (Platform-side)

- Must be `https://`
- Must be valid URL format
- Max 500 characters
- **NOT** validated for accessibility - user ensures URL works

## Auto-Append Token Logic

| User Provided | Platform Appends | Final URL |
|--------------|-------------------|-----------|
| `https://store.com/verify` | `?token=xxx` | `https://store.com/verify?token=xxx` |
| `https://store.com/verify?ref=abc` | `&token=xxx` | `https://store.com/verify?ref=abc&token=xxx` |

## Status

- [ ] Create migration
- [ ] Add entity field
- [ ] Update repository
- [ ] Add API field with validation
- [ ] Update email template
- [ ] Test