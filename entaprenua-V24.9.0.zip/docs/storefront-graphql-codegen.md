# Storefront GraphQL Codegen

## Overview

Replace hand-written TypeScript entity types (`lib/types/entities.ts`) with types auto-generated from the backend GraphQL schema. Fragments, queries, and component logic stay untouched — only type annotations change.

```
Before:                         After:
entities.ts (hand-written)      lib/generated/graphql.ts (auto-generated, never hand-edit)
  └─ spotty, always stale           └─ matches backend schema exactly
```

## Architecture

```
┌───────────────────────────────────────────────┐
│ Backend: GET /api/v1/graphql/schema           │  (SchemaPrinter, no auth)
│   → SDL output (text/plain)                   │
└───────────────────┬───────────────────────────┘
                    │ curl > schema.graphql
                    ▼
┌──────────────────────────────┐
│  schema.graphql (committed)  │  (single source of truth)
└──────────────┬───────────────┘
               │ codegen.ts reads it
               ▼
┌──────────────────────────────────────┐
│  lib/generated/graphql.ts            │  (gitignored, regenerated)
│    Product, Cart, Order, Variant...  │
└──────────────┬───────────────────────┘
               │ import type
               ▼
┌──────────────────────────────────────┐
│  api/*.ts  +  components/ui/**       │
│  type annotations only — logic unchanged │
└──────────────────────────────────────┘
```

## Backend Setup

### 1. Clean schema names via `@GraphQLName`

All 43 `*GraphQL` data classes annotated to drop the suffix from the GraphQL schema while keeping Kotlin class names collision-free:

```kotlin
@GraphQLName("Product")
data class ProductGraphQL(...)

@GraphQLName("Cart")
data class CartGraphQL(...)
```

10 files in `backend/src/.../store/graphql/types/` updated. Schema exposes `Product`, `Cart`, `Order`, etc. — no `*GraphQL` suffix.

### 2. Schema endpoint

`GET /api/v1/graphql/schema` — public, no auth, no store context. Returns SDL via `graphql-java`'s `SchemaPrinter`:

```kotlin
// ApiRouterConfig.kt
GET("/graphql/schema") { _ ->
    val schema = graphQL.graphQLSchema
    val sdl = SchemaPrinter(...).print(schema)
    ServerResponse.ok().contentType(MediaType.TEXT_PLAIN).bodyValueAndAwait(sdl)
}
```

Inject `graphql.GraphQL` bean directly (auto-configured by graphql-kotlin).

### 3. Filter allowlisting

Two filters need the schema path whitelisted:

| Filter | Change | File |
|--------|--------|------|
| `AuthenticationFilter` | Add `"/api/v1/graphql/schema"` to `publicPrefixes` | `AuthenticationFilter.kt:127` |
| `StoreContextFilter` | Add `"graphql"` to `reservedWords` (prevents it being treated as a store publicId) | `StoreContextFilter.kt:143` |

### 4. Introspection issue (resolved)

graphql-java's built-in introspection limiter blocks the standard `graphql-codegen introspect-schema` query (too many `__Type.fields` references). The SDL endpoint bypasses this entirely — `SchemaPrinter.print()` generates the SDL without hitting the introspection guard.

**Instead of**: `codegen → introspection query → backend` (blocked by limiter)

**We use**: `curl GET /api/v1/graphql/schema → schema.graphql` (committed) → codegen reads local file

### 5. Product review fields

`ReviewStatsGraphQL` and `ReviewConnectionGraphQL` weren't in the schema because graphql-kotlin didn't pick up `ProductFieldResolver` methods automatically. Fixed by declaring them as nullable fields on `ProductGraphQL`:

```kotlin
data class ProductGraphQL(
    ...
    val reviews: ReviewConnectionGraphQL? = null,
    val reviewStats: ReviewStatsGraphQL? = null,
)
```

`ProductFieldResolver.reviews()` and `.reviewStats()` resolve the actual values when queried.

## Storefront Setup

### Files

| File | Role |
|------|------|
| `codegen.ts` | Config: reads `schema.graphql`, outputs `lib/generated/graphql.ts` |
| `schema.graphql` | Committed SDL snapshot from backend |
| `lib/generated/graphql.ts` | Auto-generated types (gitignored) |

### npm scripts

```json
{
  "codegen": "graphql-codegen",
  "codegen:dump": "curl http://localhost:8080/api/v1/graphql/schema > schema.graphql"
}
```

### Daily workflow

```bash
# After backend schema change:
npm run codegen:dump && npm run codegen

# Normal dev (schema unchanged):
npm run codegen
```

### Type imports

All types flow through `lib/types/index.ts` as a barrel:

```ts
// lib/types/index.ts
export * from "../generated/graphql"
export * from "./validators"
export * from "./result"
```

API and component files import from `"~/lib/types"` or `"~/lib/generated/graphql"` — no hand-written entity types remain.

## What was removed (storefront clean-up)

| File | Reason |
|------|--------|
| `lib/types/entities.ts` | Replaced by generated types |
| `lib/types/guards.ts` | Admin-focused, wrong type references |
| `lib/types/assertions.ts` | Depended on guards.ts |
| `lib/guards/` (directory) | Admin platform code, moved auth to `components/ui/auth/` |
| `lib/types/reviews.ts` | All types now in generated `graphql.ts` |
| `lib/api/auth.ts` | Platform admin auth, storefront uses OTP auth |
| `lib/api/payments.ts` | Platform admin payments |
| `components/ui/header/` | Missing dependency modules |
| `components/footer.tsx` | Broken component |
