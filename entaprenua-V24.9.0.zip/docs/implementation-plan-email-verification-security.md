# Email Verification & Security Implementation Plan

## Overview
- Implement strict email verification requirements
- Prevent email hijacking scenarios
- Block unverified users from accessing resources
- Auto-cleanup unverified accounts (24 hours)
- Rate limit verification resend requests (60s cooldown, 3/hour)

## Security Flow

### Registration Flow (Standard Pattern)
1. Check if email exists with `emailVerified = true` → Block "Email already registered"
2. Check if email exists with `emailVerified = false`:
   - Same password? → Resend verification email (same user)
   - Different password? → Block "Email already registered. Contact support if this is your email."
3. Create user with `emailVerified = false`
4. Send verification email
5. Return success but user cannot login until verified

### Login Flow
- Block login if `emailVerified = false`
- Return "Please verify your email first. Check your inbox for the verification link."

### Password Reset Flow
- For verified users only - blocked for unverified accounts
- Unverified users must verify email first or wait for cleanup

### Verification Flow
1. Validate token
2. Set `emailVerified = true`
3. Reset verificationResendCount to 0
4. Clear lastVerificationResendAt

### Resend Verification Rate Limiting (Per User - Standard)
- **Cooldown period**: 60 seconds between requests
- **Max attempts**: 3 per hour per user record
- **Reset**: Count resets when email is verified OR after 1 hour of no requests

### Auto-Cleanup (24 Hours - Stricter than Standard)
- Run daily
- Delete users where `emailVerified = false` AND `verificationExpiresAt < now`
- After 24 hours of no verification, email becomes available again

## Implementation Tasks

### 1. AuthServiceImpl.kt
- **register()**: 
  - Check existing unverified users
  - If same password → resend verification
  - If different password → reject with "wait for cleanup" message
  - Return clear message that email requires verification
- **login()**: 
  - Check `emailVerified` field
  - Block if false with message "Please verify your email first..."
- **resendVerification()**:
  - 60 second cooldown between requests
  - Max 3 requests per hour per user
  - Track resend count and last resend time
- **verifyEmail()**:
  - Reset rate limit counters on successful verification

### 2. User Entity (User.kt)
- Added `verificationResendCount: Int = 0`
- Added `lastVerificationResendAt: OffsetDateTime? = null`

### 3. UserRepository.kt
- Updated `mapToUser()` to include new fields
- Updated `save()` to persist new fields
- Added `findUnverifiedExpired()` for cleanup job

### 4. Database Migration (V29)
- Added `verification_resend_count` column (INT, default 0)
- Added `last_verification_resend_at` column (TIMESTAMP WITH TIME ZONE)
- Added index for cleanup query performance

### 5. UnverifiedUserCleanupService.kt
- Scheduled job runs every 24 hours
- Deletes unverified accounts past expiration (24 hours)

### 6. Application.kt
- Added `@EnableScheduling` annotation

## Files Modified
1. `runtime/src/main/kotlin/com/entaprenua/auth/impl/AuthServiceImpl.kt`
2. `runtime/src/main/kotlin/com/entaprenua/entities/User.kt`
3. `runtime/src/main/kotlin/com/entaprenua/repositories/UserRepository.kt`
4. `runtime/src/main/kotlin/com/entaprenua/Application.kt`

## Files Created
1. `runtime/src/main/kotlin/com/entaprenua/auth/services/UnverifiedUserCleanupService.kt`
2. `runtime/src/main/resources/db/migration/V29__Add_verification_rate_limit_columns.sql`
3. `docs/implementation-plan-email-verification-security.md`

## Configuration
- Verification token expires: 7 days
- Cleanup frequency: 24 hours (stricter than standard 7 days)
- Rate limit cooldown: 60 seconds
- Rate limit max: 3 per hour per user

## Testing Scenarios
1. ✅ Register → Cannot login until verified
2. ✅ Same email, same password → Resends verification
3. ✅ Same email, different password → Blocked "wait for cleanup"
4. ✅ Forgot password on unverified → Not possible (blocked)
5. ✅ Verify email → Can login, rate limit resets
6. ✅ Unverified account auto-cleanup after 24 hours
7. ✅ Rate limit: 60s cooldown between resend requests
8. ✅ Rate limit: Max 3 per hour

## Status - COMPLETED
- [x] Update register() method
- [x] Update login() method  
- [x] Update resendVerification() with rate limiting
- [x] Update verifyEmail() to reset rate limits
- [x] Create cleanup service
- [x] Add database migration (V29)
- [x] Update user entity and repository
- [x] Build compiles successfully
