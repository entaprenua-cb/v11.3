# Storefront Monitoring

**Last Updated**: 2026-03-31  
**Status**: 📋 Planned

---

## Overview

Monitor resource usage, performance, and health of storefront processes. Each storefront runs as an isolated Node.js process managed by PM2.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    STOREFRONT PROCESS                             │
│                   (SolidStart SSR via PM2)                       │
│                                                                 │
│  /metrics endpoint ──► Prometheus                                 │
│  stdout/stderr ──────► PM2 logs ──────► Log files              │
│  Health checks ──────► Spring Boot Runtime                      │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    PROMETHEUS                                     │
│              (Scrape metrics every 15s)                          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    GRAFANA                                        │
│         (Per-store dashboards + Email alerts)                    │
└─────────────────────────────────────────────────────────────────┘
```

---

## Metrics

### Per-Store Metrics

| Metric | Description | Alert Threshold |
|--------|-------------|-----------------|
| `storefront_memory_rss_bytes` | Actual RAM used | > 500MB |
| `storefront_memory_heap_bytes` | V8 heap used | - |
| `storefront_cpu_seconds_total` | CPU time consumed | - |
| `storefront_http_requests_total` | Total HTTP requests | - |
| `storefront_http_request_duration_seconds` | Request latency | > 2s |
| `storefront_errors_total` | Error count | > 1% rate |
| `storefront_uptime_seconds` | Process uptime | < 1h (restarts) |

### Global Metrics

| Metric | Description |
|--------|-------------|
| `storefront_processes_total` | Number of running storefronts |
| `storefront_total_memory_bytes` | Total RAM across all stores |
| `storefront_stores_by_status` | Stores by status (running/stopped/error) |

---

## Implementation

### 1. Metrics Endpoint

```typescript
// src/metrics.ts in storefront template
import client from 'prom-client'

const register = new client.Registry()
register.setDefaultLabels({ app: 'storefront', store_id: process.env.STORE_ID })

client.collectDefaultMetrics({ register })

const httpRequestDuration = new client.Histogram({
  name: 'http_request_duration_seconds',
  help: 'Duration of HTTP requests',
  labelNames: ['method', 'route', 'status'],
  buckets: [0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10],
  registers: [register],
})

const httpRequestsTotal = new client.Counter({
  name: 'http_requests_total',
  help: 'Total number of HTTP requests',
  labelNames: ['method', 'route', 'status'],
  registers: [register],
})

const errorsTotal = new client.Counter({
  name: 'errors_total',
  help: 'Total number of errors',
  labelNames: ['type'],
  registers: [register],
})

app.get('/metrics', async (req, res) => {
  res.set('Content-Type', register.contentType)
  res.end(await register.metrics())
})

app.use((req, res, next) => {
  const start = Date.now()
  res.on('finish', () => {
    const duration = (Date.now() - start) / 1000
    httpRequestDuration.observe({ 
      method: req.method, 
      route: req.route?.path || req.path,
      status: res.statusCode 
    }, duration)
    httpRequestsTotal.inc({ 
      method: req.method, 
      route: req.route?.path || req.path,
      status: res.statusCode 
    })
  })
  next()
})
```

### 2. PM2 Configuration

```javascript
// ecosystem.config.js
module.exports = {
  apps: [{
    name: 'storefront-{storeId}',
    script: 'server/index.mjs',
    instances: 1,
    max_memory_restart: '512M',
    env: {
      NODE_ENV: 'production',
      STORE_ID: '{storeId}',
      STORE_NAME: '{storeName}',
    },
  }]
}
```

### 3. Prometheus Scrape Config

```yaml
# prometheus.yml
scrape_configs:
  - job_name: 'storefronts'
    metrics_path: '/metrics'
    scrape_interval: 15s
    static_configs:
      - targets: ['storefront-1:3001', 'storefront-2:3002', '...']
        labels:
          group: 'storefronts'
```

### 4. Log Format

```typescript
// Structured JSON logs for easy parsing
const logFormat = (level: string, storeId: string, message: string, meta?: object) => {
  return JSON.stringify({
    timestamp: new Date().toISOString(),
    level,
    store_id: storeId,
    message,
    ...meta,
  })
}

// Usage
console.log(logFormat('INFO', process.env.STORE_ID, 'Request', {
  method: 'GET',
  path: '/products',
  status: 200,
  duration: 45,
}))

// Output
{"timestamp":"2026-03-31T10:15:30.000Z","level":"INFO","store_id":"abc123","message":"Request","method":"GET","path":"/products","status":200,"duration":45}
```

### 5. Health Check Endpoint

```typescript
// src/health.ts
app.get('/health', (req, res) => {
  const mem = process.memoryUsage()
  
  const healthy = mem.rss < 800 * 1024 * 1024 // 800MB
  
  res.status(healthy ? 200 : 503).json({
    status: healthy ? 'healthy' : 'unhealthy',
    uptime: process.uptime(),
    memory: {
      rss: mem.rss,
      heapUsed: mem.heapUsed,
    },
    timestamp: new Date().toISOString(),
  })
})
```

---

## Grafana Dashboards

### Per-Store Dashboard Template

```json
{
  "title": "Storefront: ${store_name}",
  "uid": "storefront-${store_id}",
  "templating": {
    "store_id": "{store_id}",
    "store_name": "{store_name}"
  },
  "panels": [
    {
      "title": "Memory Usage",
      "type": "gauge",
      "targets": [{
        "expr": "storefront_memory_rss_bytes{store_id=\"$store_id\"}",
        "legendFormat": "{{store_id}}"
      }],
      "fieldConfig": {
        "defaults": {
          "thresholds": {
            "mode": "absolute",
            "steps": [
              {"color": "green", "value": null},
              {"color": "yellow", "value": 400 * 1024 * 1024},
              {"color": "red", "value": 500 * 1024 * 1024}
            ]
          },
          "unit": "bytes"
        }
      }
    },
    {
      "title": "Response Time (p95)",
      "type": "graph",
      "targets": [{
        "expr": "histogram_quantile(0.95, rate(http_request_duration_seconds_bucket{store_id=\"$store_id\"}[5m]))"
      }]
    },
    {
      "title": "Error Rate",
      "type": "stat",
      "targets": [{
        "expr": "rate(errors_total{store_id=\"$store_id\"}[5m]) / rate(http_requests_total{store_id=\"$store_id\"}[5m]) * 100"
      }],
      "fieldConfig": {
        "defaults": {
          "unit": "percent",
          "thresholds": {
            "steps": [
              {"color": "green", "value": null},
              {"color": "yellow", "value": 0.5},
              {"color": "red", "value": 1}
            ]
          }
        }
      }
    },
    {
      "title": "Requests/min",
      "type": "stat",
      "targets": [{
        "expr": "rate(http_requests_total{store_id=\"$store_id\"}[1m]) * 60"
      }]
    },
    {
      "title": "Uptime",
      "type": "stat",
      "targets": [{
        "expr": "storefront_uptime_seconds{store_id=\"$store_id\"}"
      }],
      "fieldConfig": {
        "defaults": {
          "unit": "s"
        }
      }
    }
  ]
}
```

### Dashboard Variables

| Variable | Query | Description |
|----------|-------|-------------|
| `store_id` | `label_values(storefront_memory_rss_bytes, store_id)` | Dropdown of all stores |
| `store_name` | `label_values(storefront_info{store_id="$store_id"}, store_name)` | Store display name |

---

## Alerts

### Alert Rules (Prometheus)

```yaml
# alerts.yml
groups:
  - name: storefront
    interval: 30s
    rules:
      - alert: StorefrontHighMemory
        expr: storefront_memory_rss_bytes > 500 * 1024 * 1024
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High memory usage on {{ $labels.store_id }}"
          description: "Memory usage is above 500MB for 5 minutes (current: {{ $value | humanize1024 }})"

      - alert: StorefrontCriticalMemory
        expr: storefront_memory_rss_bytes > 800 * 1024 * 1024
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Critical memory on {{ $labels.store_id }}"
          description: "Memory usage exceeded 800MB, process may be killed"

      - alert: StorefrontHighCPU
        expr: rate(storefront_cpu_seconds_total[5m]) > 0.8
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High CPU on {{ $labels.store_id }}"

      - alert: StorefrontHighErrorRate
        expr: rate(errors_total[2m]) / rate(http_requests_total[2m]) > 0.01
        for: 2m
        labels:
          severity: critical
        annotations:
          summary: "High error rate on {{ $labels.store_id }}"
          description: "Error rate is above 1%"

      - alert: StorefrontDown
        expr: up{job="storefronts"} == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Storefront {{ $labels.store_id }} is down"
```

### Alertmanager Config (Email)

```yaml
# alertmanager.yml
global:
  smtp_smarthost: 'smtp.example.com:587'
  smtp_from: 'alerts@entaprenua.com'
  smtp_auth_username: 'alerts@entaprenua.com'
  smtp_auth_password: '${SMTP_PASSWORD}'

route:
  group_by: ['alertname', 'store_id']
  group_wait: 30s
  group_interval: 5m
  repeat_interval: 4h
  receiver: 'email'

receivers:
  - name: 'email'
    email_configs:
      - to: 'ops@entaprenua.com'
        headers:
          subject: '[{{ .Status | toUpper }}] {{ .GroupLabels.alertname }} - {{ .CommonLabels.store_id }}'
```

---

## PM2 Commands

```bash
# List all storefront processes
pm2 list

# Real-time monitoring
pm2 monit

# View logs for specific store
pm2 logs storefront-{storeId} --lines 100

# Restart a store
pm2 restart storefront-{storeId}

# Stop a store
pm2 stop storefront-{storeId}

# Delete a store
pm2 delete storefront-{storeId}

# Detailed info
pm2 show storefront-{storeId}
```

### PM2 Log Format

```
                    ┌─────────────────────────────────────────────────────────┐
│  Storefront Logs  │ 2026-03-31 10:15:30 [INFO] [abc123] Request: GET /products 200 45ms │
│                    │ 2026-03-31 10:15:31 [ERROR] [abc123] Database connection failed │
                    └─────────────────────────────────────────────────────────┘
```

---

## Resource Thresholds

| Resource | Warning | Critical | Action |
|----------|---------|----------|--------|
| Memory RSS | > 400MB | > 500MB | Alert |
| Memory RSS | > 600MB | > 800MB | Auto-restart |
| CPU | > 70% (5m) | > 90% (1m) | Alert |
| Response Time | > 1s p95 | > 2s p95 | Alert |
| Error Rate | > 0.5% | > 1% | Alert |
| Uptime | < 1 hour | < 5 min | Store restarted |

---

## Dashboards

### Per-Store Dashboard

```
┌────────────────────────────────────────────────────────────────────────┐
│  Storefront: My Store (abc123)                                           │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ┌──────────────────────┐    ┌──────────────────────┐                │
│  │  Memory              │    │  CPU                 │                │
│  │  ██████████░░░░     │    │  ███░░░░░░░░░░░░    │                │
│  │  340 MB / 512 MB    │    │  12%                 │                │
│  └──────────────────────┘    └──────────────────────┘                │
│                                                                        │
│  ┌──────────────────────┐    ┌──────────────────────┐                │
│  │  Response Time (p95) │    │  Error Rate          │                │
│  │  █████░░░░░░░░░░░░   │    │  █░░░░░░░░░░░░░░░   │                │
│  │  145ms               │    │  0.1%                │                │
│  └──────────────────────┘    └──────────────────────┘                │
│                                                                        │
│  ┌──────────────────────┐    ┌──────────────────────┐                │
│  │  Requests/min       │    │  Uptime              │                │
│  │  234                │    │  14d 7h 23m          │                │
│  └──────────────────────┘    └──────────────────────┘                │
│                                                                        │
│  Recent Requests                                                      │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ 10:15:30  GET  /products         200  45ms                    │  │
│  │ 10:15:29  GET  /products/123     200  23ms                    │  │
│  │ 10:15:28  GET  /cart             200  12ms                    │  │
│  │ 10:15:27  POST /checkout         200  234ms                   │  │
│  └────────────────────────────────────────────────────────────────┘  │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

---

## Dashboard Auto-Provisioning

When a store is created, automatically provision its dashboard:

```typescript
// On store creation
async function provisionDashboard(storeId: string, storeName: string) {
  // 1. Create dashboard in Grafana
  const dashboard = await grafana.createDashboard({
    title: `Storefront: ${storeName}`,
    uid: `storefront-${storeId}`,
    template: STOREFRONT_DASHBOARD_TEMPLATE,
    variables: {
      store_id: storeId,
      store_name: storeName,
    },
  })

  // 2. Create alert rules
  await prometheus.createAlerts(storeId, STOREFRONT_ALERTS)

  // 3. Store dashboard URL in database
  await db.stores.update(storeId, {
    monitoring: {
      grafanaUrl: dashboard.url,
      prometheusJob: `storefront-${storeId}`,
    }
  })
}

// On store deletion
async function cleanupDashboard(storeId: string) {
  await grafana.deleteDashboard(`storefront-${storeId}`)
  await prometheus.deleteAlerts(storeId)
}
```

---

## Grafana API Client

```typescript
// grafana-client.ts
export class GrafanaClient {
  private baseUrl: string
  private token: string

  async createDashboard(config: {
    title: string
    uid: string
    template: object
    variables: Record<string, string>
  }): Promise<{ id: number; url: string }> {
    const dashboard = this.interpolateTemplate(config.template, config.variables)
    
    const response = await fetch(`${this.baseUrl}/api/dashboards/db`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        dashboard: {
          ...dashboard,
          title: config.title,
          uid: config.uid,
        },
        overwrite: true,
      }),
    })
    
    return response.json()
  }
}
```

---

## Related Documentation

- [VCS Integration](VCS_INTEGRATION.md) — Repository setup
- [SSR Implementation](SSR_IMPLEMENTATION.md) — Storefront deployment
- [Storefront Architecture](STOREFRONT.md) — Overall architecture

---

## Future Enhancements

1. **Trace collection** — OpenTelemetry for distributed tracing
2. **Log aggregation** — Loki/ELK for centralized log search
3. **Anomaly detection** — ML-based alerting for unusual patterns
4. **Cost estimation** — Calculate cloud costs per store
5. **Custom dashboards** — Let store owners see their own metrics
6. **API endpoint metrics** — Per-endpoint performance breakdown
