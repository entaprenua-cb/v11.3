# Transparent Data Encryption (pg_tde) Setup

Percona `pg_tde` provides Transparent Data Encryption (TDE) for PostgreSQL, encrypting data at rest at the storage level. The `store_customers` table contains customer PII (email, name, phone) and is encrypted using the `tde_heap` access method.

## Architecture

| Piece | Value |
|---|---|
| Extension | `pg_tde` v2.2.2 (Percona) |
| PostgreSQL | Percona Server for PostgreSQL 18.6.1 |
| Access method | `tde_heap` (encrypts tuples, indexes, WAL) |
| Keyring | File-based (`/etc/pg_tde/entaprenua.per`) |
| Encrypted tables | `store_customers` |
| Key provider | `entaprenua-keyring` |
| Principal key | `entaprenua-default-key` |

## Environments

| | Local | VPS |
|---|---|---|
| PG version | Percona PG 18.6.1 | Percona PG 18.6.1 |
| Previous PG | PostgreSQL 14.24 (upstream) | PostgreSQL 16.15 (upstream) |
| Keyring file | `/etc/pg_tde/entaprenua.per` | `/etc/pg_tde/entaprenua.per` |
| Backup location | `baks/pg-pre-tde-20260905/` | `/tmp/pg-backup/` |

## How it works

- `pg_tde` is a PostgreSQL extension that provides the `tde_heap` storage access method
- Data is encrypted on disk using AES-256; decryption happens transparently in memory
- No application code changes needed — JDBC, jOOQ, and Flyway work transparently
- WAL (write-ahead log) is also encrypted
- Temporary files and statistics are **not** encrypted (as of v2.2.2)

## Keyring configuration

### File-based keyring (current — local/dev)

```sql
-- Create file-based key provider
SELECT pg_tde_add_database_key_provider_file(
    'entaprenua-keyring',
    '/etc/pg_tde/entaprenua.per'
);

-- Create principal key
SELECT pg_tde_create_key_using_database_key_provider(
    'entaprenua-default-key',
    'entaprenua-keyring'
);

-- Set as default key
SELECT pg_tde_set_key_using_database_key_provider(
    'entaprenua-default-key',
    'entaprenua-keyring'
);
```

### Production: Vault / KMS

For production, use an external KMS (Vault, Fortanix, KMIP, etc.) instead of file-based keyring. See [Percona KMS docs](https://docs.percona.com/pg-tde/global-key-provider-configuration/overview.html).

## Encrypting a table

```sql
-- Set table to use tde_heap access method
ALTER TABLE store_customers SET ACCESS METHOD tde_heap;

-- Verify encryption
SELECT pg_tde_is_encrypted('store_customers');
-- Returns: t

-- Verify via table metadata
\d+ store_customers
-- Access method: tde_heap
```

## Verifying encryption status

```sql
-- Check a specific table
SELECT pg_tde_is_encrypted('store_customers');

-- Check all tables
SELECT
    schemaname,
    tablename,
    CASE WHEN am.amname = 'tde_heap' THEN 'ENCRYPTED' ELSE 'plain' END AS encryption
FROM pg_tables t
JOIN pg_class c ON c.relname = t.tablename
JOIN pg_am am ON am.oid = c.relam
WHERE t.schemaname = 'public'
ORDER BY encryption DESC, tablename;

-- Check key info
SELECT * FROM pg_tde_default_key_info();
```

## Installing pg_tde on a new environment

### Prerequisites

- Ubuntu 22.04+ or 24.04
- `wget`, `gnupg2`, `lsb-release`

### Step 1: Install Percona release tooling

```bash
cd /tmp
wget -q https://repo.percona.com/apt/percona-release_latest.generic_all.deb
sudo dpkg -i percona-release_latest.generic_all.deb
sudo percona-release enable-only ppg-18
sudo apt-get update
```

### Step 2: Remove upstream PostgreSQL

```bash
# Stop PostgreSQL
sudo systemctl stop postgresql

# Find installed version
pg_lsclusters

# Remove upstream packages (replace 14/16 with your version)
sudo apt-get remove -y postgresql-14 postgresql-client-14 postgresql postgresql-client postgresql-contrib
sudo apt-get autoremove -y
```

### Step 3: Install Percona PG 18 + pg_tde

```bash
sudo apt-get install -y \
    percona-postgresql-18 \
    percona-postgresql-client-18 \
    percona-postgresql-contrib \
    percona-pg-tde18
```

### Step 4: Create cluster

```bash
# Remove old cluster metadata
sudo pg_dropcluster <old-version> main --stop 2>/dev/null || true

# Create new cluster
sudo pg_createcluster 18 main --start -- -U postgres
```

### Step 5: Configure pg_tde

```bash
# Enable pg_tde in shared_preload_libraries
sudo su - postgres -c "psql -c \"ALTER SYSTEM SET shared_preload_libraries = 'pg_tde';\""

# Restart PostgreSQL
sudo systemctl restart postgresql

# Create extension in template1 (all new databases)
sudo su - postgres -c "psql -d template1 -c 'CREATE EXTENSION IF NOT EXISTS pg_tde;'"
```

### Step 6: Create user and databases

```bash
sudo su - postgres -c "psql -c \"CREATE USER nesh WITH PASSWORD '...' SUPERUSER;\""
sudo su - postgres -c "psql -c 'CREATE DATABASE entaprenua OWNER nesh;'"
sudo su - postgres -c "psql -c 'CREATE DATABASE gorse OWNER nesh;'"
sudo su - postgres -c "psql -d entaprenua -c 'CREATE EXTENSION IF NOT EXISTS citext;'"
sudo su - postgres -c "psql -d entaprenua -c 'CREATE EXTENSION IF NOT EXISTS ltree;'"
```

### Step 7: Restore data

```bash
pg_restore -U nesh -d entaprenua /path/to/entaprenua.dump
pg_restore -U nesh -d gorse /path/to/gorse.dump
```

### Step 8: Configure keyring and encrypt

```bash
# Create keyring directory
sudo mkdir -p /etc/pg_tde
sudo chmod 700 /etc/pg_tde
sudo chown postgres:postgres /etc/pg_tde

# Run SQL to set up keyring and encrypt tables
psql -U nesh -d entaprenua << 'EOF'
SELECT pg_tde_add_database_key_provider_file('entaprenua-keyring', '/etc/pg_tde/entaprenua.per');
SELECT pg_tde_create_key_using_database_key_provider('entaprenua-default-key', 'entaprenua-keyring');
SELECT pg_tde_set_key_using_database_key_provider('entaprenua-default-key', 'entaprenua-keyring');
ALTER TABLE store_customers SET ACCESS METHOD tde_heap;
EOF
```

## Upgrading from upstream PostgreSQL

The migration path is: upstream PG → Percona PG 18 (fresh install).

1. **Back up all databases** before starting
2. Remove upstream PostgreSQL packages
3. Install Percona PG 18 + pg_tde
4. Create new cluster (data directory is wiped)
5. Restore from backup

There is no in-place upgrade path from upstream to Percona — it's a clean install + restore.

## Backups

Backups were created before the migration:

- **Local**: `baks/pg-pre-tde-20260905/` contains `entaprenua.dump` (1.2M) and `gorse.dump` (5K)
- **VPS**: `/tmp/pg-backup/` contains `entaprenua.dump` (1.4M) and `gorse.dump` (9.5K)

To restore from backup:

```bash
pg_restore -U nesh -d entaprenua /path/to/entaprenua.dump
```

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `pg_tde_is_encrypted` returns `f` | Table not yet encrypted — run `ALTER TABLE ... SET ACCESS METHOD tde_heap` |
| `ERROR: access method "tde_heap" does not exist` | pg_tde not loaded — check `shared_preload_libraries = 'pg_tde'` and restart PG |
| `ERROR: permission denied for table ...` | User lacks privileges — ensure user is superuser or table owner |
| `FATAL: Peer authentication failed` | Using socket connection without correct user — use `-h localhost` for TCP auth |
| Keyring file not found | Check `/etc/pg_tde/entaprenua.per` exists and is owned by `postgres` |
| `pg_restore: error: ... schema_migrations` | Permission issue — restore as superuser or table owner |
| App can't connect after PG upgrade | Verify `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD` in `.env` match new PG config |

## References

- [Percona pg_tde docs](https://docs.percona.com/pg-tde/index.html)
- [pg_tde GitHub](https://github.com/percona/pg_tde)
- [Keyring file configuration](https://docs.percona.com/pg-tde/global-key-provider-configuration/keyring.html)
- [KMS configuration](https://docs.percona.com/pg-tde/global-key-provider-configuration/overview.html)
