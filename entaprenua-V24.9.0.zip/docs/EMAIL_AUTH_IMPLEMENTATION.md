# Email & Authentication Implementation Plan

**Status**: 📋 Planned  
**Last Updated**: 2026-04-01

---

## Overview

Production-ready email and authentication system:
- User registration (OAuth + Email/Password)
- Email validation (Abstract API - existing)
- Email sending (Resend - to implement)
- Team invitations
- Transactional emails (order confirmations)

---

## Current State

### Already Implemented ✅

| Feature | File | Status |
|---------|------|--------|
| Email verification columns | `V11__Add_email_verification.sql` | DB ready |
| Email validation (Abstract API) | `EmailValidationService.kt` | Working |
| Store members table | `V10__Add_store_members.sql` | Working |
| StoreMemberService | `StoreMemberService.kt` | Add existing users |
| Auth (OAuth + email/password) | `AuthServiceImpl.kt` | Complete |

### What's Missing ❌

| Feature | Priority |
|---------|----------|
| Email sending (Resend) | 1 - Foundation |
| Team invitation flow | 2 - Core feature |
| Order confirmation emails | 3 - E-commerce |

---

## Implementation

### Priority 1: Email Service (Resend)

**Files to create/modify:**

| File | Purpose |
|------|---------|
| `email/EmailService.kt` | Resend API client |
| `email/EmailTemplates.kt` | HTML email templates |
| `auth/EmailVerificationService.kt` | Update to use Resend |
| `application.properties` | Resend config |
| `ApiRouterConfig.kt` | Resend webhook route |

**Configuration:**
```properties
# application.properties
resend.api.key=${RESEND_API_KEY}
resend.webhook.secret=${RESEND_WEBHOOK_SECRET}
app.email.from=${EMAIL_FROM:noreply@entaprenua.com}
```

**Webhook handling:**
```
POST /webhooks/resend
  - email.bounced → Mark user email invalid
  - email.complained → Unsubscribe
```

### Priority 2: Team Invitations

**Database:**
```sql
-- V28: Store invitations
CREATE TABLE store_invitations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    email VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'editor',
    token VARCHAR(255) NOT NULL UNIQUE,
    status VARCHAR(20) DEFAULT 'PENDING',
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

CREATE INDEX idx_store_invitations_store ON store_invitations(store_id);
CREATE INDEX idx_store_invitations_token ON store_invitations(token);
CREATE INDEX idx_store_invitations_email ON store_invitations(email);
```

**API Endpoints:**

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/stores/{id}/invitations` | Create invitation |
| GET | `/api/v1/stores/{id}/invitations` | List pending |
| DELETE | `/api/v1/stores/{id}/invitations/{id}` | Cancel |
| POST | `/api/v1/invitations/{token}/accept` | Accept invitation |

**Flow:**

```
1. Admin enters email → POST /invitations
         ↓
2. Create invitation record + token
         ↓
3. Send invitation email (Resend)
         ↓
4. User clicks link → /invitations/{token}/accept
         ↓
5. IF logged in → Add to store_members
         ↓
6. IF not logged in → Redirect to register → Accept → Add
         ↓
7. Admin can revoke pending invitations
```

### Priority 3: Transactional Emails

**Email Types:**

| Email | Trigger | Priority |
|-------|---------|----------|
| Email verification | Register (email/password) | High |
| Team invitation | Admin invites member | High |
| Order confirmation | Checkout complete | High |
| Password reset | User requests | Medium |

---

## Security Considerations

1. **Token security**: 256-bit random tokens, hashed storage
2. **Invitation expiry**: 7 days
3. **Rate limiting**: Max 10 invitations/hour per store
4. **Email enumeration**: Generic responses for invite/create
5. **Bounce handling**: Mark accounts unverified on bounce

---

## Files to Create/Modify

```
runtime/src/main/kotlin/com/entaprenua/
├── email/
│   ├── EmailService.kt           # Resend API (NEW)
│   ├── EmailTemplates.kt          # HTML templates (NEW)
│   └── ResendWebhookHandler.kt   # Webhook handler (NEW)
├── auth/
│   └── impl/
│       └── EmailVerificationServiceImpl.kt # Use Resend (UPDATE)
└── store/
    └── services/
        └── InvitationService.kt   # Team invites (NEW)
```

---

## Implementation Order

| Step | Task | Files |
|------|------|-------|
| 1 | Resend service | `EmailService.kt` |
| 2 | Resend webhook | Route + handler |
| 3 | Email verification | Update existing |
| 4 | Invitations table | Migration |
| 5 | Invitation service | `InvitationService.kt` |
| 6 | Invite endpoints | Update router |
| 7 | Order confirmations | Trigger on checkout |

---

## NOT Overengineered

- **No**: Separate email validation service (Abstract API exists)
- **No**: Email queue/workers (Resend handles async)
- **No**: Complex template engine (Simple HTML strings)
- **No**: Multiple email providers (Resend only)
- **Yes**: Bounce webhook (Resend provides this)
- **Yes**: Invitation expiry (7 days, auto-cleanup)

---

## Related Documentation

- [VCS Integration](./VCS_SPRINGBOOT_IMPLEMENTATION.md)
- [VCS Clone](./VCS_CLONE_IMPLEMENTATION.md)