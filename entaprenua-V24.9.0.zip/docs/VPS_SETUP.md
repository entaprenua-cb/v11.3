# VPS Setup Guide

This guide explains how to set up a fresh VPS for the Entaprenua platform.

## Prerequisites

- A VPS with Ubuntu 22.04+ (recommended)
- SSH access to the VPS with a key at `~/.ssh/id_ed25519`
- A domain name configured with DNS pointing to the VPS IP

## Quick Start

### 1. Run the Setup Script

```bash
cd /home/nesh/repos/Applications/entaprenua

# Set environment variables (optional)
export VPS_HOST="your-vps-ip"
export VPS_USER="root"
export DOMAIN="your-domain.com"
export ADMIN_EMAIL="admin@your-domain.com"

# Run the setup script
./scripts/setup-vps.sh
```

### 2. Add GitHub SSH Key

During setup, a public key will be displayed. Add it to your GitHub organization:

1. Go to GitHub → Organization → Settings → SSH and GPG Keys
2. Click "New SSH Key"
3. Paste the public key from the setup output

### 3. Configure Cloudflare DNS

**Recommended**: Use Cloudflare for free automatic wildcard SSL.

See [Cloudflare Setup Guide](CLOUDFLARE_SETUP.md) for detailed steps.

**Quick Summary**:
1. Create free Cloudflare account
2. Add `your-domain.com`
3. Set all DNS records to **DNS Only** (grey cloud)
4. Update nameservers at your registrar (Hostinger)
5. Wait for DNS propagation (1-24 hours)
6. Set SSL/TLS mode to `Full` in Cloudflare

**Note**: With Cloudflare, you **do not need certbot**. Cloudflare handles all SSL certificates automatically.

### 4. Deploy the Backend

```bash
./scripts/deploy-backend.sh
```

---

## What the Setup Script Installs

| Component | Version | Purpose |
|-----------|---------|---------|
| Java JDK | 21.0.2 | Runtime for Spring Boot |
| Gradle | 8.6 | Build tool for backend |
| Node.js | 20 LTS | SolidStart builder & store processes |
| PostgreSQL | 18 (Percona) | Primary database with pg_tde TDE |
| Redis | Latest | Cache for subdomain routing |
| OpenResty | Latest | Nginx + Lua for subdomain routing |
| Certbot | Latest | SSL certificate management |

---

## Manual Setup (Alternative)

If you prefer to set up manually, here's what you need:

### System Packages

```bash
apt-get update
apt-get install -y \
    curl wget git vim htop net-tools unzip zip \
    ca-certificates gnupg2 lsb-release software-properties-common
```

### Java JDK 21

```bash
cd /tmp
wget https://download.java.net/java/GA/jdk21.0.2/f2283984656d49d69e91c558476027ac/13/GPL/openjdk-21.0.2_linux-x64_bin.tar.gz
tar -xzf openjdk-21.0.2_linux-x64_bin.tar.gz
mv jdk-21.0.2 /usr/local/jdk-21.0.2
update-alternatives --install /usr/bin/java java /usr/local/jdk-21.0.2/bin/java 100
```

### Gradle 8.6

```bash
cd /tmp
wget https://services.gradle.org/distributions/gradle-8.6-bin.zip
unzip gradle-8.6-bin.zip
mv gradle-8.6 /usr/local/gradle-8.6
ln -s /usr/local/gradle-8.6/bin/gradle /usr/local/bin/gradle
```

### Node.js 20

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs
npm install -g yarn
```

### PostgreSQL 18 (Percona with pg_tde)

```bash
# Install Percona release tooling
cd /tmp
wget -q https://repo.percona.com/apt/percona-release_latest.generic_all.deb
dpkg -i percona-release_latest.generic_all.deb
percona-release enable-only ppg-18
apt-get update

# Install Percona PG 18 + pg_tde
apt-get install -y percona-postgresql-18 percona-postgresql-client-18 percona-postgresql-contrib percona-pg-tde18

# Create cluster
pg_createcluster 18 main --start -- -U postgres

# Enable pg_tde
su - postgres -c "psql -c \"ALTER SYSTEM SET shared_preload_libraries = 'pg_tde';\""
systemctl restart postgresql
su - postgres -c "psql -d template1 -c 'CREATE EXTENSION IF NOT EXISTS pg_tde;'"

# Create database
su - postgres
psql -c "CREATE USER nesh WITH PASSWORD '...' SUPERUSER;"
psql -c "CREATE DATABASE entaprenua OWNER nesh;"
psql -d entaprenua -c "CREATE EXTENSION IF NOT EXISTS citext;"
psql -d entaprenua -c "CREATE EXTENSION IF NOT EXISTS ltree;"
```

See [TDE_SETUP.md](TDE_SETUP.md) for full pg_tde configuration and encryption steps.

### Redis

```bash
apt-get install -y redis-server
systemctl start redis-server
systemctl enable redis-server
```

### OpenResty

```bash
apt-get install -y curl gnupg2 ca-certificates lsb-release
wget -qO - https://openresty.org/package/pubkey.gpg | apt-key add -
echo "deb http://openresty.org/package/ubuntu $(lsb_release -sc) main" | tee /etc/apt/sources.list.d/openresty.list
apt-get update
apt-get install -y openresty
systemctl enable openresty
systemctl start openresty
```

### OpenResty Configuration

Edit `/usr/local/openresty/nginx/conf/nginx.conf`:

```nginx
# At the TOP of the file (before events block)
env REDIS_HOST;
env REDIS_PORT;
env REDIS_AUTH;
env REDIS_KEY_PREFIX;

# In the http block, after mime.types include
lua_package_path '/usr/local/openresty/lualib/?.lua;;/etc/nginx/lua/?.lua;;';
include /etc/nginx/sites-enabled/*;
```

### SSL Certificates (Cloudflare Recommended)

**Recommended**: Use Cloudflare for automatic wildcard SSL (see [Cloudflare Setup Guide](CLOUDFLARE_SETUP.md)).

Alternative (certbot - requires manual DNS challenge for wildcard):

```bash
apt-get install -y certbot python3-certbot-nginx

# For standard cert (entaprenua.com + www)
certbot --nginx -d your-domain.com -d www.your-domain.com

# For wildcard (requires DNS TXT record)
certbot certonly --manual -d "*.your-domain.com" -d "your-domain.com" --preferred-challenges dns
```

### GitHub SSH Key

```bash
ssh-keygen -t ed25519 -C "automation@entaprenua" -f ~/.ssh/github_automation -N ""
git config --global url."git@github.com:".insteadOf "https://github.com/"
# Add ~/.ssh/github_automation.pub to GitHub organization
```

---

## Directory Structure

```
/opt/entaprenua/
├── backend/           # Spring Boot application
│   └── entaprenua.jar
│
/var/lib/entaprenua/
├── stores/            # Deployed store files
├── platform/          # Platform repository
└── temp/              # Build temp files
```

---

## Environment Variables

The backend requires these environment variables in `/home/nesh/.env`:

```bash
# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=entaprenua
DB_USER=mnesh
DB_PASSWORD=martoh1996

# Redis
REDIS_HOST=127.0.0.1
REDIS_PORT=6379
REDIS_PASSWORD=

# Security
APP_SECURITY_JWT_SECRET=your-secret-key

# VCS
VCS_GITHUB_ORG=your-github-org
GITHUB_PAT_TOKEN=ghp_your_token
```

---

## Troubleshooting

### PostgreSQL Connection Failed

```bash
# Check PostgreSQL status
systemctl status postgresql

# Check if listening
ss -tlnp | grep 5432

# Check logs
tail -f /var/log/postgresql/postgresql-*-main.log
```

### Redis Connection Failed

```bash
# Check Redis status
systemctl status redis-server

# Test connection
redis-cli ping

# Check config
cat /etc/redis/redis.conf | grep bind
```

### OpenResty Not Starting

```bash
# Check configuration
/usr/local/openresty/nginx/sbin/nginx -t

# Check error logs
tail -f /usr/local/openresty/nginx/logs/error.log

# View full config
/usr/local/openresty/nginx/sbin/nginx -T
```

### SSL Certificate Issues

```bash
# Check certificates
certbot certificates

# Renew certificates
certbot renew

# Test renewal
certbot renew --dry-run
```

### GitHub SSH Not Working

```bash
# Test SSH connection
ssh -T git@github.com

# Add GitHub to known hosts
ssh-keyscan -t rsa,ed25519,ecdsa github.com >> ~/.ssh/known_hosts
```
