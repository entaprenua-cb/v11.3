# Research: Storefront Customer Registration Architecture

## Overview
This document compares how major e-commerce platforms handle storefront customer registration and data storage in multi-tenant environments.

## Platform Comparisons

### 1. Shopify

**Architecture:** Per-store customer IDs

| Aspect | Approach |
|--------|----------|
| User Table | Separate customer tables per store |
| Customer ID | Unique per store (Store A customer #1 ≠ Store B customer #1) |
| Authentication | Separate OAuth 2.0 Customer Account API |
| Login | Passwordless (email magic links) |
| Verification | Email verification required |

**Key Features:**
- Customer Account API (GraphQL)
- Separate authentication from admin
- Data scoped per store and customer
- No shared user IDs across stores

**Documentation:** [Shopify Customer Account API](https://shopify.dev/docs/storefronts/headless/building-with-the-customer-account-api)

---

### 2. WooCommerce (WordPress)

**Architecture:** Per-installation users

| Aspect | Approach |
|--------|----------|
| User Table | WordPress `wp_users` table |
| Customer Data | `wp_usermeta` with customer fields |
| Multi-store | Not natively supported |
| Authentication | WordPress user system |

**Key Features:**
- Deeply integrated with WordPress
- Customer data stored in user meta
- For multi-store: separate WordPress installations required
- Uses WordPress authentication

**Documentation:** [WooCommerce Customer Database](https://usersinsights.com/woocommerce-customer-database)

---

### 3. Magento (Adobe Commerce)

**Architecture:** Single table with website scope

| Aspect | Approach |
|--------|----------|
| User Table | Single `customer_entity` table |
| Customer ID | Global (same ID across websites) |
| Scope | Customers scoped by website/store |
| Customer Groups | Different per store |

**Key Features:**
- Single customer entity table
- Customers can belong to multiple websites
- Different attributes per website/store
- Shared login across websites (configurable)

**Key Insight:** Uses join/attribute tables to scope customer data per store rather than separate customer IDs.

---

### 4. BigCommerce

**Architecture:** Per-channel customer IDs

| Aspect | Approach |
|--------|----------|
| User Table | Separate customer records per channel |
| Customer ID | Unique per storefront/channel |
| Same Email | Can exist on different storefronts with separate records |
| Login | Shared across storefronts |

**Key Features:**
- Multi-storefront support
- GraphQL Storefront API for customers
- Customer IDs are channel-specific
- Same email can have different customer records per storefront

---

## Architecture Patterns Summary

| Pattern | Platforms | Description |
|---------|-----------|-------------|
| **Standalone Table** | Shopify, BigCommerce | Customer records unique per store |
| **Join Table** | Custom platforms, Magento | Global users + link to stores |
| **Website Scope** | Magento | Single table, scoped by website |
| **Separate DBs** | WooCommerce (multi-site) | Complete isolation per store |

---

## Our Platform Decision: Standalone Store Customers Table

### Why Standalone Table?

1. **Different passwords per store**: Same email can have different passwords in different stores
2. **Store-specific control**: Each store owns their customer data
3. **Independent verification**: Each store can customize their verification flow
4. **Industry-aligned**: Similar to Shopify and BigCommerce approach

---

### Database Design

#### 1. Users Table (Platform) - Add/Update Fields

```sql
ALTER TABLE users ADD COLUMN user_type VARCHAR(20) DEFAULT 'PLATFORM';
ALTER TABLE users ADD COLUMN phone VARCHAR(50);
-- Platform users: store owners, admins
-- user_type values: 'PLATFORM' (default), 'CUSTOMER'
```

#### 2. Store Customers Table (NEW)

```sql
CREATE TABLE store_customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id UUID NOT NULL REFERENCES stores(id),
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR,
    name VARCHAR(255),
    phone VARCHAR(50),
    identity_provider VARCHAR(20) DEFAULT 'LOCAL',
    email_verified BOOLEAN DEFAULT false,
    verification_token UUID,
    verification_expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    UNIQUE(store_id, email)
);

CREATE INDEX idx_store_customers_store_id ON store_customers(store_id);
CREATE INDEX idx_store_customers_email ON store_customers(email);
```

#### 3. Stores Table - Remove & Add Columns

**Remove:**
- `logo` column
- `favicon` column

**Add:**

| Column | Type | Default | Description |
|--------|------|---------|-------------|
| `verificationRedirectUrl` | VARCHAR(500) | null | Custom verification URL |
| `verificationEmailSubject` | VARCHAR(200) | "Verify your account" | Email subject line |
| `verificationSuccessRedirectUrl` | VARCHAR(500) | null | Post-verification redirect |
| `verificationSenderName` | VARCHAR(100) | "Store Team" | "From:" display name |
| `verificationSenderEmail` | VARCHAR(255) | null | From email (from verified domain) |
| `verificationEmailTemplate` | TEXT | platform default | Custom HTML template |
| `verificationExpiryHours` | INT | 24 | Token validity hours |

---

### Verification Email Template

Store owners provide custom HTML. We dynamically replace:

| Placeholder | Description |
|-------------|-------------|
| `{customer_email}` | Customer's email address |
| `{verification_link}` | Full verification URL with token |

**Example template:**
```html
<!DOCTYPE html>
<html>
<head>
    <title>Verify your account</title>
</head>
<body>
    <h1>Welcome to MyStore!</h1>
    <p>Hi,</p>
    <p>Please verify your email: {customer_email}</p>
    <a href="{verification_link}">Click here to verify</a>
    <p>This link expires in 24 hours.</p>
</body>
</html>
```

---

### Authentication Providers

Both platform users and store customers support:

| Provider | Value | Description |
|----------|-------|-------------|
| Local | `LOCAL` | Email/password (default) |
| Google OAuth | `GOOGLE` | Google OAuth login |
| GitHub OAuth | `GITHUB` | GitHub OAuth login |

---

### API Endpoints (Proposed)

#### Platform Auth (Existing)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/auth/register` | Platform user registration |
| POST | `/api/v1/auth/login` | Platform user login |
| GET | `/api/v1/auth/verify-email` | Verify email |

#### Storefront Customer Auth (NEW)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/stores/{storeId}/customers/register` | Customer registers on storefront |
| GET | `/api/v1/stores/{storeId}/customers/verify` | Verify email + create customer |
| POST | `/api/v1/stores/{storeId}/customers/login` | Customer login (store-specific) |
| GET | `/api/v1/stores/{storeId}/customers/me` | Get current customer |
| POST | `/api/v1/stores/{storeId}/customers/logout` | Customer logout |

---

### Login Separation

- Platform login (`POST /api/v1/auth/login`) → Platform users (user_type = PLATFORM)
- Storefront login (`POST /api/v1/stores/{id}/customers/login`) → Store customers (stored in store_customers)

---

### Analytics

Analytics (total orders, total spent, last order) retrieved dynamically from orders table, not stored in store_customers.

---

## Implementation Status

- [x] Research completed
- [ ] Implementation pending

---

## References

- [Shopify Customer Account API](https://shopify.dev/docs/storefronts/headless/building-with-the-customer-account-api)
- [BigCommerce Multi-Storefront](https://developer.bigcommerce.com/docs/storefront/multi-storefront)
- [Magento Customer Architecture](https://developer.adobe.com/commerce/php/architecture/)
- [WooCommerce User Data](https://usersinsights.com/woocommerce-customer-database)
- [Multi-Tenant Database Patterns](https://snow.dog/blog/multi-tenant-database-architecture-for-multi-store-ecommerce-platforms)