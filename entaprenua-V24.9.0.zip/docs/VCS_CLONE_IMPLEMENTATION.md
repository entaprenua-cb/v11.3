# VCS Clone Implementation

**Status**: ✅ Implemented & Fixed
**Last Updated**: 2026-04-07

## Related

- [Templates](../templates/) - Pre-built templates for cloning
- [Platform Repo](https://github.com/entaprenua/platform) - Protected platform code
- [Basic Template](https://github.com/entaprenua/basic-template) - Basic storefront template

## Overview

VCS clone functionality for cloning a template to create a new store via admin API.

## Clone Flow

```
1. POST /api/v1/templates/{id}/clone { "storeName": "My Store" }
           │
           ▼
2. Create GitHub repository via GitHub API (platform-owned)
           │
           ▼
3. Save store record with repository_url
           │
           ▼
4. Background task:
   a. Clone template repository (via JGit + SSH)
   b. Read platform-version.json → version
   c. Clone entaprenua/platform @ {version}
   d. Merge template files into platform
   e. Push to target repo (via JGit + SSH)
   f. Register webhook (fails locally, works in production)
   g. Create VCS connection record
   h. Queue initial build
```

## API Endpoints

### Template Management (Admin)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/templates` | Create a new template |
| GET | `/api/v1/templates` | List all templates |
| GET | `/api/v1/templates/{id}` | Get template by ID |
| POST | `/api/v1/templates/{id}/clone` | Clone template to create new store |

### Authentication

Admin endpoints use **Basic Authentication**:
```bash
curl -u "admin:changeme123" ...
```

### Create Template

```json
POST /api/v1/templates
{
  "name": "Basic Template",
  "slug": "basic-template",
  "description": "Basic storefront template",
  "repositoryUrl": "https://github.com/entaprenua/basic-template"
}
```

### Clone Template

```json
POST /api/v1/templates/{template-id}/clone
{
  "storeName": "My New Store"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "...",
    "name": "My New Store",
    "publicId": "st_...",
    "repositoryUrl": "https://github.com/entaprenua/store-st_xxx-my-new-store.git",
    ...
  }
}
```

## Protected Files (from platform repo)

These are excluded from template source files during merge:
- `src/components/ui/*` - Platform UI components
- `src/lib/*` - Platform lib
- `package.json` / `package-lock.json` - Dependencies
- `node_modules` - Generated on npm install
- `.output` - Generated on npm build

## Implementation Details

### Build Output Deployment

After build completes, output is deployed directly to the store directory:
```
/var/lib/entaprenua/stores/{storeId}/
├── nitro.json
├── public/
├── server/
└── ...
```

The `.output/` wrapper is flattened — files are copied directly into the store directory. The store can be started with: `node server/index.mjs`

### Null Byte Sanitization

Process output (npm install/build) can contain null bytes which PostgreSQL rejects in UTF-8 text columns. The `readLinesSanitized()` extension strips nulls using the Unicode Replacement Character (`\uFFFD`):

```kotlin
private fun BufferedReader.readLinesSanitized(): Sequence<String> =
    lineSequence().map { it.replace("\u0000", "\uFFFD") }
```

This is applied to all npm process output captured in build logs.

### Repository Pattern (Flow)

The VCS repositories use `Flow` (via `.asFlow()`) for consistency with the rest of the codebase:

```kotlin
fun findByConnectionId(connectionId: UUID, limit: Int = 20): Flow<VcsBuild> {
    return dsl.selectFrom(table)
        .where(table.VCS_CONNECTION_ID.eq(connectionId))
        .orderBy(table.BUILD_NUMBER.desc())
        .limit(limit)
        .asFlow()
        .map { it.mapToBuild() }
}
```

Call sites use `.toList()` at the service layer to convert to `List`.

### JGit Configuration

- Uses JGit 7.6.0 with Apache SSH transport
- SSH key: `~/.ssh/github_automation`
- Clones via SSH (`git@github.com:...`) instead of HTTPS
- Supports both SSH and HTTPS transports automatically

### Key Files

| File | Changes |
|------|---------|
| `vcs/dtos/VcsDtos.kt` | Added CloneTemplateRequest, PlatformVersion |
| `vcs/services/VcsService.kt` | Added cloneTemplate method |
| `vcs/services/BuildQueueService.kt` | Clone/push, build pipeline, log sanitization |
| `vcs/services/JGitService.kt` | Created - JGit wrapper for SSH git operations |
| `vcs/services/VcsHandlers.kt` | Added VcsCloneService interface |
| `vcs/services/VcsHandlerServices.kt` | Added VcsCloneServiceImpl |
| `vcs/repositories/VcsBuildRepository.kt` | Flow-based queries with `.asFlow()` |
| `vcs/repositories/VcsConnectionRepository.kt` | Flow-based queries with `.asFlow()` |
| `config/AdminAuthFilter.kt` | Created - Basic auth for admin endpoints |
| `build.gradle.kts` | Added JGit dependencies |
| `db/migration/V38__add_store_repository_url.sql` | Added repository_url column |

## Error Handling

- Clone/push failures are logged but don't fail the API response
- Store is created in database even if clone/push fails
- Webhook registration failures are gracefully handled (fails locally, works in production)

## Development Notes

### Local Development Limitation
- Webhook registration fails because GitHub cannot reach localhost
- In production with a public URL, webhooks will work automatically
- Build can be triggered manually via VCS connection API

### SSH Setup Required
```bash
# Generate SSH key (if not exists)
ssh-keygen -t ed25519 -C "automation@entaprenua" -f ~/.ssh/github_automation -N ""

# Add public key to GitHub: Settings → SSH Keys

# Test connection
ssh -T git@github.com
```

### Environment Variables
```bash
# GitHub PAT (for API operations)
GITHUB_PAT_TOKEN=ghp_...

# GitHub Organization/User for VCS
VCS_GITHUB_ORG=entaprenua

# App base URL (for webhooks in production)
APP_BASE_URL=https://your-production-domain.com
```