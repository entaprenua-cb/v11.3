# Storefront Nginx Dynamic Routing Setup

**Last Updated**: 2026-04-05

---

## Overview

The storefront routing system uses **OpenResty (Nginx + Lua)** with **Redis** for dynamic domain-to-port mapping. Each store runs as an independent Node.js process, and Nginx routes requests based on the subdomain.

---

## Prerequisites

| Requirement | Version | Purpose |
|-------------|---------|---------|
| OpenResty | Latest | Dynamic routing via Lua |
| Redis | 6.x+ | Store port cache |
| Spring Boot | 3.x | API + Process Manager |
| SSL Certificates | - | For HTTPS (production) |

---

## Automatic Installation (via deploy-backend.sh)

The `deploy-backend.sh` script automatically installs and configures OpenResty:

```bash
# Run deployment
./scripts/deploy-backend.sh
```

The script will:
1. Install OpenResty if not present
2. Read Redis config from `.env` (REDIS_HOST, REDIS_PORT, REDIS_PASSWORD)
3. Configure OpenResty environment variables
4. Upload Lua scripts to `/etc/nginx/lua/`
5. Reload OpenResty

---

## Manual Installation (if needed)

### 1. Install OpenResty

```bash
# Ubuntu/Debian
wget -qO - https://openresty.org/package/pubkey.gpg | sudo apt-key add -
sudo add-apt-repository -y "deb http://openresty.org/package/ubuntu $(lsb_release -sc) main"
sudo apt-get update
sudo apt-get install -y openresty

# Stop and disable regular nginx
systemctl stop nginx && systemctl disable nginx
systemctl enable openresty && systemctl start openresty
```

### 2. Configure Redis

```conf
# /etc/redis/redis.conf
bind 127.0.0.1
requirepass your_secure_password_here
maxmemory 256mb
maxmemory-policy allkeys-lru
```

```bash
sudo systemctl restart redis-server
redis-cli -a your_password ping  # Should return PONG
```

### 3. Set Environment Variables

The deploy script reads from `.env`. For manual setup:

```bash
# Create OpenResty env file
sudo mkdir -p /etc/openresty

cat > /etc/openresty/env.conf << EOF
REDIS_HOST=127.0.0.1
REDIS_PORT=6379
REDIS_AUTH=your_password
EOF

# Create systemd override
mkdir -p /etc/systemd/system/openresty.service.d
cat > /etc/systemd/system/openresty.service.d/env.conf << EOF
[Service]
EnvironmentFile=/etc/openresty/env.conf
EOF

systemctl daemon-reload && systemctl restart openresty
```

### 4. Install Lua Scripts

```bash
sudo mkdir -p /etc/nginx/lua
sudo cp scripts/storefront/redis-helpers.lua /etc/nginx/lua/
sudo cp scripts/storefront/storefront-lookup.lua /etc/nginx/lua/
sudo chmod 644 /etc/nginx/lua/*.lua
```

---

## Configuration Files

| File | Source | Destination | Purpose |
|------|--------|-------------|---------|
| `nginx-entaprenua.conf` | `scripts/` | `/etc/nginx/sites-available/entaprenua` | Main config |
| `storefront-lookup.lua` | `scripts/storefront/` | `/etc/nginx/lua/` | Domain lookup |
| `redis-helpers.lua` | `scripts/storefront/` | `/etc/nginx/lua/` | Redis utilities |
| `env.conf` | Auto-generated | `/etc/openresty/env.conf` | Environment vars |

---

## Redis Configuration (from .env)

The Lua scripts read Redis config from environment variables:

```bash
# .env file should contain:
REDIS_HOST=127.0.0.1
REDIS_PORT=6379
REDIS_PASSWORD=your_secure_password
```

---

## Routing Flow

```
Request: mystore.entaprenua.com
         │
         ▼
   Nginx extracts "mystore"
         │
         ▼
   Lua: Redis GET storefront:mystore
         │
    ┌────┴────┐
    │         │
  Found    Not Found
    │         │
    ▼         ▼
  Proxy    502 Bad Gateway
to port
```

---

## Testing

### Test Redis Connection

```bash
redis-cli -a your_password ping
# Expected: PONG
```

### Test Store Lookup

```bash
# Manually set a store
redis-cli -a your_password SET storefront:teststore 3001

# Test routing
curl -H "Host: teststore.entaprenua.com" http://127.0.0.1/
```

### Check OpenResty Logs

```bash
# View error logs
tail -f /var/log/nginx/error.log

# Test config
/usr/local/openresty/nginx/sbin/nginx -t
```

---

## Common Issues

| Issue | Solution |
|-------|----------|
| 502 Bad Gateway | Store not started - check Spring Boot process manager |
| 503 Service Unavailable | Redis down or wrong password |
| Lua errors | Check `/etc/nginx/lua/` scripts exist |
| SSL errors | Run certbot to generate certificates |

---

## Security Checklist

- [x] Redis password required
- [x] Redis bound to 127.0.0.1 only
- [x] Environment variables via systemd (not exposed)
- [ ] SSL certificates configured
- [ ] Firewall: only 80/443 open

---

## Related Documentation

- [STOREFRONT_NGINX_ROUTING.md](./STOREFRONT_NGINX_ROUTING.md) - Architecture
- [STOREFRONT.md](./STOREFRONT.md) - Storefront overview
- [CACHING.md](./CACHING.md) - Redis caching strategy
