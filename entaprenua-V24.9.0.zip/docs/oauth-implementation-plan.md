# OAuth Implementation Plan

## Overview
Implement OAuth authentication for:
- **Platform (Admin)**: Google, GitHub
- **Storefront (Customers)**: Google, Facebook

## OAuth Redirect Flow

### Convention
The OAuth redirect follows the industry standard pattern:

1. **One fixed callback URL** registered with all OAuth providers:
   - Platform: `https://entaprenua.com/api/v1/auth/oauth/{provider}/callback`
   - Storefront: `https://entaprenua.com/api/v1/stores/{storeId}/customers/oauth/{provider}/callback`

2. **State parameter** carries context (store ID, action type) - encoded in OAuth state

3. **Post-auth redirect** - After successful OAuth, redirect to store's preferred page:
   - Uses existing `verificationSuccessRedirectUrl` setting from store
   - Falls back to `/signup` or `/account` if not configured

This approach is consistent across all providers (Google, Facebook, GitHub).

### Post-Auth Redirect Logic

The `verificationSuccessRedirectUrl` setting from store settings controls where users land after OAuth:

| User Input | Result |
|------------|--------|
| `https://mystore.com/signup` | `https://mystore.com/signup` (use as-is) |
| `mystore.com/signup` | `mystore.com/signup` (use as-is - user's responsibility) |
| `/signup` | `mystore.entaprenua.com/signup` (prepend store domain) |
| (empty) | `mystore.entaprenua.com/signup` (fallback to /signup) |

**Logic:**
- If input starts with `http://` or `https://` → use as-is
- Otherwise → prepend store domain (custom domain > subdomain.entaprenua.com > domainName > baseUrl)

Note: User is responsible for providing valid URLs. The system trusts the user input.

## Current State

| Provider | Platform | Storefront |
|----------|----------|------------|
| Google | ✅ Implemented | ✅ Implemented |
| GitHub | ✅ Implemented | ❌ N/A |
| Facebook | ✅ Added | ✅ Implemented |
| Apple | ❌ Not implemented | ❌ Not implemented |

## Implementation Steps

### Step 1: Add Configuration

**File:** `runtime/src/main/resources/application.properties`

```properties
# Google OAuth (both platform & storefront)
app.oauth.google.client-id=${GOOGLE_CLIENT_ID:}
app.oauth.google.client-secret=${GOOGLE_CLIENT_SECRET:}
app.oauth.google.redirect-uri=${GOOGLE_REDIRECT_URI:http://localhost:8080/api/v1/auth/oauth/google/callback}

# GitHub OAuth (platform only)
app.oauth.github.client-id=${GITHUB_CLIENT_ID:}
app.oauth.github.client-secret=${GITHUB_CLIENT_SECRET:}
app.oauth.github.redirect-uri=${GITHUB_REDIRECT_URI:http://localhost:8080/api/v1/auth/oauth/github/callback}

# Facebook OAuth (storefront only)
app.oauth.facebook.client-id=${FACEBOOK_CLIENT_ID:}
app.oauth.facebook.client-secret=${FACEBOOK_CLIENT_SECRET:}
app.oauth.facebook.redirect-uri=${FACEBOOK_REDIRECT_URI:http://localhost:8080/api/v1/auth/oauth/facebook/callback}
```

### Step 2: Fix Existing OAuthServiceImpl Issues

**Status:** ✅ Completed

- Replaced inconsistent `error()` calls with `apiBadRequest()`, `apiError()`, etc.
- Removed unused `error()` helper function
- Consistent with AuthServiceImpl pattern

### Step 3: Add Facebook Provider

**Status:** ✅ Completed

- Created `FacebookProvider` class
- Added to OAuthServiceImpl
- Added bean in AuthConfig
- Added configuration in application.properties

### Step 4: Add Apple Provider (FUTURE)

**Status:** Not started - deferred

See "Future Implementations" section at bottom.

### Step 5: Add Storefront OAuth Endpoints

**Status:** ✅ Completed

- Added OAuth methods to StorefrontAuthService interface
- Implemented OAuth methods in StorefrontAuthServiceImpl
- Added routes in ApiRouterConfig
- Added avatar_url column to store_customers table (V34 migration)

**Endpoints:**
```
POST /api/v1/stores/{storeId}/customers/oauth/{provider}     # Get OAuth URL
GET  /api/v1/stores/{storeId}/customers/oauth/{provider}/callback  # Handle callback
```

**File:** `runtime/src/main/kotlin/com/entaprenua/config/ApiRouterConfig.kt`

```
# Storefront OAuth (for customer registration)
POST /api/v1/stores/{storeId}/customers/oauth/{provider}     # Get OAuth URL
GET  /api/v1/stores/{storeId}/customers/oauth/{provider}/callback  # Handle callback
```

**Files to modify:**
- `StorefrontAuthService.kt` - Add interface methods
- `StorefrontAuthServiceImpl.kt` - Implement OAuth for customers
- `ApiRouterConfig.kt` - Add routes

### Step 6: Create Storefront-Specific OAuth Service

**New File:** `runtime/src/main/kotlin/com/entaprenua/store/services/StorefrontOAuthService.kt`

- Similar to OAuthService but for storefront customers
- Links customer to store during OAuth flow
- Can customize based on store settings

## API Endpoints Summary

### Platform (Admin)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/auth/oauth/{provider}` | Get OAuth URL |
| GET | `/api/v1/auth/oauth/{provider}/callback` | Handle OAuth callback |

### Storefront (Customers)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/stores/{storeId}/customers/oauth/{provider}` | Get OAuth URL |
| GET | `/api/v1/stores/{storeId}/customers/oauth/{provider}/callback` | Handle OAuth callback |

## Credentials Needed

Before testing, obtain credentials from:

| Provider | URL |
|----------|-----|
| Google | https://console.cloud.google.com/apis/credentials |
| GitHub | https://github.com/settings/developers |
| Facebook | https://developers.facebook.com/apps |
| Apple | https://developer.apple.com/account/resources/identifiers/list |

## Testing Checklist

- [ ] Test Google OAuth on platform
- [ ] Test GitHub OAuth on platform
- [ ] Test Google OAuth on storefront
- [ ] Test Facebook OAuth on storefront
- [ ] Test Apple OAuth on storefront (if implemented)
- [ ] Verify token refresh works
- [ ] Verify error handling for declined permissions

## Notes

- GitHub is for platform users (developers building stores)
- Google/Facebook are for storefront customers
- All OAuth flows should handle the case where user denies permission
- Storefront OAuth should associate the new customer with the store

## Future Implementations

### Apple Sign In (Deferred)

Apple Sign In is more complex because it's not standard OAuth 2.0:
- Uses JWT-based authentication
- Requires generating signed JWTs with private key
- Requires Apple Developer Program membership
- More strict review process for App Store

**To implement later:**
1. Create AppleProvider class with JWT signing
2. Add Apple configuration to application.properties
3. Add Apple to storefront OAuth endpoints
