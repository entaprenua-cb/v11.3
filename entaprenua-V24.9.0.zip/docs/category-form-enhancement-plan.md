# Category Form Enhancement Plan

## Overview
Improve the category form with missing fields and production-ready pagination.

## Part 1: Missing Fields

### 1.1 Add `slug` Field ✅
- **File:** `src/routes/admin/categories/sections/CategoryBasicInfoSection.tsx`
- Add text input for slug (optional, auto-generated if empty)
- Add label: "URL Slug" with helper text
- Auto-generate from name if empty (handled by backend)

### 1.2 Add `parentId` Field ✅
- **File:** `src/routes/admin/categories/sections/CategoryBasicInfoSection.tsx`
- Add dropdown/select for parent category
- Filter options:
  - Exclude current category
  - Exclude children of current category (prevent circular)
  - Only show categories of appropriate level (if level 1, can have level 2 parents)

### 1.3 Update Types ✅
- **File:** `src/routes/admin/categories/category-editor-context.tsx`
- Update `CategoryFormData` type to include:
  ```typescript
  type CategoryFormData = {
    name: string
    slug: string  // NEW
    level: number | null
    parentId: string | null  // NEW
    visibility: "public" | "private" | "draft"
    image: string | null
  }
  ```

### 1.4 Update Save Function ✅
- **File:** `src/routes/admin/categories/category-editor-context.tsx`
- Include `slug` and `parentId` in categoryData

---

## Part 2: Load More Pagination

### 2.1 Subcategories Section ✅
- **File:** `src/routes/admin/categories/sections/CategorySubcategoriesSection.tsx`
- Changes:
  - Add `page` and `hasMore` state
  - Initial load: page 0, size 20
  - Display total count: "Showing X of Y subcategories"
  - "Load More" button when hasMore is true
  - Keep existing search functionality
  - Loading state for Load More button

### 2.2 Products Section ✅
- **File:** `src/routes/admin/categories/sections/CategoryProductsSection.tsx`
- Same pattern as subcategories
- Changes:
  - Add `page` and `hasMore` state
  - Initial load: page 0, size 20
  - Display total count: "Showing X of Y products"
  - "Load More" button when hasMore is true
  - Keep existing search functionality
  - Loading state for Load More button

### 2.3 Implement Product Mapping Diff ✅
- **File:** `src/routes/admin/categories/category-editor-context.tsx`
- Added `initialProductIds` signal to track original product IDs
- Added `setInitialProducts` function for CategoryProductsSection to call
- Computes addedProducts and removedProducts diff on save
- CategoryProductsSection calls `setInitialProducts(mappedIds)` on initial load

---

## Part 3: UI Improvements

### 3.1 Production-Ready Components ✅
- Add proper loading spinners
- Add empty states with helpful messages
- Add disabled states for buttons
- Add aria-labels for accessibility
- Add keyboard navigation support

### 3.2 Consistent Styling ✅
- Match existing UI patterns
- Use proper spacing and layout
- Mobile-responsive design

---

## Implementation Order

1. Update `CategoryFormData` type in context ✅
2. Add slug and parentId to `CategoryBasicInfoSection` ✅
3. Update save function to handle new fields ✅
4. Implement Load More in `CategorySubcategoriesSection` ✅
5. Implement Load More in `CategoryProductsSection` ✅
6. Implement product mapping diff ✅
7. Test all functionality

---

## Files Modified

| File | Changes |
|------|---------|
| `category-editor-context.tsx` | Types, save logic, product diff, initialProductIds |
| `CategoryBasicInfoSection.tsx` | Add slug, parentId fields |
| `CategorySubcategoriesSection.tsx` | Load More pagination |
| `CategoryProductsSection.tsx` | Load More pagination, setInitialProducts call |

---

## API Calls

### Get All Categories (with pagination)
```typescript
categoriesApi.getAll(storeId, page, size, { parentId, search })
```

### Get Products (with pagination)
```typescript
productsApi.getAll(storeId, page, size, { categoryId, search })
```

---

## UI States

### Subcategories Section
```
┌─────────────────────────────────────┐
│ Subcategories                    [5] │
├─────────────────────────────────────┤
│ 🔍 Search subcategories...          │
├─────────────────────────────────────┤
│ ☑ Electronics (current child)       │
│ ☐ Clothing                          │
│ ☐ Home & Garden                     │
│ ☐ Sports                            │
│ ...                                  │
├─────────────────────────────────────┤
│ Showing 5 of 25 subcategories       │
│ [ Load More ]                       │
└─────────────────────────────────────┘
```

### Products Section
```
┌─────────────────────────────────────┐
│ Products                         [3]│
├─────────────────────────────────────┤
│ 🔍 Search products...                │
├─────────────────────────────────────┤
│ ☑ Nike Air Max (current)            │
│ ☐ Adidas Ultraboost                 │
│ ☐ Running Shoes Pro                 │
│ ...                                  │
├─────────────────────────────────────┤
│ Showing 3 of 150 products           │
│ [ Load More ]                       │
└─────────────────────────────────────┘
```
