# VCS Custom Repository Connection Plan

## Overview

Allow users to connect their custom GitHub repositories to stores. This enables:
- User commits code to their own GitHub repo
- Webhook triggers rebuild on push
- Code is cloned and built (platform merged with user code)
- Store is deployed with user's customizations

## Architecture

### Data Flow

```
┌─────────────────────────────────────────────────────────────────────┐
│                         USER ACTIONS                                 │
│                                                                      │
│  1. Connect GitHub Account                                           │
│     (Login → OAuth → user:email scope)                               │
│                              │                                       │
│                              ▼                                       │
│  2. Connect Custom Repository                                        │
│     (Upgrade to repo scope → List repos → Select repo)              │
│                              │                                       │
│                              ▼                                       │
│  3. Commit Code to Repository                                        │
│     (User pushes to GitHub)                                          │
│                              │                                       │
│                              ▼                                       │
│  4. Webhook Triggers Build                                          │
│     (GitHub → Our Server → Queue Build)                              │
│                              │                                       │
│                              ▼                                       │
│  5. Build & Deploy                                                   │
│     (Clone repo → Merge platform → Build → Deploy)                   │
└─────────────────────────────────────────────────────────────────────┘
```

### Database Schema

#### Extend `user_oauth_identities` (existing table)

```sql
ALTER TABLE user_oauth_identities 
    ADD COLUMN IF NOT EXISTS access_token_encrypted TEXT,
    ADD COLUMN IF NOT EXISTS refresh_token_encrypted TEXT,
    ADD COLUMN IF NOT EXISTS token_expires_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS scope VARCHAR(200);
```

**New Columns:**
| Column | Type | Description |
|--------|------|-------------|
| `access_token_encrypted` | TEXT | Encrypted GitHub access token |
| `refresh_token_encrypted` | TEXT | Encrypted GitHub refresh token |
| `token_expires_at` | TIMESTAMPTZ | When token expires (GitHub: ~8 hours for token, longer for refresh) |
| `scope` | VARCHAR(200) | OAuth scopes granted (e.g., "user:email,repo") |

#### Extend `vcs_connections` (existing table)

```sql
ALTER TABLE vcs_connections
    ADD COLUMN IF NOT EXISTS user_oauth_identity_id UUID REFERENCES user_oauth_identities(id);
```

**New Column:**
| Column | Type | Description |
|--------|------|-------------|
| `user_oauth_identity_id` | UUID | Links to user's GitHub OAuth identity for token lookup |

### Entity Relationships

```
users
  │
  └── user_oauth_identities (one per GitHub account per user)
        ├── user_id
        ├── provider: GITHUB
        ├── provider_id: GitHub user ID
        ├── access_token_encrypted
        ├── refresh_token_encrypted
        ├── token_expires_at
        ├── scope
        │
        └── vcs_connections (via user_oauth_identity_id)
              ├── store_id
              ├── repository_url
              ├── branch
              ├── webhook_id
              └── (other VCS fields)
```

## Implementation Plan

### Phase 1: Database & Token Storage

#### Step 1.1: Create Migration

**File:** `db/migration/V41__add_github_tokens_to_oauth.sql`

```sql
-- V41: Add GitHub OAuth token storage for VCS

-- Add token columns to user_oauth_identities
ALTER TABLE user_oauth_identities 
    ADD COLUMN IF NOT EXISTS access_token_encrypted TEXT,
    ADD COLUMN IF NOT EXISTS refresh_token_encrypted TEXT,
    ADD COLUMN IF NOT EXISTS token_expires_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS scope VARCHAR(200);

-- Add link from vcs_connections to user_oauth_identities
ALTER TABLE vcs_connections
    ADD COLUMN IF NOT EXISTS user_oauth_identity_id UUID REFERENCES user_oauth_identities(id);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_vcs_connections_oauth_identity 
    ON vcs_connections(user_oauth_identity_id) 
    WHERE user_oauth_identity_id IS NOT NULL;
```

#### Step 1.2: Update Entity

**File:** `src/main/kotlin/com/entaprenua/entities/UserOAuthIdentity.kt`

```kotlin
@Serializable
data class UserOAuthIdentity(
    @Contextual
    val id: UUID? = null,
    @Contextual
    val userId: UUID,
    val provider: IdentityProvider,
    val providerId: String,
    @Contextual
    val createdAt: OffsetDateTime? = null,
    // New fields for GitHub token storage
    val accessTokenEncrypted: String? = null,
    val refreshTokenEncrypted: String? = null,
    @Contextual
    val tokenExpiresAt: OffsetDateTime? = null,
    val scope: String? = null
)
```

#### Step 1.3: Update Repository

**File:** `src/main/kotlin/com/entaprenua/auth/repositories/UserOAuthIdentityRepository.kt`

Add methods:
- `findByUserIdAndProvider(userId, provider)` - Get specific OAuth identity
- `updateTokens(id, accessToken, refreshToken, expiresAt, scope)` - Update tokens

#### Step 1.4: Add Encryption Service (reuse existing)

Use existing `EncryptionService` from VCS module for token encryption:
- `encrypt(plaintext)` - Encrypt token
- `decrypt(ciphertext)` - Decrypt token

### Phase 2: OAuth Scope Upgrade Flow

#### Step 2.1: Modify OAuthServiceImpl

**File:** `src/main/kotlin/com/entaprenua/auth/impl/OAuthServiceImpl.kt`

Add methods:
```kotlin
// Check if token needs scope upgrade
fun hasScope(oauthIdentity: UserOAuthIdentity, requiredScope: String): Boolean

// Upgrade scope by re-authorizing
suspend fun upgradeScope(code: String, additionalScopes: String): OAuthTokenResult

// Refresh token if expired
suspend fun refreshToken(oauthIdentity: UserOAuthIdentity): OAuthTokenResult
```

#### Step 2.2: OAuth Token Response

**File:** `src/main/kotlin/com/entaprenua/auth/OAuthModels.kt`

```kotlin
data class OAuthTokenResult(
    val accessToken: String,
    val refreshToken: String?,
    val expiresIn: Long,  // seconds
    val scope: String
)

data class OAuthScopeUpgrade(
    val needsUpgrade: Boolean,
    val currentScope: String?,
    val upgradeUrl: String?
)
```

### Phase 3: Repository Connection API

#### Step 3.1: New Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/stores/{publicId}/vcs/repos` | List user's GitHub repositories |
| GET | `/api/v1/stores/{publicId}/vcs/repos/github` | Get GitHub OAuth URL to connect/upgrade |
| POST | `/api/v1/stores/{publicId}/vcs/repos` | Connect a repository (select from list) |
| GET | `/api/v1/stores/{publicId}/vcs/repos/upgrade-callback` | Handle OAuth upgrade callback |

#### Step 3.2: Repository Listing

**GitHub API:** `GET https://api.github.com/user/repos`

```kotlin
suspend fun listUserRepositories(accessToken: String): List<GitHubRepo> {
    val response = client.get()
        .uri("https://api.github.com/user/repos?per_page=100&sort=updated")
        .header("Authorization", "Bearer $accessToken")
        .header("Accept", "application/vnd.github.v3+json")
        .retrieve()
        .awaitBody<List<Map<String, Any>>>()
    
    return response.map { repo ->
        GitHubRepo(
            id = repo["id"] as String,
            name = repo["name"] as String,
            fullName = repo["full_name"] as String,
            owner = (repo["owner"] as Map<String, Any>)["login"] as String,
            private = repo["private"] as Boolean,
            url = repo["html_url"] as String,
            cloneUrl = repo["clone_url"] as String,
            defaultBranch = repo["default_branch"] as String
        )
    }
}
```

#### Step 3.3: Connect Repository Service

**File:** `src/main/kotlin/com/entaprenua/vcs/services/VcsCustomRepoService.kt`

```kotlin
@Service
class VcsCustomRepoService(
    private val oauthIdentityRepository: UserOAuthIdentityRepository,
    private val vcsConnectionRepository: VcsConnectionRepository,
    private val gitHubApiService: GitHubApiService,
    private val encryptionService: EncryptionService
) {
    // Step 1: Check if user needs to upgrade OAuth scope
    suspend fun checkScopeUpgradeNeeded(storeId: UUID, userId: UUID): OAuthScopeUpgrade
    
    // Step 2: Get OAuth URL for scope upgrade
    suspend fun getUpgradeOAuthUrl(storeId: UUID): String
    
    // Step 3: Handle OAuth callback after scope upgrade
    suspend fun handleUpgradeCallback(code: String, state: String): UserOAuthIdentity
    
    // Step 4: List repositories user can access
    suspend fun listRepositories(userId: UUID): List<GitHubRepo>
    
    // Step 5: Connect selected repository
    suspend fun connectRepository(storeId: UUID, userId: UUID, repo: GitHubRepo, branch: String): VcsConnection
}
```

### Phase 4: Webhook Handling for Custom Repos

#### Step 4.1: Modify WebhookService

**File:** `src/main/kotlin/com/entaprenua/vcs/services/WebhookService.kt`

When receiving webhook:
1. Find VCS connection by repository ID
2. Get user's OAuth identity from connection
3. Use user's token to clone the repository (instead of automation token)

```kotlin
suspend fun handleGitHubPush(request: ServerRequest): ServerResponse {
    // ... existing validation ...
    
    val connection = vcsConnectionRepository.findByRepositoryId(payload.repositoryId)
        ?: return ServerResponse.ok().bodyValueAndAwait(mapOf("status" to "ignored"))
    
    // Get user's OAuth token
    val oauthIdentity = connection.userOauthIdentityId?.let { 
        oauthIdentityRepository.findById(it) 
    }
    
    // Use user's token for cloning (will be passed to build queue)
    val userAccessToken = oauthIdentity?.let { 
        encryptionService.decrypt(it.accessTokenEncrypted) 
    }
    
    // Trigger build with user token
    val triggered = vcsService.triggerBuildFromWebhook(payload, userAccessToken)
    // ...
}
```

#### Step 4.2: Modify BuildQueueService

**File:** `src/main/kotlin/com/entaprenua/vcs/services/BuildQueueService.kt`

Add user token parameter to build execution:
```kotlin
suspend fun executeBuild(
    connection: VcsConnection, 
    build: VcsBuild,
    userAccessToken: String? = null  // NEW: User's OAuth token
) {
    // If userAccessToken provided, use it for cloning
    // Otherwise, fall back to automation token
    val cloneUrl = if (userAccessToken != null) {
        // Convert HTTPS URL to token-authenticated URL
        connection.repositoryUrl?.replace(
            "https://",
            "https://$userAccessToken@"
        )
    } else {
        connection.repositoryUrl
    }
    
    // Clone using the appropriate URL
    cloneRepository(cloneUrl, ...)
}
```

### Phase 5: Frontend Integration

#### Step 5.1: API Client

**File:** `admin/src/lib/api/vcs.ts`

```typescript
export async function getGitHubOAuthUrl(publicId: string): Promise<string>
export async function listGitHubRepos(publicId: string): Promise<GitHubRepo[]>
export async function connectRepository(
    publicId: string, 
    repo: GitHubRepo, 
    branch: string
): Promise<VcsConnection>
export async function checkScopeUpgrade(publicId: string): Promise<ScopeUpgradeStatus>
```

#### Step 5.2: VCS Settings Page

Add UI for:
1. "Connect Custom Repository" button
2. Repository list with search/filter
3. Branch selection
4. Connected repository info with "Change" option

## Build Flow for Custom Repositories

### Current Flow (Platform-Owned Repos)

```
1. Webhook triggers build
2. Clone platform repo (using automation token)
3. Clone user repo (using automation token - we own it)
4. Merge user code into platform
5. Build merged code
6. Deploy
```

### New Flow (Custom Repos)

```
1. Webhook triggers build
2. Clone user repo (using USER's token)
3. Read platform-version.json from user repo
4. Clone platform at specified version
5. Merge user code into platform
6. Build merged code
7. Deploy
```

### Key Difference

For custom repos:
- We DON'T push to user's repo (user owns it)
- We only READ from user's repo
- Webhook registers on user's repo using user's token

## Security Considerations

1. **Token Storage**: Encrypt with AES-256 before storing in database
2. **Token Access**: Only allow access to tokens for builds of the same user
3. **Webhook Security**: Signature verification still works (uses stored webhook secret)
4. **Token Refresh**: Handle token expiration gracefully, notify user if refresh fails
5. **User Isolation**: Each store's builds only access that store's connected repo

## Scope Changes

### Current (Login Only)
```
Scope: user:email
Purpose: Get user email for registration/login
```

### After Upgrade (VCS Access)
```
Scope: user:email repo
Purpose: 
- user:email - Still needed for login
- repo - Access user repositories for VCS builds
```

## Testing Checklist

- [ ] Create migration and verify schema
- [ ] Test OAuth token storage (encrypt/decrypt)
- [ ] Test scope upgrade flow
- [ ] Test repository listing
- [ ] Test repository connection
- [ ] Test webhook with custom repo
- [ ] Test build with user token
- [ ] Test token refresh
- [ ] Test disconnect/reconnect repository

## Files to Create/Modify

### Backend

| File | Action |
|------|--------|
| `db/migration/V41__add_github_tokens_to_oauth.sql` | Create |
| `src/main/kotlin/com/entaprenua/entities/UserOAuthIdentity.kt` | Modify |
| `src/main/kotlin/com/entaprenua/auth/repositories/UserOAuthIdentityRepository.kt` | Modify |
| `src/main/kotlin/com/entaprenua/auth/impl/OAuthServiceImpl.kt` | Modify |
| `src/main/kotlin/com/entaprenua/auth/OAuthModels.kt` | Create |
| `src/main/kotlin/com/entaprenua/vcs/services/VcsCustomRepoService.kt` | Create |
| `src/main/kotlin/com/entaprenua/vcs/services/WebhookService.kt` | Modify |
| `src/main/kotlin/com/entaprenua/vcs/services/BuildQueueService.kt` | Modify |
| `src/main/kotlin/com/entaprenua/vcs/services/VcsService.kt` | Modify |
| `src/main/kotlin/com/entaprenua/vcs/services/VcsHandlerServices.kt` | Modify |
| `src/main/kotlin/com/entaprenua/vcs/services/VcsHandlers.kt` | Modify |
| `src/main/kotlin/com/entaprenua/vcs/dtos/VcsDtos.kt` | Modify |
| `src/main/kotlin/com/entaprenua/config/ApiRouterConfig.kt` | Modify |

### Frontend (Future)

| File | Action |
|------|--------|
| `admin/src/lib/api/vcs.ts` | Modify |
| `admin/src/routes/admin/settings/vcs.tsx` | Modify |

## Environment Variables

```bash
# GitHub OAuth (existing)
GITHUB_CLIENT_ID=your_github_oauth_client_id
GITHUB_CLIENT_SECRET=your_github_oauth_client_secret

# Callback URL
# Platform: https://entaprenua.com/api/v1/auth/oauth/github/callback
# VCS Upgrade: https://entaprenua.com/api/v1/stores/{storeId}/vcs/repos/upgrade-callback
```

## User Experience Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                     VCS Settings Page                            │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │  Current: Platform-Owned Repository                        │ │
│  │  Repository: entaprenua/store-st12345                      │ │
│  │  Branch: main                                              │ │
│  │  Status: Connected ✓                                       │ │
│  │  [Disconnect]                                              │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │  Connect Custom Repository                                   │ │
│  │                                                              │ │
│  │  [Connect GitHub Repository] ──────────────────────────────▶ │
│  └─────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘

User clicks "Connect GitHub Repository"
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│  GitHub OAuth (Scope Upgrade)                                     │
│                                                                  │
│  "Entaprenua is requesting additional access to your account"    │
│                                                                  │
│  Current access:                                                 │
│  • Read your email address                                       │
│                                                                  │
│  Additional access requested:                                     │
│  • Access repositories you have access to                        │
│                                                                  │
│  [Authorize]  [Cancel]                                           │
└─────────────────────────────────────────────────────────────────┘

User authorizes
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│  Repository Selection                                            │
│                                                                  │
│  Search: [________________________]                              │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │ ○ my-store-frontend          my-username   Private  Main ✓  │ │
│  │ ○ ecommerce-app              my-username   Private  main    │ │
│  │ ○ legacy-website             my-org        Public   master  │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  Branch: [main ▼]                                               │
│                                                                  │
│  [Connect Repository]                                           │
└─────────────────────────────────────────────────────────────────┘
```

## Success Metrics

- User can connect GitHub account during registration (existing)
- User can upgrade scope when connecting first repo
- User can see list of their GitHub repositories
- User can select a repository to connect
- Webhook is registered on user's repository
- Push to user's repo triggers build
- Build uses user's code (merged with platform)
- User can disconnect and reconnect different repos
