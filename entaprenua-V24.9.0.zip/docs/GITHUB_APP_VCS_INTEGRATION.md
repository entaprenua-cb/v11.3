# GitHub App Integration for VCS Custom Repository Connection

## Overview

This document details the implementation of GitHub App for connecting custom user repositories to stores. This replaces the previous OAuth-based flow.

## Architecture

### User Flow

```
1. Store already has VcsConnection (platform repo)
2. User clicks "Connect Repository"
3. Redirected to GitHub to install App with state={storeId}
4. User installs App on their account
5. GitHub redirects to /github-app/callback?installation_id={id}&state={storeId}
6. We store installation_id on VcsConnection (one repo per store)
7. User pushes to their custom repo
8. Webhook push event triggers build
9. Clone user's repo (read-only using installation token)
10. Run npm build
11. Deploy
```

### No Merging
- No platform merge, no template merging
- User's code is assumed ready for build
- Just clone as-is, run `npm build`, deploy

### Key Differences: OAuth vs GitHub App

| Aspect | OAuth (Previous) | GitHub App (New) |
|--------|------------------|-----------------|
| **Permission Grant** | User grants `repo` scope via OAuth | User installs GitHub App |
| **Token Storage** | Encrypted OAuth tokens in DB | Installation ID only (one per store) |
| **Build Clone** | Uses stored OAuth token | Uses installation token (fetched on build) |
| **Write Access** | We could push to repo | Read-only (no write) |
| **Per-Store** | User OAuth identity | One installation per store |

## State Parameter

We pass `store_id` as the `state` parameter in the install URL:

```
https://github.com/apps/entaprenua/installations/new?state={storeId}
```

After installation, GitHub redirects to:

```
{baseUrl}/api/v1/github-app/callback?installation_id={id}&state={storeId}
```

We extract `store_id` from `state` and update the existing VcsConnection with `installation_id`.

## Configuration

### Environment Variables

Add to `backend/.env`:

```bash
# GitHub App
GITHUB_APP_ID=3325063
GITHUB_APP_WEBHOOK_SECRET=d7df3601a2ff642c65547882a27268a5e9603756
GITHUB_APP_PRIVATE_KEY="-----BEGIN RSA PRIVATE KEY-----\n..."
```

### GitHub App Settings

| Config | Value |
|--------|-------|
| App ID | 3325063 |
| Client ID | Iv23li1XJdLvumCuNSGb |
| Client Secret | d7df3601a2ff642c65547882a27268a5e9603756 |
| Webhook Secret | d7df3601a2ff642c65547882a27268a5e9603756 |

### GitHub App Permissions

- **Contents**: Read-only (for cloning)
- **Metadata**: Read-only (for repo info)

## Database Schema

### New Column on vcs_connections

```sql
ALTER TABLE vcs_connections 
    ADD COLUMN IF NOT EXISTS github_installation_id BIGINT;
```

### Entity Update

```kotlin
data class VcsConnection(
    // ... existing fields
    val githubInstallationId: Long? = null
)
```

## API Endpoints

### New Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/{storeId}/vcs/repos/install-url` | Get GitHub App install URL |
| GET | `/{storeId}/vcs/repos` | List repos where app is installed |
| POST | `/{storeId}/vcs/repos/connect` | Connect selected repo |
| DELETE | `/{storeId}/vcs/repos/connect` | Disconnect custom repo |
| GET | `/api/v1/github-app/callback` | Handle install redirect |
| POST | `/api/v1/github-app/webhook` | Handle push events |

### Removed Endpoints (OAuth)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/{storeId}/vcs/repos/upgrade-oauth-url` | OAuth scope upgrade |
| GET | `/{storeId}/vcs/repos/upgrade-callback` | OAuth callback |
| GET | `/{storeId}/vcs/repos/scope-upgrade-status` | Check scope upgrade status |

## Services

### GitHubAppService

Location: `backend/src/main/kotlin/com/entaprenua/vcs/services/GitHubAppService.kt`

| Method | Description |
|---------|-------------|
| `generateJWT()` | Create signed JWT for GitHub API authentication |
| `getInstallationToken(installationId)` | Exchange JWT for installation access token |
| `getInstallationUrl(storeId)` | Generate GitHub App install URL with state parameter |
| `listInstallationRepositories(installationId)` | List repositories where app is installed |
| `verifyWebhookSignature(payload, signature)` | Verify webhook authenticity |

### GitHubAppWebhookService

Location: `backend/src/main/kotlin/com/entaprenua/vcs/services/GitHubAppWebhookService.kt`

| Endpoint | Event | Action |
|----------|-------|--------|
| GET `/github-app/callback` | - | Handle install redirect, update VcsConnection with installation_id |
| POST `/github-app/webhook` | `push` | Clone user's repo, run npm build |
| POST `/github-app/webhook` | `installation.deleted` | Clear installation_id |

## Build Flow

### Custom Repository Build

```
1. User pushes code to their GitHub repository
2. GitHub sends webhook (push event)
3. We find VCS connection by repository owner/name
4. Get fresh installation token from installation_id
5. Clone repository using installation token (read-only)
6. Run npm build
7. Deploy
```

### Key Implementation Details

- **Read-Only**: We use installation token only for cloning, never push
- **Ephemeral Tokens**: Installation tokens expire, get fresh token on each build
- **Webhook Security**: Verify webhook signature using webhook secret

## Webhook Events

### Push Event

```json
{
  "action": "push",
  "repository": {
    "full_name": "username/repo-name",
    "id": 12345678
  },
  "ref": "refs/heads/main",
  "after": "abc123..."
}
```

### Installation Events

```json
{
  "action": "created",
  "installation": {
    "id": 12345678,
    "account": {
      "login": "username",
      "type": "User"
    }
  },
  "repositories": [...]
}
```

## Security Considerations

1. **JWT Expiration**: JWT tokens expire after 600 seconds (10 minutes)
2. **Webhook Verification**: Always verify signature before processing
3. **Token Storage**: Installation ID stored, tokens fetched on-demand
4. **Read-Only Access**: Never write to user's repository

## Files to Create/Modify

### Create

| File | Description |
|------|-------------|
| `vcs/services/GitHubAppWebhookService.kt` | Handle install callback and build webhooks |

### Modify

| File | Description |
|------|-------------|
| `db/migration/V51__add_github_installation.sql` | Add installation_id column |
| `vcs/entities/VcsConnection.kt` | Add githubInstallationId field |
| `vcs/services/VcsCustomRepoService.kt` | Replace OAuth with GitHub App |
| `vcs/services/VcsService.kt` | Use installation token for cloning |
| `config/ApiRouterConfig.kt` | New endpoints + remove OAuth |

## Testing Checklist

- [ ] GitHub App installation URL generated correctly with state
- [ ] Callback updates VcsConnection with installation_id
- [ ] List repositories shows correct repos from installation
- [ ] Connect repository saves installation_id
- [ ] Webhook push triggers build
- [ ] Build uses installation token for cloning
- [ ] Disconnect clears installation_id
- [ ] Webhook signature verification works
- [ ] npm build runs successfully