# M-Pesa Integration Documentation

## Overview

M-Pesa Daraja API integration for mobile money payments in Kenya (Kenyan Shillings - KES).

## Architecture

```
┌─────────────┐     ┌──────────────┐     ┌─────────────────┐
│   Client    │────▶│  Backend     │────▶│  Safaricom       │
│  (Browser) │     │  (Spring)    │     │  Daraja API      │
└─────────────┘     └──────────────┘     └─────────────────┘
                           │                      │
                           │    ┌─────────────────┘
                           ▼    ▼
                    ┌─────────────────┐
                    │  M-Pesa Callback │
                    │  (Webhook)        │
                    └─────────────────┘
```

## Flow

```
1. POST /stores/{publicId}/checkout (paymentMethod="mpesa", paymentPhone="2547...")
2. Backend generates OAuth token from Safaricom
3. Backend calls Safaricom STK Push API
4. Customer receives USSD prompt on their phone
5. Customer enters M-Pesa PIN
6. Safaricom processes payment
7. Safaricom calls /mpesa/callback with result
8. Backend updates payment and order status
```

## Configuration

### Environment Variables

```env
MPESA_ENABLED=true
MPESA_CONSUMER_KEY=<your_consumer_key>
MPESA_CONSUMER_SECRET=<your_consumer_secret>
MPESA_SHORTCODE=<your_shortcode>
MPESA_TILL_NUMBER=<your_till_number>
MPESA_PAYBILL_NUMBER=<your_paybill_number>
MPESA_PASSKEY=<your_passkey>
MPESA_ENVIRONMENT=sandbox
MPESA_CALLBACK_BASE_URL=https://yourdomain.com
```

### Sandbox vs Production

| Environment | Base URL | AccountReference Limit |
|-------------|----------|----------------------|
| Sandbox | https://sandbox.safaricom.co.ke | Max 12 characters |
| Production | https://api.safaricom.co.ke | Max 20 characters |

**Note**: The `AccountReference` field in STK Push has different limits per environment. Current implementation uses 12 characters (truncated to `ORD-YYYYMMDD` format) which works in both environments.

## API Endpoints

### Checkout (Initiate M-Pesa Payment)

```http
POST /api/v1/stores/{publicId}/checkout
Content-Type: application/json

{
  "cartId": "uuid",
  "storeId": "uuid",
  "guestEmail": "customer@example.com",
  "paymentMethod": "mpesa",
  "paymentPhone": "+254707123456"
}
```

Response:
```json
{
  "success": true,
  "data": {
    "success": true,
    "orderId": "uuid",
    "orderNumber": "ORD-20260405-001",
    "referenceId": "ws_CO_...",
    "status": "processing",
    "message": "Check your phone and enter your M-Pesa PIN"
  }
}
```

### M-Pesa Callback

```http
POST /mpesa/callback
Content-Type: application/json

{
  "Body": {
    "stkCallback": {
      "MerchantRequestID": "...",
      "CheckoutRequestID": "ws_CO_...",
      "ResultCode": 0,
      "ResultDesc": "The service request is processed successfully.",
      "CallbackMetadata": {
        "Item": [
          {"Name": "Amount", "Value": 1.00},
          {"Name": "MpesaReceiptNumber", "Value": "NLJ7RT61SV"},
          {"Name": "TransactionDate", "Value": 20260405120000},
          {"Name": "PhoneNumber", "Value": 254707123456}
        ]
      }
    }
  }
}
```

### Check Payment Status

```http
GET /api/v1/mpesa/status/{referenceId}
```

## Result Codes

| Code | Description | Order Status |
|------|-------------|--------------|
| 0 | Success | paid |
| 1032 | Request cancelled by user | payment_failed |
| 1037 | Request timeout | payment_failed |
| 2001 | Wrong PIN | payment_failed |
| GV50113 | Generic error | payment_failed |

## Order Status Flow

```
pending_payment
    │
    ▼ (STK Push initiated)
processing
    │
    ├─▶ (callback: result=0) ──▶ paid
    │
    └─▶ (callback: result!=0) ──▶ payment_failed
```

## Sandbox Testing

### Simulator Usage

1. Go to https://developer.safaricom.co.ke/sandbox
2. Open your app
3. Click "Simulator"
4. Enter:
   - Phone: Test phone number (e.g., `254707815273`)
   - Amount: Payment amount
   - **Account Reference**: Order reference (max **12 characters** for sandbox)
   - Callback URL: https://yourdomain.com/mpesa/callback
5. Click Submit

**Important**: Sandbox has a strict 12-character limit for AccountReference. The system automatically truncates to `ORD-YYYYMMDD` format.

### Test Phone Numbers

Standard sandbox test numbers:
- `254707815273` (recommended for most testing)
- `254708374149` (alternative)

### Known Sandbox Issues

1. **GV50113 Error**: Sandbox simulator sometimes returns this error. Use production credentials for real testing.
2. **Callback ID Mismatch**: Simulator may create new checkout IDs instead of using provided ones.
3. **Real Costs**: Ensure sandbox app is properly configured to avoid real charges.

## Nginx Configuration

```nginx
location /mpesa/ {
    proxy_pass http://127.0.0.1:8080/mpesa/;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
}
```

## Database Schema

### Payments Table Updates

For M-Pesa, the `payments` table stores:

- `reference_id` - Safaricom CheckoutRequestID
- `merchant_request_id` - Safaricom MerchantRequestID
- `payment_phone` - Customer's M-Pesa phone number
- `transaction_id` - M-Pesa receipt number (after success)

### Orders Table

Order status transitions based on payment result:
- `pending_payment` → `processing` (on STK Push)
- `processing` → `paid` (on successful callback)
- `processing` → `payment_failed` (on failed callback)

## Security Considerations

1. **Never expose credentials**: Keep Consumer Key/Secret in `.env` files
2. **HTTPS required**: Callback URL must use HTTPS in production
3. **Idempotency**: Handle duplicate callbacks gracefully
4. **Logging**: Log all callbacks for debugging

## Troubleshooting

### "Wrong credentials" Error

1. Verify Consumer Key/Secret are correct
2. Ensure app has "Lipa Na M-Pesa" product subscribed
3. Check shortcode and passkey are configured

### Callback Not Received

1. Verify callback URL is publicly accessible
2. Check firewall allows incoming HTTPS traffic
3. Ensure SSL certificate is valid
4. Check Safaricom simulator URL configuration

### Payment Marked as Failed

1. Check logs for actual result code
2. Verify order status update logic
3. Common causes: wrong PIN, insufficient funds, timeout

## Files Modified

- `MpesaService.kt` - Core M-Pesa API integration
- `MpesaController.kt` - Callback handler
- `CheckoutServiceImpl.kt` - Checkout flow with M-Pesa
- `.env` - Configuration

## Testing Checklist

- [ ] STK Push initiation works
- [ ] Customer receives payment prompt
- [ ] Callback is received
- [ ] Order status updates correctly on success
- [ ] Order status updates correctly on failure
- [ ] Payment status updates correctly
- [ ] SMS confirmation received

## Go Live Checklist

- [ ] Use production credentials
- [ ] Configure production callback URL (HTTPS)
- [ ] Set `MPESA_ENVIRONMENT=production`
- [ ] Test with small real amount
- [ ] Verify SMS confirmation
- [ ] Check order in Safaricom portal
