# Component Registry Refactor Implementation Plan

## Overview
Refactor `component-registry.ts` to be the single source of truth for allowed components, then update parser and renderer to use it. No transform logic in parser - validation only.

## Files to Modify

### 1. `src/builder/utils/component-registry.ts`
**Changes:**

1. Rename current registry to `_componentRegistry` (internal source of truth)
2. Add all HTML tags with component mappings
3. Add helper functions to derive exports at module load
4. Add exports: `ALLOWED_COMPONENTS`, `componentMap`

**HTML Tags to Add:**
- Block elements: `div`, `p`, `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `pre`, `blockquote`
- Inline elements: `span`, `a`, `strong`, `em`, `code`, `small`
- List elements: `ul`, `ol`, `li`
- Table elements: `table`, `thead`, `tbody`, `tr`, `th`, `td`
- Media: `img` (already mapped to image)

**Structure for HTML tags:**
```typescript
// For text-based tags that map to Text component
h1: { component: Text, variant: 'h1' },
h2: { component: Text, variant: 'h2' },
p: { component: Text },
span: { component: Text },

// For div mapping to Box
div: { component: Box },
```

**Derivation Functions:**
```typescript
// Returns Set<string> - all component names (top-level + contextuals + HTML tags)
function flattenToSet(reg): Set<string>

// Returns Record<string, Component> - all components for rendering
function flattenToMap(reg): Record<string, any>
```

**Exports:**
- `ALLOWED_COMPONENTS: Set<string>` - for parser validation
- `componentMap: Record<string, any>` - for renderer (includes nested + HTML tags)
- `componentRegistry` - nested (for component.ts)
- `_componentRegistry` - internal access

---

### 2. `src/lib/server/parser/index.ts`
**Changes:**

1. Remove hardcoded `ALLOWED_COMPONENTS` Set (lines 89-109)
2. Import `ALLOWED_COMPONENTS` from registry
3. Update `DEFAULT_OPTIONS` to use imported set
4. Remove transform logic in `resolveComponentName()` - keep only name normalization

**Import:**
```typescript
import { ALLOWED_COMPONENTS } from '~/builder/utils/component-registry'
```

**Before (hardcoded):**
```typescript
const ALLOWED_COMPONENTS = new Set([...]);
```

**After (from registry):**
```typescript
const DEFAULT_OPTIONS: ParseOptions = {
  ...DEFAULT_OPTIONS,
  allowedComponents: ALLOWED_COMPONENTS,
}
```

---

### 3. `src/builder/canvas/renderer/index.tsx`
**Changes:**

1. No import changes needed (already imports `componentMap`)
2. Add variant handling for HTML text tags in `BuilderComponent`

**Variant Handling:**
```typescript
// HTML tags that should use Text component with variant prop
const TEXT_VARIANTS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'span', 'pre', 'blockquote', 'strong', 'em', 'code', 'small'];

const variant = createMemo(() => {
  const name = componentName();
  if (TEXT_VARIANTS.includes(name)) {
    return name;
  }
  return undefined;
});
```

---

### 4. `src/builder/utils/component.ts`
**No changes needed** - continues using nested `componentRegistry` via re-export, which stays the same.

---

## Implementation Steps

### Step 1: Refactor component-registry.ts
1. Rename `componentRegistry` to `_componentRegistry`
2. Add all HTML tag entries to `_componentRegistry`
3. Add `flattenToSet()` function
4. Add `flattenToMap()` function  
5. Add exports: `ALLOWED_COMPONENTS`, `componentMap`
6. Re-export `_componentRegistry as componentRegistry`

### Step 2: Update parser
1. Remove hardcoded allowlist
2. Import from registry
3. Remove transform logic (keep normalization only)

### Step 3: Update renderer
1. Add variant handling for HTML text tags

### Step 4: Verify
1. Check component.ts still works
2. Run typecheck/lint

---

## Success Criteria

- [ ] Parser validates against registry (no transform logic)
- [ ] Renderer supports nested components (dialogTrigger, cardHeader, etc.)
- [ ] Renderer handles HTML tags with proper variant prop
- [ ] component.ts works without changes
- [ ] All lookups are O(1) (pre-computed at module load)
- [ ] TypeScript compiles without errors