# Email Verification Page Implementation Plan

## Overview
Create a frontend page to handle email verification when users click the verification link sent to their email.

## Files to Create/Modify

### 1. New File: `src/routes/verify-email.tsx`
- Extract `token` from URL query parameter using `useSearch`
- Call backend API `GET /api/v1/auth/verify-email?token=xxx` on page load
- Display appropriate UI states:
  - **Loading:** While verification is in progress
  - **Success:** When email is verified successfully → show message + redirect to login
  - **Error:** When verification fails (invalid/expired token) → show error + resend link

### 2. Modify: `src/lib/utils/routes.ts`
- Add new route: `verifyEmail: "/verify-email"`

## Implementation Details

### Frontend Logic
1. On page load, check if `token` exists in URL
2. If no token → show error "Verification token is required"
3. If token exists → call API to verify
4. Show loading spinner while API call is in progress
5. On success → show "Email verified successfully!" + "Go to Login" button
6. On error → show error message + "Resend verification email" link

### API Endpoint (Backend - Already exists)
- `GET /api/v1/auth/verify-email?token={token}`

## UI Design
- Consistent with existing auth pages (log-in.tsx, sign-up.tsx)
- Use same AuthLayout component pattern
- Show appropriate icons for success/error states

## Acceptance Criteria
- [x] Page loads when user visits `/verify-email?token=xxx`
- [x] Token is extracted from URL
- [x] API is called on page load
- [x] Loading state is shown while verifying
- [x] Success message and redirect to login on success
- [x] Error message and resend link on failure
- [x] Route is added to routes.ts

## Status: COMPLETED ✅

## Files Created/Modified
1. **Created:** `src/routes/verify-email.tsx`
   - Extracts token from URL query param
   - Calls backend API `GET /api/v1/auth/verify-email?token=xxx`
   - Shows loading/success/error states
   - "Go to Login" button on success
   - "Need a new verification email?" button on error

2. **Modified:** `src/lib/utils/routes.ts`
   - Added `verifyEmail: "/verify-email"`