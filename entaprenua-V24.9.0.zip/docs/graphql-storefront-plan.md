# GraphQL Storefront API Plan

## Why GraphQL
Custom storefronts (Next.js, mobile, third-party) need different data per page. GraphQL lets each client fetch exactly what it needs in one round trip, without the REST problems of over-fetching and N+1 endpoints.

## Scope

| Layer | API | Why |
|-------|-----|-----|
| **Storefront** (products, categories, carts, checkout, orders, reviews) | **GraphQL** | Varying field needs per client. Complex mutations (checkout). Multiple related resources per page. |
| **Admin** (settings, members, VCS, media, dashboard) | **REST** (unchanged) | Fixed shapes, low traffic, SchemaForm handles dynamic forms. No benefit from GraphQL. |

REST and GraphQL coexist. The built SolidStart storefront continues using REST. GraphQL is for custom storefronts.

## Architecture

```
/storefront/graphql  ← public, API-key or customer-session
/api/v1/stores/...   ← REST (unchanged, coexists)
```

Resolvers delegate to existing services — no logic rewrite.

## Types

### Queries

```graphql
type Query {
  # Products
  product(id: ID, slug: String): Product
  products(filters: ProductFilters, pagination: PaginationInput): ProductConnection!

  # Categories
  category(id: ID, slug: String): Category
  categories(filters: CategoryFilters): CategoryConnection!

  # Cart
  cart(id: ID!): Cart

  # Orders
  orderLookup(storeId: ID!, orderNumber: String!, email: String!): OrderLookupResult

  # Combined storefront data
  storefrontSettings(storeId: ID!): StorefrontSettings!
}
```

### Mutations

```graphql
type Mutation {
  # Cart
  addToCart(cartId: ID!, productId: ID!, quantity: Int!): Cart!
  updateCartItem(cartId: ID!, productId: ID!, quantity: Int!): Cart!
  removeCartItem(cartId: ID!, productId: ID!): Cart!

  # Checkout
  checkout(input: CheckoutInput!): CheckoutResult!

  # Reviews
  createReview(productId: ID!, rating: Int!, comment: String): Review

  # Wishlist
  addToWishlist(storeId: ID!, productId: ID!): Wishlist!
  removeFromWishlist(storeId: ID!, productId: ID!): Boolean!
}
```

### Type Shapes

```
Product {
  id, name, slug, price, compareToPrice, image, description, visibility
  sku, stockQuantity, trackInventory, allowBackorder, weight
  shippingClass { id, name }
  deliveryZoneIds: [ID!]
  media: [Media!]
  reviews: ReviewConnection!
  category: Category
  relatedProducts: [Product!]
  averageRating, reviewCount
}

Category {
  id, name, slug, image, level, parentId, path
  children: [Category!]!
  products(filters, pagination): ProductConnection!
}

Cart {
  id, items: [CartItem!]!, subtotal, total
  guestSessionId, guestEmail, expiresAt
}

CartItem {
  productId, quantity, name, price, image, sku, slug, subtotal
}

CheckoutResult {
  order { id, number, status, total, currency }
  payment { referenceId, status, method }
}

StorefrontSettings {
  store { name, currency, logo }
  countries: [String!]!
  citiesByCountry: JSON
  deliveryTypes: [DeliveryType!]!
}
```

## Implementation Order

### Phase 1: Foundation
1. Add `graphql-kotlin-spring-server` to `build.gradle.kts`
2. Create `GraphQLConfig.kt`:
   - Schema registration with `graphql-kotlin-spring-server` auto-wiring
   - UUID scalar (serialized as ID)
   - JSON scalar for JSONB fields (conditions, metadata)
   - BigDecimal scalar (serialized as String)

### Phase 2: GraphQL Data Classes
3. Create `graphql/types/` directory with data classes annotated for GraphQL:
   - `ProductGraphQL`, `CategoryGraphQL`, `CartGraphQL`, `CartItemGraphQL`
   - `OrderGraphQL`, `OrderItemGraphQL`, `ReviewGraphQL`
   - `CheckoutResultGraphQL`, `PaymentResultGraphQL`
   - `StorefrontSettingsGraphQL`, `DeliveryTypeGraphQL`
   - `ProductConnection`, `CategoryConnection`, `PaginationInput`
   - `ProductFilters`, `CategoryFilters`, `CheckoutInput`
   - `MediaGraphQL`, `ShippingClassGraphQL`

### Phase 3: Resolvers
4. `StorefrontQueryResolver.kt` — top-level Query fields
5. `StorefrontMutationResolver.kt` — top-level Mutation fields
6. `ProductResolver.kt` — field resolvers for Product.reviews, .category, .relatedProducts, .shippingClass
7. `CategoryResolver.kt` — field resolver for Category.children, .products
8. `CartResolver.kt` — field resolver for Cart.items
9. `ReviewResolver.kt` — field resolver for ReviewConnection fields

Each resolver calls existing service/repository methods directly:
```kotlin
// Example
class ProductQueryResolver(
    private val productGetService: ProductGetServiceImpl
) {
    suspend fun product(
        @GraphQLDescription("Fetch by ID or slug")
        id: String? = null,
        slug: String? = null
    ): ProductGraphQL? {
        // Calls existing ProductGetServiceImpl.getBySlug() or getById()
        // which handles visibility filtering, media enrichment, etc.
    }
}
```

### Phase 4: Auth Wiring
10. Create `GraphQLContext.kt` — map API key + customer session into GraphQL context
11. Add directive-based auth checks matching existing `@requireRole` / `@allowApiKeyOrRole`

### Phase 5: Route Registration
12. Add `/storefront/graphql` endpoint in `ApiRouterConfig.kt`
13. Register GraphQL schema servlet (public, no auth required for queries; auth for mutations)

### Phase 6: Testing
14. Integration tests for key queries (product list, product detail, cart mutation, checkout)
15. Verify REST endpoints still work unchanged

## Key Decisions
- **No `@secured` directives** — auth is handled at the resolver level, same as REST services
- **Resolvers call existing services** — no duplication of business logic
- **REST stays** — backward compatibility for built storefront
- **graphql-kotlin-spring-server** — Kotlin-native, Spring Boot integration, same ecosystem as JOOQ
- **Cursor-based pagination** — same as existing REST product list
