# VCS Build Logs Refactor

## Goal

Replace the current in-memory StringBuilder + DB blob approach with SSE streaming via Redis pub/sub, with DB persistence at completion.

## Architecture

```
Build (any instance)
  │
  ├── StringBuilder (buffer for final DB write)  
  │
  ├── BuildLogStream.publish(line)
  │     ├── MutableSharedFlow (in-memory, same-instance SSE)
  │     └── Redis PUBLISH build.log:{buildId} line (cross-instance SSE)
  │
  └── on complete:
        publish("__EOF__")
        vcsBuildRepository.markCompleted(id, logs = buffer.toString())

SSE Endpoint (any instance)
  │
  └── BuildLogStream.subscribe(buildId) → Flow<String> → text/event-stream
        ├── reads from MutableSharedFlow (same instance, zero latency)
        └── subscribes to Redis SUBSCRIBE build.log:{buildId} (cross-instance)
              via ReactiveRedisMessageListenerContainer
              → merges both into a single Flow

Static Endpoint
  │
  └── GET /builds/{id}/logs?offset=N&limit=M
        → reads from vcs_builds.logs column (DB)
        → supports byte-range reads via SQL substring
```

## Files to Create/Modify

| File | Action | What |
|------|--------|------|
| `vcs/services/BuildLogStream.kt` | Create | Interface, both impls, BuildLogContext |
| `VcsDtos.kt` | Modify | Remove `logs` from `VcsBuildDto` |
| `VcsBuildRepository.kt` | Modify | Add `findLogsById()` |
| `VcsService.kt` | Modify | Add `getBuildLogs()` |
| `VcsHandlers.kt` | Modify | Add `getBuildLogs()` + `streamBuildLogs()` |
| `VcsHandlerServices.kt` | Modify | Drop logs from DTOs; add two handlers |
| `BuildQueueService.kt` | Modify | Replace `StringBuilder` with `BuildLogContext` |
| `ApiRouterConfig.kt` | Modify | Add two routes |

## Implementation Details

### BuildLogStream (interface)

```kotlin
interface BuildLogStream {
    fun publish(buildId: UUID, line: String)
    fun subscribe(buildId: UUID): Flow<String>
    fun complete(buildId: UUID)
}
```

Two implementations: `InMemoryBuildLogStream` (default) and `RedisBuildLogStream` (when Redis is available). Spring `@ConditionalOnBean` picks the right one.

### BuildLogContext

Replaces `StringBuilder` parameter across the build pipeline. Same API (`appendLine`, `toString`) + streaming.

### DB

- Logs still stored in `vcs_builds.logs` column at build completion
- `GET /builds/{id}/logs` reads from DB with optional offset/limit
- `VcsBuildDto` no longer carries `logs` field
