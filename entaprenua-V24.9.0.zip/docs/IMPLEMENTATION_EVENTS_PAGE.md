# Events Page Implementation Plan

## Overview
Refactor the build/events management system in the admin panel to use proper store context from admin state instead of route parameters.

## Current Issues

1. `/admin/events/index.tsx` uses `params.id` which doesn't exist at `/admin/events` route
2. No action buttons (Retry/Cancel/Redeploy) in events page
3. VCS settings page has embedded build history that should be separate
4. Logs page lacks Cancel button during active builds

## Solution

### Store ID Source
All pages must get store publicId from `admin.storeId()` or `admin.currentStore.publicId`, NOT from route parameters.

```tsx
const admin = useAdminPanel()
const storePublicId = () => admin.storeId()  // Returns publicId string
```

---

## Page-Specific Changes

### 1. `/admin/events/index.tsx` - Build Management Hub

**Purpose**: Full build history + all build actions

**Changes**:
- Replace `params.id` with `admin.storeId()`
- Add Retry button (for failed builds)
- Add Cancel button (for pending/building builds)
- Add Redeploy button (always visible)
- Update UI: "Build History" → "Events"
- Fix back button navigation

**Actions Placement**:
- Retry: Show when `status === "failed"`
- Cancel: Show when `status === "pending" || status === "building"`
- Redeploy: Always visible in header toolbar

### 2. `/admin/logs/index.tsx` - Live Build Monitor

**Purpose**: Active monitoring during store creation/rebuild

**Changes**:
- Add Cancel button (show when status is "pending" or "building")
- Keep existing live polling behavior

### 3. `/admin/settings/vcs.tsx` - VCS Configuration

**Purpose**: GitHub repository configuration only

**Changes**:
- Remove the "Build History" card section
- Add link to "/admin/events" for build management

### 4. `/admin.tsx` - Sidebar Navigation

**Purpose**: Add Events link to sidebar menu

**Changes**:
- Import ActivityIcon from lucide-solid
- Add to menuItems: `{ icon: ActivityIcon, label: "Events", href: routes.adminEvents }`

---

## API Functions (Already Exist)

| Function | Endpoint | Usage |
|----------|----------|-------|
| `storesApi.getBuilds(publicId, limit)` | GET /vcs/builds | List builds |
| `storesApi.retryBuild(publicId, buildId)` | POST /vcs/builds/{id}/retry | Retry failed build |
| `storesApi.cancelBuild(publicId, buildId)` | POST /vcs/builds/{id}/cancel | Cancel pending/building |
| `storesApi.redeploy(publicId, branch?)` | POST /vcs/redeploy | Trigger new build |

---

## Files to Modify

| File | Changes |
|------|---------|
| `admin/src/routes/admin/events/index.tsx` | Fix store ID, add action buttons, update UI |
| `admin/src/routes/admin/logs/index.tsx` | Add Cancel button |
| `admin/src/routes/admin/settings/vcs.tsx` | Remove build history, add Events link |
| `admin/src/routes/admin.tsx` | Add Events to sidebar menu |

---

## Implementation Order

1. Update `/admin/events/index.tsx` (main changes)
2. Update `/admin/logs/index.tsx` (add Cancel)
3. Update `/admin/settings/vcs.tsx` (remove history, add link)
4. Update `/admin.tsx` (sidebar link)

---

## Acceptance Criteria

- [x] Events page loads using `admin.storeId()` (not route params)
- [x] Events page shows Retry button for failed builds
- [x] Events page shows Cancel button for pending/building builds
- [x] Events page shows Redeploy button in header
- [x] Logs page shows Cancel button during active build
- [x] VCS settings page has no build history section
- [x] VCS settings page links to Events page
- [x] Sidebar has Events link
