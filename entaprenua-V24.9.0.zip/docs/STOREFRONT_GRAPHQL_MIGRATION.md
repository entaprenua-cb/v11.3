# Storefront REST → GraphQL Migration

## Overview

The backend already has a **full GraphQL implementation** at `POST /api/v1/stores/{publicId}/graphql` using `graphql-kotlin-spring-server v9.2.0`. The storefront (SolidStart + TanStack Query) still uses **pure REST** via hand-rolled `fetch` calls in `src/lib/api/*.ts`.

This document is the migration plan to wire the storefront to GraphQL while keeping the existing `<Query>` component wrappers, `useQueryState()` pattern, and TanStack Query infrastructure intact.

## Tooling: graphql-request + graphql-codegen

### graphql-request

A minimal, fetch-based GraphQL client (~4kB). Sends raw GraphQL strings as POST requests and returns parsed JSON. Pairs naturally with TanStack Query because:

- No cache normalization (TanStack Query handles caching)
- No provider wrappers (just a client instance)
- Works with `queryFn` directly
- Supports `credentials: 'include'` for cookie-based auth

```ts
import { GraphQLClient } from 'graphql-request'

const client = new GraphQLClient('/api/v1/stores/{publicId}/graphql', {
  credentials: 'include',
  headers: { 'X-Store-API-Key': import.meta.env.VITE_STORE_API_KEY }
})

createQuery(() => ({
  queryKey: ['product', slug],
  queryFn: () => client.request(PRODUCT_QUERY, { slug })
}))
```

### graphql-codegen

`@graphql-codegen/cli` + `@graphql-codegen/typescript-graphql-request` introspects the running GraphQL schema and generates fully typed functions from `.graphql` files:

```graphql
# src/lib/graphql/queries/product.graphql
query Product($slug: String) {
  product(slug: $slug) { id name slug price image stockQuantity }
}
```

```ts
// Generated: src/lib/graphql/generated.ts
export const getProduct = (client: GraphQLClient, variables: ProductQueryVariables) =>
  client.request(ProductDocument, variables)
  // return type: ProductQuery — fully typed
```

## Auth & Store Resolution

**Store identity**: Resolved from `X-Store-API-Key` header (already sent in every request, `client.ts:39-43`). No `publicId` needed.

**Auth**: Cookie-based sessions (`credentials: 'include'`) and CSRF tokens continue to work. The GraphQL endpoint reads the same cookies/headers as REST.

**OTP / Auth flow** (`/auth/otp`, `/auth/verify`) stays REST.

## Backend GraphQL Schema

### Custom Scalars

```graphql
scalar UUID
scalar JSON
```

### Queries

| Query | Arguments | Return Type |
|-------|-----------|-------------|
| `product` | `id: String, slug: String` | `ProductGraphQL` |
| `products` | `filters: ProductFiltersInput, pagination: PaginationInput` | `ProductConnectionGraphQL!` |
| `categories` | `filters: CategoryFiltersInput` | `[CategoryGraphQL!]!` |
| `category` | `id: String, slug: String` | `CategoryGraphQL` |
| `cart` | `cartId: String` | `CartGraphQL` |
| `orderLookup` | `storeId: String!, orderNumber: String!, email: String!` | `OrderLookupResultGraphQL!` |
| `storeSettings` | (none) | `StoreSettingsGraphQL!` |
| `deliveryZones` | (none) | `[DeliveryZoneGraphQL!]!` |
| `deliveryZone` | `id: String!` | `DeliveryZoneGraphQL` |

### Mutations

| Mutation | Arguments | Return Type |
|----------|-----------|-------------|
| `addToCart` | `input: CartItemInput!` | `CartGraphQL!` |
| `updateCartItem` | `cartId, productId, quantity, selected` | `CartGraphQL!` |
| `removeCartItem` | `cartId, productId` | `Boolean!` |
| `createReview` | `input: CreateReviewInput!` | `ReviewGraphQL!` |
| `addToWishlist` | `input: WishlistInput!` | `Boolean!` |
| `removeFromWishlist` | `wishlistId: String!` | `Boolean!` |
| `checkout` | `input: CheckoutInput!` | `CheckoutResultGraphQL!` |

### Inputs

```kotlin
PaginationInput(cursor: String?, page: Int?, size: Int = 20)
ProductFiltersInput(search, status, visibility, categoryId, minPrice, maxPrice, sortBy, sortOrder, minRating)
CategoryFiltersInput(tree, root, parentId, level)
CartItemInput(cartId: String, productId: String, quantity: Int = 1)
CheckoutInput(cartId, provider = "mpesa", paymentPhone, guestEmail, customerEmail)
CreateReviewInput(productId, rating, title, content)
```

### Types

**ProductGraphQL**: `id, name, slug, price, compareToPrice, image, description, visibility, sku, stockQuantity, trackInventory, allowBackorder, weight, shippingClassId, averageRating, reviewCount`

**ProductConnectionGraphQL**: `items: [ProductGraphQL!]!, totalElements, hasMore, nextCursor`

**CategoryGraphQL**: `id, name, slug, image, level, parentId, path, children: [CategoryGraphQL!]!`

**CartGraphQL**: `id, items: [CartItemGraphQL!]!, subtotal, total, guestSessionId, guestEmail`

**CartItemGraphQL**: `id, productId, quantity, selected`

**OrderGraphQL**: `id, orderNumber, status, total, currency, paid, trackingNumber, items: [OrderItemGraphQL!]!`

**CheckoutResultGraphQL**: `success, orderId, orderNumber, total, currency, paymentMethod, status`

**ReviewGraphQL**: `id, rating, comment, authorName, createdAt`

**StoreSettingsGraphQL**: (all optional)
- `contact`: email, phone, address, latitude, longitude, workingHours[], customFields
- `social`: twitter, facebook, instagram, tiktok, linkedin, youtube, customFields
- `about`: story, mission, vision, values[], whyUs, customFields
- `email`: enabled, otpTemplate, senderName, senderEmail, tokenExpiryHours, domain, customFields
- `integrations`: googleMapsApiKey, googleClientId, googleClientSecret, facebookClientId, facebookClientSecret, oauthRedirectUrl, successRedirectUrl, customFields
- `currencies`: rates[{currency, rate, symbol}], customFields
- `delivery`: countries[], citiesByCountry[], deliveryTypes[], shippingClasses[]

## Phase 0: Backend — Add Missing Resolvers

| Feature | Backend Work |
|---------|-------------|
| **Heroes** | Add `HeroGraphQL` + `HeroItemGraphQL` types + `heroes` query in `StorefrontQueryResolver`. Delegate to existing `HeroGetService`. |
| **Recommendations** | Add `recommendations` query in `StorefrontQueryResolver`. Delegate to existing `RecommendationService`. |
| **Wishlist query** | Add `wishlist` query (only mutations exist). Delegate to `WishlistGetService`. |

## Phase 1: Client Infrastructure

1. Install: `npm install graphql-request graphql`
2. Install dev: `npm install -D @graphql-codegen/cli @graphql-codegen/typescript @graphql-codegen/typescript-graphql-request @graphql-codegen/introspection`
3. Create `src/lib/graphql/client.ts`
4. Create `codegen.ts` config pointing at the running GraphQL endpoint
5. Create `.graphql` files per domain in `src/lib/graphql/queries/` and `src/lib/graphql/mutations/`
6. Run `npx graphql-codegen` to generate `src/lib/graphql/generated.ts`

## Phase 2: Migrate API Modules

Each module is independent. Only the `queryFn` changes — `<Query>` wrappers, `useQueryState()`, `query-keys.ts`, and optimistic updates stay intact.

| Module | REST → GraphQL | Key Win |
|--------|---------------|---------|
| **settings** | 6 separate `GET /settings/:type` → 1 `storeSettings { contact social about email integrations currencies }` | 6→1 round-trips |
| **products** | `GET /products?page=&search=` → `query products(filters, pagination)` | Request-only fields |
| **categories** | `GET /categories?tree=true` → `query categories(filters: { tree: true }) { ... children }` | Single call for tree |
| **carts** | `GET /carts`, `POST /carts/:id/items` → `query cart`, `mutation addToCart` | Standardized |
| **reviews** | `GET /products/:id/reviews` → `product(id) { reviews { items } }` | Nested via field resolver |
| **orders** | `GET /orders/lookup` → `query orderLookup(...)` | Same complexity |
| **checkout** | Multi-step REST → `mutation checkout(input)` | 1 mutation |
| **wishlist** | `GET /wishlists` + `POST /wishlists` → `query wishlist` + `mutation addToWishlist` | Standardized |

### Modules staying REST

- Auth/OTP (`auth.ts`) — not exposed in GraphQL
- Sessions (`sessions.ts`) — not exposed
- Payments (`payments.ts`) — status is sub-field of checkout
- Heroes t — until backend resolver added
- Recommendations — until backend resolver added

## Phase 3: Component Updates

| Component | File | Change |
|-----------|------|--------|
| `ProductRoot` | `product-root.tsx` | Swap `queryFn` from `productsApi.getBySlug` to GraphQL |
| `ProductList` | `product-list.tsx` | Swap `queryFn` from `productsApi.getAll`/`search` to GraphQL |
| `CategoryRoot` | `category-root.tsx` | Swap `queryFn` from `categoriesApi.getBySlug` to GraphQL |
| `CartProvider` | `cart-context.tsx` | Swap all `createQuery`/`createMutation` `queryFn`s to GraphQL |
| `HeroRoot` | `hero-root.tsx` | Wait for backend hero resolver |
| `RecommendationsRoot` | `recommendations-root.tsx` | Wait for backend recommendations resolver |
| Settings consumers | various | Replace N `useQuery` calls with 1 `storeSettings` query |

## Phase 4: Clean Up

After full migration: remove unused `src/lib/api/*.ts` modules and `routes.ts` entries. Keep `client.ts` and `auth.ts` for auth/OTP REST endpoints.

## Execution Order

```
1. Backend: add hero + recommendations + wishlist query resolvers
2. Storefront: install graphql-request + graphql-codegen, generate schema
3. Migrate settings (biggest win: 6→1 round-trips)
4. Migrate products
5. Migrate categories
6. Migrate reviews
7. Migrate cart + checkout (most complex — optimistic updates)
8. Migrate wishlist
9. Clean up unused REST modules
```

Each step is incremental. REST and GraphQL coexist during migration. Rollback is per-module.
