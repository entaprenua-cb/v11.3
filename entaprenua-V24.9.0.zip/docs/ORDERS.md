# Orders Management

## Overview

The orders module provides functionality for managing store orders, including listing, viewing details, and updating order statuses.

## API Endpoints

### Orders API (`src/lib/api/orders.ts`)

```typescript
import { ordersApi, ORDER_STATUS_LABELS, ORDER_STATUS_COLORS } from "~/lib/api/orders"
```

#### Available Methods

| Method | Endpoint | Description |
|--------|----------|-------------|
| `getAll(storeId, params)` | `GET /stores/{storeId}/orders` | List orders with pagination, filtering, sorting |
| `getById(storeId, orderId)` | `GET /stores/{storeId}/orders/{id}` | Get single order details |
| `updateStatus(storeId, orderId, status)` | `PUT /stores/{storeId}/orders/{id}/status` | Update order status |
| `cancel(storeId, orderId)` | `PUT /stores/{storeId}/orders/{id}/status` | Cancel an order |

#### Parameters

**getAll params:**
```typescript
interface OrderSearchParams {
  page?: number       // Page number (0-indexed)
  size?: number      // Items per page
  status?: OrderStatus  // Filter by status
  search?: string   // Search order number
  sortBy?: 'created' | 'updated' | 'total'
  sortOrder?: 'asc' | 'desc'
}
```

#### Order Statuses

```typescript
type OrderStatus = 
  | 'pending'      // Order created, awaiting confirmation
  | 'confirmed'   // Order confirmed by merchant
  | 'processing'  // Order being prepared
  | 'shipped'     // Order shipped to customer
  | 'delivered'   // Order delivered
  | 'cancelled'   // Order cancelled
  | 'refunded'    // Order refunded
```

#### Helper Constants

- `ORDER_STATUS_LABELS` - Human-readable status labels
- `ORDER_STATUS_COLORS` - Badge variant colors for each status

## Routes

### Admin Orders List (`src/routes/admin/orders/index.tsx`)

- **Route:** `/admin/orders`
- **Features:**
  - Paginated orders table
  - Filter by status
  - Search by order number
  - Sort by date or total
  - Bulk status update
  - Individual status update dialog

### Order Detail (`src/routes/admin/orders/[id]/index.tsx`)

- **Route:** `/admin/orders/{id}`
- **Features:**
  - Full order information
  - Order items list with prices
  - Shipping/billing addresses
  - Order summary with totals
  - Status badge with update dialog
  - Print functionality

## Usage Examples

### Fetching Orders

```typescript
const response = await ordersApi.getAll(storeId, {
  page: 0,
  size: 20,
  status: 'pending',
  sortBy: 'created',
  sortOrder: 'desc'
})

// Access orders
const orders = response.content
const totalPages = response.totalPages
```

### Updating Order Status

```typescript
await ordersApi.updateStatus(storeId, orderId, 'processing')
```

### Displaying Status Badge

```tsx
import { Badge } from "~/components/ui"
import { ORDER_STATUS_LABELS, ORDER_STATUS_COLORS } from "~/lib/api/orders"

<Badge variant={ORDER_STATUS_COLORS[order.status]}>
  {ORDER_STATUS_LABELS[order.status]}
</Badge>
```

## Data Types

### Order Interface

```typescript
interface Order {
  id: string
  storeId: string
  customerId: string
  orderNumber: string
  status: OrderStatus
  currency: string
  subtotal: number
  tax: number
  shippingCost: number
  discount: number
  total: number
  billingAddress: Address | null
  shippingAddress: Address | null
  notes: string | null
  trackingNumber: string | null
  paid: boolean
  paidAt: string | null
  shippedAt: string | null
  deliveredAt: string | null
  cancelledAt: string | null
  refundedAt: string | null
  version: number
  insertedAt: string
  updatedAt: string
  lastModifiedBy: string | null
  items?: OrderItem[]
}

interface OrderItem {
  id: string
  orderId: string
  productId: string
  productName: string
  price: number
  quantity: number
  subtotal: number
}

interface Address {
  firstName: string
  lastName: string
  company?: string
  addressLine1: string
  addressLine2?: string
  city: string
  state?: string
  postalCode: string
  country: string
  phone?: string
}
```

## Integration with Admin Panel

The orders module integrates with the `useAdminPanel` store for store context:

```typescript
const admin = useAdminPanel()
const storeId = () => admin().currentStore?.id

// Use storeId in API calls
const orders = await ordersApi.getAll(storeId()!)
```
