# Product Reviews — Implementation Plan

## Overview

Product rating/review system with verified-purchase-only reviews, auto-approve moderation, and cached average rating on the products table.

## Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Verified purchase | Required | Only customers who purchased the product can review (check `orders` + `order_items`) |
| Moderation | Auto-approve (`status = 'approved'` by default) | Verified purchase is sufficient trust signal; admin can reject manually |
| Unique constraint | `UNIQUE(customer_id, product_id)` | One review per customer per product |
| Avg rating cache | DB trigger on `product_reviews` → updates `products.average_rating`, `review_count` | Avoids expensive `AVG()` aggregation on every product list query |
| Edit/Delete | Allowed | Customer can edit or delete own review |
| Product list filters | Add `minRating`, `sortBy: "rating"` | Filter/sort product list by rating |

## Database

### New table

```sql
CREATE TABLE product_reviews (
    id UUID DEFAULT gen_random_uuid() NOT NULL,
    product_id UUID NOT NULL REFERENCES products(id),
    customer_id UUID NOT NULL REFERENCES store_customers(id),

    rating SMALLINT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    title VARCHAR(255),
    content TEXT,
    status VARCHAR(20) DEFAULT 'approved' NOT NULL,

    version INTEGER DEFAULT 1 NOT NULL,
    is_deleted BOOLEAN DEFAULT false,
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),

    CONSTRAINT product_reviews_pkey PRIMARY KEY (id),
    CONSTRAINT product_reviews_unique_customer_product UNIQUE (customer_id, product_id)
);

CREATE INDEX idx_reviews_product_status ON product_reviews(product_id, status) WHERE is_deleted = false;
CREATE INDEX idx_reviews_customer ON product_reviews(customer_id) WHERE is_deleted = false;
```

### Cached columns on products

```sql
ALTER TABLE products ADD COLUMN average_rating NUMERIC(3,2) DEFAULT 0;
ALTER TABLE products ADD COLUMN review_count INTEGER DEFAULT 0;
```

### Trigger to maintain cache

```sql
CREATE OR REPLACE FUNCTION update_product_rating()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE products
    SET average_rating = (
        SELECT COALESCE(AVG(rating)::numeric(3,2), 0)
        FROM product_reviews
        WHERE product_id = COALESCE(NEW.product_id, OLD.product_id)
        AND status = 'approved'
        AND is_deleted = false
    ),
    review_count = (
        SELECT COUNT(*)
        FROM product_reviews
        WHERE product_id = COALESCE(NEW.product_id, OLD.product_id)
        AND status = 'approved'
        AND is_deleted = false
    )
    WHERE id = COALESCE(NEW.product_id, OLD.product_id);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_product_review_rating
    AFTER INSERT OR UPDATE OR DELETE ON product_reviews
    FOR EACH ROW EXECUTE FUNCTION update_product_rating();
```

## Entity

```kotlin
// entities/ProductReview.kt
@Serializable
data class ProductReview(
    val id: UUID? = null,
    val productId: UUID,
    val customerId: UUID,
    val rating: Int,
    val title: String? = null,
    val content: String? = null,
    val status: String = "approved",
    val version: Int = 1,
    val isDeleted: Boolean = false,
    val insertedAt: OffsetDateTime? = null,
    val updatedAt: OffsetDateTime? = null
)
```

## DTOs

```kotlin
// store/dtos/ProductReviewDto.kt
@Serializable
data class ProductReviewInput(
    val rating: Int,
    val title: String? = null,
    val content: String? = null,
)

@Serializable
data class ProductReviewUpdateInput(
    val rating: Int? = null,
    val title: String? = null,
    val content: String? = null,
)

@Serializable
data class ProductReviewDto(
    val id: String,
    val productId: String,
    val customer: ReviewCustomer?,
    val rating: Int,
    val title: String? = null,
    val content: String? = null,
    val status: String,
    val verifiedPurchase: Boolean,
    val insertedAt: String,
    val updatedAt: String,
) {
    companion object {
        fun fromEntity(review: ProductReview, customer: ReviewCustomer?, verifiedPurchase: Boolean): ProductReviewDto
    }
}

@Serializable
data class ReviewCustomer(
    val name: String,
    val avatarUrl: String? = null,
)

@Serializable
data class ProductReviewStats(
    val averageRating: BigDecimal,
    val totalReviews: Int,
    val distribution: Map<Int, Int>,  // { 1: 2, 2: 3, 3: 8, 4: 15, 5: 19 }
)
```

### ProductFilters additions

```kotlin
// Add to existing ProductFilters
val minRating: String? = null,     // filter by minimum average rating
```

### ProductDto additions

```kotlin
// Add to existing ProductDto
val averageRating: String? = null,
val reviewCount: Int = 0,
```

## Repository

```kotlin
// store/repositories/ProductReviewRepository.kt
@Repository
class ProductReviewRepository(private val dsl: DSLContext) {

    // Find approved reviews for a product (public)
    fun findByProductId(productId: UUID, offset: Int, limit: Int, sortBy: String?, sortOrder: String?): Flow<ProductReview>
    
    // Find all reviews for admin (with status filter)
    fun findByStoreId(storeId: UUID, status: String?, offset: Int, limit: Int): Flow<ProductReview>
    
    // Find by ID
    suspend fun findById(id: UUID): ProductReview?
    
    // Find by customer + product (for edit/delete ownership check)
    suspend fun findByCustomerAndProduct(customerId: UUID, productId: UUID): ProductReview?
    
    // Create
    suspend fun save(review: ProductReview): ProductReview?
    
    // Update
    suspend fun update(review: ProductReview): Boolean
    
    // Soft delete
    suspend fun delete(id: UUID): Boolean
    
    // Update status (admin approve/reject)
    suspend fun updateStatus(id: UUID, status: String): Boolean
    
    // Purchase verification
    suspend fun hasPurchasedProduct(customerId: UUID, productId: UUID): Boolean
    
    // Rating stats
    suspend fun getStats(productId: UUID): ProductReviewStats?
    
    // Count
    suspend fun countByProductId(productId: UUID): Long
    suspend fun countByStoreId(storeId: UUID, status: String?): Long
}
```

## Service Interfaces

```kotlin
// store/services/ProductReviewGetService.kt
@Service
interface ProductReviewGetService {
    suspend fun getByProduct(request: ServerRequest): ServerResponse
    suspend fun getStats(request: ServerRequest): ServerResponse
    suspend fun getAll(request: ServerRequest): ServerResponse       // admin
}

// store/services/ProductReviewSaveService.kt
@Service
interface ProductReviewSaveService {
    suspend fun create(request: ServerRequest): ServerResponse
    suspend fun update(request: ServerRequest): ServerResponse
    suspend fun delete(request: ServerRequest): ServerResponse
    suspend fun updateStatus(request: ServerRequest): ServerResponse  // admin
}
```

## API Routes

```
# Public — approved reviews only
GET    /{publicId}/products/{productId}/reviews
       → productReviewGetService::getByProduct
       Query: page, size, sortBy (newest|oldest|highest|lowest)

GET    /{publicId}/products/{productId}/reviews/stats
       → productReviewGetService::getStats

# Customer (extracts customerId from storefront session/cookie)
POST   /{publicId}/products/{productId}/reviews
       → productReviewSaveService::create

PUT    /{publicId}/products/{productId}/reviews/{id}
       → productReviewSaveService::update
       (verifies ownership: matches request customerId)

DELETE /{publicId}/products/{productId}/reviews/{id}
       → productReviewSaveService::delete
       (verifies ownership)

# Admin (editor+ role)
GET    /{publicId}/reviews?status=pending
       → productReviewGetService::getAll

PATCH  /{publicId}/reviews/{id}/status
       → productReviewSaveService::updateStatus
       Body: { "status": "approved" | "rejected" }
```

## Purchase Verification

Check that the customer has a delivered/paid order containing the product:

```kotlin
suspend fun hasPurchasedProduct(customerId: UUID, productId: UUID): Boolean {
    return Flux.from(
        dsl.selectOne()
            .from(orders)
            .join(orderItems).on(orderItems.ORDER_ID.eq(orders.ID))
            .where(orders.CUSTOMER_ID.eq(customerId))
            .and(orderItems.PRODUCT_ID.eq(productId))
            .and(orders.STATUS.`in`("delivered", "paid", "processing"))
            .and(orders.IS_DELETED.eq(false))
            .limit(1)
    ).awaitFirstOrNull() != null
}
```

## Average Rating in Product List

### On product queries

`ProductRepository` already has `findAllByStoreIdFiltered()`, `findAllByStoreIdPaginated()`, etc. The `productBaseRow` needs to include `average_rating` and `review_count` columns. The `mapToProduct()` and `ProductDto.fromEntity()` need to pass these through.

### minRating filter

Add to `findAllByStoreIdFiltered()`:

```kotlin
filters.minRating?.let { minRating ->
    queryBuilder = queryBuilder.and(productsTable.AVERAGE_RATING.ge(minRating.toBigDecimal()))
}
```

### sortBy: "rating"

```kotlin
"rating" -> if (filters.sortOrder?.lowercase() == "desc") 
    queryBuilder.orderBy(productsTable.AVERAGE_RATING.desc()) 
else 
    queryBuilder.orderBy(productsTable.AVERAGE_RATING.asc())
```

## Files to Create (8)

| # | File |
|---|------|
| 1 | `backend/src/main/resources/db/migration/V69__Create_product_reviews.sql` |
| 2 | `backend/src/main/kotlin/com/entaprenua/entities/ProductReview.kt` |
| 3 | `backend/src/main/kotlin/com/entaprenua/store/dtos/ProductReviewDto.kt` |
| 4 | `backend/src/main/kotlin/com/entaprenua/store/repositories/ProductReviewRepository.kt` |
| 5 | `backend/src/main/kotlin/com/entaprenua/store/services/ProductReviewGetService.kt` |
| 6 | `backend/src/main/kotlin/com/entaprenua/store/services/ProductReviewSaveService.kt` |
| 7 | `backend/src/main/kotlin/com/entaprenua/store/impl/ProductReviewGetServiceImpl.kt` |
| 8 | `backend/src/main/kotlin/com/entaprenua/store/impl/ProductReviewSaveServiceImpl.kt` |

## Files to Modify (3)

| # | File | Change |
|---|------|--------|
| 9 | `config/ApiRouterConfig.kt` | Add review routes + inject service constructors |
| 10 | `store/dtos/ProductDto.kt` | Add `averageRating`, `reviewCount` to ProductDto; add `minRating` to ProductFilters |
| 11 | `store/repositories/ProductRepository.kt` | Include avg_rating/review_count in queries, add minRating filter, add sortBy: "rating" |

## Post-Implementation

```bash
gradle jooqCodegen   # Regenerate JOOQ classes for new table
```
