# Parser Integration Implementation Plan

## Overview
Integrate the parser into the upload system for production-readiness. The parser validates JSX components against the registry and provides proper error handling.

---

## Files to Modify

### 1. Create: `src/routes/api/parse/index.ts`
New API endpoint for parsing single JSX code snippets.

**Features:**
- Accept JSON body with `code` field
- Validate code is string, not empty
- Validate code length (max 500KB)
- Call parser and return result
- Proper error responses

**Response Format:**
```typescript
// Success
{ success: true, data: JsxNode, warnings: [], metadata: {...} }

// Error
{ success: false, error: "Error message" }
```

---

### 2. Modify: `src/lib/server/upload.ts`
Update to use actual parser instead of regex.

**Changes:**
- Import parser
- Replace `parsePageContent` function to use parser
- Add file extension validation (.tsx, .jsx only)
- Add file size validation (max 500KB per file)
- Handle parse failures with fallback (preserve original name)
- Remove framework detection (only SolidStart)
- Support both .tsx and .jsx files in src/routes/

**Fallback Strategy:**
- On parse failure: store `{ name: 'userSentName', rawJsx: 'original code' }`
- This allows renderer to show "Unknown: userSentName" placeholder

**Default Page:**
- If no files found in src/routes/, create default home page

---

### 3. Modify: `src/routes/api/stores/import.ts`
Simplify by removing framework detection.

**Changes:**
- Remove Next.js/SolidStart detection
- Always treat as SolidStart codebase
- Pass files directly to upload service

---

## Validation Checklist

- [x] Parse endpoint accepts valid JSX
- [x] Parse endpoint rejects empty code (400)
- [x] Parse endpoint rejects oversized code (413)
- [x] Parse endpoint returns proper errors
- [x] Upload accepts .tsx files
- [x] Upload accepts .jsx files
- [x] Upload rejects other extensions (return error)
- [x] Upload rejects oversized files (>500KB)
- [x] Upload handles parse failures gracefully (fallback)
- [x] Upload creates default page when no routes
- [x] Import endpoint works without framework detection

---

## Limits

| Parameter | Value |
|-----------|-------|
| Max code size (parse endpoint) | 500KB |
| Max file size (upload) | 500KB per file |
| Supported extensions | .tsx, .jsx |

---

## Error Handling

| Scenario | Behavior |
|----------|----------|
| Empty code | Return 400: `{ error: "Code is required" }` |
| Code too large | Return 413: `{ error: "Code exceeds 500KB limit" }` |
| Invalid file extension | Skip file, log warning |
| File too large | Skip file, log warning |
| Parse failure | Store fallback: `{ name: 'origName', rawJsx: '...' }` |
| No routes found | Create default home page |

---

## Implementation Order

1. Create parser API endpoint
2. Test parser endpoint
3. Update upload service
4. Update import endpoint
5. Test full flow

---

## Future Improvements

### Phase 1: Basic Improvements

| Optimization | Description |
|--------------|-------------|
| **ZIP support** | Extract and process ZIP files containing codebases |
| **Parallel parsing** | Use `Promise.all()` for concurrent parsing of multiple files |
| **File filtering** | Skip `node_modules`, `.git`, test files (`*.test.tsx`, `*.spec.tsx`) |
| **Size limits** | Max total codebase size (e.g., 10MB) |

### Phase 2: Incremental Uploads

**How File Change Detection Works:**

1. **First Upload:** Parse all files, store file hashes in database
```typescript
// Database schema addition
interface PageFile {
  id: string;
  pageId: string;
  filePath: string;
  contentHash: string;  // SHA-256 hash
  parsedContent: Json;
  updatedAt: Date;
}
```

2. **Re-upload:** Compare file hashes, skip unchanged files
```typescript
async function processUpload(files: Record<string, string>) {
  for (const [path, content] of Object.entries(files)) {
    const newHash = await computeHash(content);
    const stored = await getStoredFile(path);
    
    if (stored && stored.contentHash === newHash) {
      // File unchanged - skip parsing
      continue;
    }
    
    // File changed or new - parse and store
    const parsed = parse(content);
    await saveFile(path, newHash, parsed);
  }
}
```

**Benefits:**
- Faster re-uploads (skip unchanged files)
- Less server processing
- Better user experience

**Requirements:**
- Database schema update (add `file_hash` column)
- Client-side: track modified files (optional)

### Phase 3: Production Features

| Feature | Description |
|---------|-------------|
| **Rate limiting** | Prevent abuse (e.g., max 10 uploads/minute) |
| **Queue system** | Process large uploads in background job |
| **Progress tracking** | Return upload progress to client |
| **Streaming ZIP** | Process files as they're extracted (memory efficient) |
| **Web Workers** | Offload parsing to background threads |
| **Caching** | Cache parsed results by file hash |

---

## Performance Considerations

### Current: Sequential Processing
```
File 1 → Parse → Save
File 2 → Parse → Save
File 3 → Parse → Save
(total time = sum of all)
```

### Future: Parallel Processing
```
File 1 ─┐
File 2 ─┼─→ Parse (concurrent) → Save
File 3 ─┘
(total time = max of all)
```

### Benchmark Targets

| Metric | Current | Target |
|--------|---------|--------|
| Parse single file (10KB) | ~5ms | ~5ms |
| Parse 100 files | ~500ms | ~100ms (parallel) |
| Full codebase upload (10MB) | N/A | <5s |
