# Systemd Store Management

## Status

**Target architecture**: systemd user services per store
**Implementation**: Planned (2026-05-14)
**Replaces**: `ProcessBuilder` + in-memory `processes` map + heartbeat loop

---

## Overview

Migrate store Node process lifecycle from Java `ProcessBuilder` (in-memory `ConcurrentHashMap`) to systemd user services. The backend delegates spawning, monitoring, and crash recovery to systemd — the industry-standard process supervisor for Linux.

### Architecture Change

```
BEFORE:                              AFTER:

Backend (ProcessBuilder)             Backend (systemctl --user)
  │                                     │
  ├─ spawns node process               ├─ writes unit file
  ├─ tracks PID in ConcurrentHashMap   ├─ systemctl start
  ├─ heartbeats every 60s              ├─ systemctl stop
  ├─ must clean up on @PreDestroy      └─ systemd owns lifecycle
  └─ on crash: marks DB "crashed"            │
                                       ├─ auto-restarts on crash
                                       ├─ cgroup cleanup (no orphans)
                                       ├─ journald logging
                                       └─ survives backend restart
```

### Why systemd

| Requirement | ProcessBuilder | systemd |
|-------------|----------------|---------|
| Auto-restart on crash | ❌ (heartbeat detects, marks crashed) | ✅ (Restart=on-failure, RestartSec=5) |
| No orphaned processes | ❌ (cgroup boundary is process-group) | ✅ (systemd cgroup — all children tracked) |
| Logs survive backend restart | ❌ (in-memory process logger lost) | ✅ journald — `journalctl -u entaprenua-store-{id}` |
| Backend restart kills stores | ❌ (PreDestroy kills children) | ✅ (systemd owns them, they keep running) |
| Code complexity | ~200 lines + heartbeat + process tracking | ~50 lines + SystemdService wrapper |

---

## How It Works

### Start Flow

```
1. Client clicks "Start Store"
2. Backend allocates port              (allocatePort())
3. Backend builds systemd unit file     (SystemdService.buildUnitFile())
4. Backend writes unit to ~/.config/systemd/user/   (SystemdService.start())
5. Backend runs: systemctl --user daemon-reload
6. Backend runs: systemctl --user start entaprenua-store-{publicId}
7. Backend runs: systemctl --user enable entaprenua-store-{publicId}
8. systemd spawns: node server/index.mjs with PORT={port} + env vars
9. Backend waits briefly, checks systemctl --user is-active
10. Backend writes port to Redis + DB (status="running")
```

### Stop Flow

```
1. Client clicks "Stop Store"
2. Backend runs: systemctl --user stop entaprenua-store-{publicId}
3. systemd sends SIGTERM to process + all cgroup children
4. If process doesn't exit in 90s, systemd sends SIGKILL
5. Backend runs: systemctl --user disable entaprenua-store-{publicId}
6. Backend removes unit file
7. Backend clears Redis + DB (status="stopped")
```

### Crash Flow

```
1. Node process crashes (OOM, uncaught exception, segfault)
2. systemd detects exit code != 0
3. systemd waits 5s (RestartSec)
4. systemd re-spawns the process on the SAME port
5. Backend is NOT involved — no heartbeat, no detection needed
6. Redis still has port mapping — traffic continues flowing
```

### Backend Restart Flow

```
1. systemd starts entaprenua-backend.service
2. @EventListener(ApplicationReadyEvent) fires
3. Queries DB: WHERE storefront_status = 'running'
4. For each store:
   a. Check: systemctl --user is-active entaprenua-store-{publicId}
   b. If active → store is already running → refresh in-memory maps
   c. If inactive/failed → systemctl --user reset-failed, then start
5. Store processes that were running remain running throughout
```

### Backend Shutdown Flow

```
1. systemctl stop entaprenua-backend.service
2. @PreDestroy fires
3. Store processes are NOT stopped — systemd owns them
4. DB status stays "running"
5. On restart, stores are found via is-active check
```

---

## New File: `SystemdService.kt`

Location: `backend/src/main/kotlin/com/entaprenua/storefront/SystemdService.kt`

### Responsibilities

- Build systemd unit file strings for stores
- Write/remove unit files to `~/.config/systemd/user/`
- Execute `systemctl --user <command> <unit>` and parse results
- Provide `start()`, `stop()`, `isActive()`, `isFailed()` methods

### Unit File Template

```
[Unit]
Description=Entaprenua Store {publicId}
After=network.target

[Service]
Type=simple
Environment=PORT={port}
Environment=STORE_DOMAIN={domain}
Environment=STORE_ID={storeId}
Environment=STORE_PUBLIC_ID={publicId}
Environment=STORE_API_KEY={decryptedKey}
ExecStart=/usr/bin/node {basePath}/{storeId}/server/index.mjs
WorkingDirectory={basePath}/{storeId}
Restart=on-failure
RestartSec=5
StartLimitIntervalSec=60
StartLimitBurst=3
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=default.target
```

### API

```kotlin
class SystemdService(
    private val config: StorefrontConfig
) {
    fun buildUnitFile(storeId: String, publicId: String, port: Int, domain: String, env: Map<String,String>): String
    suspend fun start(publicId: String, unitFile: String): Result<Unit>
    suspend fun stop(publicId: String): Result<Unit>
    suspend fun isActive(publicId: String): Boolean
    suspend fun isFailed(publicId: String): Boolean
    suspend fun listRunning(): List<String>  // list active store unit names
}
```

---

## Changes to `ProcessManagerService.kt`

### Removed

| Method / Field | Reason |
|----------------|--------|
| `processes: ConcurrentHashMap<String, StoreProcess>` | No need — systemd tracks processes |
| `heartbeatJobs: ConcurrentHashMap<String, Job>` | No heartbeat needed |
| `portToStoreId: ConcurrentHashMap<Int, String>` | Kept for port allocation |
| `assignedPorts: ConcurrentHashMap<String, PortInfo>` | **New** — thin: storeId → (port, domain, publicId) |
| `launchProcessLogger()` | systemd journald handles logs |
| `waitForHealthy()` | systemd is-active after start |
| `cleanupFailedStart()` | No cleanup needed |
| `reconnectStore()` | No reconnection needed |
| `startHeartbeat()` / `stopHeartbeat()` | No heartbeat |
| `isPortInUse()` (for recovery) | Only needed for allocatePort |
| `@PreDestroy shutdown()` (process kill) | No-op for stores |
| `RedisService` for heartbeat | Only needed for register/unregister |

### Simplified

| Method | Old | New |
|--------|-----|-----|
| `startStore()` | Spawns ProcessBuilder, starts heartbeat | Builds unit file, systemctl start, checks is-active |
| `stopStore()` | Kills Process, removes from maps | systemctl stop, removes unit file |
| `getStoreStatus()` | Checks process.isAlive + port fallback | Checks systemctl is-active |
| `onApplicationReady()` | Queries port in use, reconnects or restarts | Queries systemctl is-active, starts if needed |
| `allocatePort()` | Scans basePort..basePort+maxStores | Scans basePort..65535 (unlimited, from Pillar 1) |

---

## Changes to `StoreServiceImpl.kt`

### Status Endpoint (`GET /{publicId}/status`)

Minor change to match the new `getStoreStatus()` signature. The API response shape stays the same — frontend changes are minimal (just add `lastStatus` field).

### Start Endpoint (`POST /{publicId}/start`)

No changes — it calls `processManager.startStore()` which now uses systemd underneath.

### Stop Endpoint (`POST /{publicId}/stop`)

No changes — it calls `processManager.stopStore()` which now uses systemd underneath.

---

## Changes to `StorefrontConfig.kt`

```kotlin
class StorefrontConfig {
    var basePath: String = "/var/lib/entaprenua/stores"
    var basePort: Int = 3000
    // maxStores removed — no limit
    var startTimeoutSeconds: Int = 30
    var processManagerEnabled: Boolean = true
    // heartbeatIntervalSeconds removed — no heartbeat
}
```

---

## Changes to `application.properties`

```properties
# Remove:
# app.storefront.heartbeat-interval-seconds=60

# Keep:
app.storefront.redis-key-prefix=storefront:
app.storefront.redis-ttl-seconds=300
```

Redis TTL can be increased (e.g., 3600s) since no heartbeat refreshes it. The entry is only written on start and deleted on stop. If the TTL expires, OpenResty returns 502 and the backend status endpoint falls back to systemctl check.

---

## VPS Setup

### One-Time Commands

```bash
# Enable user services to survive logout
ssh root@vps "loginctl enable-linger nesh"

# Verify it's enabled
ssh root@vps "loginctl show-user nesh | grep Linger"
# Should show: Linger=yes

# Test that nesh can manage user services
ssh nesh@vps "systemctl --user list-units"
```

### Verification

```bash
# After deploying, start a store and check:
ssh nesh@vps "systemctl --user list-units 'entaprenua-store-*'"
# Should show: entaprenua-store-{publicId}.service loaded active running

# Check logs:
ssh nesh@vps "journalctl --user -u entaprenua-store-{publicId} --no-pager -n 20"
```

---

## Rollback Plan

If systemd integration needs to be reverted:

1. Revert all changes in `ProcessManagerService.kt` to the ProcessBuilder-based implementation
2. Delete `SystemdService.kt`
3. Revert `StorefrontConfig.kt` and `application.properties`
4. Delete all generated unit files on VPS:
   ```bash
   ssh nesh@vps "rm -f ~/.config/systemd/user/entaprenua-store-*.service"
   ssh nesh@vps "systemctl --user daemon-reload"
   ```
5. Restart backend

---

## Testing Scenarios

| Scenario | Expected Behavior |
|----------|-------------------|
| Start store via admin UI | systemd unit created + started, status shows "Running" |
| Stop store via admin UI | systemd unit stopped + removed, status shows "Stopped" |
| Kill store process manually (`kill -9 <pid>`) | systemd auto-restarts within 5s, UI still shows "Running" |
| Kill store process 4 times in 60s | systemd stops restarting (StartLimitBurst=3), status shows "Failed" |
| Restart backend service | Stores remain running (systemd owns them), status still shows "Running" |
| Restart VPS | systemd auto-starts store services on boot, status shows "Running" |
| New build deployed (VCS) | BuildQueueService stops old unit, creates new unit, starts it |
| Redis expires (TTL runs out) | OpenResty returns 502 → status endpoint falls back to systemctl check |

### Test Commands

```bash
# Simulate crash
ssh nesh@vps "systemctl --user status entaprenua-store-{publicId}"  # get MainPID
ssh nesh@vps "kill -9 {MainPID}"
ssh nesh@vps "sleep 6 && systemctl --user is-active entaprenua-store-{publicId}"  # should show "active"

# Check restart count
ssh nesh@vps "systemctl --user show entaprenua-store-{publicId} -p NRestarts"

# Simulate crash loop (4 rapid kills)
for i in 1 2 3 4; do
  PID=$(ssh nesh@vps "systemctl --user show entaprenua-store-{publicId} -p MainPID --value")
  ssh nesh@vps "kill -9 $PID"
  sleep 1
done
# After 4th: should show "failed"
```

---

## Migration Steps (Production)

1. **Prepare VPS**: `loginctl enable-linger nesh`
2. **Deploy backend with systemd code**: The `ProcessManagerService` now uses systemd
3. **Migrate running stores on deploy**:
   - `onApplicationReady()` queries `findRunningStorefronts()`
   - For each with `status = "running"`:
     - If systemd unit already exists and is active → refresh maps (zero-downtime)
     - If systemd unit doesn't exist → create unit, `systemctl start` (brief downtime)
   - For each with active systemd unit but DB status = "stopped" → stop unit

### Zero-Downtime Migration

On first deploy with systemd code:
1. All current stores are running via ProcessBuilder
2. The backend will be stopped (old code) — all store processes die
3. New backend starts, `onApplicationReady()` runs
4. DB still has `status = "running"` for these stores
5. For each, systemd creates a unit and starts the store
6. Total downtime: time for backend restart + stores to start (~10-30s)
7. Future backend restarts: zero downtime for stores (they keep running)

---

## Files

| File | Action |
|------|--------|
| `backend/.../storefront/SystemdService.kt` | CREATE |
| `backend/.../storefront/ProcessManagerService.kt` | REFACTOR |
| `backend/.../storefront/StorefrontConfig.kt` | UPDATE |
| `backend/.../store/impl/StoreServiceImpl.kt` | MINOR UPDATE |
| `backend/src/main/resources/application.properties` | UPDATE |
| `docs/STORE_PERSISTENCE.md` | UPDATE (reference this doc) |
