# Orders Admin

Order management UI with list, status updates, and detail view.

## File Structure

```
src/routes/admin/orders/
├── index.tsx                    # List page with filters, status badges
├── [id]/
│   └── index.tsx               # View/Edit order details
```

## Features

### List Page (`index.tsx`)
- Search by order number
- Filter by status (pending, confirmed, processing, shipped, delivered, cancelled, refunded)
- Sort by date or total
- Pagination
- Bulk status update
- Quick status update dialog
- Table columns: Checkbox, Order #, Status, Customer, Items, Total, Date, Actions

### Detail Page (`[id]/index.tsx`)
- Order information (number, dates, status)
- Order items table with product, quantity, price
- Billing/Shipping addresses
- Status management
- Order notes
- Print invoice button

## Data Model

```typescript
interface Order {
  id: string;
  storeId: string;
  customerId: string;
  orderNumber: string;
  status: OrderStatus;
  currency: string;
  subtotal: string;
  tax: string;
  shippingCost: string;
  discount: string;
  total: string;
  billingAddress: Address | null;
  shippingAddress: Address | null;
  notes: string | null;
  trackingNumber: string | null;
  paid: boolean;
  paidAt: string | null;
  shippedAt: string | null;
  deliveredAt: string | null;
  cancelledAt: string | null;
  refundedAt: string | null;
  insertedAt: string;
  updatedAt: string;
  items: OrderItem[] | null;
}

interface OrderItem {
  id: string;
  orderId: string;
  productId: string;
  productName: string;
  price: string;
  quantity: number;
  subtotal: string;
}

type OrderStatus = 
  | "pending" 
  | "processing" 
  | "shipped" 
  | "delivered" 
  | "cancelled" 
  | "refunded" 
  | "returned"
```

## API Usage

```typescript
import { ordersApi } from "~/"

// Get all orderslib/api/orders (returns PagedResponse)
const response = await ordersApi.getAll(storeId)
const orders = response.content ?? []
const total = response.totalElements ?? 0

// Get order by ID
const response = await ordersApi.getById(storeId, id)

// Create order
const response = await ordersApi.create(storeId, { ... })

// Update order status
const response = await ordersApi.updateStatus(storeId, id, "shipped")

// Delete order
await ordersApi.delete(storeId, id)
```

## Status State Machine

Valid transitions:
- `pending` → `processing`, `cancelled`
- `processing` → `shipped`, `cancelled`
- `shipped` → `delivered`, `returned`
- `delivered` → `returned`, `refunded`
- `cancelled` → `refunded`
- `returned` → `refunded`

## Notes

- Orders are primarily created via checkout flow, not manually
- Main admin action is status updates
- Follow same patterns as products/categories: DataTableServer, quick edit dialog, form sections
