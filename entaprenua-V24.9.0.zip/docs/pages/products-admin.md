# Products Admin Module

## Overview

The products admin module provides comprehensive product management capabilities including CRUD operations, media management, metadata handling, and enterprise-grade list management with pagination, sorting, filtering, and bulk actions.

## Directory Structure

```
src/routes/admin/products/
├── index.tsx                           # Products list page
├── new.tsx                             # Create new product
├── [id]/
│   └── index.tsx                      # Edit existing product
├── product-editor-context.tsx          # Shared editor provider
├── product-quick-edit.tsx              # Quick edit dialog
├── ProductForm.tsx                    # Main product form wrapper
└── sections/
    ├── index.ts                       # Barrel export
    ├── ProductBasicInfoSection.tsx    # Name, description, price
    ├── ProductInventorySection.tsx    # Stock, thresholds
    ├── ProductImageSection.tsx        # Featured image
    ├── ProductMediaSection.tsx        # Media gallery
    ├── ProductMetadataSection.tsx     # Custom metadata
    └── ProductVisibilitySection.tsx    # Visibility, status
```

## Architecture

### ProductEditorProvider

The module uses a context-based architecture with `ProductEditorProvider` for centralized state management:

```typescript
// Usage in ProductForm
<ProductEditorProvider
  storeId="..."
  mode="create" | "edit"
  initialProduct={...}
  initialMedia={...}
  initialMetadata={...}
  initialImage={...}
  onSaved={(product) => ...}
  onDeleted={() => ...}
>
  <ProductFormContent />
</ProductEditorProvider>
```

### Quick Edit

Quick edit uses the same provider with `isQuickEdit` flag for simplified save behavior:

```typescript
<ProductEditorProvider
  storeId="..."
  mode="edit"
  isQuickEdit={true}
  initialProduct={product}
>
  <QuickEditForm />
</ProductEditorProvider>
```

## Routes

| Route | Method | Description |
|-------|--------|-------------|
| `/admin/products` | GET | List all products (paginated) |
| `/admin/products/new` | GET | Create new product form |
| `/admin/products/:id` | GET | Edit existing product |

## Dependencies

```bash
npm install @tanstack/solid-table
```

This module uses `@tanstack/solid-table` for the data table component.

## Product List (index.tsx) - Enterprise Grade

### Features

**Pagination**
- Server-side pagination via `productsApi.getAll()` or `productsApi.search()`
- Previous/Next buttons with page indicator
- Shows "Showing X of Y products" count

**Sorting**
- Click column headers to sort
- Sortable columns: Name, Price, Stock, Visibility
- Visual indicator (chevron icons) for current sort
- Toggle between ascending/descending

**Filtering**
- **Search** - Search by product name or ID
- **Status filter** - All Status, In Stock, Low Stock, Out of Stock, Not Tracked
- **Visibility filter** - All, Public, Private, Draft

**Bulk Actions**
- Checkbox for each row to select products
- "Select All" checkbox in header
- Bulk delete with confirmation dialog
- Shows count of selected items

**Editing Options (3 Levels)**

| Method | Use Case | Access |
|--------|-----------|--------|
| Inline | Stock quantity only | Direct input in table |
| Quick Edit Dialog | Name, price, visibility | Edit button in row |
| Full Page | Media gallery, metadata, full settings | More (⋯) button |

### Actions Column

| Button | Action | Opens |
|--------|--------|-------|
| Edit (pencil) | Quick edit dialog | Dialog |
| More (⋯) | Full editor | New page |
| Delete (trash) | Delete product | Confirmation |

**Note:** Image can only be changed in the full page editor.

### Data Flow
```
TanStack Query
  └─> productsApi.getAll(storeId, page, pageSize) 
     OR productsApi.search(query, storeId, page, pageSize)
  └─> Client-side: sort + filter + status badges
  └─> AdminPanelProvider for mutations (delete, update stock)
```

## Product Form Sections

### ProductBasicInfoSection
- Product name (required)
- Description
- Price
- Compare at price

### ProductInventorySection
- Track inventory toggle
- Stock quantity (when tracking)
- Low stock threshold
- Out of stock threshold
- Allow backorder toggle

### ProductImageSection
- Featured image upload
- Image preview
- Delete image

### ProductMediaSection
- Multi-file upload (images, videos, audio)
- Preview media in grid layout
- Delete existing media
- Max 15 files limit

### ProductMetadataSection
- Add/Edit/Delete custom key-value pairs
- Schema.org properties support

### ProductVisibilitySection
- Visibility dropdown (Draft, Private, Public)
- Status badge preview

## Server Integration

### Endpoints Used
- `GET /api/v1/stores/{storeId}/products` - List products (paginated)
- `GET /api/v1/stores/{storeId}/products/search` - Search products
- `GET /api/v1/stores/{storeId}/products/:id?includeMedia=true` - Get product
- `POST /api/v1/stores/{storeId}/products` - Create product
- `PUT /api/v1/stores/{storeId}/products/:id` - Update product
- `DELETE /api/v1/stores/{storeId}/products/:id` - Delete product
- `POST /api/v1/media?storeId=...` - Upload media files

### ProductSaveService (Server)
Expects metadata and media as maps:
- `metadata: Map<String, String>` - key-value pairs
- `media: Map<String, String>` - id-url pairs

Special values:
- `"deleted"` in media map → delete that media
- Key starting with `"new-"` in media map → new media entry

## Types

### ProductFilters
```typescript
interface ProductFilters {
  status?: "in_stock" | "low_stock" | "out_of_stock" | "not_tracked"
  visibility?: "public" | "private" | "draft"
  categoryId?: string
  minPrice?: number
  maxPrice?: number
  sortBy?: "name" | "price" | "stockQuantity" | "visibility" | "createdAt"
  sortOrder?: "asc" | "desc"
}
```

### ProductFormData
```typescript
type ProductFormData = {
  name: string
  description: string
  price: string
  compareToPrice: string
  stockQuantity: number
  trackInventory: boolean
  allowBackorder: boolean
  lowStockThreshold: number
  outOfStockThreshold: number
  visibility: "public" | "private" | "draft"
}
```

### ProductMediaEntry
```typescript
type ProductMediaEntry = {
  id: string
  url: string
  type: string // "image" | "video" | "audio"
  isNew?: boolean
  isDeleted?: boolean
  file?: File
}
```

## State Management

- **TanStack Query** - Server state, caching, pagination, loading states
- **TanStack Table** - Table state (sorting, filtering, pagination, selection)
- **ProductEditorProvider** - Form state, media, metadata, save/delete actions
- **createSignal** - Local form state, pagination, sorting, filters, selection
- **createStore** - Media and metadata internal state
- **AdminPanelProvider** - CRUD operations

## Validation

- Product name is required
- Price must be a valid number if provided
- Form validation with error messages
- Name uniqueness check with warning

## Error Handling

- Query error boundaries with retry option
- Form validation errors displayed inline
- Console logging for failed operations
- User-friendly alert messages for clipboard/import errors
- Confirmation dialogs for destructive actions (delete)

## Best Practices

1. **Use server-side features** - Pagination and search are server-side for performance
2. **Optimistic updates** - Inline stock editing provides immediate feedback
3. **Bulk operations** - Select multiple items for batch delete
4. **Context-based architecture** - All form state in provider for reusability
5. **Sections are reusable** - Import sections for custom forms
6. **Filters** - Combine search with status/visibility filters for precise results
