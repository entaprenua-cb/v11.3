# Home Page Documentation

## Overview

The home page (`src/routes/index.tsx`) serves as the main landing page for the Entaprenua platform. It showcases the platform's capabilities, provides navigation to key features, and highlights the enterprise-grade backend infrastructure.

## Architecture

### Component Structure

```
HomePage
├── Title & Meta (SEO)
├── HeaderSection
│   ├── Logo
│   ├── Navigation
│   └── Auth Buttons
├── HeroSection
│   ├── Badge
│   ├── Headline
│   ├── Description
│   ├── CTA Buttons
│   └── Feature Highlights
├── FeaturesSection
│   └── FeatureCard[] (6 cards)
├── ApiShowcaseSection
│   ├── StatCard[] (4 stats)
│   └── Backend Feature Cards (4 categories)
├── TechnologyStackSection
│   └── Technology Cards (4 categories)
├── CTASection
│   └── Call-to-action
└── FooterSection
    ├── Footer Links (4 columns)
    └── Copyright
```

## Components

### FeatureCard

Displays a feature with icon, title, description, and navigation link.

```tsx
type FeatureCardProps = {
  title: string
  description: string
  icon: JSX.Element
  href: string
  badge?: string
  disabled?: boolean
}
```

**Features:**
- Hover animations (shadow, border, translate)
- Disabled state for coming-soon features
- Badge support for status indicators
- Automatic icon color transition on hover

### StatCard

Displays a metric with label, value, and optional description.

```tsx
type StatCardProps = {
  label: string
  value: string | number
  description?: string
  trend?: "up" | "down" | "neutral"
}
```

### NavItem

Navigation link with variant support.

```tsx
type NavItemProps = {
  href: string
  children: JSX.Element
  variant?: "default" | "primary"
}
```

## Sections

### 1. HeaderSection

Sticky header with:
- **Logo**: ShoppingCartIcon + "Entaprenua" text
- **Navigation**: My Sites, Templates, Docs, Support
- **Auth**: Log In + Sign Up buttons

**Behavior:**
- Fixed position at top
- Backdrop blur effect
- Border separator

### 2. HeroSection

Primary call-to-action area with:
- Gradient background overlay
- Enterprise badge
- Large headline with highlighted text
- Two CTA buttons (primary + outline)
- Feature checkmarks

**Props:**
```tsx
type HeroSectionProps = {
  onGetStarted: () => void
}
```

### 3. FeaturesSection

Grid of 6 feature cards linking to:

| Feature | Route | Status |
|---------|-------|--------|
| My Sites | `/my-sites` | Active |
| Templates | `/templates` | Active |
| My Modules | `/my-modules` | Active |
| Admin Panel | `/admin-panel` | Active |
| Store Builder | `/site-edit` | Coming Soon (disabled) |
| Support | `/support` | Active |

**Grid Configuration:**
- Mobile: 1 column
- Tablet (md): 2 columns
- Desktop (lg): 3 columns

### 4. ApiShowcaseSection

Backend capabilities showcase:

**Stats:**
- 40 API Endpoints
- 5 Core Modules
- 99.9% Uptime
- <100ms Latency

**Feature Categories:**
1. E-Commerce (Products, Cart, Orders, Payments, Inventory)
2. Builder (Visual Editor, Components, Export, SEO, Templates)
3. Infrastructure (PostgreSQL, Redis, Typesense, Stripe, Media)
4. Enterprise (JWT Auth, Rate Limiting, Optimistic Locking, Auditing, OpenAPI)

### 5. TechnologyStackSection

Technology breakdown by category:

| Category | Technologies |
|----------|-------------|
| Frontend | SolidJS, SolidStart, Tailwind CSS, Kobalte UI, TanStack Query |
| Backend | Kotlin, Spring Boot 3, WebFlux, R2DBC, JOOQ |
| Database | PostgreSQL, Redis, Flyway, JSONB |
| Services | Typesense, Stripe, Apache Tika, Node.js Parser |

### 6. CTASection

Final call-to-action with gradient background:
- Headline
- Description
- Two CTA buttons

### 7. FooterSection

Four-column footer with:
- Product links
- Resources links
- Company links
- Legal links
- Copyright notice

## SEO

The page includes comprehensive SEO meta tags:

```tsx
<Title>Entaprenua - Visual E-Commerce Platform</Title>
<Meta name="description" content="..." />
<Meta name="keywords" content="e-commerce, page builder, no-code, SolidJS, NextJS, storefront, online store" />
```

## Styling

### Color Scheme

Uses Tailwind CSS custom properties:
- `--color-primary`: Primary brand color
- `--color-secondary`: Secondary accent
- `--color-muted`: Muted backgrounds
- `--color-foreground`: Text color

### Responsive Design

| Breakpoint | Behavior |
|------------|----------|
| Mobile (< 640px) | Single column, stacked navigation |
| Tablet (md) | 2-column grids, visible nav |
| Desktop (lg) | 3-4 column grids, full features |

### Animations

- Card hover: `translate-y(-4px)`, shadow increase
- Button hover: `translate-x(4px)` on arrow
- Icon hover: Background color transition

## Dependencies

```tsx
// Core
import { createSignal, createMemo, For, Show, Suspense, ErrorBoundary, type JSX } from "solid-js"
import { A } from "@solidjs/router"
import { Title, Meta } from "@solidjs/meta"

// Components
import { Button, Card, Flex, Grid, Badge, Text, ... } from "~/components/ui"

// Utilities
import { cn } from "~/lib/utils"
import { routes } from "~/lib/utils/routes"

// Icons
import { ArrowRightIcon, ShoppingCartIcon, ... } from "~/icons"
```

## Navigation Routes

All routes are defined in `src/lib/utils/routes.ts`:

```tsx
routes = {
  home: "/",
  mySites: "/my-sites",
  templates: "/templates",
  myModules: "/my-modules",
  adminPanel: "/admin-panel",
  siteEdit: "/site-edit",
  support: "/support",
  documentation: "/docs",
  signUp: "/sign-up",
  logIn: "/log-In",
}
```

## Best Practices

### 1. Component Isolation
Each section is a separate component for:
- Easier testing
- Better code organization
- Reusability

### 2. Type Safety
All props are typed with TypeScript interfaces.

### 3. Accessibility
- Semantic HTML (`<header>`, `<main>`, `<footer>`, `<section>`, `<nav>`)
- Proper heading hierarchy (h1 → h2 → h3)
- ARIA labels where needed

### 4. Performance
- No unnecessary re-renders (SolidJS fine-grained reactivity)
- Lazy loading ready with `Suspense`
- Optimized icons (tree-shakeable from lucide-solid)

### 5. Maintainability
- Consistent naming conventions
- Reusable utility functions (`cn`)
- Centralized route definitions

## Future Enhancements

1. **Analytics Integration**: Add event tracking for CTA clicks
2. **A/B Testing**: Support variant testing for hero section
3. **i18n**: Internationalization support
4. **Dark Mode**: Theme toggle in header
5. **Performance Metrics**: Add Core Web Vitals monitoring
6. **Feature Flags**: Dynamic enable/disable of features

## Testing

### Unit Tests (Recommended)

```tsx
// FeatureCard.test.tsx
describe('FeatureCard', () => {
  it('renders with correct props', () => {
    render(<FeatureCard title="Test" description="Desc" icon={<Icon />} href="/test" />)
    expect(screen.getByText('Test')).toBeInTheDocument()
  })

  it('disables card when disabled prop is true', () => {
    render(<FeatureCard {...props} disabled />)
    expect(screen.queryByRole('link')).not.toBeInTheDocument()
  })
})
```

### E2E Tests (Recommended)

```tsx
// home.spec.ts
test('home page navigation', async ({ page }) => {
  await page.goto('/')
  await page.click('text=Get Started Free')
  await expect(page).toHaveURL('/sign-up')
})
```

## Changelog

### v1.0.0 (2026-02-21)
- Initial implementation
- 6 feature cards
- Backend API showcase
- Technology stack section
- SEO meta tags
- Responsive design
