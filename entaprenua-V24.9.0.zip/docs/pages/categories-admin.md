# Categories Admin

Enterprise-grade category management UI with list, create, edit, and children management.

## File Structure

```
src/routes/admin/categories/
├── index.tsx                    # List page with filters, bulk actions
├── category-quick-edit.tsx      # Dialog for quick editing
├── CategoryForm.tsx             # Main form component
├── new/
│   └── index.tsx                # Create new category
├── [id]/
│   └── index.tsx                # Edit category with children management
└── sections/
    ├── CategoryBasicInfoSection.tsx
    └── CategoryVisibilitySection.tsx
```

## Implementation Plan

### 1. category-editor-context.tsx
- Context provider for form state management
- Form fields: name, level, visibility, image
- Validation (name required)
- Save/delete API calls using categoriesApi
- Loading states (isSaving, isUploading, isDeleting)

### 2. CategoryForm.tsx
- Main form layout with AdminHeader
- Sections: BasicInfo, Visibility
- Save/Delete buttons in header
- Wraps ProductEditorProvider pattern

### 3. sections/CategoryBasicInfoSection.tsx
- Name input (required)
- Level select (1=Primary, 2=Secondary, 3=Tertiary)
- Image preview (read-only in quick edit)

### 4. sections/CategoryVisibilitySection.tsx
- Visibility dropdown (public/private/draft)
- Status badge

### 5. index.tsx (List Page)
- DataTableServer with server-side pagination
- Filters: Search, Level, Visibility
- Table columns: Image, Name, Level, Children Count, Visibility, Actions
- Row actions: Quick edit, View/Edit, Delete
- Bulk actions: Select multiple, bulk delete

### 6. category-quick-edit.tsx
- Dialog with inline form
- Edit name, level, visibility
- Read-only image preview
- Optimistic save via admin store

### 7. new/index.tsx
- Create page wrapping CategoryForm
- Mode: "create"

### 8. [id]/index.tsx
- Edit page fetching category data
- Query category with children
- Mode: "edit"

## Data Model

```typescript
interface Category {
  id: string;
  storeId: string;
  name: string;
  image: string | null;
  level: number | null;      // 1=Primary, 2=Secondary, 3=Tertiary
  visibility: string | null; // "public" | "private" | "draft"
  subcategories: Category[] | null;
  insertedAt: string;
  updatedAt: string;
}
```

## API Usage

```typescript
import { categoriesApi } from "~/lib/api/categories"

// Get all categories (returns PagedResponse)
const response = await categoriesApi.getAll(storeId)
const categories = response.content ?? []
const total = response.totalElements ?? 0

// Get category with children
const response = await categoriesApi.getById(id, true)

// Create category
const response = await categoriesApi.create({ name, level, visibility, storeId })

// Update category (uses upsert pattern - include id in data)
const response = await categoriesApi.create(storeId, { id, name, level, visibility })

// Delete category
await categoriesApi.delete(storeId, id)
```

## Level Labels

| Level | Label     | Description                    |
|-------|-----------|--------------------------------|
| 1     | Primary   | Main navigation categories     |
| 2     | Secondary | Subcategories                  |
| 3     | Tertiary  | Sub-subcategories              |

## Notes

- Categories use a flat list structure (not tree) with many-to-many relationships via `category_hierarchy` table
- `level` represents category type, not hierarchy depth
- Children are fetched via `getById?includeChildren=true`
- Categories support multiple parents (DAG structure)
- Follow same patterns as products: editor context, form component, sections, list page with DataTableServer
- Uses `create` API with `id` in data for updates (upsert pattern on server)

## Known Issues

- **Table not updating after create/edit**: After creating or editing a category, the table does not automatically refresh to show the changes. The `invalidateQueries` call does not properly trigger a refresh because the `DataTableServer` component uses a separate QueryClient instance. Need to investigate how to properly share the QueryClient or use a different approach for cache invalidation. Products work correctly - need to compare the implementation.
