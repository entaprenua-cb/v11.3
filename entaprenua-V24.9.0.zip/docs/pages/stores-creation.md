# Store Creation Flow Documentation

## Overview

The store creation flow allows users to create new stores by cloning a marketplace template.

This document describes the complete flow and architecture.

---

## User Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         STORE CREATION FLOW                                  │
└─────────────────────────────────────────────────────────────────────────────┘

   ┌──────────────┐     ┌─────────────────┐     ┌──────────────────────────┐
   │  /stores    │────▶│  /stores/new   │────▶│  Step 1: Choose Template │
   │  (List)     │     │  (Wizard)       │     │                          │
   └──────────────┘     └─────────────────┘     │  ┌────────────────────┐ │
                                                 │  │ Browse Templates  │ │
   [+ Create New Store]                          │  │ ────────────────  │ │
         │                                       │  │ [Browse → /templ]│ │
         ▼                                       │  └────────────────────┘ │
   ┌──────────────┐                              │                          │
   │  /stores/new │     ┌─────────────────┐     │  ┌────────────────────┐ │
   │  (Wizard)    │◀────│ ?templateId=xxx│     │  │ Select Template   │ │
   └──────────────┘     │ (pre-selected) │     │  │ ────────────────  │ │
                        └─────────────────┘     │  │ [List of        │ │
                                                │  │  templates]      │ │
                                                │  └────────────────────┘ │
                                                └──────────────────────────┘
                                                          │
                                                          ▼
                                             ┌──────────────────────────┐
                                             │  Step 2: Store Details   │
                                             │  ─────────────────────   │
                                             │  • Store Name           │
                                             │  • Description          │
                                             └──────────────────────────┘
                                                          │
                                                          ▼
                                             ┌──────────────────────────┐
                                             │  Step 3: Domain Setup   │
                                             │  ─────────────────────   │
                                             │  • Subdomain            │
                                             │  • Custom Domain        │
                                             └──────────────────────────┘
                                                          │
                                                          ▼
                                             ┌──────────────────────────┐
                                             │  Step 4: Review & Create│
                                             └──────────────────────────┘
                                                          │
                                                          ▼
                                             ┌──────────────────────────┐
                                             │  /stores/:id/build      │
                                             │  (Builder)              │
                                             └──────────────────────────┘
```

---

## Routes

| Route | File | Description |
|-------|------|-------------|
| `/stores` | `routes/stores/index.tsx` | List of user's stores |
| `/stores/new` | `routes/stores/new.tsx` | Store creation wizard |
| `/stores/new?templateId=xxx` | `routes/stores/new.tsx` | Pre-selected template |
| `/templates` | `routes/templates/index.tsx` | Template marketplace |
| `/templates/:id` | `routes/templates/[id].tsx` | Template detail page |

---

## Step-by-Step Flow

### Step 1: Choose Template

**User Options:**

1. **Browse Templates**
   - Click "Browse Templates" button
   - Navigates to `/templates` marketplace
   - User browses and selects a template
   - Clicks "Use Template"
   - Redirects to `/stores/new?templateId={template_id}`
   - Template is pre-selected in the wizard

**Code Location:** `src/routes/stores/new.tsx` - Step 1 UI

---

### Store Creation Wizard State

```tsx
const [currentStep, setCurrentStep] = createSignal(1)
const [selectedTemplate, setSelectedTemplate] = createSignal<string | null>(null)
const [name, setName] = createSignal("")
const [description, setDescription] = createSignal("")
const [domainType, setDomainType] = createSignal<"subdomain" | "custom">("subdomain")
const [subdomain, setSubdomain] = createSignal("")
const [customDomain, setCustomDomain] = createSignal("")
const [nameAvailable, setNameAvailable] = createSignal<boolean | null>(null)
```

### Step Validation

```tsx
const isStep1Valid = () => selectedTemplate() !== null

const isStep2Valid = () => name().trim().length >= 3 && nameAvailable() !== false

const isStep3Valid = () => {
  if (domainType() === "subdomain") {
    return subdomain().trim().length >= 3
  }
  return customDomain().trim().length >= 3
}
```

---

## API Integration

### Creating a Store

```tsx
const handleSubmit = async () => {
  const storeData = {
    name: name(),
    description: description() || undefined,
    visibility: "private",
    templateId: selectedTemplate(),
  }

  // Set domain
  if (domainType() === "subdomain") {
    storeData.subdomain = subdomain().toLowerCase()
  } else {
    storeData.customDomain = customDomain()
  }

  const response = await storesApi.createStore(storeData)
  return response
}
```

### Store Creation Response

```tsx
interface CreateStoreResponse {
  id: string
  publicId: string
  name: string
  // ... other fields
}
```

---

## Template Marketplace

### Template List Page

**Route:** `/templates`

**Features:**
- Grid of available templates
- Template cards with:
  - Thumbnail image
  - Template name
  - Brief description
  - "Use Template" button
- Filter by category (optional)

**Code Location:** `src/routes/templates/index.tsx`

### Template Detail Page

**Route:** `/templates/:id`

**Features:**
- Large preview image
- Template name and description
- Feature list
- "Use Template" button
- "Preview" button (optional)

**Code Location:** `src/routes/templates/[id].tsx`

### Using a Template

```tsx
const handleUseTemplate = (templateId: string) => {
  navigate(`/stores/new?templateId=${templateId}`)
}
```

---

## Store Name Validation

```tsx
const checkNameAvailability = async (name: string) => {
  if (name.trim().length < 3) {
    setNameAvailable(null)
    return
  }

  setNameAvailable(false) // Optimistic
  const response = await storesApi.checkName(name)
  setNameAvailable(response.available)
}
```

---

## Domain Setup

### Subdomain Option

```
{store-slug}.entaprenua.com
```

### Custom Domain Option

```
store.example.com
```

Requires DNS verification (CNAME record).

---

## Error Handling

### Template Not Found

```tsx
const [templateError, setTemplateError] = createSignal<string | null>(null)

const loadTemplate = async (templateId: string) => {
  try {
    const template = await templatesApi.getTemplate(templateId)
    setSelectedTemplate(template)
  } catch (err) {
    setTemplateError("Template not found")
  }
}
```

### Store Creation Failed

```tsx
const [createError, setCreateError] = createSignal<string | null>(null)

const handleCreate = async () => {
  try {
    const store = await storesApi.createStore(storeData)
    navigate(`/stores/${store.id}/build`)
  } catch (err) {
    setCreateError(err.message)
  }
}
```

---

## Success Flow

```
┌─────────────────────┐
│  Store Created!    │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Redirect to      │
│  /stores/:id/build │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  VCS Clone starts  │
│  (background job)   │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  User can edit    │
│  store settings   │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Clone completes   │
│  (notify user)     │
└─────────────────────┘
```

---

## Backend Integration

### Store Creation Flow

```
1. POST /stores
   - Validate input
   - Create store record
   - Return store ID

2. POST /stores/:id/vcs/clone-from-template
   - Create GitHub repo
   - Clone template
   - Clone platform
   - Merge files
   - Push to repo
   - Register webhook
   - Queue build job
```

### Relevant Backend Files

| File | Purpose |
|------|---------|
| `stores/StoreService.kt` | Store CRUD operations |
| `vcs/VcsService.kt` | VCS operations |
| `vcs/BuildQueueService.kt` | Clone and build queue |

---

## Related Documentation

- [VCS Integration](../VCS_INTEGRATION.md) - Full VCS documentation
- [VCS Clone Implementation](../VCS_CLONE_IMPLEMENTATION.md) - Clone flow details
- [Templates](../templates/) - Template structure
