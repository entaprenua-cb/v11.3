# Messaging Implementation Plan

## Overview

Two-way real-time chat between merchants (admin app) and customers (storefront app). Customers start conversations from the storefront; merchants reply from the admin inbox. Messages delivered in real-time via WebSocket, with email fallback for offline customers.

Built on existing stack: Spring WebFlux (reactive) + PostgreSQL (JOOQ) + SolidStart (admin & storefront).

## Architecture

```
Customer (storefront)
  → ChatWidget → POST /messages/customer/conversations (start)
              → POST /messages/customer/conversations/{id}/reply
              → WebSocket connect /messages/ws
                     ↑↓ real-time
Merchant (admin panel)
  → Inbox → GET /messages/conversations (list)
         → GET /messages/conversations/{id} (view)
         → POST /messages/conversations/{id}/reply
         → WebSocket connect /messages/ws

WebSocket server:
  ConversationRegistry (in-memory map: conversationId → Set<WebSocketSession>)
  On message: persist to DB → broadcast to all sessions in conversation
  On new message from merchant → NotificationService.send("new_message", ...) → email to customer
```

## Database

**V75 migration:**

```sql
CREATE TABLE conversations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    customer_id UUID NOT NULL REFERENCES store_customers(id) ON DELETE CASCADE,
    subject VARCHAR(255),
    last_message_at TIMESTAMPTZ,
    is_resolved BOOLEAN DEFAULT false,
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(store_id, customer_id)
);

CREATE TABLE messages (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    sender_type VARCHAR(10) NOT NULL CHECK (sender_type IN ('store', 'customer')),
    content TEXT NOT NULL,
    read_at TIMESTAMPTZ,
    inserted_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_messages_conversation ON messages(conversation_id, inserted_at);
CREATE INDEX idx_conversations_store ON conversations(store_id, last_message_at DESC);
CREATE INDEX idx_conversations_customer ON conversations(customer_id);
```

## API Endpoints

All under `/{publicId}/messages/`. Store context resolved via `StoreContextFilter`.

### Merchant (Admin)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/conversations` | Admin | List conversations with unread counts, sorted by last message |
| GET | `/conversations/{id}` | Admin | Get conversation with paginated messages |
| POST | `/conversations/{id}/reply` | Admin | Send reply as merchant. Triggers email notification to customer |
| PUT | `/conversations/{id}/resolve` | Admin | Toggle `is_resolved` |
| GET | `/ws` | Admin | WebSocket upgrade. Client sends `{ type: "subscribe", conversationId }` |

### Customer (Storefront)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/customer/conversations` | Customer session | Customer's own conversations |
| POST | `/customer/conversations` | Customer session | Start new conversation (auto-creates if not exists) |
| GET | `/customer/conversations/{id}` | Customer session | Get conversation with messages |
| POST | `/customer/conversations/{id}/reply` | Customer session | Send reply. Broadcasts to merchant via WebSocket |
| GET | `/customer/ws` | Customer session | WebSocket upgrade |

### Response shapes

```jsonc
// GET /conversations
{
  "conversations": [
    {
      "id": "uuid",
      "customerId": "uuid",
      "customerName": "Alice",
      "customerEmail": "alice@example.com",
      "subject": "Order #1024",
      "lastMessage": {
        "content": "When will my order ship?",
        "senderType": "customer",
        "insertedAt": "2026-05-25T10:00:00Z"
      },
      "unreadCount": 2,
      "isResolved": false
    }
  ]
}

// GET /conversations/{id}
{
  "conversation": {
    "id": "uuid",
    "customerName": "Alice",
    "subject": "Order #1024",
    "isResolved": false,
    "messages": [
      {
        "id": "uuid",
        "senderType": "customer",
        "content": "When will my order ship?",
        "readAt": null,
        "insertedAt": "2026-05-25T10:00:00Z"
      },
      {
        "id": "uuid",
        "senderType": "store",
        "content": "It ships tomorrow! Tracking will be emailed.",
        "readAt": null,
        "insertedAt": "2026-05-25T10:05:00Z"
      }
    ]
  }
}
```

## Backend Files

### New files

| File | Purpose |
|------|---------|
| `db/migration/V75__Add_messaging.sql` | Creates `conversations` + `messages` tables |
| `entities/Conversation.kt` | Data class: id, storeId, customerId, subject, lastMessageAt, isResolved |
| `entities/Message.kt` | Data class: id, conversationId, senderType, content, readAt |
| `store/repositories/MessageRepository.kt` | JOOQ CRUD: findConversations, findMessages, insertMessage, markRead, toggleResolved |
| `store/services/MessageService.kt` | Interface: listMerchantConversations, getConversation, reply, listCustomerConversations, startConversation |
| `store/impl/MessageServiceImpl.kt` | Business logic: auto-create conversation, sender validation, email notification on merchant reply |
| `store/impl/MessageWebSocketHandler.kt` | WebFlux `WebSocketHandler`: session registry keyed by conversationId, broadcast on new message, auth validation |
| `dtos/MessageDtos.kt` | Request/response DTOs: ConversationListResponse, MessageResponse, ReplyRequest, StartConversationRequest |

### Existing files to modify

| File | Change |
|------|--------|
| `config/ApiRouterConfig.kt` | Add `/messages` route group under `/{publicId}` with all endpoints |
| `templates/notifications/defaults.json` | Add `new_message` event with email template |

## Real-Time (WebSocket)

Uses Spring WebFlux's built-in `WebSocketHandler` — no extra dependencies.

### Server-side: `MessageWebSocketHandler`

```kotlin
class MessageWebSocketHandler : WebSocketHandler {
    // conversationId → Set<WebSocketSession>
    private val registry = ConcurrentHashMap<UUID, MutableSet<WebSocketSession>>()

    override fun handle(session: WebSocketSession): Mono<Void> {
        // 1. Authenticate from query params (JWT for admin, session token for customer)
        // 2. Client sends: { "type": "subscribe", "conversationId": "uuid" }
        // 3. Register session in registry[conversationId]
        // 4. On message: { "type": "message", "conversationId": "uuid", "content": "..." }
        // 5. Broadcast to all sessions in registry[conversationId] (including sender)
        // 6. On close: remove from registry
    }
}
```

### Client-side (shared utility)

```typescript
// lib/api/ws.ts
export function createMessageSocket(conversationId: string, onMessage: (msg) => void) {
  const ws = new WebSocket(`wss://host/${publicId}/messages/ws?token=...`);
  ws.onopen = () => ws.send(JSON.stringify({ type: "subscribe", conversationId }));
  ws.onmessage = (e) => onMessage(JSON.parse(e.data));
  return { close: () => ws.close() };
}
```

### WebSocket message protocol

```jsonc
// Client → Server (subscribe to conversation)
{ "type": "subscribe", "conversationId": "uuid" }

// Client → Server (send message through WS)
{ "type": "message", "conversationId": "uuid", "content": "Hello!" }

// Server → Client (new message received)
{
  "type": "message",
  "message": {
    "id": "uuid",
    "conversationId": "uuid",
    "senderType": "customer",
    "content": "Hello!",
    "insertedAt": "2026-05-25T10:00:00Z"
  }
}
```

## Email Notification

When merchant replies to a customer, `MessageServiceImpl` calls:

```kotlin
notificationService.send("new_message", NotificationContext(
    store = store,
    customerEmail = customer.email,
    customerName = customer.name,
    cart = CartNotificationData(
        cartId = "",
        total = "",
        itemCount = 0,
        recoveryUrl = "${baseUrl}/messages/${conversationId}",
        items = emptyList()
    )
))
```

New `new_message` event in `defaults.json`:

```json
{
  "new_message": {
    "email": {
      "subject": "New message from ${store.name}",
      "body_html": "...",
      "body_text": "Hi ${customer.name},\n\nYou have a new message from ${store.name}.\n\nView: ${cart.recoveryUrl}\n\n${store.name}"
    }
  }
}
```

*(Note: `recoveryUrl` in `CartNotificationData` doubles as message link until a dedicated context is added.)*

## Frontend — Admin

### New files

| File | Purpose |
|------|---------|
| `routes/admin/messages/index.tsx` | Conversation list: search, unread badge, last message preview, resolved toggle. Click to open chat. |
| `routes/admin/messages/[id].tsx` | Chat view: message list (auto-scroll, date separators), input box, resolve button, WebSocket hook |
| `components/messages/MessageBubble.tsx` | Message row: sender avatar, content, timestamp, read indicator |
| `components/messages/MessageInput.tsx` | Text area + send button, Enter to send, Shift+Enter newline |
| `lib/api/messages.ts` | `listConversations()`, `getConversation(id)`, `sendReply(id, content)`, `resolveConversation(id)` |
| `lib/api/ws.ts` | `createMessageSocket()` — shared WebSocket utility |

### Existing files to modify

| File | Change |
|------|--------|
| `routes/admin.tsx` | Add `Messages` menu item with `MessageSquareIcon` to sidebar `menuItems` |
| `lib/utils/routes.ts` | Add `adminMessages: "${ADMIN}/messages"` |

### UI Layout

```
┌──────────────────────────────────────┐
│ Messages  🔍 Search conversations... │
├────────────┬─────────────────────────┤
│            │                         │
│ Conv list  │   Chat view             │
│ ─────────  │   ─────────────────     │
│ Alice   2  │   Alice: When will my   │
│ Order #1024│   order ship?           │
│            │                         │
│ Bob      ✓ │   You: It ships         │
│ Question   │   tomorrow! ✓✓          │
│            │                         │
│ Carol   1  │   ┌───────────────┐     │
│ Returns    │   │ Type a reply...│ [→] │
│            │   └───────────────┘     │
└────────────┴─────────────────────────┘
```

## Frontend — Storefront

### New files

| File | Purpose |
|------|---------|
| `components/chat/ChatWidget.tsx` | Floating button (bottom-right corner). Opens slide-out panel. Shows "Chat with us" when no conversation exists, or message list when one does. |
| `components/chat/MessageBubble.tsx` | Message row: customer right-aligned (blue), merchant left-aligned (gray) |
| `components/chat/MessageInput.tsx` | Text input + send. Disabled while sending. |
| `lib/api/messages.ts` | `getConversations()`, `startConversation(subject?)`, `getConversation(id)`, `sendReply(id, content)` |

### Existing files to modify

| File | Change |
|------|--------|
| `app.tsx` or `home.tsx` | Mount `<ChatWidget />` globally in storefront layout |

### UI Layout (collapsed)

```
Storefront page content
...
                                    ┌─┐
                                    │💬│  ← floating button
                                    └─┘
```

### UI Layout (expanded)

```
Storefront page content
...
                         ┌──────────────────────┐
                         │ Chat with StoreName  ✕│
                         ├──────────────────────┤
                         │                      │
                         │ Store: Hi Alice! How  │
                         │ can we help?          │
                         │                      │
                         │        Alice: When   │
                         │        will my order │
                         │        ship? ✓       │
                         │                      │
                         │ Store: It ships      │
                         │ tomorrow!            │
                         │                      │
                         ├──────────────────────┤
                         │ [Type a message...] [→]│
                         └──────────────────────┘
```

## Customer Authentication for Chat

Storefront uses customer sessions (managed by `StoreCustomerSessionRepository`). The chat widget is available to:

1. **Authenticated customers** — full history, persistent conversations
2. **Guest customers** — can start conversation by providing email (similar to guest checkout pattern)

Customer API endpoints are protected by the existing `StoreCustomerContextFilter`.

## Phases

### Phase 1 (MVP)

- Migration, entities, JOOQ codegen
- `MessageRepository` — CRUD operations
- `MessageServiceImpl` — business logic + email notification hook
- REST API: all merchant + customer endpoints
- `MessageWebSocketHandler` — real-time delivery
- `ApiRouterConfig` — route registration
- Admin frontend: conversation list + chat view + WebSocket
- `new_message` email template in `defaults.json`
- Storefront: floating chat widget + WebSocket

### Phase 2

- Typing indicators via WebSocket (`{ type: "typing", conversationId }`)
- Read receipts (mark messages read on view, broadcast read status)
- Unread count badge in admin sidebar
- File/image attachments via existing upload infrastructure
- Message search in admin inbox

### Phase 3

- Customer chat enable/disable toggle per store (schema-driven setting)
- Pre-chat form (name, email, order number) for guests
- Canned responses for merchants (quick replies)
- Chat transcript export
- Mobile push notifications (FCM/APNs)

## Integration Notes

- **No new dependencies** — WebSocket via Spring WebFlux core, no extra libraries
- **JOOQ reactive pattern** — all queries use `.asFlow()` / `Flux.from()` as per project conventions
- **Auth reuse** — admin routes use `requireRole(ADMIN)`, customer routes use `StoreCustomerContextFilter`
- **Notification reuse** — merchant replies trigger `NotificationService.send("new_message", ...)` using existing Thymeleaf + Resend pipeline
- **Schema-driven** — future per-store chat settings go through the existing `store_settings` JSONB system
