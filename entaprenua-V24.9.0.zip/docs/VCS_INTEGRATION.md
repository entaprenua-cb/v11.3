# Storefront VCS Integration Plan

**Last Updated**: 2026-04-07  
**Status**: ✅ Implemented (Template Cloning, Build Pipeline, Nginx Subdomain Routing)

## Related Documentation

- [Storefront Checker](../packages/storefront-check/README.md) - CLI tool for validating storefront code
- [Storefront Code Security](STOREFRONT_CODE_SECURITY.md) - Security rules and allowed patterns

---

## Overview

Allow storefront owners to build their stores using GitHub or GitLab repositories. When they push changes, we detect those changes and automatically rebuild/deploy their storefront.

---

## Why VCS Integration?

### Current State
- Stores are built using the visual builder (drag-and-drop)
- Pages stored as JSON in database
- Published via SolidStart Builder API

### With VCS Integration
- Store owners can code their storefronts directly in GitHub/GitLab
- Full control over code, not limited to builder components
- Push to trigger automatic builds
- Can use custom components, integrations, etc.

---

## Repository Ownership Models

There are two approaches for storing storefront code:

### Model A: User-Owned Repository (OAuth)
- Store owner has their own GitHub account
- They connect via OAuth and select/create their own repo
- Full control stays with the owner
- Requires GitHub account

### Model B: Platform-Owned Repository (No GitHub Required)
- We create repos under our GitHub Organization
- Store owner is added as a collaborator
- Works for users without GitHub accounts
- Owner receives email invite to collaborate

---

## Supported Providers

| Provider | Priority | Notes |
|----------|----------|-------|
| **GitHub** | Primary | 100M+ users, mature webhooks, best Actions ecosystem |
| **GitLab** | Secondary | Good for enterprise/self-hosted preference |

### GitHub Organization Setup

Create a GitHub Organization (e.g., `entaprenua-stores`) to host all platform-managed repositories:

```
Organization: entaprenua-stores
├── store-{storeId}-mystore       # One repo per store
├── store-{storeId}-anotherstore
└── ... (unlimited repos)
```

**Benefits:**
- All repos under our control
- Easy management via GitHub API
- Consistent webhook handling
- One place to monitor all store code

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    STOREFRONT REPOSITORY                        │
│                  (GitHub/GitLab owned by store owner)           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ├── src/routes/           # Page components                    │
│  ├── src/components/      # Custom components                   │
│  ├── src/lib/             # Utilities                           │
│  ├── app.config.ts        # SolidStart config                  │
│  └── package.json         # Dependencies                       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼ (Webhook)
┌─────────────────────────────────────────────────────────────────┐
│                    ENTAPRENUA PLATFORM                           │
│                                                                 │
│  1. Receive webhook (push event)                               │
│  2. Verify webhook signature                                   │
│  3. Queue build job                                            │
│  4. Clone repository                                           │
│  5. Run npm build                                              │
│  6. Deploy to storefront node process                          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    STOREFRONT (Live)                             │
│              (SolidStart SSR on store domain)                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Implementation Phases

### Phase 1: GitHub Integration

#### 1.1 Repository Linking

**Option A: User-Owned Repository (OAuth)**
- Store owner connects their GitHub account (OAuth)
- They select/create a repository for their store
- We store: `repository_id`, `repository_name`, `branch`, `webhook_id`

**Option B: Platform-Owned Repository (No GitHub Required)**
- We create a repo under our GitHub Organization
- Add store owner as collaborator (via email)
- Store owner can push via GitHub web editor or Git

---

#### 1.2 Platform-Owned Repository Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    STORE CREATION                                 │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  1. Create repository under GitHub Organization                  │
│                                                                 │
│  POST /orgs/{org}/repos                                        │
│  {                                                              │
│    "name": "store-{uuid}-mystore",                            │
│    "description": "My Store - entaprenua.com",                 │
│    "private": true,                                            │
│    "auto_init": true,                                          │
│    "gitignore_template": "Node"                                │
│  }                                                             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  2. Push skeleton template to repository                        │
│                                                                 │
│  git clone https://github.com/entaprenua-stores/{repo}         │
│  cp -r platform/* .                                            │
│  git add . && git commit -m "Initial commit"                  │
│  git push origin main                                          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  3. Add store owner as collaborator                            │
│                                                                 │
│  PUT /repos/{org}/{repo}/collaborators/{username}             │
│  { "permission": "push" }                                      │
│                                                                 │
│  OR invite by email (if no GitHub account):                   │
│                                                                 │
│  PUT /repos/{org}/{repo}/collaborators/{username}             │
│  { "permission": "push" }                                      │
│  → GitHub sends email invite to username                       │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  4. Store configuration                                         │
│                                                                 │
│  Store in database:                                            │
│  {                                                              │
│    storeId,                                                    │
│    vcsProvider: 'github',                                     │
│    repositoryId: 123456789,                                    │
│    repositoryName: 'store-uuid-mystore',                      │
│    repositoryUrl: 'https://github.com/entaprenua-stores/...',  │
│    ownerUsername: 'john@example.com' | 'github-handle',        │
│    branch: 'main',                                             │
│    webhookId: 987654321                                        │
│  }                                                             │
└─────────────────────────────────────────────────────────────────┘
```

---

#### 1.3 Platform Repository API

```typescript
// GitHub API: Create repository under organization
async function createPlatformRepository(storeId: string, storeName: string) {
  const repoName = `store-${storeId}-${slugify(storeName)}`
  
  const response = await githubApi.post(`/orgs/${GITHUB_ORG}/repos`, {
    name: repoName,
    description: `${storeName} - Powered by Entaprenua`,
    private: true,
    auto_init: true,
    gitignore_template: 'Node',
  })
  
  return {
    id: response.id,
    fullName: response.full_name,
    cloneUrl: response.clone_url,
    htmlUrl: response.html_url,
  }
}

// GitHub API: Add collaborator
async function addCollaborator(repoId: string, identifier: string) {
  // identifier can be GitHub username OR email address
  const username = identifier.includes('@') 
    ? identifier  // GitHub will handle email invite
    : identifier
  
  await githubApi.put(`/repos/${GITHUB_ORG}/${repoId}/collaborators/${username}`, {
    permission: 'push'
  })
}

// GitHub API: Push template files
async function pushTemplate(repo: Repository) {
  const workingDir = await cloneTemplate()
  
  // Copy skeleton template files
  await copySkeletonTemplate(workingDir)
  
  // Configure package.json with store-specific info
  await updatePackageJson(workingDir, {
    name: `entaprenua-store-${repo.name}`,
    storeId: storeId,
  })
  
  // Push to repo
  await gitPush(workingDir, repo.cloneUrl)
  
  await fs.rm(workingDir, { recursive: true })
}
```

---

#### 1.4 User Without GitHub Account

For users without GitHub accounts:

```
┌─────────────────────────────────────────────────────────────────┐
│  Repository Created Under Platform Organization                   │
│  📁 entaprenua-stores/store-abc123-mystore                     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  Add collaborator via email                                      │
│                                                                 │
│  PUT /repos/{org}/{repo}/collaborators/{email}                 │
│  { "permission": "push" }                                       │
│                                                                 │
│  GitHub sends email to: john@example.com                        │
│  Subject: [Entaprenua] You've been invited to collaborate      │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  Owner clicks link in email                                     │
│                                                                 │
│  → If they have GitHub: redirects to repo, they can push       │
│  → If no GitHub: prompted to create account (free)              │
│     After account creation: auto-redirected to repo             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  Owner can now edit via:                                        │
│                                                                 │
│  1. GitHub Web Editor (in-browser, no Git install needed)      │
│  2. Clone locally and push (if they have Git)                  │
│  3. GitHub Mobile app                                          │
└─────────────────────────────────────────────────────────────────┘
```

---

#### 1.5 GitHub Web Editor (For Non-Technical Users)

The GitHub web editor is perfect for store owners who don't want to install Git:

```
┌─────────────────────────────────────────────────────────────────┐
│  GitHub Repository: entaprenua-stores/store-abc123-mystore      │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  [ <> Code ▼ ]  [ main ▼ ]  [⚙ Settings]                       │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  + New file  |  Upload file  |  Find file  | Go to file │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  📁 src/routes/                                                │
│    📄 index.tsx  (Edit)                                         │
│    📄 products/index.tsx                                        │
│    📄 products/[slug].tsx                                       │
│    📄 cart.tsx                                                 │
│                                                                 │
│  📁 src/components/                                            │
│    ...                                                          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**Features available via web editor:**
- Create/edit/delete files
- Preview Markdown files
- Commit changes
- View file history
- Search across files
- No Git installation required

---

#### 1.6 Repository Linking (continued)

#### 1.2 Webhook Setup
```typescript
// Webhook payload (GitHub push event)
interface PushEvent {
  ref: string              // "refs/heads/main"
  repository: {
    id: number
    full_name: string
    clone_url: string
  }
  commits: Commit[]
  sender: User
}

// Register webhook
POST /repos/{owner}/{repo}/hooks
{
  "name": "web",
  "active": true,
  "events": ["push"],
  "config": {
    "url": "https://api.entaprenua.com/webhooks/github",
    "content_type": "json",
    "secret": "webhook_secret"
  }
}
```

#### 1.3 Webhook Handler
```typescript
// POST /webhooks/github
async function handleGitHubWebhook(req: Request) {
  // 1. Verify signature
  const signature = req.headers.get('x-hub-signature-256')
  verifySignature(payload, signature, secret)

  // 2. Extract event info
  const event = req.headers.get('x-github-event')
  const { repository, ref, commits } = await req.json()

  // 3. Check if push to main branch
  if (event === 'push' && ref === 'refs/heads/main') {
    // 4. Queue build job
    await buildQueue.add('storefront-build', {
      storeId: await getStoreByRepository(repository.id),
      commitSha: commits[0]?.id,
      cloneUrl: repository.clone_url,
    })
  }

  return new Response('OK')
}
```

#### 1.4 Build Pipeline
```typescript
async function buildStorefront(job: Job) {
  const { storeId, commitSha, cloneUrl } = job.data

  // 1. Clone repository (with deploy key)
  const workDir = await cloneRepository(cloneUrl, deployKey)

  // 2. Install dependencies
  await exec('npm install', { cwd: workDir })

  // 3. Run build
  await exec('npm run build', { cwd: workDir })

  // 4. Deploy to storefront
  await deployToStorefront(storeId, workDir)

  // 5. Update build status
  await updateBuildStatus(storeId, { 
    status: 'success', 
    commitSha,
    buildTime: Date.now() - job.startTime 
  })

  // 6. Cleanup
  await fs.rm(workDir, { recursive: true })
}
```

---

### Phase 2: GitLab Integration

#### 2.1 Differences from GitHub

| Feature | GitHub | GitLab |
|---------|--------|--------|
| OAuth | GitHub OAuth App | GitLab OAuth Application |
| Webhook secret | `X-Hub-Signature-256` | `X-Gitlab-Token` (token-based) |
| Webhook events | `push` | `Push Hook` |
| Deploy keys | SSH deploy keys | Deploy keys |

#### 2.2 GitLab Webhook Handler
```typescript
// POST /webhooks/gitlab
async function handleGitLabWebhook(req: Request) {
  const token = req.headers.get('x-gitlab-token')
  if (token !== gitlabWebhookSecret) {
    return new Response('Unauthorized', { status: 401 })
  }

  const event = req.headers.get('x-gitlab-event')
  const payload = await req.json()

  if (event === 'Push Hook' && payload.ref === 'refs/heads/main') {
    await buildQueue.add('storefront-build', {
      storeId: await getStoreByRepository(payload.project.id),
      commitSha: payload.checkout_sha,
      cloneUrl: payload.project.git_http_url,
    })
  }

  return new Response('OK')
}
```

---

## Repository Structure

### Skeleton Template (what owners clone)

```
platform/
├── src/
│   ├── routes/
│   │   ├── index.tsx          # Home page
│   │   ├── products/
│   │   │   ├── index.tsx      # Products list
│   │   │   └── [slug].tsx     # Product detail
│   │   ├── cart.tsx           # Cart page
│   │   └── checkout.tsx       # Checkout page
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Header.tsx
│   │   │   ├── Footer.tsx
│   │   │   └── Layout.tsx
│   │   ├── product/
│   │   │   ├── ProductCard.tsx
│   │   │   └── ProductGrid.tsx
│   │   └── cart/
│   │       └── CartDrawer.tsx
│   ├── lib/
│   │   ├── api.ts             # API client (configured)
│   │   └── store.ts           # Store data context
│   ├── app.tsx
│   └── root-layout.tsx
├── public/
│   └── images/
├── app.config.ts
├── package.json
└── README.md
```

### Owner Customizes

```
my-store/
├── src/
│   ├── routes/                # Override/add pages
│   ├── components/             # Add custom components
│   └── lib/                   # Custom utilities
├── app.config.ts              # Custom config
├── package.json                # Add dependencies
└── .env                       # Store-specific vars
```

---

## Platform Repository Management

### GitHub Organization Requirements

```typescript
// Required Organization Settings
const GITHUB_ORG_CONFIG = {
  name: 'entaprenua-stores',
  
  // Settings
  settings: {
    defaultRepositoryPermission: 'none',  // Explicit collaborator access only
    membersCanCreatePublicRepositories: false,
    membersCanCreatePrivateRepositories: false,
    requireTwoFactorAuthentication: true,
    allowForking: false,  // Disable forking across the org
  },
  
  // Team structure
  teams: {
    platform: {
      name: 'Platform',
      description: 'Entaprenua internal team',
      members: ['admin@entaprenua.com'],  // Your team
      permission: 'admin'
    },
    store-owners: {
      name: 'Store Owners',
      description: 'All store owners (auto-managed)',
      members: [],  // Dynamically managed via API
      permission: 'push'
    }
  }
}
```

### Repository Naming Convention

```typescript
function generateRepoName(storeId: string, storeName: string): string {
  const slug = slugify(storeName, { lowercase: true, strict: true })
  const shortId = storeId.slice(0, 8)  // First 8 chars of UUID
  return `store-${shortId}-${slug}`
}

// Examples:
// Store ID: abc123def456, Name: "My Cool Store"
// → store-abc123de-my-cool-store

// Store ID: xyz789abc012, Name: "John's Shop"
// → store-xyz789ab-johns-shop
```

### GitHub API Rate Limits

| Endpoint | Authenticated | Organization |
|----------|---------------|--------------|
| Create repo | 50/hour | 100/hour |
| Add collaborator | 50/hour | 100/hour |
| Create webhook | 100/hour | 100/hour |

**Mitigation strategies:**
- Implement request queuing
- Use GitHub App authentication (higher limits)
- Batch operations where possible

### Repository Lifecycle

```typescript
interface RepositoryLifecycle {
  // On store creation
  createRepository(): Promise<Repository>
  pushTemplate(repo): Promise<void>
  addCollaborator(email): Promise<void>
  registerWebhook(repo): Promise<void>
  
  // On store deletion
  removeWebhook(repo): Promise<void>
  removeCollaborator(repo, user): Promise<void>
  deleteRepository(repo): Promise<void>  // Or archive
}
```

---

## Comparison: User-Owned vs Platform-Owned

| Aspect | User-Owned | Platform-Owned |
|--------|------------|---------------|
| **GitHub Required** | Yes (owner) | No (optional) |
| **Repository Location** | User's account/org | Our organization |
| **Access Control** | User manages | We manage |
| **Cleanup on Delete** | User decides | We handle |
| **Webhook Reliability** | Depends on user's repo settings | Always works |
| **GitHub API Calls** | User's OAuth token | Our PAT/GitHub App |
| **User Experience** | More familiar | May be confusing at first |

### Recommendation

**Use Platform-Owned (Model B) as default** because:
1. Works for users without GitHub accounts
2. We control the repository structure
3. Consistent webhook handling
4. Easier cleanup when store is deleted
5. Users can still push via GitHub web editor

**Offer User-Owned (Model A) as option** for:
- Users with existing GitHub repos they want to use
- Technical users who prefer their own infrastructure
- Users who need collaborators beyond just them

---

## Security Considerations

### 1. Webhook Verification
```typescript
// GitHub: HMAC-SHA256 signature
function verifyGitHubSignature(payload: string, signature: string, secret: string) {
  const expected = 'sha256=' + crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex')
  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))
}

// GitLab: Token comparison
function verifyGitLabToken(token: string, secret: string) {
  return crypto.timingSafeEqual(Buffer.from(token), Buffer.from(secret))
}
```

### 2. Repository Access
- **Deploy keys**: Read-only SSH keys we generate per store
- **No OAuth scopes for full repo access** unless needed
- Owners can revoke access anytime via GitHub/GitLab settings

### 2b. Platform-Owned Repository Security

```typescript
// We need these GitHub App/PAT permissions:
// - repo (full control) - for creating repos, managing collaborators
// - admin:org (read:org) - for organization management

// Per-repository security:
const REPO_SECURITY = {
  visibility: 'private',        // Repos are always private
  deletion: 'admins only',      // Only org admins can delete
  transfer: 'disabled',         // Prevent accidental transfers
  fork: false,                  // Disable forking (prevents data exfiltration)
  issues: true,                // Allow issue tracking for users
  wiki: false,                 // Disable wiki
  projects: false,             // Disable projects
}

// Collaborator permissions
const COLLABORATOR_PERMISSION = 'push'  // Can push, cannot manage settings

// Note on forking:
// - Forking is disabled to prevent accidental data exposure
// - Users can still change visibility (e.g., make repo public if they want)
// - But they cannot fork private repos to their personal account
// - This prevents: store owner clones to personal account → forks public → leaks code
```

### 3. Build Isolation
- Each build runs in isolated container/VM
- No persistence between builds
- Network restrictions (can't access other stores)

---

## UI Flow

### Connect Repository (Platform-Owned - Default)

```
┌─────────────────────────────────────────────────────────────┐
│  Set Up Your Store's Code Repository                   [X]  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  How would you like to manage your store's code?            │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐ │
│  │  🏢 Use Entaprenua Repository (Recommended)         │ │
│  │  ─────────────────────────────────────────────────  │ │
│  │  • No GitHub account required                        │ │
│  │  • Edit directly in browser                         │ │
│  │  • We'll create a repository for you                │ │
│  │  [Get Started →]                                     │ │
│  └─────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐ │
│  │  📦 Connect Existing GitHub Repository               │ │
│  │  ─────────────────────────────────────────────────  │ │
│  │  • Use your own GitHub account                       │ │
│  │  • Requires GitHub account                           │ │
│  │  [Connect with GitHub →]                            │ │
│  └─────────────────────────────────────────────────────┘ │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Connect Existing GitHub (User-Owned)

```
┌─────────────────────────────────────────────────────────────┐
│  Connect to GitHub                                    [X]  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  [GitHub Logo]  Connect with GitHub                        │
│                                                             │
│  You'll be redirected to GitHub to authorize access.        │
│                                                             │
│  Required permissions:                                     │
│  • Read access to repositories                            │
│  • Manage webhooks                                         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Repository Created (Platform-Owned)

```
┌─────────────────────────────────────────────────────────────┐
│  Repository Created                                    [X]  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ✓ Your store repository is ready!                        │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐ │
│  │  📁 entaprenua-stores/store-abc123-mystore          │ │
│  └─────────────────────────────────────────────────────┘ │
│                                                             │
│  We sent an invitation to: john@example.com               │
│                                                             │
│  Next steps:                                               │
│  1. Check your email and accept the GitHub invitation     │
│  2. Start editing your store's pages                      │
│                                                             │
│  How would you like to edit?                               │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐ │
│  │  🌐 Edit in Browser (No Git needed)                 │ │
│  │  Opens GitHub's web editor. You can edit files      │ │
│  │  directly without installing anything.               │ │
│  │  [Open GitHub Editor →]                             │ │
│  └─────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐ │
│  │  💻 Clone to Your Computer                          │ │
│  │  If you're comfortable with Git, clone the repo     │ │
│  │  and push changes.                                  │ │
│  │  [Copy Clone URL]                                   │ │
│  └─────────────────────────────────────────────────────┘ │
│                                                             │
│  Changes you push will automatically deploy your store.   │
│                                                             │
│  [Done]                                                    │
└─────────────────────────────────────────────────────────────┘
```

### Repository Connected (Platform-Owned)

```
┌─────────────────────────────────────────────────────────────┐
│  Repository Settings                                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Your Repository                                             │
│  ┌─────────────────────────────────────────────────────┐  │
│  │  📁 entaprenua-stores/store-abc123-mystore          │  │
│  │  Branch: main                                       │  │
│  │  Owner: john@example.com (collaborator)             │  │
│  └─────────────────────────────────────────────────────┘  │
│                                                             │
│  [View on GitHub →]  [Open Editor →]  [Disconnect]        │
│                                                             │
│  Build Status                                               │
│  ┌─────────────────────────────────────────────────────┐  │
│  │  ✓ Build #42 • 2 min ago                           │  │
│  │  Branch: main • Commit: a1b2c3d                     │  │
│  │  Status: Deployed                                   │  │
│  └─────────────────────────────────────────────────────┘  │
│                                                             │
│  Build History                                              │
│  • #42 (current) - a1b2c3d - Deployed                     │
│  • #41 - 9f8e7d6 - Deployed                               │
│  • #40 - 3c4d5e6 - Failed                                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## API Endpoints

### Store Settings

```typescript
// GET /api/v1/stores/:id/vcs
interface VCSConnection {
  provider: 'github' | 'gitlab'
  repositoryId: string
  repositoryName: string
  branch: string
  webhookId: string
  lastDeployCommit: string
  lastDeployTime: string
  buildStatus: 'idle' | 'building' | 'success' | 'failed'
}

// POST /api/v1/stores/:id/vcs/connect
interface ConnectVCSRequest {
  provider: 'github' | 'gitlab'
  repositoryId: string
  branch?: string
}

// DELETE /api/v1/stores/:id/vcs/disconnect
// DELETE /api/v1/stores/:id/vcs/redeploy
```

### Webhooks

```typescript
// POST /webhooks/github
// POST /webhooks/gitlab
// Internal endpoints, signature verified
```

---

## Build Status Tracking

```typescript
interface BuildRecord {
  id: string
  storeId: string
  commitSha: string
  commitMessage: string
  commitAuthor: string
  branch: string
  status: 'pending' | 'building' | 'success' | 'failed'
  startedAt: string
  completedAt: string | null
  durationMs: number | null
  errorMessage: string | null
  logs: string[]  // Build output (last 100 lines)
}
```

---

## Future Enhancements

1. **Preview Deploys** — Deploy PR branches to preview URLs
2. **Branch Previews** — Each branch gets a preview subdomain
3. **Environment Variables** — Secure store config via dashboard
4. **Build Caching** — Cache node_modules between builds
5. **Rollback** — One-click rollback to previous deploy
6. **Build Notifications** — Slack/Discord/webhook on success/failure

---

## Related Documentation

- [SSR Implementation](SSR_IMPLEMENTATION.md) — How storefronts are currently built
- [Storefront Architecture](STOREFRONT.md) — Multi-tenant SSR architecture
- [Publish System](../docs/SSR_IMPLEMENTATION.md) — Current publish workflow

---

## Decision Summary

### Repository Model

**Use Platform-Owned (Model B) as default**:
1. Works for users without GitHub accounts
2. We control repository structure and settings
3. Consistent webhook handling
4. Easier cleanup when stores are deleted
5. Users can still edit via GitHub web editor

**Offer User-Owned (Model A) as option** for:
- Technical users with existing repos
- Users who prefer their own GitHub infrastructure

### VCS Provider

**Use GitHub first** for these reasons:
1. Most store owners likely have GitHub accounts
2. GitHub Actions has the best CI/CD ecosystem
3. Webhook reliability is excellent
4. Better documentation and community
5. GitHub web editor enables non-technical editing

**GitLab support** can be added later if:
- Enterprise customers request it
- Self-hosted option becomes a priority

### Design Principles

1. **Abstract VCS provider** behind an interface so adding GitLab later doesn't require frontend changes
2. **Platform owns the repos** for consistency and control
3. **Users don't need Git** — web editor is first-class citizen
4. **Email invites** for non-GitHub users
5. **Same workflow** whether user has GitHub or not
