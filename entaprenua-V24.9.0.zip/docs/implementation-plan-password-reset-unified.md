# Password Reset - Unified Implementation Plan

## Overview
Shared password reset logic for both platform users and storefront customers.

## Requirements

| Requirement | Value |
|-------------|-------|
| Method | 6-digit code (not link) |
| Expiry | 15 minutes |
| Rate limiting | 60s cooldown, 3 requests per hour |
| Template | Platform fixed HTML (not customizable) |
| Sender | Store's domain/subdomain (for store customers) |

## Database Changes

### Users Table (Platform)
```sql
ALTER TABLE users ADD COLUMN IF NOT EXISTS password_reset_token VARCHAR(6);
ALTER TABLE users ADD COLUMN IF NOT EXISTS password_reset_expires_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS password_reset_count INT DEFAULT 0;
```

### Store Customers Table
```sql
ALTER TABLE store_customers ADD COLUMN IF NOT EXISTS password_reset_token VARCHAR(6);
ALTER TABLE store_customers ADD COLUMN IF NOT EXISTS password_reset_expires_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE store_customers ADD COLUMN IF NOT EXISTS password_reset_count INT DEFAULT 0;
```

## PasswordResetService (Shared)

### Methods

```kotlin
interface PasswordResetService {
    // Generate and send reset code
    suspend fun sendResetCode(email: String, userType: UserType, storeId: UUID?): ResetResult
    
    // Verify code (without resetting)
    suspend fun verifyCode(email: String, code: String, userType: UserType, storeId: UUID?): Boolean
    
    // Reset password with valid code
    suspend fun resetPassword(email: String, code: String, newPassword: String, userType: UserType, storeId: UUID?): ResetResult
}
```

### Rate Limiting Logic
```kotlin
// Check rate limit before sending
if (user.lastResetRequestAt != null) {
    val minutesSinceLastRequest = Duration.between(user.lastResetRequestAt, now).toMinutes()
    
    if (minutesSinceLastRequest < 1) {  // 60 second cooldown
        return Result.Error("Please wait before requesting another reset code")
    }
    
    if (user.resetCount >= 3 && minutesSinceLastRequest < 60) {
        return Result.Error("Too many reset requests. Try again later.")
    }
}
```

### Email Sending Logic
```kotlin
// Determine sender based on user type
val senderEmail = when (userType) {
    UserType.PLATFORM -> "noreply@entaprenua.com"  // Platform default
    UserType.CUSTOMER -> {
        // Get store's verification domain
        val store = storeRepository.findById(storeId)
        val customDomain = store.verificationCustomDomain
        val subdomain = store.verificationSubdomain
        
        when {
            customDomain != null -> "noreply@$customDomain"
            subdomain != null -> "noreply@$subdomain.entaprenua.com"
            else -> {
                // Auto-extract from store domain
                val domain = store.domainName
                val prefix = domain.substringBefore(".entaprenua.com")
                "noreply@$prefix.entaprenua.com"
            }
        }
    }
}

val senderName = userType == UserType.CUSTOMER ? "Store Team" : "Entaprenua"
```

## API Endpoints

### Platform Password Reset
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/auth/password-reset/request` | Request reset code |
| POST | `/api/v1/auth/password-reset/confirm` | Confirm with code |

### Storefront Customer Password Reset
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/stores/{storeId}/customers/password-reset/request` | Request reset code |
| POST | `/api/v1/stores/{storeId}/customers/password-reset/confirm` | Confirm with code |

## HTML Template (Platform Fixed)

```html
<!DOCTYPE html>
<html>
<head>
    <title>Reset Your Password</title>
</head>
<body>
    <h1>Reset Your Password</h1>
    <p>Your password reset code is:</p>
    <h2 style="letter-spacing: 5px; font-size: 32px;">{reset_code}</h2>
    <p>This code expires in 15 minutes.</p>
    <p>If you didn't request this, please ignore this email.</p>
</body>
</html>
```

## Implementation Files

| File | Description |
|------|-------------|
| `PasswordResetService.kt` | Shared interface |
| `PasswordResetServiceImpl.kt` | Implementation |
| `UserRepository.kt` | Update with password reset queries |
| `StoreCustomerRepository.kt` | Add password reset methods |
| `EmailTemplates.kt` | Add password reset template |
| `ApiRouterConfig.kt` | Add reset endpoints |

## Status
- [x] Plan documented