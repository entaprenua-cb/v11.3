# Known Issues

---

## Query Component - Now Uses SolidJS createResource

**Change**: Refactored `components/ui/query` to use SolidJS native `createResource` instead of TanStack Query.

**Benefits**:
- Native SSR support - prefetches on server, hydrates to client
- No hydration mismatches
- No `onMount`/`mounted` workaround needed in routes
- Simpler, no external dependencies

**How it works**:
- `createResource` is SolidJS's native async primitive
- Works with Suspense out of the box
- SSR: fetches on server, includes data in HTML
- CSR: seamlessly hydrates from server data

**Status**: Fixed ✓

---

## Templates API - Array Response Format

**Issue**: The `/api/v1/templates` endpoint returns a plain array instead of a `PagedResponse` object.

**Issue**: The `/api/v1/templates` endpoint returns a plain array instead of a `PagedResponse` object.

**Current Response**:
```json
[{ "id": "...", "name": "Basic", ... }]
```

**Expected Response**:
```json
{
  "content": [{ "id": "...", "name": "Basic", ... }],
  "page": 0,
  "size": 12,
  "totalElements": 1,
  "totalPages": 1,
  "first": true,
  "last": true,
  "empty": false
}
```

**Frontend Workaround**:
The frontend now handles both array and PagedResponse formats for compatibility.

**Backend Fix Required**:
- Update `StoreGetService.getTemplates()` to return `PagedResponse<Store>` instead of `List<Store>`
- Or update the route handler to wrap the response in a PagedResponse

**Status**: Backend fix needed

---

## Admin Products Page - Inefficient Filtering/Sorting

**Issue**: `routes/admin/products/index.tsx` has inefficient client-side filtering and sorting.

**Problems**:
1. **Inconsistent pagination**: Page state exists but not used properly - fetches all products then filters client-side
2. **Client-side sorting**: Sorting is done client-side via `filteredProducts` memo despite server support
3. **Client-side filtering**: Status and visibility filters are applied client-side after fetching

**Current Behavior**:
- User selects filter → triggers API call → fetches all products → applies filter client-side
- Sorting is applied to the entire dataset client-side

**Expected Behavior**:
- Filters and sorting should be passed to the API
- Server should handle filtering/sorting with pagination
- Only the current page's data should be fetched

**Code Location**: `src/routes/admin/products/index.tsx`

**Status**: Needs refactoring to use server-side filtering/sorting
