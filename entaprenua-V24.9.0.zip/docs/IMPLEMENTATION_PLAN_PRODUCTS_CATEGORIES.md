# Implementation Plan: Products & Categories Mockups

## Overview
Create mockup SQL files with products, categories, and category-product mappings for the M-Shop store.

## Database Schema

### Tables Used
- `categories` - Category hierarchy with LTree paths
- `products` - Product catalog with images, prices, inventory
- `category_products` - Junction table for many-to-many relationships

### Store Context
- **M-Shop Store ID**: `019c0000-0000-0000-0000-000000000010`

---

## UUID Prefix Scheme
| Entity | Prefix |
|--------|--------|
| Categories | `04c00000-0000-0000-0000-00000000xxxx` |
| Products | `05c00000-0000-0000-0000-00000000xxxx` |
| Category Products | `06c00000-0000-0000-0000-00000000xxxx` |

---

## Step 1: Categories (`categories.sql`)

### Hierarchy Structure
```
Electronics (L1) - path: "1"
├── Smartphones (L2) - path: "1.1"
├── Laptops (L2) - path: "1.2"
│   ├── Gaming Laptops (L3) - path: "1.2.1"
│   └── Business Laptops (L3) - path: "1.2.2"
├── Accessories (L2) - path: "1.3"
│   ├── Chargers (L3) - path: "1.3.1"
│   └── Cases (L3) - path: "1.3.2"
└── Audio (L2) - path: "1.4"
    └── Headphones (L3) - path: "1.4.1"

Home & Living (L1) - path: "2"
├── Kitchen (L2) - path: "2.1"
│   ├── Cookware (L3) - path: "2.1.1"
│   └── Drinkware (L3) - path: "2.1.2"
├── Decor (L2) - path: "2.2"
│   └── Vases (L3) - path: "2.2.1"
└── Furniture (L2) - path: "2.3"

Clothing (L1) - path: "3"
├── Men (L2) - path: "3.1"
├── Women (L2) - path: "3.2"
└── Accessories (L2) - path: "3.3"

Stationery (L1) - path: "4"
├── Office Supplies (L2) - path: "4.1"
│   └── Pens (L3) - path: "4.1.1"
├── Notebooks (L2) - path: "4.2"
└── Art Supplies (L2) - path: "4.3"
```

### Fields
- `id` - UUID primary key
- `store_id` - FK to stores (M-Shop)
- `name` - Category name
- `image` - External image URL (Unsplash)
- `level` - 1, 2, or 3
- `parent_id` - Self-referencing FK for hierarchy
- `path` - LTree path for efficient queries
- `visibility` - "public"
- `is_deleted` - false
- `version` - 1

---

## Step 2: Products (`products.sql`)

### Product Count: 30+ products

#### Electronics (12 products)
| # | Name | Price | Stock | Image |
|---|------|-------|-------|-------|
| 1 | iPhone 15 Pro Max | $1,199.00 | 50 | Unsplash phone |
| 2 | Samsung Galaxy S24 Ultra | $1,099.00 | 45 | Unsplash phone |
| 3 | Google Pixel 8 Pro | $899.00 | 30 | Unsplash phone |
| 4 | MacBook Pro 16" | $2,499.00 | 25 | Unsplash laptop |
| 5 | Dell XPS 15 | $1,799.00 | 20 | Unsplash laptop |
| 6 | Lenovo ThinkPad X1 | $1,499.00 | 15 | Unsplash laptop |
| 7 | ASUS ROG Gaming Laptop | $2,199.00 | 10 | Unsplash gaming laptop |
| 8 | MacBook Air M3 | $1,099.00 | 35 | Unsplash laptop |
| 9 | Anker USB-C Charger | $49.99 | 100 | Unsplash charger |
| 10 | Belkin Wireless Charger | $39.99 | 80 | Unsplash charger |
| 11 | iPhone 15 Case (Clear) | $29.99 | 150 | Unsplash phone case |
| 12 | Samsung Leather Case | $34.99 | 120 | Unsplash phone case |
| 13 | Sony WH-1000XM5 | $349.99 | 40 | Unsplash headphones |
| 14 | AirPods Pro 2 | $249.99 | 60 | Unsplash headphones |

#### Home & Living (6 products)
| # | Name | Price | Stock | Image |
|---|------|-------|-------|-------|
| 15 | Stainless Steel Cookware Set | $299.99 | 25 | Unsplash cookware |
| 16 | Non-Stick Frying Pan | $49.99 | 50 | Unsplash pan |
| 17 | Crystal Glass Set (6pc) | $79.99 | 40 | Unsplash glasses |
| 18 | Ceramic Mug Set (4pc) | $34.99 | 60 | Unsplash mugs |
| 19 | Modern Vase | $45.99 | 35 | Unsplash vase |
| 20 | Table Lamp | $89.99 | 30 | Unsplash lamp |

#### Clothing (5 products)
| # | Name | Price | Stock | Image |
|---|------|-------|-------|-------|
| 21 | Classic Cotton T-Shirt | $24.99 | 200 | Unsplash tshirt |
| 22 | Slim Fit Jeans | $59.99 | 100 | Unsplash jeans |
| 23 | Summer Dress | $49.99 | 75 | Unsplash dress |
| 24 | Wool Winter Coat | $199.99 | 40 | Unsplash coat |
| 25 | Leather Belt | $39.99 | 80 | Unsplash belt |

#### Stationery (5 products)
| # | Name | Price | Stock | Image |
|---|------|-------|-------|-------|
| 26 | Premium Ballpoint Pen Set | $19.99 | 150 | Unsplash pens |
| 27 | Gel Pen Multi-Pack | $12.99 | 200 | Unsplash pens |
| 28 | Leather Notebook A5 | $29.99 | 100 | Unsplash notebook |
| 29 | Spiral Notebook Pack | $9.99 | 250 | Unsplash notebook |
| 30 | Artist Brush Set | $24.99 | 60 | Unsplash brushes |

---

## Step 3: Category-Products Mapping (`category-products.sql`)

### Mapping Strategy
- Each product maps to 1-3 categories
- Use junction table `category_products`
- Categories follow the hierarchy, so products in subcategories also inherit parent categories

### Example Mappings
| Product | Primary Category | Additional Categories |
|---------|-----------------|---------------------|
| iPhone 15 Pro Max | Smartphones | Electronics, Accessories |
| MacBook Pro 16" | Laptops | Electronics, Business Laptops |
| ASUS ROG Gaming Laptop | Gaming Laptops | Laptops, Electronics |
| Stainless Steel Cookware Set | Cookware | Kitchen, Home & Living |
| Classic Cotton T-Shirt | Men | Clothing, Accessories |

---

## Image Sources

All images from Unsplash (free, no attribution required):
- Base URL: `https://images.unsplash.com/photo-xxxxxxxxxxxxxx`
- Using direct image links for stability

---

## Execution Order

1. **categories.sql** - Create category hierarchy first
2. **products.sql** - Create products
3. **category-products.sql** - Map products to categories

---

## Files to Create

1. `runtime/src/main/resources/db/mockups/categories.sql`
2. `runtime/src/main/resources/db/mockups/products.sql`
3. `runtime/src/main/resources/db/mockups/category-products.sql`

---

## Success Criteria

- [x] Categories created with proper LTree paths
- [x] Category hierarchy properly linked via parent_id
- [x] 30+ products with real Unsplash images
- [x] Products mapped to multiple categories
- [x] All foreign key references valid
- [x] ON CONFLICT DO NOTHING for idempotent inserts

---

## Files Created

1. `runtime/src/main/resources/db/mockups/categories.sql` - 21 categories (4 L1, 13 L2, 4 L3)
2. `runtime/src/main/resources/db/mockups/products.sql` - 30 products
3. `runtime/src/main/resources/db/mockups/category-products.sql` - 70+ category-product mappings

---

## Execution

Run these SQL files against the database:

```bash
# Apply in order:
psql -h localhost -U mnesh -d entaprenua -f runtime/src/main/resources/db/mockups/categories.sql
psql -h localhost -U mnesh -d entaprenua -f runtime/src/main/resources/db/mockups/products.sql
psql -h localhost -U mnesh -d entaprenua -f runtime/src/main/resources/db/mockups/category-products.sql
```

---

## Refactor: Category UI Components

### Goal
Refactor `components/ui/category.tsx` to match the directory structure of `product/*` and `cart/*`.

### Current Structure (single file)
```
components/ui/category.tsx (444 lines)
```

### Target Structure (directory)
```
components/ui/category/
├── category-context.tsx   # CategoryContext, useCategory hook
├── category-sections.tsx  # All UI components
└── index.ts              # Exports
```

### Convention to Follow

Based on `product/*` and `cart/*`:

| File | Purpose |
|------|---------|
| `*-context.tsx` | Context, hooks (useCategory, CategoryProvider), types |
| `*-sections.tsx` | UI components (CategoryRoot, CategoryName, CategoryImage, etc.) |
| `index.ts` | Re-exports all public API |

### Components to Extract

From `category.tsx`:
1. **category-context.tsx**:
   - `CategoryContext`
   - `useCategory` hook
   - `CategoryProvider` component
   - Types: `CategoryProps`, `CategoryLevel`, `CategoryContextValue`
   - `CategoryProviderProps`

2. **category-sections.tsx**:
   - `CategoryRoot` / `CategoryRootContent`
   - `CategoryName`
   - `CategoryImage`
   - `CategoryLevelBadge`
   - `CategoryBreadcrumb`
   - `CategoryListView`
   - `CategoryTreeView` / `CategoryTreeNode`
   - `CategoryMenu` / `CategoryMenuItem`

3. **index.ts**:
   - Re-export all types and components

### Files to Update
Find all imports from `~/components/ui/category` and update to `~/components/ui/category`

### Execution Steps

1. Create directory: `src/components/ui/category/`
2. Create `category-context.tsx`
3. Create `category-sections.tsx`
4. Create `index.ts`
5. Update all import paths
6. Delete old `category.tsx` ✅

---

## Refactoring Completed

### Status: ✅ COMPLETED

### Created Files

```
components/ui/category/
├── STRUCTURE.md              # Architecture documentation
├── index.ts                  # Barrel exports
├── category-context.tsx      # CategoryContext, useCategory, CategoryProvider
├── category-sections.tsx     # All UI components
```

### Exported Components

- `CategoryProvider` - Context provider
- `useCategory` - Hook to access category context
- `CategoryRoot` - Root component for single category
- `CategoryName` - Display category name
- `CategoryImage` - Display category image
- `CategoryLevelBadge` - Display level badge (Primary/Secondary/Tertiary)
- `CategoryBreadcrumb` - Breadcrumb navigation
- `CategoryListView` - Grid/list view for categories
- `CategoryTreeView` - Tree view with expand/collapse
- `CategoryTreeNode` - Individual tree node
- `CategoryMenu` - Horizontal/vertical menu
- `CategoryMenuItem` - Menu item with dropdown

### Types Exported

- `CategoryProps` - Category data shape
- `CategoryLevel` - 1 | 2 | 3
- `CategoryContextValue` - Context value type
- `CategoryProviderProps` - Provider props type
