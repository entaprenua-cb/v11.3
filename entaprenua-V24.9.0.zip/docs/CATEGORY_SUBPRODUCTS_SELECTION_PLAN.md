# Category Subcategories & Products Selection Implementation Plan

## Overview

This document outlines the implementation plan for adding category subcategory and product selection UI to the category editor.

## Server API Summary

### Subcategories
- **Endpoint**: `GET /stores/{storeId}/categories?parentId={categoryId}`
- **Response**: All categories with level > parentLevel
- **Flag**: `isMappedToParent = true` if category is a direct child

### Products
- **Endpoint**: `GET /stores/{storeId}/products?categoryId={categoryId}`
- **Response**: All products
- **Flag**: `isMappedToCategory = true` if product is mapped to category

### Save Operations
- **Endpoint**: `POST /stores/{storeId}/categories`
- **Payload**:
  - `addChildren: [ids]` - categories to add as children
  - `removeChildren: [ids]` - categories to remove as children
  - `addProducts: [ids]` - products to add to category
  - `removeProducts: [ids]` - products to remove from category

## Implementation Steps

### Step 1: Update Category Type
**File**: `src/lib/types/entities.ts`

Add `isMappedToParent` to Category interface:
```typescript
export interface Category {
  id: string;
  storeId: string;
  name: string;
  image: string | null;
  level: number | null;
  visibility: string | null;
  isDeleted: boolean;
  subcategories: Category[] | null;
  isMappedToParent?: boolean;  // NEW
  insertedAt: string;
  updatedAt: string;
}
```

### Step 2: Update Category Editor Context
**File**: `src/routes/admin/categories/category-editor-context.tsx`

Add state management:
```typescript
// State
selectedChildIds: string[]       // User's subcategory selections
selectedProductIds: string[]      // User's product selections

// Functions
toggleChildCategory(id: string)    // Toggle subcategory selection
toggleProduct(id: string)         // Toggle product selection
computeChildDiff()               // Compute addChildren/removeChildren
computeProductDiff()             // Compute addProducts/removeProducts
```

### Step 3: Create CategorySubcategoriesSection
**File**: `src/routes/admin/categories/sections/CategorySubcategoriesSection.tsx`

Features:
- Fetch: `GET /categories?parentId={categoryId}`
- Display: Table with checkbox, name, image
- Checked state: `isMappedToParent` from API
- Level restriction: Hide if category level = 3
- Filter: Search by name

### Step 4: Create CategoryProductsSection
**File**: `src/routes/admin/categories/sections/CategoryProductsSection.tsx`

Features:
- Fetch: `GET /products?categoryId={categoryId}`
- Display: Table with checkbox, name, price, image
- Checked state: `isMappedToCategory` from API
- Filter: Search by name

### Step 5: Export New Sections
**File**: `src/routes/admin/categories/sections/index.ts`

```typescript
export { CategoryBasicInfoSection } from "./CategoryBasicInfoSection"
export { CategoryVisibilitySection } from "./CategoryVisibilitySection"
export { CategoryImageSection } from "./CategoryImageSection"
export { CategorySubcategoriesSection } from "./CategorySubcategoriesSection"
export { CategoryProductsSection } from "./CategoryProductsSection"
```

### Step 6: Add Sections to CategoryForm
**File**: `src/routes/admin/categories/CategoryForm.tsx`

Layout:
```
┌────────────────────────────────────────────┐
│ Basic Information                          │
├────────────────────────────────────────────┤
│ CategoryBasicInfoSection                   │
└────────────────────────────────────────────┘

┌────────────────────────────────────────────┐
│ Subcategories (if level < 3)               │
├────────────────────────────────────────────┤
│ CategorySubcategoriesSection               │
└────────────────────────────────────────────┘

┌────────────────────────────────────────────┐
│ Products                                   │
├────────────────────────────────────────────┤
│ CategoryProductsSection                    │
└────────────────────────────────────────────┘

┌──────────────┐  ┌─────────────────────────┐
│ Image        │  │ Status                  │
├──────────────┤  ├─────────────────────────┤
│ ImageSection │  │ VisibilitySection       │
└──────────────┘  └─────────────────────────┘
```

## Data Flow

### Load Subcategories
```
1. User opens category editor (edit mode)
2. Fetch: GET /categories?parentId={categoryId}
3. Server returns all categories with isMappedToParent flag
4. Initialize selectedChildIds with categories where isMappedToParent=true
```

### Load Products
```
1. User opens category editor (edit mode)
2. Fetch: GET /products?categoryId={categoryId}
3. Server returns all products with isMappedToCategory flag
4. Initialize selectedProductIds with products where isMappedToCategory=true
```

### Save
```
1. User clicks Save
2. Compute diff:
   - addedChildren = selectedChildIds.filter(id => !originalChildIds.includes(id))
   - removedChildren = originalChildIds.filter(id => !selectedChildIds.includes(id))
   - addedProducts = selectedProductIds.filter(id => !originalProductIds.includes(id))
   - removedProducts = originalProductIds.filter(id => !selectedProductIds.includes(id))
3. Send to server with category data
```

## UI Mockups

### Subcategories Section
```
┌─────────────────────────────────────────────────────┐
│ Subcategories                              [+ Add]  │
├─────────────────────────────────────────────────────┤
│ 🔍 Search subcategories...                          │
├────────┬─────────────────┬─────────────────────────┤
│   ☐   │ Name            │ Image                   │
├────────┼─────────────────┼─────────────────────────┤
│   ☑   │ Electronics     │ [img]                   │
│   ☐   │ Clothing       │ [img]                   │
│   ☑   │ Home & Garden  │ [img]                   │
└────────┴─────────────────┴─────────────────────────┘
Selected: 2
```

### Products Section
```
┌─────────────────────────────────────────────────────┐
│ Products                                           │
├─────────────────────────────────────────────────────┤
│ 🔍 Search products...                               │
├────────┬─────────────────┬────────┬─────────────────┤
│   ☐   │ Name            │ Price  │ Image           │
├────────┼─────────────────┼────────┼─────────────────┤
│   ☑   │ T-Shirt        │ $29.99 │ [img]           │
│   ☐   │ Jeans          │ $49.99 │ [img]           │
│   ☑   │ Sneakers       │ $79.99 │ [img]           │
└────────┴─────────────────┴────────┴─────────────────┘
Selected: 2
```

## Level Rules

| Category Level | Can have Parent | Can have Subcategories |
|----------------|----------------|----------------------|
| 1 (Primary)    | ❌ No          | ✅ Yes (Level 2, 3)  |
| 2 (Secondary)  | ✅ Level 1     | ✅ Yes (Level 3)     |
| 3 (Tertiary)   | ✅ Level 2     | ❌ No                 |

## Files to Modify/Create

| File | Action |
|------|--------|
| `src/lib/types/entities.ts` | Add `isMappedToParent` to Category |
| `src/routes/admin/categories/category-editor-context.tsx` | Add selection state + diff logic |
| `src/routes/admin/categories/sections/CategorySubcategoriesSection.tsx` | Create |
| `src/routes/admin/categories/sections/CategoryProductsSection.tsx` | Create |
| `src/routes/admin/categories/sections/index.ts` | Export new sections |
| `src/routes/admin/categories/CategoryForm.tsx` | Add new sections to layout |

## Notes

- Uses explicit diff pattern (add/remove) - aligns with server implementation
- Level 3 categories hide subcategories section
- Server handles circular reference validation
- Follows existing UI patterns from product editor
