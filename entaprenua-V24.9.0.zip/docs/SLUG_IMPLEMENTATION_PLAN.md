# Slug Implementation Plan

## Overview

Add URL-friendly slugs to products and categories for clean, SEO-friendly URLs.

## Goals

1. Add `slug` field to products and categories tables
2. Create slug redirects table for 301 redirects when slugs change
3. Auto-generate slugs from names
4. Ensure slugs are unique per store
5. Track slug changes for SEO redirects
6. Always generate valid slugs (no empty slugs)

## URL Structure

```
/products/{slug}           # Product page
/categories/{slug}        # Category page
```

## Database Changes

### Migration 1: Add slug to products

```sql
-- V23__Add_product_slug.sql
ALTER TABLE products ADD COLUMN slug VARCHAR(255);
CREATE INDEX idx_products_slug ON products(slug);
CREATE UNIQUE INDEX idx_products_store_slug_unique ON products(store_id, slug) WHERE slug IS NOT NULL AND slug != '';
ALTER TABLE products ADD CONSTRAINT products_store_name_unique UNIQUE (store_id, name);
```

### Migration 2: Add slug to categories

```sql
-- V24__Add_category_slug.sql
ALTER TABLE categories ADD COLUMN slug VARCHAR(255);
CREATE INDEX idx_categories_slug ON categories(slug);
CREATE UNIQUE INDEX idx_categories_store_slug_unique ON categories(store_id, slug) WHERE slug IS NOT NULL AND slug != '';
ALTER TABLE categories ADD CONSTRAINT uq_category_name_level UNIQUE (store_id, name, level);
```

### Migration 3: Create slug redirects table

```sql
-- V25__Add_slug_redirects.sql
CREATE TABLE slug_redirects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id UUID REFERENCES stores(id) ON DELETE CASCADE,
    entity_type VARCHAR(20) NOT NULL CHECK (entity_type IN ('product', 'category')),
    old_slug VARCHAR(255) NOT NULL,
    new_slug VARCHAR(255) NOT NULL,
    entity_id UUID NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(store_id, entity_type, old_slug)
);

CREATE INDEX idx_slug_redirects_lookup ON slug_redirects(store_id, entity_type, old_slug);
CREATE INDEX idx_slug_redirects_entity ON slug_redirects(entity_id);
CREATE INDEX idx_slug_redirects_created ON slug_redirects(created_at);
```

## Backend Changes

### 1. SlugService

```kotlin
@Service
class SlugService(
    private val redirectRepository: SlugRedirectRepository
) {
    // Generate URL-friendly slug from name
    fun generateSlug(name: String): String
    
    // Sanitize user-provided slug
    fun sanitizeSlug(slug: String?): String
    
    // Get or generate slug (always returns valid slug)
    suspend fun getOrGenerateSlug(
        name: String,
        providedSlug: String?,
        storeId: UUID,
        entityType: String,
        existsChecker: suspend (...) -> Boolean
    ): String
    
    // Make slug unique with counter suffix
    suspend fun makeUnique(...): String
    
    // Create redirect when slug changes
    suspend fun createRedirect(oldSlug: String, newSlug: String, ...): Unit
    
    // Get redirect target
    suspend fun getRedirect(storeId: UUID, entityType: String, slug: String): String?
    
    // Clean up redirects when entity deleted
    suspend fun cleanupOldRedirects(entityId: UUID): Unit
    
    companion object {
        const val ENTITY_TYPE_PRODUCT = "product"
        const val ENTITY_TYPE_CATEGORY = "category"
    }
}
```

### 2. Product Entity

```kotlin
data class Product(
    val slug: String? = null,
    // ... existing fields
)
```

### 3. Category Entity

```kotlin
data class Category(
    val slug: String? = null,
    // ... existing fields
)
```

### 4. Repository Changes

**ProductRepository:**
- `findBySlug(storeId, slug)` ✅
- `existsBySlug(storeId, slug, excludeId)` ✅
- `save()` - includes SLUG column in insert/update

**CategoryRepository:**
- `findBySlug(storeId, slug)` ✅
- `existsBySlug(storeId, slug, excludeId)` ✅
- `save()` - includes SLUG column in insert/update

### 5. Service Changes

**ProductSaveServiceImpl:**
- On create: generate slug using `getOrGenerateSlug()`
- On update: always validate/regenerate slug using `getOrGenerateSlug()`
- On slug change: create redirect in `slug_redirects` table

**CategorySaveServiceImpl:**
- Same behavior as ProductSaveServiceImpl

### 6. Slug Auto-Generation Logic

```
getOrGenerateSlug(name, providedSlug, ...):
1. Try user-provided slug (after sanitization)
2. Try generating from name
3. Fall back to UUID (8 chars)
```

### 7. API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/stores/{id}/products/by-slug/{slug}` | Get product by slug (SEO-friendly URLs) |
| GET | `/stores/{id}/products/{id}` | Get product by UUID |
| GET | `/stores/{id}/categories/by-slug/{slug}` | Get category by slug (SEO-friendly URLs) |
| GET | `/stores/{id}/categories/{id}` | Get category by UUID |
| POST | `/stores/{id}/products` | Create/update product (auto-generates slug) |
| POST | `/stores/{id}/categories` | Create/update category (auto-generates slug) |

## Slug Generation Rules

```kotlin
// Sanitize user-provided slug
fun sanitizeSlug(slug: String?): String {
    if (slug.isNullOrBlank()) return ""
    return slug
        .lowercase()
        .normalizeAccents()
        .replace(Regex("[^a-z0-9\\s-]"), "")
        .replace(Regex("\\s+"), "-")
        .replace(Regex("-+"), "-")
        .replace(Regex("^-|-$"), "")
        .take(255)
}

// Generate from name
fun generateSlug(name: String): String {
    if (name.isBlank()) return ""
    return name
        .lowercase()
        .normalizeAccents()
        .replace(Regex("[^a-z0-9\\s-]"), "")
        .replace(Regex("\\s+"), "-")
        .replace(Regex("-+"), "-")
        .replace(Regex("^-|-$"), "")
        .take(255)
}

// Make unique
suspend fun makeUnique(baseSlug, storeId, entityType, existsChecker): String {
    var slug = baseSlug
    var counter = 1
    while (existsChecker(storeId, slug, entityType)) {
        slug = "$baseSlug-$counter"
        counter++
    }
    return slug
}
```

## Examples

| Name | Sanitized Slug | Unique Slug |
|------|----------------|-------------|
| Wireless Headphones Pro | `wireless-headphones-pro` | `wireless-headphones-pro` |
| Men's T-Shirt (Blue!) | `mens-t-shirt-blue` | `mens-t-shirt-blue` |
| Café Latte 500ml | `cafe-latte-500ml` | `cafe-latte-500ml` |
| Wireless Headphones Pro (duplicate) | `wireless-headphones-pro` | `wireless-headphones-pro-1` |
| (empty) | (empty) | `a1b2c3d4` (UUID) |

## Testing Checklist

- [x] Create product without slug → slug auto-generated
- [x] Create category without slug → slug auto-generated
- [x] Update product name → slug updated, redirect created
- [x] Update category name → slug updated, redirect created
- [x] Old slug returns 301 redirect to new slug (WebFilter)
- [x] Duplicate name → unique slug with suffix (e.g., `name-2`)
- [x] Special characters in name → cleaned slug (e.g., "Café Latte" → "cafe-latte")
- [ ] Frontend product URLs use slug
- [ ] Frontend category URLs use slug

## Files Modified/Created

### Backend (runtime/)

```
src/main/kotlin/com/entaprenua/
├── common/
│   ├── SlugService.kt              # Updated with sanitization methods
│   ├── repositories/
│   │   └── SlugRedirectRepository.kt  # NEW: CRUD for slug_redirects
│   └── filter/
│       └── SlugRedirectFilter.kt     # NEW: 301 redirect WebFilter
├── entities/
│   ├── Product.kt                  # Already has slug field
│   └── Category.kt                 # Already has slug field
├── store/
│   ├── repositories/
│   │   ├── ProductRepository.kt    # Added SLUG to productRow, findBySlug, existsBySlug
│   │   └── CategoryRepository.kt   # Added SLUG to categoryRow, findBySlug, existsBySlug
│   └── impl/
│       ├── ProductSaveServiceImpl.kt   # Uses getOrGenerateSlug(), creates redirects
│       └── CategorySaveServiceImpl.kt  # Uses getOrGenerateSlug(), creates redirects
├── config/
│   └── ApiRouterConfig.kt          # Added /by-slug routes with comments
└── resources/db/migration/
    ├── V23__Add_product_slug.sql   # Updated with unique constraints
    ├── V24__Add_category_slug.sql  # Updated with unique constraints
    └── V25__Add_slug_redirects.sql # Creates slug_redirects table
```

### Frontend (src/)

```
src/
├── lib/
│   ├── types/entities.ts       # Add slug to types (TODO)
│   └── api/
│       ├── products.ts         # Add getBySlug method (TODO)
│       └── categories.ts       # Add getBySlug method (TODO)
└── components/ui/
    ├── product/
    │   └── product-root.tsx   # Use slug for URLs (TODO)
    └── category/
        └── category-root.tsx   # Use slug for URLs (TODO)
```

## Timeline

1. [x] Database migrations (V23-V25)
2. [x] Backend: Entity + Repository updates
3. [x] Backend: SlugService creation with sanitization
4. [x] Backend: Service updates with slug handling
5. [x] Backend: API endpoints with by-slug support
6. [x] Backend: 301 redirect WebFilter
7. [ ] Frontend: Type updates
8. [ ] Frontend: API client updates
9. [ ] Frontend: Component href updates
10. [ ] Testing and bug fixes

## Status: Implementation Complete ✅

### Backend Fully Implemented

1. **Database**: Migrations V23-V25 applied
   - `products.slug` column with unique index
   - `categories.slug` column with unique index
   - `slug_redirects` table for 301 redirects

2. **Repositories**:
   - `findBySlug(storeId, slug)` - Find by slug
   - `existsBySlug(storeId, slug, excludeId)` - Check if slug exists

3. **SlugService**:
   - `generateSlug(name)` - Generate from name
   - `sanitizeSlug(slug)` - Sanitize user-provided slug
   - `getOrGenerateSlug()` - Always returns valid slug
   - `makeUnique()` - Make slug unique with counter
   - `createRedirect()` - Create 301 redirect
   - `cleanupOldRedirects()` - Clean up redirects

4. **Save Services**:
   - Auto-generate slug on create
   - Always validate/regenerate slug on update
   - Create redirect when slug changes

5. **API Endpoints**:
   - `GET /stores/{id}/products/by-slug/{slug}` - Get by slug
   - `GET /stores/{id}/categories/by-slug/{slug}` - Get by slug

6. **WebFilter**:
   - `SlugRedirectFilter` - Returns 301 redirect for old slugs
   - Pattern: `/api/v1/stores/{storeId}/products/{slug}` and `/api/v1/stores/{storeId}/categories/{slug}`
   - Skips UUIDs (preserves ID-based lookups)

### Remaining: Frontend

- Update TypeScript types with slug field
- Add `getBySlug()` to API clients
- Update component hrefs to use slugs

### Notes

**Redirect behavior:** When a product/category slug changes, the old slug is stored in `slug_redirects` table. The `SlugRedirectFilter` WebFilter intercepts requests and returns 301 redirect to the new slug.

**WebFilter Implementation:**
- File: `runtime/src/main/kotlin/com/entaprenua/common/filter/SlugRedirectFilter.kt`
- Pattern: `/api/v1/stores/{storeId}/products/{slug}` and `/api/v1/stores/{storeId}/categories/{slug}`
- Skips UUIDs (e.g., `/products/019d0274-6a07-7bf8-8b8a-eaef787ac062`)
- Returns 301 `MOVED_PERMANENTLY` with `Location` header

**Redirect Chain Handling:** Current implementation redirects one step at a time (A→B, not A→B→C)
