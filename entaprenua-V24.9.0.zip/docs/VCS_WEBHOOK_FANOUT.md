# VCS Connection & Webhook Fan-Out

## Overview

Stores can connect to GitHub repositories in two ways:

1. **Template linking** — pick a pre-built template by name; the store uses the template's repository URL directly (no cloning).  
2. **GitHub App connection** — install the platform GitHub App on a user's account, then pick a repository from the installation.

Both paths reuse webhooks when multiple stores connect to the same repository. A single push triggers rebuilds for all matching stores.

---

## Connection Paths

### 1. Template Linking — `POST /{publicId}/link-template`

**Frontend**: Admin panel → Settings → Source Code → "Use a Template" combobox.  
**Backend**: `VcsService.linkTemplate(storeId, templateId)`.

**Flow**:
1. Validate the template exists and is a template (`store.isTemplate == true`).
2. Parse the template's `repositoryUrl` to extract `owner` and `repoName`.
3. Fetch repo info from GitHub API to get the `repositoryId`.
4. Check `vcsConnectionRepository.findByRepositoryId(repoId)` for an existing connection:
   - **Found with `webhookId`?** Reuse `webhookId` + `webhookSecretEncrypted`.
   - **Not found?** Generate a secret, encrypt it, register a new webhook on GitHub via PAT.
5. Save a `VcsConnection` row with the (possibly reused) webhook credentials.
6. Update `store.repositoryUrl`.
7. Queue an initial build.

### 2. GitHub App Connection — `POST /{publicId}/vcs/repos`

**Frontend**: Admin panel → Settings → Source Code → Install GitHub App → pick repo.  
**Backend**: `GitHubAppInstallService.connectRepository(storeId, body)`.

**Flow**:
1. Require a pre-existing `VcsConnection` with a `githubInstallationId` (the user must install the app first).
2. List repos accessible via the installation token; validate the user's selection.
3. **Check `findByRepositoryId(repoId)` for an existing connection:**
   - **Found with `webhookId`?** Reuse `webhookId` + `webhookSecretEncrypted`.
   - **Not found?** Generate a secret, encrypt it, register a webhook on GitHub via the installation token.  
     (GitHub App webhook URL: `/api/v1/github-app/webhook` — separate from the PAT-based `/webhooks/github`.)
4. Save the `VcsConnection` with the repo info and (possibly reused) webhook credentials in a single `save()` call.
5. Update `store.repositoryUrl`.
6. Queue an initial build.

---

## Webhook Architecture

### Shared Secret Model

Multiple stores can point to the same GitHub repository. Each store has its own `vcs_connections` row, but rows for the same repo share identical `webhook_id` and `webhook_secret_encrypted`. This means:

- Only **one** webhook is registered on GitHub per repository.
- When a push triggers that webhook, **all** `vcs_connection` rows with the matching secret match the incoming HMAC signature.

### Deduplication Logic

Both `linkTemplate()` and `connectRepository()` follow the same pattern:

```
existing = findByRepositoryId(repoId)
if (existing?.webhookId != null) {
    reuse existing.webhookId + existing.webhookSecretEncrypted
} else {
    generate secret → encrypt → register webhook on GitHub
}
```

This guarantees that two stores linked to the same repo never create duplicate webhooks (staying well under GitHub's 20-webhook-per-repo limit).

---

## Push-to-Build Flow

```
                GitHub repo
                     │
                     │ push to branch
                     ▼
         GitHub sends webhook POST
         (X-Hub-Signature-256 header)
                     │
                     ▼
  ┌──────────────────────────────────────┐
  │  WebhookService.handleGitHubPush()   │
  │                                      │
  │  1. verifyAndFindConnections()       │
  │     - Load ALL vcs_connection rows   │
  │     - Decrypt each webhook secret    │
  │     - Compute HMAC-SHA256            │
  │     - Compare to X-Hub-Signature-256 │
  │     - Return all matching rows       │
  │                                      │
  │  2. For each matched connection:     │
  │     - Check branch matches ref       │
  │     - Skip if buildStatus == BUILDING│
  │     - Call triggerBuildFromWebhook() │
  │       with the specific connection   │
  └──────────────────────────────────────┘
                     │
                     ▼
  ┌──────────────────────────────────────┐
  │  VcsService.triggerBuildFromWebhook()│
  │                                      │
  │  - Uses connection.storeId directly  │
  │  - Update buildStatus → BUILDING     │
  │  - Update lastDeployCommit           │
  │  - Create VcsBuild row               │
  │  - Queue build in BuildQueueService  │
  └──────────────────────────────────────┘
                     │
                     ▼
               Build executes
                     │
                     ▼
          Store auto-starts after
          successful build
```

### Example: Two stores, one repo

```
Stores:  Store A (branch: main)
         Store B (branch: main)
         Both connected to repo owner/ecommerce-template

vcs_connections:
  row_A: storeId=A, repoId=123, webhookId=wh_abc, secret=enc(xxx)
  row_B: storeId=B, repoId=123, webhookId=wh_abc, secret=enc(xxx)
                            ^^^^^^^^^^^^^^^^^^^^^^^ same webhook

Push → GitHub fires webhook wh_abc

verifyAndFindConnections():
  - Decrypts row_A secret → HMAC matches → matched
  - Decrypts row_B secret → HMAC matches → matched
  Result: [row_A, row_B]

Loop:
  - row_A: branch matches → triggerBuildFromWebhook(row_A, payload)
    → build queued for Store A
  - row_B: branch matches → triggerBuildFromWebhook(row_B, payload)
    → build queued for Store B

Result: One push, two builds, one webhook.
```

---

## Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Shared webhook per repo** | Avoids GitHub's 20-webhook limit. One push → HMAC matches all connections with the same secret. |
| **HMAC-based fan-out, not repo-id lookup** | The same HMAC signature verifies once, then matches all rows sharing the secret. No need to maintain a whitelist of repo-specific UUIDs. |
| **Connection passed to triggerBuildFromWebhook** | Previously the method did its own `findByRepositoryId()` which returned only the first row. Now it receives the specific `VcsConnection` from the fan-out loop, ensuring each store gets its own build. |
| **Template linking = no clone** | Template stores are not cloned. The store directly uses the template's repository URL. Same webhook triggers rebuilds when the template is updated. |
| **Dedup before save, not after** | The deduplication check runs before creating the `VcsConnection` row, so webhook credentials are included in the initial `save()` rather than a separate `updateWebhookId()`. |

---

## Relevant Files

| File | Role |
|------|------|
| `VcsService.kt:linkTemplate()` | Template linking with webhook dedup |
| `VcsService.kt:triggerBuildFromWebhook()` | Build triggering (accepts connection from caller) |
| `GitHubAppInstallService.kt:connectRepository()` | GitHub App repo connection with webhook dedup |
| `WebhookService.kt:handleGitHubPush()` | Webhook receiver; fan-out loop and HMAC matching |
| `WebhookService.kt:verifyAndFindConnections()` | HMAC matching against all vcs_connections |
| `VcsConnectionRepository.kt:findByRepositoryId()` | Single-row lookup by repository_id (used for dedup) |
| `VcsDtos.kt:WebhookPayload` | Webhook payload DTO |
| `VcsDtos.kt:LinkTemplateRequest` | Template link request DTO |
