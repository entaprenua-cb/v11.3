# Guest Session Management Implementation

## Overview

This document outlines the implementation of server-generated guest sessions for the e-commerce platform, following the existing authentication patterns and reusing the `user_sessions` table.

## Goals

1. **Security**: Server-controlled session IDs (not client-generated UUIDs)
2. **Persistence**: Sessions persist across browser sessions via httpOnly cookies
3. **Compatibility**: Reuse existing `user_sessions` table with nullable `user_id`
4. **Standards**: Follow existing auth patterns (httpOnly cookies, SameSite)

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Guest Session Flow                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  1. First Store Visit (no cookie)                               │
│     GET /stores/{publicId}/sessions                             │
│     │                                                            │
│     ▼                                                            │
│     GuestSessionService.createGuestSession()                    │
│     ├── Create user_sessions record (user_id = null)            │
│     ├── Set httpOnly cookie: guest_session_id=<sessionId>       │
│     └── Return: { sessionId, expiresAt }                        │
│                                                                  │
│  2. Subsequent Requests (cookie present)                        │
│     │                                                            │
│     ▼                                                            │
│     Request reads guest_session_id cookie                        │
│     │                                                            │
│     ▼                                                            │
│     Cart/Other services use session for guest identification     │
│                                                                  │
│  3. User Registers/Logs In                                      │
│     │                                                            │
│     ▼                                                            │
│     AuthService creates authenticated session                     │
│     └── Optional: Merge guest cart → user cart                  │
│                                                                  │
│  4. Session Expiry                                              │
│     └── Scheduled cleanup of expired guest sessions               │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Database Schema

### Reusing `user_sessions` Table

The existing `user_sessions` table is designed to support both authenticated and guest sessions:

```sql
CREATE TABLE public.user_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,                          -- NULL for guest sessions
    session_token_hash character varying(64),
    refresh_token_hash character varying(64),
    device_fingerprint character varying(64),
    ip_address inet,
    user_agent text,
    device_type character varying(20),
    browser character varying(50),
    os character varying(50),
    is_active boolean DEFAULT true,
    last_accessed_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    PRIMARY KEY (id)
);
```

### Guest Session Fields

| Field | Value for Guests | Notes |
|-------|------------------|-------|
| `user_id` | NULL | Identifies as guest |
| `session_token_hash` | Session ID hash | Simple identifier |
| `refresh_token_hash` | NULL | Not needed for guests |
| `expires_at` | 30 days | Configurable TTL |

## API Endpoints

### 1. Get/Create Guest Session

```
GET /stores/{publicId}/sessions
```

**Request**: No body required (uses cookie)

**Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "sessionId": "uuid",
    "expiresAt": "2026-05-15T12:00:00Z",
    "isNew": true
  }
}
```

**Behavior**:
- If valid `guest_session_id` cookie exists → return existing session
- If no cookie or expired → create new session, set cookie

**Cookie**:
```
Name: guest_session_id
Value: <sessionId>
HttpOnly: true
Secure: true (production)
SameSite: Lax
Path: /
Max-Age: 2592000 (30 days)
```

### 2. Get Current Session

```
GET /stores/{publicId}/sessions/current
```

**Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "sessionId": "uuid",
    "expiresAt": "2026-05-15T12:00:00Z",
    "isGuest": true,
    "isAuthenticated": false
  }
}
```

### 3. Refresh Session

```
POST /stores/{publicId}/sessions/refresh
```

**Behavior**: Extends session expiry by another TTL period.

## Implementation Details

### 1. GuestSessionService

**File**: `services/GuestSessionService.kt`

```kotlin
@Service
class GuestSessionService(
    private val sessionRepository: SessionRepository,
    private val cookieSettings: GuestCookieSettings
) {
    
    suspend fun getOrCreateSession(
        request: ServerRequest,
        publicId: String
    ): GuestSessionResponse
    
    suspend fun getCurrentSession(request: ServerRequest): GuestSessionResponse?
    
    suspend fun refreshSession(request: ServerRequest): GuestSessionResponse
    
    suspend fun getSessionIdFromRequest(request: ServerRequest): UUID?
}
```

### 2. GuestCookieSettings

**File**: `config/GuestCookieSettings.kt`

Extends existing cookie patterns:

```kotlin
@Component
class GuestCookieSettings(
    @Value("\${app.security.cookies.secure:true}") private val secure: Boolean
) {
    companion object {
        const val COOKIE_NAME = "guest_session_id"
        const val DEFAULT_TTL_DAYS = 30L
    }
    
    fun setGuestCookie(builder: ServerResponse.BodyBuilder, sessionId: UUID, maxAgeSeconds: Long): ServerResponse.BodyBuilder
    
    fun getGuestSessionId(request: ServerRequest): String?
    
    fun clearGuestCookie(builder: ServerResponse.BodyBuilder): ServerResponse.BodyBuilder
}
```

### 3. SessionRepository Extensions

**File**: `auth/repositories/SessionRepository.kt` (existing)

Add methods for guest sessions:

```kotlin
suspend fun createGuestSession(session: GuestSession): UserSession {
    // Creates session with nullable user_id
}

suspend fun findGuestSession(sessionId: UUID): UserSession? {
    // Finds guest session by ID
}

suspend fun extendGuestSession(sessionId: UUID, newExpiry: OffsetDateTime): Boolean {
    // Extends expiry for guest sessions
}

suspend fun deleteExpiredGuestSessions(): Int {
    // Cleanup job
}
```

### 4. Cart Integration

**File**: `store/impl/CartGetServiceImpl.kt`

```kotlin
override suspend fun getByStoreId(request: ServerRequest): ServerResponse {
    val storeId = request.requireStoreId()
    
    // Try authenticated user first
    val ctx = RequestContextHolder.get()
    if (ctx?.isAuthenticated == true) {
        // Get cart by customer_id
        return getAuthenticatedUserCart(storeId, ctx.userId)
    }
    
    // Fall back to guest session
    val guestSessionId = guestSessionService.getSessionIdFromRequest(request)
    if (guestSessionId != null) {
        // Get cart by guest_session_id
        return getGuestCart(storeId, guestSessionId)
    }
    
    // No session - return empty cart
    return ServerResponse.ok().bodyValueAndAwait(apiSuccess(emptyCart))
}
```

**File**: `store/impl/CartSaveServiceImpl.kt`

```kotlin
override suspend fun save(request: ServerRequest): ServerResponse {
    val storeId = request.requireStoreId()
    val ctx = RequestContextHolder.get()
    
    // Get guest session ID for associating cart
    val guestSessionId = if (ctx?.isAuthenticated != true) {
        guestSessionService.getSessionIdFromRequest(request)
    } else null
    
    // Build cart entity with guestSessionId
    val cart = Cart(
        storeId = storeId,
        customerId = ctx?.userId,
        guestSessionId = guestSessionId,
        // ... other fields
    )
    
    repository.save(cart)
}
```

## Files to Create

| File | Purpose |
|------|---------|
| `services/GuestSessionService.kt` | Core guest session logic |
| `config/GuestCookieSettings.kt` | Cookie management |
| `entities/GuestSession.kt` | Guest session data class |

## Files to Modify

| File | Changes |
|------|---------|
| `config/ApiRouterConfig.kt` | Add session endpoints |
| `auth/repositories/SessionRepository.kt` | Add guest session methods |
| `store/impl/CartGetServiceImpl.kt` | Read guest session from cookie |
| `store/impl/CartSaveServiceImpl.kt` | Associate cart with guest session |
| `AuthConfig.kt` | Wire GuestSessionService |

## Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `GUEST_SESSION_TTL_DAYS` | 30 | Session expiry in days |
| `GUEST_SESSION_ENABLED` | true | Enable guest sessions |

## Security Considerations

1. **XSS Protection**: httpOnly cookies cannot be accessed by JavaScript
2. **CSRF**: Guest sessions don't require CSRF (no state-changing operations)
3. **Session Fixation**: New session ID on each visit (no fixation possible)
4. **Expiration**: Automatic cleanup of expired sessions

## Cart Merge on Login

When a guest user registers or logs in:

### Strategy Options

| Option | Description | Complexity |
|--------|-------------|------------|
| **A: Migrate** | Move guest cart items to user cart | Medium |
| **B: Preserve** | Keep both carts, user can view guest cart | Low |
| **C: Prompt** | Ask user which cart to keep | High |

### Recommended: Option A (Migrate)

```
1. Guest user has session with associated cart
2. User logs in/registers
3. System finds guest cart by session ID
4. System finds/creates user cart
5. Merge: Add guest cart items to user cart (avoiding duplicates)
6. Delete guest cart
7. Optional: Clear guest cookie or leave for future guest visits
```

### Implementation

```kotlin
suspend fun mergeGuestCartToUser(userId: UUID, guestSessionId: UUID) {
    val guestCart = cartRepository.findByGuestSessionId(guestSessionId)
    val userCart = cartRepository.findByCustomerId(userId) 
        ?: cartRepository.create(userId)
    
    guestCart.items.forEach { guestItem ->
        val existingItem = userCart.items.find { it.productId == guestItem.productId }
        if (existingItem != null) {
            // Add quantities
            userCart.updateQuantity(existingItem.productId, 
                existingItem.quantity + guestItem.quantity)
        } else {
            // Add new item
            userCart.addItem(guestItem)
        }
    }
    
    cartRepository.delete(guestCart)
}
```

## Testing

### Manual Testing

```bash
# 1. First visit - creates session
curl -v http://localhost:3000/stores/st_xxx

# 2. Verify cookie set
curl -v -b "guest_session_id=xxx" http://localhost:3000/stores/st_xxx

# 3. Add to cart
curl -X POST http://localhost:3000/stores/st_xxx/carts \
  -H "Cookie: guest_session_id=xxx" \
  -d '{"productId": "xxx", "quantity": 1}'

# 4. Verify cart persisted
curl http://localhost:3000/stores/st_xxx/carts \
  -b "guest_session_id=xxx"
```

## Future Enhancements

1. **Wishlist support**: Associate wishlist with guest session
2. **Recently viewed**: Track product views for guests
3. **Abandoned cart recovery**: Email recovery for guest checkouts
4. **Session analytics**: Track guest behavior

## References

- Existing auth implementation: `backend/src/main/kotlin/com/entaprenua/auth/`
- Cookie patterns: `backend/src/main/kotlin/com/entaprenua/config/CookieSettings.kt`
- Session repository: `backend/src/main/kotlin/com/entaprenua/auth/repositories/SessionRepository.kt`
