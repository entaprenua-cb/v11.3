# AdminHeader Component

Reusable header component for admin pages with navigation and actions.

## Usage

```tsx
import { AdminHeader } from "~/components/ui/header"

<AdminHeader
  title="Page Title"
  description="Optional description"
  backLink="/admin/products"
  showHome
  actions={<Button>Save</Button>}
/>
```

## Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `title` | `string` | Required | Main title displayed |
| `description` | `string` | - | Optional subtitle text |
| `backLink` | `string` | - | URL for back button navigation |
| `showHome` | `boolean` | `false` | Show home button |
| `actions` | `JSX.Element` | - | Action buttons on the right |

## Examples

### Basic with back button
```tsx
<AdminHeader
  title="Products"
  backLink="/admin"
/>
```

### With home and actions
```tsx
<AdminHeader
  title="Create Product"
  description="Add a new product"
  backLink="/admin/products"
  showHome
  actions={<Button>Save</Button>}
/>
```

### With multiple actions
```tsx
<AdminHeader
  title="Edit Product"
  backLink="/admin/products"
  showHome
  actions={
    <Flex class="gap-2">
      <Button variant="destructive">Delete</Button>
      <Button>Save</Button>
    </Flex>
  }
/>
```

## Files

- Component: `src/components/ui/header/index.tsx`
