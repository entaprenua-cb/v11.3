# Data Table Component

## Overview

A reusable data table component built with TanStack Table for SolidJS. Provides sorting, filtering, pagination, and row selection out of the box.

## Location

```
src/components/ui/data-table.tsx
```

## Installation

**Required dependency:**
```bash
npm install @tanstack/solid-table
```

**Note:** If npm has issues with `~/.npmrc` prefix config, use:
```bash
npm install @tanstack/solid-table --prefix=/tmp/npm-temp && cp -r /tmp/npm-temp/node_modules/@tanstack/solid-table ./node_modules/
```

## Usage

### Basic Example

```tsx
import { createSignal, For, Show } from "solid-js"
import { DataTable, createDataColumn, createActionsColumn, type ColumnDef } from "~/components/ui/data-table"
import { Button } from "~/components/ui/button"
import { Text } from "~/components/ui/text"
import { Badge } from "~/components/ui/badge"
import { PencilIcon, Trash2Icon } from "~/icons"

type Product = {
  id: string
  name: string
  price: number
  status: "active" | "draft" | "archived"
}

const columns: ColumnDef<Product>[] = [
  // Selection column
  {
    id: "select",
    header: () => <input type="checkbox" />,
    cell: () => <input type="checkbox" />,
    enableSorting: false,
  },
  // Text column
  createDataColumn({
    column: { accessorKey: "name" },
    header: "Name",
    cell: ({ row }) => <Text>{row.original.name}</Text>,
  }),
  // Formatted column
  createDataColumn({
    column: { accessorKey: "price" },
    header: "Price",
    cell: ({ row }) => (
      <Text>${row.original.price.toFixed(2)}</Text>
    ),
  }),
  // Status badge
  createDataColumn({
    column: { accessorKey: "status" },
    header: "Status",
    cell: ({ row }) => (
      <Badge variant={row.original.status === "active" ? "success" : "secondary"}>
        {row.original.status}
      </Badge>
    ),
  }),
  // Actions column
  createActionsColumn((row) => (
    <>
      <Button variant="ghost" size="icon">
        <PencilIcon />
      </Button>
      <Button variant="ghost" size="icon">
        <Trash2Icon />
      </Button>
    </>
  )),
]

export default function ProductTable() {
  const [data] = createSignal<Product[]>([
    { id: "1", name: "Product 1", price: 29.99, status: "active" },
    { id: "2", name: "Product 2", price: 49.99, status: "draft" },
  ])

  const handleRowClick = (row: Product) => {
    console.log("Clicked:", row)
  }

  return (
    <DataTable
      columns={columns}
      data={data()}
      pageSize={10}
      onRowSelect={handleRowClick}
    />
  )
}
```

## API

### DataTable Props

| Prop | Type | Required | Description |
|------|------|----------|-------------|
| `columns` | `ColumnDef<TData, TValue>[]` | Yes | Column definitions |
| `data` | `TData[]` | Yes | Data to display |
| `pageSize` | `number` | No | Rows per page (default: 10) |
| `onRowSelect` | `(row: TData) => void` | No | Row click handler |
| `getRowId` | `(row: TData) => string` | No | Custom row ID |
| `class` | `string` | No | Additional CSS classes |
| `loading` | `boolean` | No | Show loading state |

### Column Helpers

#### `createDataColumn(config)`

Creates a column with header and optional cell renderer.

```tsx
createDataColumn({
  column: { accessorKey: "fieldName" },
  header: "Display Header",
  cell: ({ row }) => <CustomComponent value={row.original.fieldName} />
})
```

#### `createActionsColumn(render)`

Creates an actions column with custom render function.

```tsx
createActionsColumn((row) => (
  <Button onClick={() => edit(row)}>Edit</Button>
))
```

### TanStack Table Features

The component includes built-in support for:

- **Sorting** - Click column headers to sort (asc/desc)
- **Filtering** - Built-in filter state management
- **Pagination** - Previous/Next buttons with page count
- **Row Selection** - Checkbox selection with select all
- **Column Visibility** - Toggle columns on/off

### Accessing Table State

For advanced use cases, you can access the table instance:

```tsx
import { createSignal } from "solid-js"
import { getFilteredRowModel, getSortedRowModel } from "@tanstack/solid-table"

// Add to table options:
getFilteredRowModel(),
getSortedRowModel(),
```

## Example: Products Table

See `src/routes/admin/products/index.tsx` for a full implementation with:

- Server-side pagination
- Client-side sorting/filtering
- Bulk selection/deletion
- Inline editing
- Status badges

## Types

```tsx
import type { 
  ColumnDef, 
  SortingState, 
  ColumnFiltersState, 
  VisibilityState 
} from "@tanstack/solid-table"
```

## Styling

The table uses Tailwind CSS classes. Customize by:

1. Wrapping with custom classes
2. Using the `class` prop
3. Modifying the component directly

## Best Practices

1. **Define columns separately** - Keep column definitions in a separate file for reuse
2. **Use proper types** - Always type your data
3. **Handle loading states** - Pass `loading` prop for async data
4. **Implement row actions** - Use `createActionsColumn` for edit/delete
5. **Consider server-side** - For large datasets, implement server-side pagination
