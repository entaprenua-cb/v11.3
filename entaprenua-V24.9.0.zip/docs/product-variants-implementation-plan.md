# Product Variants Implementation Plan

## Overview

Product variants let merchants sell the same product in different options (size, color, material) without duplicating it. Each variant gets its own SKU, price, stock, weight, and image — and the storefront shows a picker so customers select the right combination.

This uses a **separate-table model**: `product_options` defines the option dimensions, `variant_option_values` maps variant options to option group, `product_variants` holds the sellable units, and `products` keeps only the shared data. No self-referencing, no EAV. Unlimited option dimensions.

Also adds `brand`, `vendor`, and `product_type` columns to `products` for filtering — which are currently missing entirely.

## Architecture

```
products
├── id, name, description, slug, visibility
├── brand, vendor, product_type                    ← NEW
├── average_rating, review_count, is_deleted
│
├── product_options (one-to-many)
│   ├── id, name: "Size",   position: 0
│   ├── id, name: "Color",  position: 1
│   └── id, name: "Material", position: 2
│
├── product_variants (one-to-many)
│   ├── id, sku: TSH-RED-M, price, stock
│   ├── id, sku: TSH-BLU-M, price, stock
│   ├── id, sku: TSH-RED-L, price, stock
│   └── id, sku: TSH-BLU-L, price, stock
│       │
│       └── variant_option_values (one-to-many)
│           variant_id → option_id → value
│           v_1 → Size: "M",   v_1 → Color: "Red"
│           v_2 → Size: "M",   v_2 → Color: "Blue"
│           v_3 → Size: "L",   v_3 → Color: "Red"
│           v_4 → Size: "L",   v_4 → Color: "Blue"
│
├── product_media (polymorphic: variant_id NULL = product-level)
├── product_metadata (polymorphic: variant_id NULL = product-level)
└── product_reviews (product-level only)
```

**Cart/Order flow:**

```
Storefront: Customer picks Size=M, Color=Red → variant_id = v_123
  → POST /cart/add { variantId: "v_123", quantity: 2 }
    → cart_items.variant_id = v_123
    → checkout snapshot: order_items.variant_id + variant_sku + variant_options
```

**Key design decisions:**

1. Variants have their own SKU, price, stock, weight — removed from `products`
2. Unlimited option dimensions — `variant_option_values` join table (not capped at 3)
3. DB enforces `UNIQUE(variant_id, option_id)` — no variant can have two values for the same option. Cross-variant uniqueness (no two variants share the same option combination) validated at the service layer.
4. `product_media` and `product_metadata` use nullable `variant_id` — no duplicate tables needed
5. `cart_items.product_id` becomes `cart_items.variant_id` — no backward compat concern
6. Order items snapshot variant details (sku + options string) for historical fidelity

---

## Phase 1: Brand, Vendor, Product Type + Filtering

### V75 Migration (Part A)

```sql
ALTER TABLE products
    ADD COLUMN brand VARCHAR(255),
    ADD COLUMN vendor VARCHAR(255),
    ADD COLUMN product_type VARCHAR(50) DEFAULT 'physical'
        CHECK (product_type IN ('physical', 'digital', 'service'));

CREATE INDEX idx_products_brand ON products (store_id, brand);
CREATE INDEX idx_products_product_type ON products (store_id, product_type);
CREATE INDEX idx_products_vendor ON products (store_id, vendor);
```

### Backend Changes

**`entities/Product.kt`** — add fields:

```kotlin
data class Product(
    val id: UUID? = null,
    val storeId: UUID,
    val name: String,
    val slug: String? = null,
    // ... existing fields ...
    val brand: String? = null,
    val vendor: String? = null,
    val productType: String? = "physical",
)
```

**`dtos/ProductDto.kt`** — add to `ProductInput`, `ProductDto`, `ProductFilters`:

```kotlin
// ProductFilters gains:
val brand: String? = null,
val vendor: String? = null,
val productType: String? = null,
```

**`repositories/ProductRepository.kt`** — add filter clauses:

```kotlin
filters.brand?.let { brand ->
    queryBuilder.and(productsTable.BRAND.eq(DSL.inline(brand)))
}
filters.productType?.let { type ->
    queryBuilder.and(productsTable.PRODUCT_TYPE.eq(DSL.inline(type)))
}
filters.vendor?.let { vendor ->
    queryBuilder.and(productsTable.VENDOR.eq(DSL.inline(vendor)))
}
```

**`graphql/types/Inputs.kt`** — `ProductFiltersInput` gains `brand`, `vendor`, `productType`.

**`graphql/types/ProductGraphQL.kt`** — add fields to type.

### Admin UI

**`ProductBasicInfoSection.tsx`** — add Brand, Vendor fields after Description.

**Product list** — add Brand column.

### Storefront

**`storefront/src/lib/types/entities.ts`** — `Product` gains `brand`, `vendor`, `productType`.

**`storefront/src/lib/api/products.ts`** — `ProductFilters` gains same + GraphQL fragment.

### Files Changed (Phase 1)

| Layer | New | Modified |
|-------|-----|----------|
| DB migration | — | 1 (V75 part A) |
| Entity | — | 1 (Product) |
| DTOs | — | 2 (ProductDto, Inputs) |
| Repository | — | 1 (Product) |
| GraphQL | — | 2 (ProductGraphQL, Inputs) |
| Admin UI | — | 2 (BasicInfoSection, product list) |
| Storefront | — | 2 (types, products API) |
| **Total** | **0** | **11** |

---

## Phase 2: Variant Tables + Repos + Services

### V75 Migration (Part B)

```sql
CREATE TABLE product_options (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    position INT NOT NULL DEFAULT 0,
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(product_id, name)
);

CREATE TABLE product_variants (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    sku VARCHAR(100),
    price NUMERIC,
    compare_to_price NUMERIC,
    image VARCHAR(300),
    stock_quantity NUMERIC(10,2) DEFAULT 0,
    reserved_quantity NUMERIC(10,2) DEFAULT 0,
    weight NUMERIC(10,2),
    shipping_class_id UUID REFERENCES shipping_classes(id),
    version INT NOT NULL DEFAULT 1,
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(product_id, sku)
);

CREATE TABLE variant_option_values (
    variant_id UUID NOT NULL REFERENCES product_variants(id) ON DELETE CASCADE,
    option_id UUID NOT NULL REFERENCES product_options(id) ON DELETE CASCADE,
    value VARCHAR(100) NOT NULL,
    UNIQUE(variant_id, option_id)
);

-- Fast lookup: find variants by option value (e.g., all "Red" variants of a product)
CREATE INDEX idx_vov_option_value ON variant_option_values(option_id, value);

CREATE INDEX idx_product_variants_product ON product_variants(product_id);
CREATE INDEX idx_product_variants_sku ON product_variants(sku);

-- Polymorphic media/metadata support
ALTER TABLE product_media ADD COLUMN variant_id UUID REFERENCES product_variants(id);
ALTER TABLE product_metadata ADD COLUMN variant_id UUID REFERENCES product_variants(id);
CREATE INDEX idx_product_media_variant ON product_media(variant_id);
CREATE INDEX idx_product_metadata_variant ON product_metadata(variant_id);

-- Migrate existing products to single-variant (no option values)
INSERT INTO product_variants (product_id, sku, price, compare_to_price, image,
    stock_quantity, reserved_quantity, weight, shipping_class_id)
SELECT id, sku, price, compare_to_price, image,
    stock_quantity, reserved_quantity, weight, shipping_class_id
FROM products;

-- Update product_media to reference the new variant
UPDATE product_media SET variant_id = (
    SELECT pv.id FROM product_variants pv WHERE pv.product_id = product_media.product_id
);
UPDATE product_metadata SET variant_id = (
    SELECT pv.id FROM product_variants pv WHERE pv.product_id = product_metadata.product_id
);

-- Drop migrated columns from products
ALTER TABLE products
    DROP COLUMN price,
    DROP COLUMN compare_to_price,
    DROP COLUMN image,
    DROP COLUMN sku,
    DROP COLUMN stock_quantity,
    DROP COLUMN reserved_quantity,
    DROP COLUMN weight,
    DROP COLUMN shipping_class_id;
```

### New Entities

**`entities/ProductVariant.kt`:**

```kotlin
@Serializable
data class ProductVariant(
    @Serializable(with = UuidSerializer::class)
    val id: UUID? = null,
    @Serializable(with = UuidSerializer::class)
    val productId: UUID,
    val sku: String? = null,
    val price: String? = null,
    val compareToPrice: String? = null,
    val image: String? = null,
    val stockQuantity: Int = 0,
    val reservedQuantity: Int = 0,
    val weight: Double? = null,
    @Serializable(with = UuidSerializer::class)
    val shippingClassId: UUID? = null,
    val optionValues: List<VariantOptionValue>? = null,
    val version: Int = 1,
    @Serializable(with = OffsetDateTimeSerializer::class)
    val insertedAt: OffsetDateTime? = null,
    @Serializable(with = OffsetDateTimeSerializer::class)
    val updatedAt: OffsetDateTime? = null
) {
    fun incrementVersion() = copy(version = version + 1)
    fun availableQuantity() = stockQuantity - reservedQuantity
    fun isInStock() = stockQuantity > 0
}

@Serializable
data class ProductOption(
    @Serializable(with = UuidSerializer::class)
    val id: UUID? = null,
    @Serializable(with = UuidSerializer::class)
    val productId: UUID,
    val name: String,
    val position: Int = 0,
    @Serializable(with = OffsetDateTimeSerializer::class)
    val insertedAt: OffsetDateTime? = null,
    @Serializable(with = OffsetDateTimeSerializer::class)
    val updatedAt: OffsetDateTime? = null,
)

@Serializable
data class VariantOptionValue(
    @Serializable(with = UuidSerializer::class)
    val optionId: UUID,
    val optionName: String,
    val value: String,
)
```

**`entities/Product.kt`** — remove: `price`, `compareToPrice`, `image`, `sku`, `stockQuantity`, `reservedQuantity`, `weight`, `shippingClassId`. Add: `brand`, `vendor`, `productType`.

### New Repositories

**`repositories/ProductVariantRepository.kt`:**

| Method | Purpose |
|--------|---------|
| `findByProductId(productId)` | All variants for a product (with option_values joined) |
| `findById(variantId)` | Single variant lookup (with option_values joined) |
| `saveDiff(productId, variants)` | Delete removed + upsert changed + insert new |
| `saveOptionValues(variantId, optionValues)` | Delete old + batch insert new (diff pattern) |
| `findBySku(storeId, sku)` | SKU lookup (unique per store) |
| `findOptionsByProductId(productId)` | All options for a product |
| `saveOptionsDiff(productId, options)` | Delete removed + upsert changed + insert new (diff pattern) |

> **Implementation note:** Option CRUD methods (`findOptionsByProductId`, `saveOptionsDiff`) live in `ProductVariantRepository` instead of a separate `ProductOptionRepository`. They share the same `DSLContext`, table references, and `ProductOption` entity mapping. A standalone file adds no functional benefit.

### Modified Repositories

**`ProductRepository.kt`:**
- Remove price/sku/stock/weight columns from `cartRow` and `mapToCart()`
- Remove inventory filter logic (status: in_stock/out_of_stock) — moves to variant level
- Add brand/vendor/productType to `cartRow`, `mapToCart()`, `save()`, `saveAll()`
- Add brand/vendor/productType filter clauses

**`CartRepository.kt`:**
- Replace `productId` with `variantId` in cart_items queries
- Join `product_variants` → `products` for enrichment (name, slug, etc.)
- Unique constraint on `(cart_id, variant_id)` instead of `(cart_id, product_id)`

### DTO Changes

**`ProductInput`** gains `options` and `variants`:

```kotlin
data class ProductInput(
    val id: String? = null,
    val name: String? = null,
    val slug: String? = null,
    val description: String? = null,
    val visibility: String? = null,
    val brand: String? = null,
    val vendor: String? = null,
    val productType: String? = null,
    val metadata: Map<String, String>? = null,
    val media: List<ProductMediaInput>? = null,
    val options: List<OptionInput>? = null,
    val variants: List<VariantInput>? = null,
)

data class OptionInput(
    val id: String? = null,
    val name: String,
    val position: Int,
)

data class VariantInput(
    val id: String? = null,
    val sku: String? = null,
    val price: String? = null,
    val compareToPrice: String? = null,
    val image: String? = null,
    val stockQuantity: Int = 0,
    val weight: Double? = null,
    val shippingClassId: String? = null,
    val optionValues: List<OptionValueInput>? = null,
    val media: List<ProductMediaInput>? = null,
)

data class OptionValueInput(
    val optionId: String,
    val value: String,
)
```

**`ProductDto`** gains `brand`, `vendor`, `productType`, `options`, `variants`. Removes price/sku/stock fields (now on `VariantDto`).

**`ProductFilters`** gains `brand`, `vendor`, `productType`.

### Service Changes

**`ProductSaveServiceImpl.kt`:**
1. Save product with brand/vendor/productType (unchanged pattern)
2. If `options` list provided → `optionRepository.saveDiff(productId, options)`
3. If `variants` list provided → `variantRepository.saveDiff(productId, variants)`
4. If variant has `optionValues` → `variantRepository.saveOptionValues(variantId, optionValues)` (delete + re-insert, diff pattern)
5. If variant has `media` list → save media with `variant_id` set (diff pattern)
6. Generate SKUs for new variants if not provided (`{product-slug}-{opt1}-{opt2}`)
7. Application-level validation: no two variants of same product share the same option values
8. Validate: no duplicate SKUs per store

**`ProductGetServiceImpl.kt`:**
1. Fetch product
2. Fetch variants via `variantRepository.findByProductId(productId)` (joined with option_values)
3. Compute price range: `variants.minOf { it.price }` to `variants.maxOf { it.price }`
4. Compute aggregate stock: `variants.sumOf { it.stockQuantity }`
5. Fetch options via `optionRepository.findByProductId(productId)`
6. Build enriched DTO with all nested data

### Files Changed (Phase 2)

| Layer | New | Modified |
|-------|-----|----------|
| DB migration | — | 1 (V75 part B) |
| Entities | 3 (Variant, Option, VariantOptionValue) | 1 (Product) |
| Repositories | 1 (Variant; option methods included) | 1 (Product) |
| DTOs | 0 | 1 (ProductDto) |
| Services | 0 | 2 (Save, Get) |
| **Total** | **4** | **6** |

---

## Phase 3: Cart / Checkout / Order + Storefront

### Cart Changes

**Migration:**

```sql
ALTER TABLE cart_items DROP CONSTRAINT cart_items_product_id_fkey;
ALTER TABLE cart_items DROP CONSTRAINT cart_items_unique;
ALTER TABLE cart_items DROP COLUMN product_id;
ALTER TABLE cart_items ADD COLUMN variant_id UUID NOT NULL REFERENCES product_variants(id);
ALTER TABLE cart_items ADD UNIQUE (cart_id, variant_id);
```

**`entities/CartItem.kt`** — `productId` becomes `variantId`.

**`CartSaveServiceImpl.kt`:**
- Accept `variantId` in cart add/update inputs
- Validate variant exists and belongs to the store
- Validate stock: `variant.canFulfillQuantity(requestedQuantity)`

**`CartGetServiceImpl.kt`:**
- Join `cart_items` → `product_variants` → `products` for enrichment
- Return variant details (option values, variant sku, image) in cart item DTO

### Order/Checkout Changes

**Migration:**

```sql
ALTER TABLE order_items DROP CONSTRAINT order_items_unique;
ALTER TABLE order_items
    ADD COLUMN variant_id UUID REFERENCES product_variants(id),
    ADD COLUMN variant_sku VARCHAR(100),
    ADD COLUMN variant_options VARCHAR(300);
ALTER TABLE order_items ADD UNIQUE (order_id, variant_id);
```

**`entities/OrderItem.kt`** — add `variantId`, `variantSku`, `variantOptions`.

**`CheckoutServiceImpl.kt`:**
- On checkout, snapshot variant details into order_items:
  - `variant_id` = cart item's variant ID
  - `variant_sku` = variant's SKU at time of order
  - `variant_options` = "Size: M, Color: Red" (built from variant + option names)
  - `product_name`, `price` = snapshot from variant (existing pattern)
- Reserve variant stock, not product stock

### Storefront Changes

**`storefront/src/lib/types/entities.ts`:**

```typescript
interface Product {
  // ... shared fields: id, name, slug, description, brand, vendor, productType
  options: ProductOption[] | null
  variants: ProductVariant[] | null
  priceRange: { min: string; max: string } | null   // "99.00" – "129.00"
  media: ProductMedia[] | null
  metadata: string | null
}

interface ProductOption {
  id: string
  name: string           // "Size", "Color"
  position: number
}

interface ProductVariant {
  id: string
  sku: string | null
  price: string | null
  compareToPrice: string | null
  image: string | null
  stockQuantity: number
  weight: number | null
  optionValues: { optionId: string; optionName: string; value: string }[] | null
  media: ProductMedia[] | null
}

interface CartItem {
  id: string | null
  variantId: string          // was: productId
  productId: string          // derived from variant
  productName: string        // derived from product
  quantity: number
  selected: boolean
  price: string | null
  subtotal: string | null
  image: string | null       // from variant or product
  options: string | null     // "Size: M, Color: Red"
}
```

**`storefront/src/lib/graphql/fragments.ts`:**
```graphql
fragment ProductFields on ProductGraphQL {
  id name slug description visibility
  brand vendor productType
  averageRating reviewCount stockStatus
  priceRange { min max }
  options { id name position }
  variants { id sku price compareToPrice image stockQuantity weight
    optionValues { optionId optionName value }
    media { id url type alt }
  }
}
```

**`storefront/src/lib/api/carts.ts`:**
```typescript
addToCart(variantId: string, quantity: number, sessionId?: string)
// was: addToCart(productId: string, ...)
```

### Files Changed (Phase 3)

| Layer | New | Modified |
|-------|-----|----------|
| DB migration | — | 1 (cart_items + order_items) |
| Entities | — | 2 (CartItem, OrderItem) |
| Repositories | — | 2 (Cart, Order) |
| Services | — | 3 (CartSave, CartGet, Checkout) |
| GraphQL | — | 2 (ProductGraphQL, fragment) |
| Storefront types | — | 1 (entities.ts) |
| Storefront API | — | 2 (carts, products) |
| **Total** | **0** | **13** |

---

## Phase 4: Admin UI — Variant Management

### New Form Sections

**`admin/src/routes/admin/products/sections/ProductOptionsSection.tsx`:**
- "Add option" button → type name (Size, Color, Material, etc.), auto-increment position
- Each option shows its name + delete button
- Reorder via drag (matching admin UI patterns)
- Unlimited options — no hard cap

**`admin/src/routes/admin/products/sections/ProductVariantsSection.tsx`:**
- Auto-generated table from option combinations (cartesian product of all option values)
- Columns: Image thumbnail, Option values (one per option group), SKU, Price, Stock, Weight
- Inline editing per cell
- "Generate variants" button that takes each option's values and creates all combinations
- Bulk edit: select all → set price, set stock
- Each variant row has its own image upload

### Modified Form Sections

**`product-editor-context.tsx`** — new state:

```typescript
interface ProductFormData {
  // ... existing fields
  brand: string
  vendor: string
  productType: string
}

interface VariantFormData {
  id?: string
  sku: string
  price: string
  compareToPrice: string
  image: string | null
  stockQuantity: number
  weight: number | null
  shippingClassId: string | null
  optionValues: { optionId: string; optionName: string; value: string }[]
  media: MediaEntry[]
  isNew?: boolean
  isDeleted?: boolean
}

interface OptionFormData {
  id?: string
  name: string
  position: number
  isNew?: boolean
  isDeleted?: boolean
}
```

**`ProductForm.tsx`** — new sections added before Metadata. Image section removed (moves to variants).

**`ProductBasicInfoSection.tsx`** — add Brand, Vendor fields.

### Files Changed (Phase 4)

| Layer | New | Modified |
|-------|-----|----------|
| Admin component | 2 (OptionsSection, VariantsSection) | 3 (Form, BasicInfoSection, editor-context) |
| **Total** | **2** | **3** |

---

## Phase 5: Storefront — Product Page with Variant Picker

### Storefront Product Page

New route `storefront/src/routes/product/[slug].tsx`:

```
┌──────────────────────────────────┐
│ Product Image Gallery            │
│ (switches per selected variant)  │
│                                  │
├──────────────────────────────────┤
│ Product Name            $99.00   │
│ Brand: Nike                      │
│ ★★★★☆ (42 reviews)              │
│                                  │
│ Size:  [M]  [L]  [XL]  <--active│
│ Color: ○ Red  ● Blue  ○ Green   │
│                                  │
│ Stock: In stock (5 remaining)    │
│                                  │
│ [Add to Cart]  Quantity: [1]     │
└──────────────────────────────────┘
```

**Variant selection logic:**
1. On load: parse `?variant=id` URL param or select first in-stock variant
2. On option click: find matching variant, update image/price/stock
3. Disable out-of-stock combinations (grayed out, not clickable)
4. "Add to Cart" sends `variantId`, not `productId`

### Files Changed (Phase 5)

| Layer | New | Modified |
|-------|-----|----------|
| Storefront route | 1 (product/[slug].tsx) | 0 |
| Storefront components | 3 (VariantPicker, ProductGallery, AddToCart) | 1 (home.tsx — mount widget) |
| **Total** | **4** | **1** |

---

## Complete File Summary

| Phase | New Files | Modified Files | Description |
|-------|-----------|----------------|-------------|
| 1 | 0 | 11 | Brand/vendor/product_type + filtering |
| 2 | 4 | 6 | Variant tables, entities, repos, save/get |
| 3 | 0 | 13 | Cart, checkout, order + storefront types |
| 4 | 2 | 3 | Admin variant management UI |
| 5 | 4 | 1 | Storefront product page + variant picker |
| **Total** | **10** | **34** | **44 files** |

---

## Template Variables for Notifications (post-implementation)

Once variants are in place, the cart abandoned email can show variant details:

| Variable | Source |
|----------|--------|
| `${item.variantSku}` | `variants.sku` |
| `${item.variantOptions}` | e.g., "Size: M, Color: Red" |
| `${item.variantImage}` | Variant-specific image URL |

Order confirmation templates gain the same.
