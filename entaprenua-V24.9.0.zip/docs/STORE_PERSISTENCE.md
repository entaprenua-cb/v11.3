# Store Process Persistence — Startup Recovery

**Status**: Nginx Subdomain Routing ✅ Working (2026-04-07)
**Startup Recovery**: ✅ Implemented (2026-04-08)
**Graceful Shutdown**: ✅ Implemented (2026-04-08)
**Approach**: Systemd per-store services ✅ Implemented (see [SYSTEMD_STORE_MANAGEMENT.md](SYSTEMD_STORE_MANAGEMENT.md))

---

## Current State

**Nginx Subdomain Routing**: ✅ Working
- OpenResty with Lua dynamically routes `*.entaprenua.com` to running store ports
- Redis caches `{subdomain} → {port}` mappings (TTL: 5 minutes)
- Backend writes to Redis on store start, Lua reads on each request
- Both HTTP and HTTPS subdomain routing verified working

**Startup Recovery**: ✅ Implemented
- `ProcessManagerService.onApplicationReady()` runs on Spring Boot startup
- Queries database for stores with `storefront_status = 'running'`
- For each store:
  - If port is responding → Reconnect to Redis, restart heartbeat, add to processes map
  - If port NOT responding → **Auto-start the store** on the same port
- No manual restart needed after server reboot
- Stores automatically restart after server restart

**Graceful Shutdown**: ✅ Implemented
- `@PreDestroy` annotated `shutdown()` method runs when Spring Boot stops
- On shutdown:
  - Process is killed
  - Redis entry is cleared
  - Database port is cleared
  - **Database status remains 'running'** (for recovery on restart)
- Stores auto-recover on server restart if they were running before shutdown

**Systemd Integration**: ✅ Implemented
- See [SYSTEMD_STORE_MANAGEMENT.md](SYSTEMD_STORE_MANAGEMENT.md) for full architecture and usage
- Each store runs as a systemd `--user` service
- systemd handles crash recovery (`Restart=on-failure`), boot ordering, and resource limits

---

## Store Lifecycle

### Database Fields

| Field | Purpose |
|-------|---------|
| `storefront_status` | 'running' = should be running, 'stopped' = user stopped |
| `storefront_port` | Current port or NULL if not running |
| `storefront_registered_at` | When store was started |

### State Transitions

| Event | Redis | DB Status | DB Port | Process |
|-------|-------|-----------|---------|---------|
| **Store started** | subdomain→port | running | port | ✅ |
| **User stops store** | deleted | stopped | NULL | ❌ |
| **Server shutdown (@PreDestroy)** | deleted | running | NULL | ❌ |
| **Restart (port in DB)** | restored | running | port | ✅ (reconnect) |
| **Restart (port=NULL)** | subdomain→newPort | running | newPort | ✅ (auto-started) |

### Key Design Decisions

1. **Status kept on graceful shutdown**: When server stops, stores keep `status='running'` so they auto-recover on restart
2. **Port cleared on shutdown**: Redis and DB port are cleared so routing doesn't point to dead processes
3. **Auto-start on recovery**: On restart, if port is not responding, store is auto-started on a new port
4. **Stores survive server restarts**: Any store that was running before server shutdown will be running after restart

---

## Code Structure

### ProcessManagerService

```
ProcessManagerService
├── startStore(storeId, domain, nodePath)   → systemctl --user start (via SystemdService)
├── stopStore(storeId)                      → systemctl --user stop (via SystemdService)
├── getStoreStatus(storeId)                  → systemctl --user is-active (via SystemdService)
├── onApplicationReady()                     → Restores Redis entries for running stores
├── @PreDestroy shutdown()                   → No-op (systemd services survive restart)
└── assignPort(storeId)                      → Allocates next available port
```

### StoreRegistry

```
StoreRegistry
├── register()              → Sets status='running', port, Redis
├── unregister()            → Sets status='stopped', clears port, Redis
└── clearPortOnly()         → Clears port and Redis, KEEPS status='running'
```

### StoreRepository

```
StoreRepository
├── clearStorefrontRegistration()  → Clears port, sets status='stopped'
├── clearStorefrontPort()          → Clears port, KEEPS status
└── updateStorefrontPort(port, status)  → Updates port and status atomically
```

---

## Architecture

### ProcessManagerService (Current — Systemd-Managed)

```
ProcessManagerService
    ├── start/stop/status delegated to SystemdService (systemctl --user)
    ├── assignedPorts: ConcurrentHashMap<storeId, PortInfo> (ports only)
    ├── Per-store Mutex for concurrency safety
    ├── @PreDestroy: No-op (systemd services survive backend restart)
    ├── onApplicationReady: Restores Redis entries for running stores
    └── systemd handles lifecycle, crash recovery, boot order
```

### Previous (ProcessBuilder) - Legacy

```
ProcessManagerService (before systemd migration)
    ├── processes: ConcurrentHashMap<storeId, StoreProcess>
    ├── portToStoreId: ConcurrentHashMap<port, storeId>
    ├── @PreDestroy: Stops stores, keeps status='running'
    ├── onApplicationReady: Recovers running stores
    └── Heartbeat: Monitors port availability
```

---

## Systemd Integration

Each store runs as a systemd **user** service via `systemctl --user`. See [SYSTEMD_STORE_MANAGEMENT.md](SYSTEMD_STORE_MANAGEMENT.md) for complete implementation details.

**Key changes from ProcessBuilder approach**:
- Services survive backend restarts (no @PreDestroy killing stores)
- systemd handles crash recovery (`Restart=on-failure`, `RestartSec=5`)
- No heartbeat loop — status comes from `systemctl --user is-active`
- User services (`--user`) avoid sudo requirement; backend runs as `nesh`
- `loginctl enable-linger nesh` ensures services survive logout

---



## Future Enhancements

- [x] Startup recovery on server restart (implemented 2026-04-08)
- [x] Graceful shutdown with status preservation (implemented 2026-04-08)
- [x] Auto-start stores on recovery (implemented 2026-04-08)
- [x] Process crash detection and auto-restart (systemd Restart=on-failure)
- [x] Full systemd integration for crash recovery and boot ordering (see SYSTEMD_STORE_MANAGEMENT.md)
- [ ] Per-store resource limits based on plan tier (e.g., memory, CPU)
- [ ] Health check endpoint per store
- [ ] Automatic updates (git pull + restart on new commits)

---

## Rollback Plan (If Needed)

If auto-start recovery needs to be reverted to previous behavior (clear instead of auto-start):

1. Modify `ProcessManagerService.onApplicationReady()` to call `storeRegistry.unregister()` instead of `startStore()` when port is not responding
2. Restart Spring Boot

### Database Impact

No migration needed. `updateStorefrontPort()` saves port to database on start/stop. Stores that were running will have port set in database.

---

## Testing

### Test Scenarios

1. **Start store → verify DB status='running', port set**
2. **Stop store via API → verify DB status='stopped', port=NULL**
3. **Server restart with running stores → verify stores auto-recover (auto-started)**
4. **Server restart with stopped stores → verify stores stay stopped**
5. **Ctrl+C server → verify stores recover on restart**

### Database Query

```sql
-- Check store status
SELECT id, name, storefront_status, storefront_port, storefront_registered_at 
FROM stores 
WHERE storefront_status IS NOT NULL;
```

---

## Nginx/Lua Subdomain Routing Configuration

### Files

| File | Location | Purpose |
|------|----------|---------|
| `nginx-entaprenua.conf` | `/etc/nginx/sites-available/entaprenua` | Main site config with subdomain routing |
| `storefront-lookup.lua` | `/etc/nginx/lua/storefront-lookup.lua` | Extracts subdomain, looks up port in Redis |
| `redis-helpers.lua` | `/etc/nginx/lua/redis-helpers.lua` | Redis connection helpers |

### Nginx Config Requirements

1. **`lua_package_path`** must include OpenResty's lualib AND custom lua scripts:
   ```nginx
   lua_package_path '/usr/local/openresty/lualib/?.lua;;/etc/nginx/lua/?.lua;;';
   ```

2. **`env` directives** must be at top of nginx.conf (outside http block):
   ```nginx
   env REDIS_HOST;
   env REDIS_PORT;
   env REDIS_AUTH;
   env REDIS_KEY_PREFIX;
   ```

3. **`sites-enabled` include** must be configured:
   ```nginx
   include /etc/nginx/sites-enabled/*;
   ```

### Lua Regex for Subdomains

The regex must allow hyphens in subdomain names:
```lua
-- Correct (allows hyphens)
local subdomain = domain:match("^([%w-]+).entaprenua.com$")

-- Wrong (only matches word characters)
local subdomain = domain:match("^(%w+).entaprenua.com$")
```

### Redis Key Format

Backend writes: `SETEX storefront:{subdomain} 300 {port}`
Lua reads: `GET storefront:{subdomain}`

### SSL/HTTPS for Subdomains

**Status**: ✅ Let's Encrypt wildcard certificate working

See [Cloudflare Setup Guide](CLOUDFLARE_SETUP.md) for full setup details.

**Quick Summary**:
- Let's Encrypt provides wildcard certificates via certbot
- DNS-01 challenge validates ownership via Cloudflare API
- DNS records set to **DNS Only** (grey cloud) so OpenResty receives all traffic
- SSL/TLS mode set to `Full` in Cloudflare dashboard
- Automatic renewal configured via certbot

**Post-Setup**:
1. Verify SSL: `curl -sk https://mystore.entaprenua.com`
2. Check certificate: `ssh root@187.124.17.59 'certbot certificates'`
3. If issues, ensure wildcard `*` record is DNS Only, not Proxied
