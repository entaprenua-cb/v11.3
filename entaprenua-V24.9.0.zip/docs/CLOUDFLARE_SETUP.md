# Cloudflare DNS Setup Guide

**Last Updated**: 2026-04-07
**Purpose**: SSL certificates for all subdomains (e.g., `*.entaprenua.com`)

---

## Architecture

```
User Request
     │
     ▼
Cloudflare (DNS + CDN)
     │
     │ HTTPS (Let's Encrypt certificate on origin)
     ▼
OpenResty/Nginx (VPS: 187.124.17.59)
     │
     ▼
Lua Script reads Host header
     │
     ▼
Redis lookup: storefront:{subdomain} → {port}
     │
     ▼
Store Node.js process
```

---

## DNS Configuration

All DNS records set to **DNS Only** (grey cloud) - NOT Proxied:

| Type | Name | Content | Proxy Status |
|------|------|---------|--------------|
| A | `*` | `187.124.17.59` | DNS Only |
| A | `entaprenua.com` | `187.124.17.59` | DNS Only |
| CNAME | `www` | `entaprenua.com` | DNS Only |

**Why DNS Only?**
- With **Proxied** mode, Cloudflare intercepts requests and may modify headers
- Nginx/Lua needs to read the raw `Host` header to extract subdomain for routing
- DNS Only allows the origin server to handle all subdomain routing logic

---

## SSL/TLS Setup

### Certificate: Let's Encrypt Wildcard

We use **Let's Encrypt wildcard certificates** via certbot with Cloudflare DNS challenge:

```
Domain: *.entaprenua.com + entaprenua.com
Provider: Let's Encrypt (via certbot)
Validation: DNS-01 challenge via Cloudflare API
Auto-renewal: certbot renew
```

### Certificate Location on VPS

```
/etc/letsencrypt/live/entaprenua.com-0001/
├── fullchain.pem    (certificate + intermediates)
├── privkey.pem      (private key)
├── cert.pem         (certificate only)
└── chain.pem        (intermediates only)
```

Additional files:
- `/etc/letsencrypt/options-ssl-nginx.conf` (SSL hardening settings)
- `/etc/letsencrypt/ssl-dhparams.pem` (DH parameters)

### Cloudflare SSL/TLS Mode: "Full"

Set in Cloudflare Dashboard → SSL/TLS → Overview → Encryption Mode: **Full**

| Mode | Description |
|------|-------------|
| Off | No encryption |
| Flexible | Visitor↔Cloudflare encrypted, Cloudflare↔origin NOT encrypted |
| **Full** | ✅ Both ends encrypted, uses origin certificate |
| Full (strict) | Both ends encrypted, requires valid certificate on origin |

---

## Certificate Renewal

### Automatic Renewal

Let's Encrypt certificates auto-renew via certbot. Check status:

```bash
ssh root@187.124.17.59 "certbot certificates"
```

### Manual Renewal

```bash
ssh root@187.124.17.59 "certbot renew --dry-run"
```

### Cloudflare API Token

Required for DNS-01 challenge. Token stored at:
```
/etc/letsencrypt/cloudflare.ini
```

Token permissions needed:
- `Zone.Zone: Read`
- `Zone.DNS: Edit`

---

## Troubleshooting

### SSL Not Working

```bash
# Test from local machine
curl -skI https://entaprenua.com
curl -skI https://testshop.entaprenua.com
```

### Check OpenResty Config

```bash
ssh root@187.124.17.59 "/usr/local/openresty/nginx/sbin/nginx -t"
```

### Check SSL Certificate

```bash
openssl s_client -connect entaprenua.com:443 -servername entaprenua.com </dev/null 2>/dev/null | openssl x509 -noout -text | grep -E "Subject:|DNS:"
```

### Verify Wildcard Coverage

```bash
openssl s_client -connect entaprenua.com:443 -servername random-store.entaprenua.com </dev/null 2>/dev/null | openssl x509 -noout -text | grep -E "DNS:"
```

### Subdomain Routing Issues

1. Check Redis has store entry:
   ```bash
   ssh root@187.124.17.59 "redis-cli KEYS 'storefront:*'"
   ```

2. Check OpenResty error log:
   ```bash
   ssh root@187.124.17.59 "tail -20 /usr/local/openresty/nginx/logs/error.log"
   ```

3. Ensure DNS records are DNS Only (grey cloud), not Proxied (orange cloud)

---

## Setup Summary

| Component | Status |
|-----------|--------|
| Cloudflare DNS | ✅ Active |
| Nameservers | ✅ Cloudflare |
| DNS records | ✅ DNS Only mode |
| SSL/TLS mode | ✅ Full |
| Let's Encrypt cert | ✅ Installed |
| OpenResty + Lua | ✅ Configured |
| Subdomain routing | ✅ Working |

---

## Rollback

To revert to Hostinger DNS:

1. Hostinger → Domain → DNS → Change to "Hostinger Nameservers"
2. Re-enable DNSSEC at Hostinger
3. Remove domain from Cloudflare dashboard
