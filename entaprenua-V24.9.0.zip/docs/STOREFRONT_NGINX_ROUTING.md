# Storefront Nginx Dynamic Routing

**Last Updated**: 2026-04-05  
**Status**: ✅ Implemented

---

## Overview

This document describes how OpenResty (Nginx + Lua) routes requests to individual store Node.js processes using Redis caching. Each store runs as an **independent** process.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              OpenResty (Nginx + Lua)                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Request: mystore.entaprenua.com                                          │
│       │                                                                     │
│       ▼                                                                     │
│  ┌─────────────────────────────────────────────────────────────────┐      │
│  │  Lua Script (storefront-lookup.lua)                               │      │
│  │  1. Extract subdomain: "mystore"                                 │      │
│  │  2. Redis GET storefront:mystore                                │      │
│  │  3. Set ngx.var.store_port                                       │      │
│  └─────────────────────────────────────────────────────────────────┘      │
│       │                                                                     │
│       ▼                                                                     │
│  Route to: http://127.0.0.1:{store_port}                                   │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  /api/*  ────────────────────────────────────────────────────► Spring Boot   │
│                                                                             │
│  /*     ────► Lua Lookup ──► Redis ──► localhost:{port}                  │
│                              │                                              │
│                              ▼                                              │
│                      ┌──────────────┐                                     │
│                      │  Node.js      │                                     │
│                      │  Store 1      │ (Independent Process)              │
│                      │  (port 3001)  │                                     │
│                      └──────────────┘                                     │
│                                                                             │
│  /*     ────► Lua Lookup ──► Redis ──► localhost:{port}                  │
│                              │                                              │
│                              ▼                                              │
│                      ┌──────────────┐                                     │
│                      │  Node.js      │                                     │
│                      │  Store 2      │ (Independent Process)              │
│                      │  (port 3002)  │                                     │
│                      └──────────────┘                                     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Request Flow

### 1. Store Starts

```
Spring Boot ProcessManager
    │
    ├─► Spawns Node.js process on port 3001
    │
    ├─► Updates Redis: SET storefront:mystore 3001
    │
    └─► Updates Database: stores table (domain, port, status)
```

### 2. User Request

```
Browser: mystore.entaprenua.com
    │
    ▼
DNS: *.entaprenua.com → Server IP
    │
    ▼
OpenResty receives request
    │
    ├─► Match server_name ~^(?<subdomain>.+)\.entaprenua\.com$
    │
    ▼
Lua Script executes
    │
    ├─► Extract subdomain: "mystore"
    │
    ├─► Redis GET storefront:mystore
    │       │
    │       ├─► Found: Returns "3001"
    │       │
    │       └─► Not Found: Return 502 Bad Gateway
    │
    ▼
Set ngx.var.store_port = 3001
    │
    ▼
location / {
    proxy_pass http://127.0.0.1:3001;  # Dynamic port
}
    │
    ▼
Node.js process returns rendered HTML
```

### 3. Store Stops

```
Spring Boot ProcessManager
    │
    ├─► Terminates Node.js process
    │
    ├─► Deletes Redis: DEL storefront:mystore
    │
    └─► Updates Database: clears port
```

---

## Component Responsibilities

### OpenResty

| Responsibility | Details |
|----------------|---------|
| SSL Termination | HTTPS → HTTP internally |
| Domain Matching | Extract subdomain from Host header |
| Lua Execution | Run lookup script per request |
| Request Proxying | Forward to Node process |
| Static Caching | Cache JS/CSS/images |
| Security Headers | X-Frame-Options, CSP, etc. |

### Lua Script

| Responsibility | Details |
|----------------|---------|
| Domain Extraction | Parse subdomain from Host |
| Redis Lookup | Check cache for port mapping |
| Error Handling | Return 502 for missing stores |
| Port Variable | Set ngx.var.store_port for proxy_pass |

### Redis

| Key Pattern | Value | TTL | Purpose |
|-------------|-------|-----|---------|
| `storefront:{subdomain}` | `{port}` | 300s | Domain → Port cache |

### Spring Boot

| Responsibility | Details |
|----------------|---------|
| Process Management | Start/stop Node.js processes |
| Port Allocation | Assign available ports (3000-3099) |
| Redis Updates | Write port mappings on start/stop |
| API | All store APIs |

### Node.js (Store Process)

| Responsibility | Details |
|----------------|---------|
| SSR Rendering | Server-side render SolidStart app |
| API Calls | Fetch data from Spring Boot |
| Static Files | Serve JS/CSS/images |

---

## Port Allocation

| Range | Usage |
|-------|-------|
| 3000-3099 | Store Node.js processes (max 100 stores) |
| 8080 | Spring Boot API |
| 6379 | Redis |
| 5432 | PostgreSQL |

---

## Cache Strategy

### TTL: 300 seconds (5 minutes)

```
TTL is a safety net, invalidation is the source of truth:
├─► Store start → Redis SET storefront:mystore 3001
├─► Store stop → Redis DEL storefront:mystore
└─► TTL (300s) → only acts as safety net if invalidation fails
```

### Cache Invalidation

```
Primary (immediate):
├─► On store start: Redis SET storefront:{subdomain} {port}
└─► On store stop: Redis DEL storefront:{subdomain}

Fallback (safety net):
└─► TTL expiry: Automatic after 300 seconds
```

---

## Error Handling

| Scenario | Response | Cause |
|----------|----------|-------|
| Store not in Redis | 502 Bad Gateway | Store not started |
| Redis connection failed | 503 Service Unavailable | Redis is down |
| Invalid domain | 404 Not Found | Domain not configured |

---

## Security

- Redis password from `.env` via OpenResty environment
- Only ports 80/443 exposed publicly
- Node processes on localhost (not accessible externally)

---

## Configuration Files

| File | Source | Purpose |
|------|--------|---------|
| `nginx-entaprenua.conf` | `scripts/` | Main OpenResty config |
| `storefront-lookup.lua` | `scripts/storefront/` | Domain → Port lookup |
| `redis-helpers.lua` | `scripts/storefront/` | Redis utilities |

---

## Setup

See [STOREFRONT_NGINX_SETUP.md](./STOREFRONT_NGINX_SETUP.md) for installation instructions.

---

## Related Documentation

- [STOREFRONT.md](./STOREFRONT.md) - Storefront architecture
- [STOREFRONT_NGINX_SETUP.md](./STOREFRONT_NGINX_SETUP.md) - Setup guide
