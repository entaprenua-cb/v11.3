# API Response Consistency Implementation Plan

## Overview

This document outlines the plan to fix the inconsistency between server API responses and client expectations after wrapping server responses in `ApiResponse`.

## Background

- Server services were returning raw data (e.g., `Order`, `Product`, etc.)
- Client expected data wrapped in `ApiResponse` wrapper
- Solution: Wrap all server responses using `apiSuccess()`, `apiError()`, `apiNotFound()`, `apiBadRequest()` with `.toServerResponse()`

## ApiResponse Structure

```json
{
  "success": true,
  "message": "Success",
  "data": { ... },
  "error": null,
  "timestamp": 1709572800000,
  "path": "/api/v1/..."
}
```

### Response Type Mapping

| Response Type | Code | HTTP Status |
|---------------|------|-------------|
| `apiSuccess()` | "SUCCESS" | 200 |
| `apiError()` | "INTERNAL_ERROR" | 500 |
| `apiNotFound()` | "NOT_FOUND" | 404 |
| `apiBadRequest()` | "BAD_REQUEST" | 400 |

## Current State

### Completed - Server Updates

All server services updated to wrap responses in `ApiResponse`:
- **store/impl**: Order, Category, Product, Cart, Wishlist, Hero, Checkout
- **builder/impl**: Store, Module, ModuleGroup, StoreClone, Builds, Upload
- **auth/impl**: AuthService
- **media/impl**: MediaGet, MediaSave
- **store/services**: Coupon, StoreMember, TemplatePurchase, SearchIndexInitializer
- **infrastructure**: UserGet, UserSave
- **storefront**: StorefrontServer
- **store**: WebhookHandler

### Completed - Client Updates

- `client.ts` updated to unwrap `ApiResponse` from server responses (lines 142-150)
- When server returns `{ success, data, error }`, client extracts `data` and throws error if `success` is false

### Issues Found

1. **API Types Still Return `ApiResponse<T>`** - 80+ functions in API files still type return as `Promise<ApiResponse<T>>` instead of `Promise<T>`
2. **Routes Check `.success` and `.data`** - 14 route files check for `.success` and `.data` properties that no longer exist on unwrapped data

## Implementation Plan

### Step 1: Update API Types

Change all API functions from returning `Promise<ApiResponse<T>>` to `Promise<T>`.

**Files to update:**
- `src/lib/api/orders.ts` - 4 functions
- `src/lib/api/categories.ts` - 6 functions
- `src/lib/api/payments.ts` - 16 functions
- `src/lib/api/media.ts` - 3 functions
- `src/lib/api/stores.ts` - 18 functions
- `src/lib/api/carts.ts` - 8 functions
- `src/lib/api/products.ts` - 4 functions
- `src/lib/api/wishlists.ts` - 7 functions
- `src/lib/api/auth.ts` - 16 functions
- `src/lib/api/builds.ts` - (check for additional functions)

**Before:**
```typescript
getById: async (storeId: string, orderId: string): Promise<ApiResponse<Order>> => {
  return api.get<ApiResponse<Order>>(`${STORES_BASE}/${storeId}/orders/${orderId}`, csrfToken);
}
```

**After:**
```typescript
getById: async (storeId: string, orderId: string): Promise<Order> => {
  return api.get<Order>(`${STORES_BASE}/${storeId}/orders/${orderId}`, csrfToken);
}
```

### Step 2: Update Route Files

Fix routes that check `.success` and `.data` to work with unwrapped data.

**Files to update:**
- `routes/admin/orders/[id]/index.tsx` - line 60
- `routes/sign-up.tsx` - line 141
- `routes/stores/[id]/index.tsx` - line 41
- `routes/log-in.tsx` - line 119
- `routes/builder/index.tsx` - lines 46, 60
- `routes/templates/[id].tsx` - lines 39, 62, 101
- `routes/stores/[id]/settings.tsx` - lines 41, 73
- `routes/stores/[id]/build.tsx` - line 95
- `routes/stores/new.tsx` - lines 125, 201

**Before:**
```typescript
const response = await ordersApi.getById(sid, orderId);
if (response.success && response.data) {
  setOrder(response.data);
}
```

**After:**
```typescript
const orderData = await ordersApi.getById(sid, orderId);
if (orderData) {
  setOrder(orderData);
}
```

### Step 3: Verify Types

Run typecheck to ensure no type errors:
```bash
cd client/entaprenua && pnpm run typecheck
```

### Step 4: Test

Test the application to ensure:
- Data loads correctly
- Error handling works properly
- All CRUD operations function as expected

## Related Files

### Server (kotlin)
- `/home/nesh/repos/Applications/entaprenua/server/entaprenua/src/main/kotlin/com/entaprenua/`
  - `common/dtos/ApiResponse.kt` - ApiResponse wrapper
  - `store/impl/` - Order, Category, Product, Cart, Wishlist, Hero, Checkout services
  - `builder/impl/` - Store, Module, Builds services
  - `auth/impl/AuthServiceImpl.kt`
  - `media/impl/`
  - `store/services/`
  - `infrastructure/`
  - `storefront/StorefrontServer.kt`
  - `store/WebhookHandler.kt`

### Client (typescript)
- `/home/nesh/repos/Applications/entaprenua/client/entaprenua/src/`
  - `lib/api/client.ts` - Unwraps ApiResponse
  - `lib/api/*.ts` - All API modules (need type updates)
  - `lib/types/api.ts` - Contains ApiResponse type definition
  - `routes/**/*.tsx` - Route components (need .success/.data removal)

## Notes

- The `.toServerResponse()` method auto-maps HTTP status codes based on response type
- Client `ApiError` class is thrown when server returns `success: false`
- Auth endpoints may need special handling (some return unwrapped data like csrfToken)
