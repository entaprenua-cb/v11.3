# Implementation Plan: Storefront Customer Registration

## Overview
Implement storefront customer registration with standalone store_customers table and per-store email verification customization.

## Related Documents
- **Password Reset**: See `docs/implementation-plan-password-reset-unified.md` for shared password reset logic (applies to both platform and store customers)

## Database Changes

### Migration: V33__Add_store_customers_and_verification_fields.sql

```sql
-- Add phone column to users table for platform users
ALTER TABLE users ADD COLUMN IF NOT EXISTS phone VARCHAR(50);
ALTER TABLE users ADD COLUMN IF NOT EXISTS password_reset_token VARCHAR(6);
ALTER TABLE users ADD COLUMN IF NOT EXISTS password_reset_expires_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS password_reset_count INT DEFAULT 0;

-- Remove logo and favicon columns from stores table (if they exist)
ALTER TABLE stores DROP COLUMN IF EXISTS logo;
ALTER TABLE stores DROP COLUMN IF EXISTS favicon;

-- Add verification customization columns to stores table
ALTER TABLE stores ADD COLUMN IF NOT EXISTS verification_redirect_url VARCHAR(500);
ALTER TABLE stores ADD COLUMN IF NOT EXISTS verification_email_subject VARCHAR(200) DEFAULT 'Verify your account';
ALTER TABLE stores ADD COLUMN IF NOT EXISTS verification_success_redirect_url VARCHAR(500);
ALTER TABLE stores ADD COLUMN IF NOT EXISTS verification_sender_name VARCHAR(100) DEFAULT 'Store Team';
ALTER TABLE stores ADD COLUMN IF NOT EXISTS verification_sender_email VARCHAR(255);
ALTER TABLE stores ADD COLUMN IF NOT EXISTS verification_email_template TEXT;
ALTER TABLE stores ADD COLUMN IF NOT EXISTS verification_expiry_hours INT DEFAULT 24;
ALTER TABLE stores ADD COLUMN IF NOT EXISTS verification_subdomain VARCHAR(100);
ALTER TABLE stores ADD COLUMN IF NOT EXISTS verification_custom_domain VARCHAR(255);

-- Create store_customers table
CREATE TABLE IF NOT EXISTS store_customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR,
    name VARCHAR(255),
    phone VARCHAR(50),
    identity_provider VARCHAR(20) DEFAULT 'LOCAL',
    email_verified BOOLEAN DEFAULT false,
    verification_token UUID,
    verification_expires_at TIMESTAMP WITH TIME ZONE,
    inserted_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    password_reset_token VARCHAR(6),
    password_reset_expires_at TIMESTAMP WITH TIME ZONE,
    password_reset_count INT DEFAULT 0,
    UNIQUE(store_id, email)
);

-- Create indexes for store_customers
CREATE INDEX IF NOT EXISTS idx_store_customers_store_id ON store_customers(store_id);
CREATE INDEX IF NOT EXISTS idx_store_customers_email ON store_customers(email);
CREATE INDEX IF NOT EXISTS idx_store_customers_phone ON store_customers(phone);
CREATE INDEX IF NOT EXISTS idx_store_customers_verification_token ON store_customers(verification_token);
CREATE INDEX IF NOT EXISTS idx_store_customers_password_reset_token ON store_customers(password_reset_token);
```

## Sender Email Logic

```
If verification_custom_domain is set:
    → Use: anything@verification_custom_domain
Else if verification_subdomain is set:
    → Use: anything@verification_subdomain.entaprenua.com
Else (auto-extract from store domain_name):
    → Extract from domain_name (e.g., mystore.entaprenua.com → mystore@entaprenua.com)
```

## Password Reset - Unified Approach

To avoid code duplication, create a shared `PasswordResetService` that handles both platform users and store customers:

### PasswordResetService (Shared)
| Method | Description |
|--------|-------------|
| `generateResetToken()` | Generate 6-digit code |
| `sendResetEmail(email, userType, storeId?)` | Send reset email with code |
| `verifyToken(token, userType, storeId?)` | Verify token is valid |
| `resetPassword(token, newPassword, userType, storeId?)` | Reset password with token |

### Password Reset Logic (Same for Platform & Store)
- **Code**: 6-digit numeric
- **Expiry**: 15 minutes
- **Rate limiting**: 60s cooldown, max 3 requests per hour
- **Template**: Platform fixed HTML (not customizable)
- **Sender**: Store's domain/subdomain (for store customers)

### Fields Added
- `users` table: `password_reset_token`, `password_reset_expires_at`, `password_reset_count`
- `store_customers` table: `password_reset_token`, `password_reset_expires_at`, `password_reset_count`

## Files to Modify/Create

### 1. Migration
- `runtime/src/main/resources/db/migration/V33__Add_store_customers_and_verification_fields.sql` - Update with correct field names and all columns

### 2. Entities
- `runtime/src/main/kotlin/com/entaprenua/entities/Store.kt` - Add verification fields, remove logo/favicon
- `runtime/src/main/kotlin/com/entaprenua/entities/StoreCustomer.kt` - NEW
- `runtime/src/main/kotlin/com/entaprenua/entities/User.kt` - Add phone, password_reset fields

### 3. Shared Service (Avoid Duplication)
- `runtime/src/main/kotlin/com/entaprenua/auth/services/PasswordResetService.kt` - NEW (shared for platform & store)

### 4. Repositories
- `runtime/src/main/kotlin/com/entaprenua/repositories/StoreRepository.kt` - Update queries for new fields
- `runtime/src/main/kotlin/com/entaprenua/repositories/StoreCustomerRepository.kt` - NEW
- `runtime/src/main/kotlin/com/entaprenua/repositories/UserRepository.kt` - Add password_reset fields and queries

### 5. Store Services
- `runtime/src/main/kotlin/com/entaprenua/store/services/StorefrontAuthService.kt` - NEW (interface)
- `runtime/src/main/kotlin/com/entaprenua/store/impl/StorefrontAuthServiceImpl.kt` - NEW

### 6. Email
- `runtime/src/main/kotlin/com/entaprenua/email/EmailTemplates.kt` - Add storefront verification template and password reset template

### 7. Config
- `runtime/src/main/kotlin/com/entaprenua/config/ApiRouterConfig.kt` - Add storefront customer endpoints

## API Endpoints

### Platform Auth (Existing + Update)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/auth/register` | Platform user registration |
| POST | `/api/v1/auth/login` | Platform user login |
| GET | `/api/v1/auth/verify-email?token={token}` | Verify email |
| POST | `/api/v1/auth/password-reset/request` | Request password reset (code) |
| POST | `/api/v1/auth/password-reset/confirm` | Confirm password reset with code |
| POST | `/api/v1/auth/resend-verification` | Resend verification email |

### Storefront Customer Auth (NEW)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/stores/{storeId}/customers/register` | Customer registration |
| GET | `/api/v1/stores/{storeId}/customers/verify?token={token}` | Verify email |
| POST | `/api/v1/stores/{storeId}/customers/login` | Customer login |
| GET | `/api/v1/stores/{storeId}/customers/me` | Get current customer |
| POST | `/api/v1/stores/{storeId}/customers/logout` | Customer logout |
| POST | `/api/v1/stores/{storeId}/customers/password-reset/request` | Request password reset (code) |
| POST | `/api/v1/stores/{storeId}/customers/password-reset/confirm` | Confirm password reset with code |

### Store Settings
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/stores/{id}/settings` | Get store settings (includes verification config) |
| PUT | `/api/v1/stores/{id}/settings` | Update store settings (includes verification config) |

## Implementation Steps

1. **Update migration V33** - Add all columns including password_reset fields
2. **Update Store.kt entity** - Add new verification fields, remove logo/favicon
3. **Create StoreCustomer.kt entity**
4. **Update User.kt entity** - Add phone, password_reset fields
5. **Create StoreCustomerRepository.kt**
6. **Create PasswordResetService.kt** (shared service)
7. **Update UserRepository.kt** - Add password_reset queries
8. **Update StoreRepository.kt** - Include new verification fields
9. **Create StorefrontAuthService.kt** (interface)
10. **Create StorefrontAuthServiceImpl.kt**
11. **Update EmailTemplates.kt** - Add storefront verification template and password reset template
12. **Update existing platform password reset endpoints** - Use shared service
13. **Update ApiRouterConfig.kt** - Add customer endpoints
14. **Test all flows**
15. **Build and deploy**

## Status
- [x] Plan written
- [x] Updated with password reset details
- [x] Consolidated password reset logic
- [ ] Implementation in progress