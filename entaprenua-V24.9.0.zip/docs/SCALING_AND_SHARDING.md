# Scaling & Sharding Analysis

## Overview

The Entaprenua backend is a Kotlin/Spring Boot/WebFlux application using PostgreSQL (via JOOQ/R2DBC) with Redis for cross-instance communication. The current architecture assumes a single server. This document catalogs everything that would hinder horizontal scaling (multiple app server instances) or database sharding (splitting data across DBs), and provides a phased migration plan.

**Current architecture:**
- Single PostgreSQL database (row-level multi-tenancy via `store_id`)
- Local disk for build artifacts (`/var/lib/entaprenua/stores/`)
- Local disk for media files (`/opt/entaprenua/media/`)
- In-process coroutine-based job queues
- Local systemd process management for storefront hosting
- Caffeine local cache (fallback: Redis)
- In-memory mutable maps for OAuth states

---

## Horizontal Scaling Blockers

### 🔴 Critical — Will break with >1 instance

| # | Blocker | Files | Line(s) | Problem |
|---|---------|-------|---------|---------|
| 1 | In-process build queue | `vcs/services/BuildQueueService.kt` | 48, 75-81 | `CoroutineScope(IO + SupervisorJob())` — builds queued on instance A are lost if A crashes; instance B has no knowledge |
| 2 | In-memory store process registry | `storefront/ProcessManagerService.kt` | 44-46 | `ConcurrentHashMap` of running stores per-instance. Instance A starts a store → B can't see or route to it |
| 3 | Local build artifacts | `vcs/services/BuildQueueService.kt`, `storefront/StorefrontConfig.kt` | 31-36, 10 | Store files on `/var/lib/entaprenua/stores/` per-server. Instance B can't serve A's store artifacts |
| 4 | Local systemd process management | `storefront/SystemdService.kt` | 143 | `ProcessBuilder("systemctl")` — systemd is per-server. If A dies, its store processes die permanently |
| 5 | In-memory OAuth pending states | `auth/impl/OAuthServiceImpl.kt`, `store/impl/StorefrontAuthServiceImpl.kt` | 67, 114 | `mutableMapOf` — user starts OAuth on A, callback hits B → "Invalid state" error |

### 🟠 High — Degraded behavior with >1 instance

| # | Blocker | Files | Line(s) | Problem |
|---|---------|-------|---------|---------|
| 6 | Local port allocation | `storefront/ProcessManagerService.kt` | 116-124 | `ServerSocket(port).bind()` — two instances can assign the same port |
| 7 | Local media storage | `media/config/MediaConfig.kt`, `media/impl/MediaGetServiceImpl.kt` | 9, 50-51 | `/opt/entaprenua/media` per-server. File uploaded to A is 404 on B |
| 8 | Local-only cache (Caffeine) | `config/CacheConfig.kt`, `media/repositories/MediaRepository.kt` | 14-23, 48 | `@Cacheable("media")` — stale reads on other instances for up to 10 minutes |

### 🟡 Medium — Degraded but mostly works via Redis fallback

| # | Blocker | Files | Line(s) | Problem |
|---|---------|-------|---------|---------|
| 9 | Token blacklist fallback | `auth/services/TokenBlacklistService.kt` | 96-97 | Falls to in-memory `ConcurrentHashMap` when Redis is down |
| 10 | Event stream in-memory fallback | `store/services/InventoryEventStream.kt`, `store/services/OrderEventStream.kt`, `vcs/services/BuildLogStream.kt` | 44, 41 | Redis pub/sub works cross-instance; in-memory `topics` fallback doesn't |
| 11 | Coroutine fire-and-forget (email, cleanup) | `auth/services/PasswordResetService.kt`, `auth/services/EmailVerificationService.kt`, `store/impl/StorefrontAuthServiceImpl.kt`, `vcs/services/TempCleanupService.kt` | 37, 21, 112, 27 | Emails fired async — lost if instance crashes before send |

---

## Database Sharding Blockers

### 🔴 Critical — Won't work sharded

| # | Blocker | Files | Line(s) | Problem |
|---|---------|-------|---------|---------|
| 12 | Global `findAll()` queries (no store_id) | `OrderRepository.kt`, `ProductRepository.kt`, `CategoryRepository.kt`, `MediaRepository.kt`, `StoreRepository.kt`, `UserRepository.kt`, `VcsBuildRepository.kt`, `VcsConnectionRepository.kt` | Various | No `store_id` filter — would need scatter-gather to EVERY shard |
| 13 | Global startup recovery query | `store/repositories/StoreRepository.kt`, `storefront/ProcessManagerService.kt` | 223, 65 | `findRunningStorefronts()` scans ALL stores across all shards to recover on startup |

### 🟠 High — Needs redesign for sharding

| # | Blocker | Files | Line(s) | Problem |
|---|---------|-------|---------|---------|
| 14 | Global sequence `order_number_seq` | `generated/sequences/Sequences.kt` | 20 | Single PostgreSQL sequence — collides across shards |
| 15 | `generateOrderNumber()` via stored proc | `store/repositories/OrderRepository.kt` | 621-629 | Calls DB function that increments global sequence |
| 16 | `getNextBuildNumber()` race condition | `vcs/repositories/VcsBuildRepository.kt` | 49-52 | Read + increment = no atomicity, duplicates possible even without sharding |

### 🟡 Medium — Needs consideration

| # | Blocker | Files | Line(s) | Problem |
|---|---------|-------|---------|---------|
| 17 | `FOR UPDATE` row locks | `OrderRepository.kt`, `CartRepository.kt`, `PaymentRepository.kt` | Multiple | Lock is per-database; cross-shard locking needs distributed lock |
| 18 | Stored procedures (business logic in DB) | `generated/routines/Routines.kt`, `store/repositories/OrderRepository.kt` | 2134, 2844, 5575, 582-596 | `transition_order_status()`, `lock_order_for_transaction()` — must be replicated per shard |

---

## What's Already Good

These patterns are sharding-friendly and should be preserved:

| Pattern | Where | Why it works |
|---------|-------|-------------|
| **Row-level multi-tenancy** | All `*ByStoreId()` repository methods | `store_id` is the natural shard key |
| **Optimistic locking (version column)** | `Order`, `Cart`, `Payment`, `Store`, `Media` entities | No cross-shard coordination needed |
| **UUID primary keys** | All entities | No sequential collisions across shards |
| **Redis pub/sub for events** | `OrderEventStream`, `InventoryEventStream`, `BuildLogStream` | Already distributes cross-instance |
| **Redis for token blacklist** | `RedisBlacklistService` | Centralized, instance-agnostic |
| **Redis for storefront routing** | `RedisService.setStorePort()/getStorePort()` | Already cross-instance |

---

## Detailed Blocker Analysis

### 1. In-Process Build Queue (`BuildQueueService.kt:48`)

```kotlin
private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

fun queueBuild(connection: VcsConnection, build: VcsBuild) {
    scope.launch { executeBuild(connection, build) }
}
```

**Problem:** The build queue is entirely in-process. If the server restarts or crashes during a build, the build is lost. There is no persistence, no retry mechanism, and no distribution across instances.

**Fix:** Replace with a persistent queue:
- Option A: Database-backed queue table with polling (simplest, no infra)
- Option B: Redis streams (if Redis is already required)
- Option C: External message broker (RabbitMQ, SQS) — best for production

Desired behavior: `queueBuild()` inserts a row into a `build_queue` table / Redis stream. A background worker (on any instance) picks up and processes it. If the worker crashes, another instance picks it up after a timeout.

### 2. In-Memory Store Process Registry (`ProcessManagerService.kt:44`)

```kotlin
private val assignedPorts = ConcurrentHashMap<String, PortInfo>()
private val portToStoreId = ConcurrentHashMap<Int, String>()
private val storeLocks = ConcurrentHashMap<String, Mutex>()
```

**Problem:** Each instance maintains its own view of which stores are running on which ports. Instance A can't route requests to stores running on instance B. On crash, the registry is lost.

**Fix:** Move to a distributed registry:
- Store port assignments in Redis (already partially done via `RedisService`)
- Use a health-check TTL so crashed instances' entries expire
- The proxy/router reads from Redis to decide which instance handles a request

### 3. Local Build Artifacts (`BuildQueueService.kt:31`)

```kotlin
@Value("\${app.vcs.build.stores-path:/var/lib/entaprenua/stores}")
private val storesPath: String
```

**Problem:** Build output is written to the local filesystem. Instance B cannot serve a store built by instance A.

**Fix:**
- **Short term:** NFS / EFS shared mount across instances
- **Long term:** Store build artifacts in object storage (S3, GCS, R2) and pull on demand at startup, or containerize the store processes so the artifact is baked into the image

### 4. Local systemd Processes (`SystemdService.kt:143`)

```kotlin
val process = ProcessBuilder(
    "systemctl", "--user", "start", "store-${publicId}"
)
```

**Problem:** systemd is inherently per-server. Store processes have no HA.

**Fix:**
- **Short term:** Move store processes to Docker Compose with health checks
- **Long term:** Kubernetes / Nomad where stores run as pods and are scheduled across the cluster automatically

### 5. In-Memory OAuth States (`OAuthServiceImpl.kt:67`)

```kotlin
private val pendingStates = mutableMapOf<String, OAuthPendingState>()
```

**Problem:** User starts OAuth on instance A (gets URL with state), callback arrives on instance B → state not found.

**Fix:** Store pending states in Redis with TTL (5 minutes). Same pattern for storefront OAuth.

### 12. Global `findAll()` Queries

Repositories that query ALL rows without a `store_id` filter:

| File | Method | Line |
|------|--------|------|
| `OrderRepository.kt` | `findAll()` | 406 |
| `ProductRepository.kt` | `findAll()` | 371 |
| `CategoryRepository.kt` | `findAll()` | 304 |
| `MediaRepository.kt` | `findAll()` | 291 |
| `StoreRepository.kt` | `findAll()` | 145 |
| `UserRepository.kt` | `findAll()` | 58 |
| `VcsBuildRepository.kt` | `findOngoingBuilds()` | 130 |
| `VcsConnectionRepository.kt` | `findAll()` | 46 |

**Fix for sharding:** Each `findAll()` must either:
- Accept a `store_id` parameter and query only one shard, or
- Be explicitly marked as scatter-gather (query all shards, merge results), or
- Be replaced with an alternative that doesn't need global scans

### 14-15. Global Sequence → Order Numbers

```kotlin
// OrderRepository.kt:621
suspend fun generateOrderNumber(storeId: UUID): String {
    val result = Flux.from(
        dsl.select(DSL.field("generate_order_number(CAST({0} AS UUID))", ...))
    ).awaitFirstOrNull()
    return result?.get(0)?.toString() ?: "ORD-${System.currentTimeMillis()}"
}
```

**Problem:** `order_number_seq` is a single PostgreSQL sequence. In a sharded setup, different shards would generate colliding order numbers.

**Fix:**
- Option A: Order number = `shard_id * 10^12 + local_sequence` (each shard has its own sequence)
- Option B: Order number = timestamp + shard_id + random (no sequence needed)
- Option C: Use UUIDs for order numbers (simplest, but less human-friendly)

### 17. `FOR UPDATE` Locks

```kotlin
// OrderRepository.kt:346
dsl.selectFrom(ORDERS).where(ORDERS.ID.eq(id)).forUpdate()
```

**Problem:** `FOR UPDATE` row locks only work within a single database. If the row is on shard A, a request on shard B can't lock it.

**Fix:**
- Prefer optimistic locking (version column) — already used in many places
- For pessimistic locking: use a distributed lock service (Redis Redlock, etc.)
- The `LockingResult` sealed class in `LockingExceptions.kt` is a good foundation

### 18. Stored Procedures

```kotlin
// OrderRepository.kt:582
dsl.select(DSL.field("transition_order_status(?, ?, ?, ?)", ...))
```

**Problem:** Stored procedures embed business logic in the database. They must exist on every shard, and cross-shard transactions become impossible.

**Fix:** Move business logic into application code. The `transition_order_status` function currently handles:
- Status state machine validation (`canTransitionTo()` already exists in the Order entity)
- Status transition logic
- Timestamp updates
- Version checking

---

## Priority Roadmap

### Phase 1 — Quick Wins (1-2 days each)

| Step | Fix | Strategy | Depends on |
|------|-----|----------|------------|
| 1.1 | Move OAuth states to Redis | Replace `mutableMapOf` with Redis `opsForValue().set(key, state, Duration.ofMinutes(5))` | Redis available |
| 1.2 | Move storefront OAuth states to Redis | Same pattern as 1.1 | Redis available |
| 1.3 | Fix `getNextBuildNumber()` race | Use `SELECT MAX(build_number) ... FOR UPDATE` or a dedicated counter table | None |

### Phase 2 — Build Queue Resiliency (3-5 days)

| Step | Fix | Strategy |
|------|-----|----------|
| 2.1 | Database-backed build queue | Create `build_queue` table with status, worker_id, retry_count, scheduled_at |
| 2.2 | Replace `scope.launch` with queue | `queueBuild()` inserts row; `ScheduledService` polls for pending jobs on any instance |
| 2.3 | Add retry + dead-letter | Failed builds go to `failed` status with error log; manual retry via existing API |

### Phase 3 — Database Sharding Foundation (4-7 days)

| Step | Fix | Strategy |
|------|-----|----------|
| 3.1 | Audit and fix all global `findAll()` | Add `store_id` parameter; remove unused global queries; mark scatter-gather explicitly |
| 3.2 | Replace global sequence for order numbers | Option B: Timestamp + shard_id + random, or Option A: shard-local sequence |
| 3.3 | Move stored procedures to app code | `transition_order_status()` → `OrderService.transitionStatus()` using optimistic locking |

### Phase 4 — Shared Storage (5-7 days)

| Step | Fix | Strategy |
|------|-----|----------|
| 4.1 | Media files to S3-compatible object storage | Replace `Files.move()` with S3 SDK upload; update URL generation |
| 4.2 | Build artifacts to shared storage | Write build output to S3 + local cache; pull on store start |
| 4.3 | Enable CDN for media | Configure CDN base URL; make it the primary delivery path |

### Phase 5 — Distributed Caching (2-3 days)

| Step | Fix | Strategy |
|------|-----|----------|
| 5.1 | Replace Caffeine with Redis cache | Spring `@CacheConfig` → `RedisCacheManager`; configure TTL per cache |
| 5.2 | Add cache invalidation via pub/sub | When instance A updates data, publish invalidation message; B evicts stale cache |

### Phase 6 — Store Process Containerization (5-10 days)

| Step | Fix | Strategy |
|------|-----|----------|
| 6.1 | Dockerize store processes | Build store artifacts into Docker images; run as containers |
| 6.2 | Replace systemd with container orchestration | Docker Compose (simple) → Nomad/K8s (full HA) |
| 6.3 | Move port allocation to distributed registry | Redis-based port leases with TTL; proxy reads from Redis |

### Phase 7 — Sharding Migration (10-20 days)

| Step | Fix | Strategy |
|------|-----|----------|
| 7.1 | Design shard key | `store_id` as primary shard key; global lookup table for cross-shard entities |
| 7.2 | Implement read replicas | Separate read/write connections; route `findAll*` to read replicas |
| 7.3 | Implement application-level sharding | Shard-aware datasource routing; CitusDB or pgbouncer for connection routing |
| 7.4 | Data migration | Zero-downtime migration: dual-write, backfill, cutover |

---

## Architecture Diagrams

### Current: Single Server

```
┌─────────────────────────────────────┐
│         App Server Instance          │
│                                      │
│  ┌──────────┐  ┌──────────────────┐  │
│  │ In-memory │  │ Coroutine Queue  │  │
│  │ OAuth     │  │ (Build, Email)   │  │
│  │ States    │  └──────────────────┘  │
│  └──────────┘         │               │
│                       ▼               │
│  ┌──────────────────────────────────┐ │
│  │     systemd Store Processes      │ │
│  │  ┌──────┐ ┌──────┐ ┌──────┐     │ │
│  │  │Store │ │Store │ │Store │     │ │
│  │  │  A   │ │  B   │ │  C   │     │ │
│  │  └──────┘ └──────┘ └──────┘     │ │
│  └──────────────────────────────────┘ │
│                                      │
│  ┌──────────┐  ┌──────────────────┐  │
│  │ Caffeine │  │ Local Disk       │  │
│  │ Cache    │  │ (Media + Builds) │  │
│  └──────────┘  └──────────────────┘  │
│                                      │
│  ┌──────────────────────────────────┐ │
│  │     PostgreSQL (Single DB)       │ │
│  └──────────────────────────────────┘ │
└─────────────────────────────────────┘
         │ Redis (optional)
         ▼
    ┌──────────┐
    │  Redis   │
    └──────────┘
```

### Target: Multi-Instance + Sharded

```
         Load Balancer
              │
     ┌────────┴────────┐
     │                 │
┌────▼────┐     ┌────▼────┐
│Instance │     │Instance │
│   A     │     │   B     │
│         │     │         │
│(no in-  │     │(no in-  │
│memory   │     │memory   │
│state)   │     │state)   │
└────┬────┘     └────┬────┘
     │               │
     └───────┬───────┘
             │
             ▼
     ┌───────────────┐
     │    Redis       │
     │ (OAuth states, │
     │  locks, cache, │
     │  event pub/sub,│
     │  port registry)│
     └───────┬───────┘
             │
     ┌───────┴───────┐
     │               │
┌────▼────┐    ┌────▼────┐
│ PGSQL   │    │ PGSQL   │
│ Shard 0 │    │ Shard 1 │
│(stores  │    │(stores  │
│ A-M)    │    │ N-Z)    │
└─────────┘    └─────────┘

Container Orchestrator (K8s/Nomad)
┌──────────────────────────────────┐
│ Store A Pod  │ Store B Pod       │
│ Store C Pod  │ Store D Pod       │
│ ...                              │
│ (scheduled across instances)     │
└──────────────────────────────────┘

Shared Object Storage (S3)
┌──────────────────────────────────┐
│ Media files │ Build artifacts    │
└──────────────────────────────────┘
```

---

## Shard Key Design

### Primary Shard Key: `store_id`

Most queries already filter by `store_id`, making it the natural shard key.

**Shard allocation:**
```
shard = hash(store_id) % num_shards
```

### Global Tables (not sharded)

These tables contain data that isn't tenant-specific and live on all shards or a dedicated "global" shard:

| Table | Why | Strategy |
|-------|-----|----------|
| `users` | Cross-tenant authentication | Replicated read-only to all shards, or use global lookup table |
| `stores` | Tenant registry (needed to resolve `store_id`) | Lookup table with shard mapping |
| `user_sessions` | Auth session validation | Replicated or global |

### Lookup Table

A small routing table that maps `store_id → shard_id`:

```sql
CREATE TABLE store_shard_map (
    store_id UUID PRIMARY KEY,
    shard_id INT NOT NULL,
    assigned_at TIMESTAMPTZ DEFAULT NOW()
);
```

Cached in Redis for fast lookup.

### Cross-Shard Queries

Queries that can't be scoped to a single shard (e.g., admin reporting, global search) should:

1. **Scatter-gather**: Send query to all shards, merge results in application layer
2. **Read replica**: Route to a dedicated read replica that aggregates all shards
3. **Eventual consistency**: Accept stale data for global views

### JOINs Across Shards

Standard SQL JOINs operate within a single database connection. They cannot reference tables on different physical database instances. This is a fundamental constraint of sharding.

**Safe JOINs** — These work without change because all tables involved share the same `store_id` shard key:

| Pattern | Example | Why it works |
|---------|---------|-------------|
| Order ↔ Order Items | `orders JOIN order_items ON order_id` | Both filtered by `store_id`; same shard |
| Product ↔ Categories | `products JOIN categories ON category_id` | Both scoped to the store; same shard |
| Cart ↔ Cart Items | `carts JOIN cart_items ON cart_id` | Same store, same shard |
| Any per-store chain | `store_id = ?` across all JOINed tables | Shard key is uniform |

**Broken JOINs** — These span shards or lack a `store_id` filter:

| Query | Problem | Fix |
|-------|---------|-----|
| `users JOIN orders ON user_id` | Users live on global shard; orders per-store | Join in application code (query user, then query orders) |
| Cross-store reporting | `WHERE store_id IN (...)` across shards | Scatter-gather to each shard, merge in app |
| `stores JOIN users ON owner_id` | Stores on shard A, users on global | N+1 or bulk load users, join in app |
| Any `findAll()` without `store_id` | Touches all shards, can't JOIN within a single query | Add `store_id` or mark as explicit scatter-gather |

**Strategies for cross-shard JOINs:**

1. **Denormalize** — Duplicate reference data onto every shard. E.g., copy `users` table (or a subset of columns) to each shard so `user_id` lookups are local. Trade-off: write amplification, sync lag.

2. **Application-layer JOIN** — Query shard A for orders, query global/users DB for user details, loop over results. Works at small scale, N+1 problem at larger scale.

3. **Batch load** — Collect all unique foreign keys from shard query, load them in one batch query to the global DB, then merge in app. Prevents N+1:

   ```kotlin
   val orders = orderRepo.findByStoreId(storeId)  // on shard
   val userIds = orders.map { it.userId }.toSet()
   val users = userRepo.findByIds(userIds)         // on global DB
   val joined = orders.map { order ->
       OrderWithUser(order, users[order.userId])
   }
   ```

4. **Materialized views / read replicas** — Maintain an aggregated read-only database that joins across shards periodically (minutes of lag). Sufficient for admin dashboards, not for real-time checkout.

5. **Move to a distributed SQL database** — Citus (PostgreSQL extension), CockroachDB, or Spanner handle distributed JOINs transparently using a coordinator node. Trade-off: operational complexity, vendor lock-in.

**Recommendation for this codebase:**

Most JOINs are safe because they're scoped to a single store's data. The few cross-shard JOINs fall into two categories:

- **Admin/analytics** — Handle via materialized views or scatter-gather with batch loading. Real-time not required.
- **User → per-store data** — Denormalize key user fields (`name`, `email`) onto the `orders`/`carts` tables per shard. This is already partially done (orders store user info at time of purchase). Extend to other tables as needed.

---

## Migration Strategy

### Phase A: No-Downtime Prep

All changes in Phases 1-5 are backwards-compatible:
- Moving OAuth states to Redis doesn't break existing flows
- Adding a DB-backed build queue alongside the existing one
- Object storage can be written in parallel with local disk

### Phase B: Dual-Write (for sharding)

1. Add a `shard_id` column to all tenant-scoped tables
2. Start writing to both current DB and new shard DB
3. Backfill historical data to shard DB
4. Run validation queries to ensure consistency
5. Cut over reads to shard DB
6. Remove dual-write

### Phase C: Cutover

1. Put app in read-only mode
2. Verify all data is consistent
3. Switch connection strings
4. Enable writes
5. Decommission old single DB if desired

---

## Key Design Principles

1. **Stateless app instances** — all shared state in Redis or database
2. **store_id is king** — every query must include it; global queries are opt-in with explicit scatter-gather
3. **Optimistic over pessimistic** — prefer version-based locking over `FOR UPDATE`; use distributed locks only when necessary
4. **Async with persistence** — all background jobs survive restarts via persistent queues
5. **Object storage for blobs** — media and build artifacts never touch local disk in production
6. **Containerized workloads** — store processes are ephemeral, scheduled by an orchestrator
