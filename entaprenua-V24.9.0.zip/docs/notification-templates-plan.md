# Notification Templates Implementation Plan

## Overview

Multi-channel notification system with merchant-customizable templates. Merchants edit email/SMS/WhatsApp templates per event type. System defaults provided out of the box; store overrides on top.

## Architecture

```
OrderEvent (checkout, shipped, delivered...)
  → NotificationService.send(eventType, order, customer)
    → Read store notification preferences from settings (which channels enabled)
    → For each enabled channel:
      → Load template (store override OR system default)
      → Resolve {{ variables }} via Thymeleaf
      → Dispatch via EmailService / SmsService / WhatsAppService
```

## Database

```sql
CREATE TABLE store_notification_templates (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    event_type VARCHAR(50) NOT NULL,
    channel VARCHAR(20) NOT NULL,
    subject VARCHAR(255),
    body_html TEXT,
    body_text TEXT,
    is_active BOOLEAN DEFAULT true,
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(store_id, event_type, channel)
);
```

System defaults live as classpath resources in `templates/notifications/defaults/{event_type}/{channel}.html` and `channel`.txt. Loaded into a `system_notification_templates` table or served from classpath.

## Event Types

| Event | Trigger | When |
|-------|---------|------|
| `order_confirmation` | Checkout completes | Immediately |
| `payment_failed` | Payment declined | Immediately |
| `order_processed` | Merchant marks processed | Manual |
| `shipped` | Tracking added | Manual |
| `ready_for_pickup` | Status → ready_for_pickup | Manual |
| `delivered` | Status → delivered | Manual |
| `delivery_delayed` | Exception logged | Manual |
| `return_refunded` | Refund processed | Manual |

## Channels

| Channel | Content sent | Notes |
|---------|-------------|-------|
| `email` | subject + body_html (fallback body_text) | Rich HTML via SendGrid/SES |
| `sms` | body_text only | Africa's Talking / Twilio |
| `whatsapp` | body_text (HTML stripped) | Twilio WhatsApp API |

## Settings Preferences

Stored in existing `store_settings` schema-driven system, NOT in the templates table:

```json
{
  "notifications": {
    "order_confirmation": { "email": true, "sms": false, "whatsapp": false },
    "shipped":            { "email": true, "sms": false, "whatsapp": false },
    "ready_for_pickup":   { "email": true, "sms": true,  "whatsapp": false },
    "delivered":          { "email": true, "sms": true,  "whatsapp": false },
    "payment_failed":     { "email": true, "sms": false, "whatsapp": false }
  }
}
```

## Template Variables

Resolved at send-time via Thymeleaf context:

| Variable | Type | Example |
|----------|------|---------|
| `store.name` | String | "My Shop" |
| `customer.name` | String | "Alice" |
| `customer.email` | String | "alice@example.com" |
| `order.number` | String | "#1024" |
| `order.total` | String | "KSh 2,500.00" |
| `order.items` | List | [{ name, quantity, price }] |
| `pickup.code` | String | "DR-042" |
| `pickup.location` | String | "Kimathi Street, Nairobi" |
| `pickup.expires_at` | String | "May 20, 2026" |
| `tracking.number` | String | "1Z999AA10123456784" |
| `tracking.url` | String | "https://..." |

## API Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/stores/{id}/notification-templates` | List all templates (store override + fallback merged) |
| GET | `/stores/{id}/notification-templates/{event}/{channel}` | Get single template |
| PUT | `/stores/{id}/notification-templates/{event}/{channel}` | Create or update store override |
| DELETE | `/stores/{id}/notification-templates/{event}/{channel}` | Remove override, revert to default |
| GET | `/stores/{id}/notification-templates/defaults` | List system defaults for reference |

## Backend Files to Create

| File | Purpose |
|------|---------|
| `db/migration/VXX__Add_notification_templates.sql` | Migration |
| `entities/NotificationTemplate.kt` | Entity |
| `repositories/NotificationTemplateRepository.kt` | JOOQ CRUD |
| `services/NotificationService.kt` | Interface |
| `services/NotificationServiceImpl.kt` | Template resolution + dispatch |
| `services/SenderService.kt` | Interface (send on any channel) |
| `services/EmailSenderService.kt` | SendGrid/SES |
| `services/SmsSenderService.kt` | Africa's Talking / Twilio |
| `services/WhatsAppSenderService.kt` | Twilio WhatsApp API |
| `dtos/NotificationTemplateDto.kt` | Request/response DTOs |
| `templates/notifications/defaults/{event}/{channel}.html` | System default templates |
| `templates/notifications/defaults/{event}/{channel}.txt` | System default plaintext |

## Integration Points

- `CheckoutServiceImpl.createOrder()` → call `NotificationService.send("order_confirmation", ...)`
- `OrderStatusChangeService` (wherever status transitions happen) → call `NotificationService.send(eventType, ...)`

## Phases

### Phase 1 (now)
- Migration, entity, repository
- System default templates for order_confirmation and payment_failed (email)
- `NotificationService` + `EmailSenderService`
- Hook into checkout flow

### Phase 2
- Template CRUD API + admin UI
- SMS channel with Africa's Talking
- All event types

### Phase 3
- WhatsApp channel
- Abandoned cart (requires delayed dispatch)
- Template preview in admin
