# Storefront Architecture

**Last Updated**: 2026-04-05  
**Status**: ✅ Implemented

---

## Overview

The storefront is served as **SolidStart SSR (Server-Side Rendering)** application with **independent Node.js processes** per store. OpenResty (Nginx + Lua) dynamically routes requests based on subdomain using Redis cache.

---

## Quick Links

- [STOREFRONT_NGINX_ROUTING.md](./STOREFRONT_NGINX_ROUTING.md) - Dynamic routing architecture
- [STOREFRONT_NGINX_SETUP.md](./STOREFRONT_NGINX_SETUP.md) - Setup instructions

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     SolidStart SSR App                          │
│  (handles ALL domains - both subdomains & custom domains)     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  1. Extract domain from request (middleware)                   │
│  2. Lookup store in database by domain                         │
│  3. Set store context (x-store-id header)                     │
│  4. Render routes with store-specific content                  │
│  5. Fetch live data from Spring Boot API                      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Spring Boot API                              │
│  - Store lookup by domain                                      │
│  - Products, Categories, Cart, Orders, etc.                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Domain Types Supported

| # | Type | Example | Hosted By |
|---|------|---------|------------|
| 1 | Subdomain | `mystore.entaprenua.com` | Your server |
| 2 | Custom Domain (on your server) | `mystore.com` | Your server |
| 3 | Custom Domain (self-hosted) | `mystore.com` | User's own server |

---

## Domain Type Details

### 1. Subdomain (Your Domain)

```
mystore.entaprenua.com
    │
    ▼
DNS: *.entaprenua.com → Server IP
    │
    ▼
Nginx → SolidStart SSR → Store Node Process
```

| Configuration | Value |
|---------------|--------|
| DNS | Wildcard A record: `*.entaprenua.com` → Server IP |
| Nginx | Wildcard virtual host |
| SSL | Let's Encrypt (auto) |

---

### 2. Custom Domain (On Your Server)

```
mystore.com
    │
    ▼
User adds A record: mystore.com → Your Server IP
    │
    ▼
Nginx → SolidStart SSR → Store Node Process
```

| Configuration | Value |
|---------------|--------|
| DNS | User adds A/CNAME record to your server IP |
| Nginx | Virtual host for custom domains |
| SSL | Let's Encrypt (auto) |

---

### 3. Custom Domain (Self-Hosted)

```
mystore.com
    │
    ▼
User hosts on their own VPS/server
    │
    ▼
Downloads ZIP of SolidStart store from your platform
    │
    ▼
Runs their own Node process or deploys as static files
```

| Configuration | Value |
|---------------|--------|
| Export | ZIP download of SolidStart store |
| Hosting | User's own server/VPS |
| SSL | User manages their own |

---

## Hosting Model

### Shared Server, Separate Node Processes

```
┌─────────────────────────────────────────────────────┐
│              One Physical Server                      │
│                                                     │
│  ┌──────────┐   ┌──────────┐   ┌──────────┐     │
│  │ Store 1  │   │ Store 2  │   │ Store 3  │     │
│  │ Node     │   │ Node     │   │ Node     │     │
│  │ Process  │   │ Process  │   │ Process  │     │
│  └──────────┘   └──────────┘   └──────────┘     │
│                                                     │
│  Shared: CPU, RAM, Disk, Network                  │
│                                                     │
└─────────────────────────────────────────────────────┘
```

| Aspect | Description |
|--------|-------------|
| Server | Same physical server |
| CPU | Shared across all stores |
| Memory | Each Node process ~200MB |
| Isolation | Separate processes per store |

### Node.js Process Resource Usage

| State | Memory | CPU |
|-------|--------|-----|
| **Idle** | 100-200 MB | Minimal |
| **Serving pages** | 200-400 MB | Low |
| **High traffic** | 400-800 MB | Variable |

---

## Implementation Phases

### Phase 1: Subdomain Routing

| Task | Details |
|------|---------|
| DNS | Add wildcard A record: `*.entaprenua.com` → Server IP |
| Nginx | Configure wildcard virtual host |
| SolidStart | Middleware extracts subdomain, looks up store |

### Phase 2: Custom Domain (Your Server)

| Task | Details |
|------|---------|
| DNS | User adds A/CNAME record to your server IP |
| Nginx | Virtual host for custom domains |
| SSL | Let's Encrypt auto-certificate |
| SolidStart | Domain lookup from database |

### Phase 3: Custom Domain (Self-Hosted)

| Task | Details |
|------|---------|
| Export | Generate ZIP of SolidStart store |
| Download | User downloads and hosts |
| Documentation | Instructions for self-hosting |

---

## SolidStart Configuration

```typescript
// app.config.ts
// SolidStart uses 'server' preset by default for SSR

export default defineConfig({
  server: {
    preset: 'server',  // SSR enabled by default
    host: '0.0.0.0',
    port: 3000,
  },
})
```

---

## Storefront SSR File Structure

```
src/
├── middleware.ts                    # Domain detection
├── lib/
│   └── storefront/
│       ├── domain-lookup.ts       # Lookup store by domain
│       ├── context.tsx            # Store context (per request)
│       └── api-client.ts          # Spring Boot API client
├── routes/
│   ├── index.tsx                  # Homepage
│   ├── product/
│   │   └── [id].tsx              # Product details
│   ├── cart.tsx                   # Cart
│   └── [[...slug]].tsx           # Dynamic catch-all
└── components/
    └── storefront/                 # Storefront components
```

---

## Data Flow Example

```
Request: mystore.com/products
    │
    ▼
Extract domain: "mystore.com"
    │
    ▼
GET /api/v1/stores/domain/mystore.com
    │
    ▼
Returns: { id: "store-uuid", name: "My Store", ... }
    │
    ▼
Set x-store-id header
    │
    ▼
Render routes with store context
    │
    ▼
Fetch products from Spring Boot API
    │
    ▼
Return rendered HTML
```

---

## Connection Pooling

### What is Connection Pooling?

**Connection pooling** = Reusing database connections across requests instead of creating new connections for each request.

```
Without Pooling (Slow):
Request 1 ──► Open connection ──► Close
Request 2 ──► Open connection ──► Close
Request 3 ──► Open connection ──► Close

With Pooling (Fast):
┌─────────────────────────────────────┐
│        Connection Pool               │
│  ┌─────┐ ┌─────┐ ┌─────┐          │
│  │ Con1│ │ Con2│ │ Con3│          │
│  └─────┘ └─────┘ └─────┘          │
│      ▲         ▲         ▲          │
└──────┼─────────┼─────────┼──────────┘
       │         │         │
  Request 1  Request 2  Request 3
```

### Why Faster?

| Approach | Speed | Reason |
|----------|--------|--------|
| **Without pooling** | ❌ Slow | Each request opens/closes connection (100-500ms overhead) |
| **With pooling** | ✅ Fast | Reuses existing connections (0ms overhead) |

### Disadvantages

| Disadvantage | Description |
|--------------|-------------|
| **Complex setup** | Need to configure pool size, timeouts |
| **Connection limits** | Database has max connections (e.g., PostgreSQL default 100) |
| **Memory usage** | Pool holds connections in memory |
| **Idle connections** | Wasted resources if stores are idle |
| **Harder debugging** | Connection issues harder to trace |
| **Configuration needed** | Must tune pool size for load |

### Pool Size Trade-offs

| Pool Size | Pros | Cons |
|-----------|------|------|
| **Too small** | Less memory | Requests wait for connection |
| **Too big** | More concurrent | Too much memory, DB overload |
| **Just right** | Balanced | Requires testing |

---

## Related Documentation

- [STOREFRONT_NGINX_ROUTING.md](./STOREFRONT_NGINX_ROUTING.md) - Dynamic routing architecture
- [STOREFRONT_NGINX_SETUP.md](./STOREFRONT_NGINX_SETUP.md) - Setup instructions
- [VCS_INTEGRATION.md](./VCS_INTEGRATION.md) - GitHub integration
