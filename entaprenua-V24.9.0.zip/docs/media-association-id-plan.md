# Media Association ID Implementation Plan (Option B)

## Problem
- Media deletion doesn't work because frontend sends `media.id` (file ID) but backend deletes by `product_media.id` (association ID)
- These are different IDs

## Solution
- Add `fileId` field to MediaDto
- `id` = association ID (product_media.id) - used for delete operations
- `fileId` = actual media file ID (media.id) - for display purposes
- Do mapping during enrichment (single responsibility principle)

## Files to Modify

### Backend (Kotlin)

1. **runtime/src/main/kotlin/com/entaprenua/media/dtos/MediaDto.kt**
   - Add `fileId: String?` field for actual file ID
   - `id` remains association ID (for delete operations)

2. **runtime/src/main/kotlin/com/entaprenua/media/services/MediaEnrichmentService.kt**
   - Change `enrichMediaMap()` signature to accept `Map<associationId, url>`
   - Return `List<MediaDto>` with association IDs set as `id` field
   - Extract fileId from URL or media entity

3. **runtime/src/main/kotlin/com/entaprenua/store/impl/ProductGetServiceImpl.kt**
   - Call `enrichMediaMap(product.media)` directly
   - Simpler code - mapping done in enrichment

### Frontend (TypeScript)

4. **src/lib/types/entities.ts**
   - Update `Media` interface to include `fileId`

5. **src/routes/admin/products/product-editor-context.tsx**
   - Uses `id` field for delete (now correctly association ID)
   - No changes needed - already uses `id`

6. **Test/verify**

## Implementation Order

1. Update MediaDto - add fileId field + factory methods
2. Update MediaEnrichmentService - change enrichMediaMap signature
3. Update ProductGetServiceImpl - simplify call
4. Update frontend types
5. Test delete operation
