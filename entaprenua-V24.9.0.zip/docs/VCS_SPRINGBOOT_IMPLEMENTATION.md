# VCS Integration - Spring Boot Implementation Plan

**Last Updated**: 2026-04-06  
**Status**: ✅ Implemented  
**Framework**: Spring Boot 3.2.5 (WebFlux, Kotlin)

---

## Overview

Implement Version Control System (VCS) integration for storefronts, allowing store owners to:
- Connect their own existing GitHub repositories
- Request collaboration access to their repositories
- Clone platform templates to create new stores
- Trigger automatic builds on push to main branch
- Maintain platform file integrity across builds

---

## Architecture Summary

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         GitHub Organization                               │
│                         (entaprenua)                                     │
│                                                                         │
    │  ┌─────────────────────┐    ┌─────────────────────────────┐            │
│  │ platform             │    │ basic                         │            │
│  │ (platform base)       │    │ - platform-version.json       │            │
│  │ - src/components/ui   │    │ - src/routes/                │            │
│  │ - src/lib/            │    │ - public/                     │            │
│  │ - package.json        │    │                               │            │
│  │ TAGS: v1.0.0..       │    │ TAGS: v1.0.0, v1.1.0..       │            │
│  └─────────────────────┘    └─────────────────────────────┘            │
│                                                                         │
│  ┌─────────────────────────────┐    ┌─────────────────────────────┐  │
│  │ ecommerce                   │    │ premium                      │  │
│  │ ...                         │    │ ...                          │  │
│  └─────────────────────────────┘    └─────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ Clone on purchase
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         User's Repository                                │
│                         (user/my-store)                                 │
│                                                                         │
│  - src/routes/              ← User custom code                          │
│  - src/components/stores/  ← User custom components                    │
│  - public/                 ← User assets                              │
│  - platform-version.json    ← Version tracking                         │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ Push → Webhook → Build
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         Platform Server                                  │
│                                                                         │
│  1. Read platform-version.json → "1.2.3"                              │
│  2. Clone entaprenua/platform @ v1.2.3                               │
│  3. Merge with user's src/routes/*                                     │
│  4. Build and deploy                                                   │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Repository Ownership Models

### Model A: User-Owned Repository
- User provides their existing GitHub repository URL
- User can optionally request collaboration access
- We register webhook for automatic builds

### Model B: Template Clone
- User purchases a template from the marketplace
- We clone the template repository to user's GitHub account
- Template includes `platform-version.json` for version tracking
- User pushes trigger builds with correct platform version

---

## Template Architecture

### GitHub Organization Structure

```
entaprenua (GitHub Organization)
│
├── platform                        # Platform base (private, versioned)
│   ├── src/
│   │   ├── components/ui/      # Platform UI components (PROTECTED)
│   │   ├── lib/                # Platform lib (PROTECTED)
│   │   ├── routes/             # Default routes (overwritable)
│   │   └── stores/             # Store-specific overrides
│   ├── public/                 # Default public assets
│   ├── package.json            # Platform dependencies
│   ├── app.tsx                 # App entry
│   ├── entry-client.tsx        # Client entry
│   ├── entry-server.tsx        # Server entry
│   └── TAGS: v1.0.0, v1.1.0, v1.2.0, v1.2.3  # Version tags
│
├── basic                          # Template #1 (slug-based naming)
│   ├── platform-version.json     # {"version": "1.2.3"}
│   ├── src/routes/              # Template-specific routes
│   ├── src/components/stores/   # Template components
│   ├── public/                  # Template assets
│   └── README.md                # "Based on platform v1.2.3"
│
├── ecommerce                      # Template #2
│   ├── platform-version.json     # {"version": "1.2.3"}
│   └── ...
│
└── premium                       # Template #3
    └── ...
```

### Platform Version File

Each template includes `platform-version.json`:

```json
{
  "version": "1.2.3",
  "committedAt": "2026-04-01T00:00:00Z",
  "skeletonCommit": "abc123def456"
}
```

### Template vs Store Differences

| Feature | Template | VCS-Connected Store |
|---------|----------|---------------------|
| VCS Webhook | ❌ No | ✅ Yes |
| User pushes | ❌ Not applicable | ✅ Triggers rebuild |
| platform-version.json | ✅ Required | ✅ Required |
| User routes | ✅ Template routes | ✅ User routes |
| User components | ✅ Template components | ✅ User components |

---

## Template Clone Flow

```
User purchases basic template
         ↓
1. Clone template repo from entaprenua/basic
         ↓
2. Read platform-version.json → version "1.2.3"
         ↓
3. Clone entaprenua/platform @ v1.2.3
         ↓
4. Combine:
   - platform/src/components/ui/*    (platform)
   - platform/src/lib/*              (platform)
   - platform/package.json           (platform)
   - platform/app.tsx                (platform)
   - platform/entry-*.tsx            (platform)
   - platform/src/routes/*           (template default routes)
   - template/src/routes/*           (template routes, overwrites skeleton)
   - template/src/components/stores/* (template components)
   - template/public/*               (template assets)
         ↓
5. Push combined repo to user's GitHub (e.g., user/my-store)
         ↓
6. Register webhook in user's repo
         ↓
7. Initial build and publish
         ↓
8. User can now push updates → builds trigger automatically
```

---

## Rebuild Flow (User Push)

```
User pushes to their repository
         ↓
Webhook triggers build
         ↓
1. Read platform-version.json → "1.2.3"
         ↓
2. Clone entaprenua/platform @ v1.2.3 (fresh)
         ↓
3. Clone user's repo @ HEAD
         ↓
4. Merge:
   - platform/src/components/ui/*    ← Protected (fetched)
   - platform/src/lib/*            ← Protected (fetched)
   - platform/package*.json        ← Protected (fetched)
   - user/src/routes/*             ← Trusted
   - user/src/components/*         ← Trusted (except ui/)
   - user/public/*                 ← Trusted
   - All other user files          ← Trusted
         ↓
5. Build with merged files
         ↓
6. Deploy to /var/lib/entaprenua/stores/{storeId}/
         ↓
7. Restart store process
```

**Security:** Only `src/components/ui/*`, `src/lib/*`, and `package*.json` are protected. Everything else is trusted from user's repo.

---

## Implementation Phases

### Phase 1b: Build Output Deployment

After a successful build, the `.output/` directory is deployed to:

```
/var/lib/entaprenua/stores/{storeId}/.output/
```

This is configured via `app.vcs.build.stores-path` (default: `/var/lib/entaprenua/stores`).

The build process copies the entire `.output/` directory including `node_modules` (Nitro `node-server` preset bundles server-side deps). On the same machine this is efficient; for cross-machine deploys, consider running `npm ci` after copy for a leaner deploy.

---

### Phase 1: Database Schema

**New Migration:** `src/main/resources/db/migration/V{n}__Add_vcs_tables.sql`

```sql
-- VCS Connections (1:1 with stores)
CREATE TABLE vcs_connections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id UUID NOT NULL UNIQUE REFERENCES stores(id) ON DELETE CASCADE,
    
    -- Provider
    provider VARCHAR(20) NOT NULL DEFAULT 'github',
    
    -- Repository
    repository_id VARCHAR(100),
    repository_name VARCHAR(255),
    repository_url VARCHAR(500),
    repository_owner VARCHAR(255),
    branch VARCHAR(100) DEFAULT 'main',
    
    -- Webhook
    webhook_id VARCHAR(100),
    webhook_secret_encrypted VARCHAR(500),  -- AES-256-GCM encrypted
    
    -- Ownership Model
    is_platform_owned BOOLEAN DEFAULT false,
    
    -- Collaboration (for user-owned repos)
    collaboration_status VARCHAR(20) DEFAULT 'not_applicable',
    -- Enum: 'owner', 'collaborator', 'pending', 'not_applicable'
    collaboration_invited_at TIMESTAMPTZ,
    collaboration_accepted_at TIMESTAMPTZ,
    
    -- Build Status
    last_deploy_commit VARCHAR(100),
    last_deploy_time TIMESTAMPTZ,
    build_status VARCHAR(20) DEFAULT 'idle',
    -- Enum: 'idle', 'building', 'success', 'failed'
    
    -- Ownership
    owner_username VARCHAR(255),
    owner_email VARCHAR(255),
    
    -- Audit
    version INT DEFAULT 1,
    inserted_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- VCS Builds (1:many with vcs_connections)
CREATE TABLE vcs_builds (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vcs_connection_id UUID NOT NULL REFERENCES vcs_connections(id) ON DELETE CASCADE,
    
    build_number INT NOT NULL,
    commit_sha VARCHAR(100),
    commit_message TEXT,
    commit_author VARCHAR(255),
    branch VARCHAR(100) DEFAULT 'main',
    
    -- Status
    status VARCHAR(20) DEFAULT 'pending',
    -- Enum: 'pending', 'building', 'success', 'failed'
    started_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    duration_ms BIGINT,
    
    -- Error/Logs
    error_message TEXT,
    logs TEXT,
    
    -- Audit
    version INT DEFAULT 1,
    inserted_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_vcs_builds_connection ON vcs_builds(vcs_connection_id);
CREATE INDEX idx_vcs_builds_status ON vcs_builds(status);
CREATE INDEX idx_vcs_builds_started_at ON vcs_builds(started_at DESC);
```

### Phase 1b: Encryption Key Table

For managing encryption keys securely:

```sql
-- Encryption keys (for webhook secrets)
CREATE TABLE encryption_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key_name VARCHAR(100) NOT NULL UNIQUE,
    key_version INT NOT NULL DEFAULT 1,
    encrypted_key BYTEA NOT NULL,  -- Master key encrypted with passphrase
    algorithm VARCHAR(50) NOT NULL DEFAULT 'AES-256-GCM',
    is_active BOOLEAN DEFAULT true,
    inserted_at TIMESTAMPTZ DEFAULT NOW()
);

-- VCS uses 'vcs_webhook_secret' key
-- Master passphrase stored in environment variable
```

---

### Phase 2: Domain Layer

**New Package:** `com.entaprenua.vcs`

```
src/main/kotlin/com/entaprenua/vcs/
├── Application.kt
├── entities/
│   ├── VcsConnection.kt
│   ├── VcsBuild.kt
│   └── CollaborationStatus.kt          # Enum
├── dtos/
│   ├── VcsConnectionDto.kt
│   ├── VcsBuildDto.kt
│   ├── ConnectVcsRequest.kt
│   ├── RequestCollaborationRequest.kt
│   └── RedeployRequest.kt
├── errors/
│   └── VcsError.kt
├── repositories/
│   ├── VcsConnectionRepository.kt
│   └── VcsBuildRepository.kt
├── services/
│   ├── VcsService.kt
│   ├── VcsGetService.kt
│   ├── VcsSaveService.kt
│   ├── GitHubApiService.kt
│   └── EncryptionService.kt             # Webhook secret encryption
└── impl/
    ├── VcsServiceImpl.kt
    ├── VcsGetServiceImpl.kt
    ├── VcsSaveServiceImpl.kt
    ├── GitHubApiServiceImpl.kt
    └── EncryptionServiceImpl.kt
```

#### Enum: CollaborationStatus

```kotlin
enum class CollaborationStatus {
    OWNER,           // User owns the repository
    COLLABORATOR,    // User has accepted collaboration invite
    PENDING,         // Invite sent, awaiting acceptance
    NOT_APPLICABLE   // Platform-owned repo (no collaboration needed)
}
```

#### Entity: VcsConnection

```kotlin
@Serializable
data class VcsConnection(
    @Serializable(with = UuidSerializer::class)
    val id: UUID? = null,
    @Serializable(with = UuidSerializer::class)
    val storeId: UUID,
    
    // Provider
    val provider: String = "github",
    
    // Repository
    val repositoryId: String? = null,
    val repositoryName: String? = null,
    val repositoryUrl: String? = null,
    val repositoryOwner: String? = null,
    val branch: String = "main",
    
    // Webhook
    val webhookId: String? = null,
    val webhookSecretEncrypted: String? = null,  // AES-256-GCM encrypted
    
    // Ownership Model
    val isPlatformOwned: Boolean = false,
    
    // Collaboration
    val collaborationStatus: CollaborationStatus = CollaborationStatus.NOT_APPLICABLE,
    val collaborationInvitedAt: OffsetDateTime? = null,
    val collaborationAcceptedAt: OffsetDateTime? = null,
    
    // Build Status
    val lastDeployCommit: String? = null,
    val lastDeployTime: OffsetDateTime? = null,
    val buildStatus: String = "idle",  // idle, building, success, failed
    
    // Owner Info
    val ownerUsername: String? = null,
    val ownerEmail: String? = null,
    
    // Audit
    val version: Int = 1,
    @Serializable(with = OffsetDateTimeSerializer::class)
    val insertedAt: OffsetDateTime? = null,
    @Serializable(with = OffsetDateTimeSerializer::class)
    val updatedAt: OffsetDateTime? = null,
) {
    fun incrementVersion(): VcsConnection = copy(version = version + 1)
    
    fun markCollaborationPending(): VcsConnection = copy(
        collaborationStatus = CollaborationStatus.PENDING,
        collaborationInvitedAt = OffsetDateTime.now()
    )
    
    fun markCollaborationAccepted(): VcsConnection = copy(
        collaborationStatus = CollaborationStatus.COLLABORATOR,
        collaborationAcceptedAt = OffsetDateTime.now()
    )
    
    fun markAsOwner(): VcsConnection = copy(
        collaborationStatus = CollaborationStatus.OWNER
    )
}
```

#### Entity: VcsBuild

```kotlin
@Serializable
data class VcsBuild(
    @Serializable(with = UuidSerializer::class)
    val id: UUID? = null,
    @Serializable(with = UuidSerializer::class)
    val vcsConnectionId: UUID,
    val buildNumber: Int,
    val commitSha: String? = null,
    val commitMessage: String? = null,
    val commitAuthor: String? = null,
    val branch: String = "main",
    val status: String = "pending",
    @Serializable(with = OffsetDateTimeSerializer::class)
    val startedAt: OffsetDateTime? = null,
    @Serializable(with = OffsetDateTimeSerializer::class)
    val completedAt: OffsetDateTime? = null,
    val durationMs: Long? = null,
    val errorMessage: String? = null,
    val logs: String? = null,
    val version: Int = 1,
    @Serializable(with = OffsetDateTimeSerializer::class)
    val insertedAt: OffsetDateTime? = null,
    @Serializable(with = OffsetDateTimeSerializer::class)
    val updatedAt: OffsetDateTime? = null,
) {
    fun markSuccess(durationMs: Long): VcsBuild = copy(
        status = "success",
        completedAt = OffsetDateTime.now(),
        durationMs = durationMs
    )
    
    fun markFailed(error: String): VcsBuild = copy(
        status = "failed",
        completedAt = OffsetDateTime.now(),
        errorMessage = error
    )
}
```

#### DTOs

```kotlin
@Serializable
data class VcsConnectionDto(
    val id: String,
    val provider: String,
    val repositoryName: String?,
    val repositoryUrl: String?,
    val branch: String,
    val isPlatformOwned: Boolean,
    val collaborationStatus: String?,
    val lastDeployCommit: String?,
    val lastDeployTime: String?,
    val buildStatus: String,
    val buildHistory: List<VcsBuildDto>?
)

@Serializable
data class VcsBuildDto(
    val id: String,
    val buildNumber: Int,
    val commitSha: String?,
    val commitMessage: String?,
    val commitAuthor: String?,
    val branch: String,
    val status: String,
    val startedAt: String?,
    val completedAt: String?,
    val durationMs: Long?,
    val errorMessage: String?
)

@Serializable
data class ConnectVcsRequest(
    val repositoryUrl: String?,
    val branch: String? = "main",
    val createPlatformOwned: Boolean = false,
    val ownerEmail: String? = null,
    val ownerUsername: String? = null
)

@Serializable
data class RequestCollaborationRequest(
    val ownerUsername: String? = null,
    val ownerEmail: String? = null,
    val permission: String = "push"
)

@Serializable
data class RedeployRequest(
    val branch: String? = null
)
```

#### Errors

```kotlin
sealed class VcsError {
    abstract val code: String
    abstract val message: String
    
    data class NotFoundError(val storeId: String) : VcsError() {
        override val code = "VCS_NOT_FOUND"
        override val message = "VCS connection not found for store: $storeId"
    }
    
    data class RepositoryNotFoundError(val url: String) : VcsError() {
        override val code = "REPOSITORY_NOT_FOUND"
        override val message = "Repository not found: $url"
    }
    
    data class GitHubApiError(val statusCode: Int, val message: String) : VcsError() {
        override val code = "GITHUB_API_ERROR"
        override val message = "GitHub API error: $message"
    }
    
    data class CollaborationRequestFailed(val reason: String) : VcsError() {
        override val code = "COLLABORATION_FAILED"
        override val message = "Failed to request collaboration: $reason"
    }
    
    data class BuildInProgressError(val storeId: String) : VcsError() {
        override val code = "BUILD_IN_PROGRESS"
        override val message = "A build is already in progress for store: $storeId"
    }
}
```

---

### Phase 3: Repository Layer

#### VcsConnectionRepository

```kotlin
@Repository
class VcsConnectionRepository(private val dsl: DSLContext) {
    
    private val table = VcsConnections.VCS_CONNECTIONS
    
    suspend fun findByStoreId(storeId: UUID): VcsConnection? {
        return Flux.from(
            dsl.selectFrom(table)
                .where(table.STORE_ID.eq(storeId))
        ).awaitFirstOrNull()?.mapToConnection()
    }
    
    suspend fun save(connection: VcsConnection): VcsConnection {
        val now = OffsetDateTime.now()
        val id = connection.id ?: UUID.randomUUID()
        
        return dsl.insertInto(table)
            .set(table.ID, id)
            .set(table.STORE_ID, connection.storeId)
            .set(table.PROVIDER, connection.provider)
            .set(table.REPOSITORY_ID, connection.repositoryId)
            .set(table.REPOSITORY_NAME, connection.repositoryName)
            .set(table.REPOSITORY_URL, connection.repositoryUrl)
            .set(table.REPOSITORY_OWNER, connection.repositoryOwner)
            .set(table.OWNER_USERNAME, connection.ownerUsername)
            .set(table.OWNER_EMAIL, connection.ownerEmail)
            .set(table.BRANCH, connection.branch)
            .set(table.WEBHOOK_ID, connection.webhookId)
            .set(table.WEBHOOK_SECRET, connection.webhookSecret)
            .set(table.IS_PLATFORM_OWNED, connection.isPlatformOwned)
            .set(table.IS_COLLABORATION_REQUESTED, connection.isCollaborationRequested)
            .set(table.COLLABORATION_STATUS, connection.collaborationStatus)
            .set(table.BUILD_STATUS, connection.buildStatus)
            .set(table.VERSION, connection.version)
            .set(table.UPDATED_AT, now)
            .onConflict(table.STORE_ID)
            .doUpdate()
            .set(table.REPOSITORY_ID, connection.repositoryId)
            .set(table.REPOSITORY_NAME, connection.repositoryName)
            .set(table.REPOSITORY_URL, connection.repositoryUrl)
            .set(table.BRANCH, connection.branch)
            .set(table.WEBHOOK_ID, connection.webhookId)
            .set(table.WEBHOOK_SECRET, connection.webhookSecret)
            .set(table.COLLABORATION_STATUS, connection.collaborationStatus)
            .set(table.BUILD_STATUS, connection.buildStatus)
            .set(table.VERSION, table.VERSION + 1)
            .set(table.UPDATED_AT, now)
            .returning()
            .awaitFirst()
            .mapToConnection()
    }
    
    suspend fun deleteByStoreId(storeId: UUID): Boolean {
        return dsl.deleteFrom(table)
            .where(table.STORE_ID.eq(storeId))
            .await() > 0
    }
    
    suspend fun updateBuildStatus(storeId: UUID, status: String, commit: String? = null): VcsConnection? {
        return dsl.update(table)
            .set(table.BUILD_STATUS, status)
            .set(table.LAST_DEPLOY_COMMIT, commit)
            .set(table.LAST_DEPLOY_TIME, OffsetDateTime.now())
            .set(table.UPDATED_AT, OffsetDateTime.now())
            .where(table.STORE_ID.eq(storeId))
            .returning()
            .awaitFirstOrNull()
            ?.mapToConnection()
    }
    
    private fun Record.mapToConnection(): VcsConnection = VcsConnection(
        id = this[table.ID],
        storeId = this[table.STORE_ID]!!,
        provider = this[table.PROVIDER] ?: "github",
        repositoryId = this[table.REPOSITORY_ID],
        repositoryName = this[table.REPOSITORY_NAME],
        repositoryUrl = this[table.REPOSITORY_URL],
        repositoryOwner = this[table.REPOSITORY_OWNER],
        ownerUsername = this[table.OWNER_USERNAME],
        ownerEmail = this[table.OWNER_EMAIL],
        branch = this[table.BRANCH] ?: "main",
        webhookId = this[table.WEBHOOK_ID],
        webhookSecret = this[table.WEBHOOK_SECRET],
        isPlatformOwned = this[table.IS_PLATFORM_OWNED] ?: false,
        isCollaborationRequested = this[table.IS_COLLABORATION_REQUESTED] ?: false,
        collaborationStatus = this[table.COLLABORATION_STATUS],
        lastDeployCommit = this[table.LAST_DEPLOY_COMMIT],
        lastDeployTime = this[table.LAST_DEPLOY_TIME],
        buildStatus = this[table.BUILD_STATUS] ?: "idle",
        version = this[table.VERSION] ?: 1,
        insertedAt = this[table.INSERTED_AT],
        updatedAt = this[table.UPDATED_AT],
    )
}
```

#### VcsBuildRepository

```kotlin
@Repository
class VcsBuildRepository(private val dsl: DSLContext) {
    
    private val table = VcsBuilds.VCS_BUILDS
    
    fun findByConnectionId(connectionId: UUID, limit: Int = 20): Flow<VcsBuild> {
        return dsl.selectFrom(table)
            .where(table.VCS_CONNECTION_ID.eq(connectionId))
            .orderBy(table.BUILD_NUMBER.desc())
            .limit(limit)
            .asFlow()
            .map { it.mapToBuild() }
    }
    
    suspend fun findLatestByConnectionId(connectionId: UUID): VcsBuild? {
        return Flux.from(
            dsl.selectFrom(table)
                .where(table.VCS_CONNECTION_ID.eq(connectionId))
                .orderBy(table.BUILD_NUMBER.desc())
                .limit(1)
        ).awaitFirstOrNull()?.mapToBuild()
    }
    
    suspend fun getNextBuildNumber(connectionId: UUID): Int {
        val latest = findLatestByConnectionId(connectionId)
        return (latest?.buildNumber ?: 0) + 1
    }
    
    suspend fun save(build: VcsBuild): VcsBuild {
        val now = OffsetDateTime.now()
        val id = build.id ?: UUID.randomUUID()
        
        return dsl.insertInto(table)
            .set(table.ID, id)
            .set(table.VCS_CONNECTION_ID, build.vcsConnectionId)
            .set(table.BUILD_NUMBER, build.buildNumber)
            .set(table.COMMIT_SHA, build.commitSha)
            .set(table.COMMIT_MESSAGE, build.commitMessage)
            .set(table.COMMIT_AUTHOR, build.commitAuthor)
            .set(table.BRANCH, build.branch)
            .set(table.STATUS, build.status)
            .set(table.STARTED_AT, now)
            .set(table.VERSION, build.version)
            .returning()
            .awaitFirst()
            .mapToBuild()
    }
    
    suspend fun update(build: VcsBuild): VcsBuild {
        return dsl.update(table)
            .set(table.STATUS, build.status)
            .set(table.COMPLETED_AT, build.completedAt)
            .set(table.DURATION_MS, build.durationMs)
            .set(table.ERROR_MESSAGE, build.errorMessage)
            .set(table.LOGS, build.logs)
            .set(table.VERSION, table.VERSION + 1)
            .set(table.UPDATED_AT, OffsetDateTime.now())
            .where(table.ID.eq(build.id))
            .returning()
            .awaitFirst()
            .mapToBuild()
    }
    
    private fun Record.mapToBuild(): VcsBuild = VcsBuild(
        id = this[table.ID],
        vcsConnectionId = this[table.VCS_CONNECTION_ID]!!,
        buildNumber = this[table.BUILD_NUMBER]!!,
        commitSha = this[table.COMMIT_SHA],
        commitMessage = this[table.COMMIT_MESSAGE],
        commitAuthor = this[table.COMMIT_AUTHOR],
        branch = this[table.BRANCH] ?: "main",
        status = this[table.STATUS] ?: "pending",
        startedAt = this[table.STARTED_AT],
        completedAt = this[table.COMPLETED_AT],
        durationMs = this[table.DURATION_MS],
        errorMessage = this[table.ERROR_MESSAGE],
        logs = this[table.LOGS],
        version = this[table.VERSION] ?: 1,
        insertedAt = this[table.INSERTED_AT],
        updatedAt = this[table.UPDATED_AT],
    )
}
```

---

### Phase 4: Encryption Service

For securing webhook secrets at rest using AES-256-GCM encryption.

```kotlin
@Service
class EncryptionService(
    @Value("\${app.vcs.encryption.master-key}") private val masterKey: String
) {
    companion object {
        private const val ALGORITHM = "AES/GCM/NoPadding"
        private const val KEY_SIZE = 256
        private const val TAG_LENGTH = 128
        private const val IV_LENGTH = 12
    }
    
    private val keySpec: SecretKeySpec = SecretKeySpec(
        Base64.getDecoder().decode(masterKey),
        "AES"
    )
    
    /**
     * Encrypt plaintext using AES-256-GCM.
     * Returns Base64-encoded string: IV + ciphertext + auth tag
     */
    fun encrypt(plaintext: String): String {
        val cipher = Cipher.getInstance(ALGORITHM)
        val iv = ByteArray(IV_LENGTH).also { SecureRandom().nextBytes(it) }
        
        val gcmParameterSpec = GCMParameterSpec(TAG_LENGTH, iv)
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, gcmParameterSpec)
        
        val ciphertext = cipher.doFinal(plaintext.toByteArray(StandardCharsets.UTF_8))
        
        // Combine IV + ciphertext (includes auth tag)
        val combined = ByteArray(iv.size + ciphertext.size)
        System.arraycopy(iv, 0, combined, 0, iv.size)
        System.arraycopy(ciphertext, 0, combined, iv.size, ciphertext.size)
        
        return Base64.getEncoder().encodeToString(combined)
    }
    
    /**
     * Decrypt ciphertext encrypted with encrypt().
     */
    fun decrypt(encrypted: String): String {
        val combined = Base64.getDecoder().decode(encrypted)
        
        // Extract IV and ciphertext
        val iv = combined.copyOfRange(0, IV_LENGTH)
        val ciphertext = combined.copyOfRange(IV_LENGTH, combined.size)
        
        val cipher = Cipher.getInstance(ALGORITHM)
        val gcmParameterSpec = GCMParameterSpec(TAG_LENGTH, iv)
        cipher.init(Cipher.DECRYPT_MODE, keySpec, gcmParameterSpec)
        
        val plaintext = cipher.doFinal(ciphertext)
        return String(plaintext, StandardCharsets.UTF_8)
    }
}
```

**Usage in VcsConnectionRepository:**

```kotlin
class VcsConnectionRepository(
    private val dsl: DSLContext,
    private val encryptionService: EncryptionService
) {
    // When saving - encrypt the webhook secret
    suspend fun save(connection: VcsConnection): VcsConnection {
        val webhookSecret = connection.webhookSecretPlaintext
        val encryptedSecret = webhookSecret?.let { encryptionService.encrypt(it) }
        
        // ... save with encryptedSecret
    }
    
    // When reading - decrypt the webhook secret
    fun mapToConnection(record: Record): VcsConnection {
        val encryptedSecret = record[table.WEBHOOK_SECRET_ENCRYPTED]
        val decryptedSecret = encryptedSecret?.let { encryptionService.decrypt(it) }
        
        return VcsConnection(
            // ...
            webhookSecretEncrypted = encryptedSecret,
            webhookSecretPlaintext = decryptedSecret  // Not stored, just for runtime use
        )
    }
}
```

**Configuration:**

```properties
# Master encryption key (Base64-encoded 32-byte key)
# Generate with: openssl rand -base64 32
app.vcs.encryption.master-key=${VCS_ENCRYPTION_MASTER_KEY:}
```

---

### Phase 5: GitHub API Client

**Service Interface:** `GitHubApiService`

```kotlin
@Service
interface GitHubApiService {
    
    data class Repository(
        val id: Long,
        val name: String,
        val fullName: String,
        val cloneUrl: String,
        val htmlUrl: String,
        val owner: String
    )
    
    data class PlatformVersion(
        val version: String,
        val committedAt: String,
        val skeletonCommit: String
    )
    
    suspend fun createPlatformRepository(
        storeId: String,
        storeName: String,
        description: String
    ): Repository
    
    suspend fun addCollaborator(
        owner: String,
        repo: String,
        username: String,
        permission: String = "push"
    ): Boolean
    
    suspend fun inviteByEmail(
        owner: String,
        repo: String,
        email: String,
        permission: String = "push"
    ): Boolean
    
    suspend fun registerWebhook(
        owner: String,
        repo: String,
        webhookUrl: String,
        secret: String
    ): String  // Returns webhook ID
    
    suspend fun deleteWebhook(
        owner: String,
        repo: String,
        webhookId: String
    ): Boolean
    
    // Template cloning methods
    suspend fun getTemplatePlatformVersion(templateOwner: String, templateRepo: String): PlatformVersion
    
    suspend fun cloneTemplateToUserRepo(
        templateOwner: String,
        templateRepo: String,
        targetOwner: String,
        targetRepo: String,
        platformVersion: PlatformVersion
    ): Repository
    
    suspend fun forkRepository(
        owner: String,
        repo: String,
        targetOwner: String
    ): Repository
    
    suspend fun getFileContent(owner: String, repo: String, path: String, ref: String? = null): String?
    
    suspend fun getTagCommit(owner: String, repo: String, tag: String): String?
    
    suspend fun deleteRepository(owner: String, repo: String): Boolean
    
    suspend fun getRepository(owner: String, repo: String): Repository?
    
    suspend fun isValidRepository(url: String): Boolean
    
    fun parseRepositoryUrl(url: String): Pair<String, String>?  // Returns (owner, repo)
}
```

**Implementation:** `GitHubApiServiceImpl`

```kotlin
@Service
class GitHubApiServiceImpl(
    @Value("\${app.vcs.github.org}") private val githubOrg: String,
    @Value("\${app.vcs.github.pat-token}") private val githubToken: String,
    @Value("\${app.vcs.webhook.base-url}") private val webhookBaseUrl: String,
    private val httpClient: HttpClient
) : GitHubApiService {
    
    private val baseUrl = "https://api.github.com"
    
    private fun headers() = Headers.of(
        HttpHeaders.AUTHORIZATION, "Bearer $githubToken",
        HttpHeaders.ACCEPT, "application/vnd.github+json",
        HttpHeaders.CONTENT_TYPE, "application/json",
        "X-GitHub-Api-Version", "2022-11-28"
    )
    
    override suspend fun createPlatformRepository(
        storeId: String,
        storeName: String,
        description: String
    ): Repository {
        val repoName = generateRepoName(storeId, storeName)
        
        val response = httpClient.post("$baseUrl/orgs/$githubOrg/repos") {
            header(headers().entries.joinToString("") { "${it.key}: ${it.value}" })
            body = """
                {
                    "name": "$repoName",
                    "description": "$description",
                    "private": true,
                    "auto_init": true,
                    "gitignore_template": "Node"
                }
            """.trimIndent()
        }
        
        if (!response.status().isSuccess) {
            throw VcsError.GitHubApiError(response.status().code(), "Failed to create repository")
        }
        
        val json = response.bodyAsText()
        val node = Json.decodeFromString<JsonNode>(json)
        
        return Repository(
            id = node["id"].asLong(),
            name = node["name"].asText(),
            fullName = node["full_name"].asText(),
            cloneUrl = node["clone_url"].asText(),
            htmlUrl = node["html_url"].asText(),
            owner = node["owner"]["login"].asText()
        )
    }
    
    override suspend fun addCollaborator(
        owner: String,
        repo: String,
        username: String,
        permission: String
    ): Boolean {
        val response = httpClient.put("$baseUrl/repos/$owner/$repo/collaborators/$username") {
            header(headers().entries.joinToString("") { "${it.key}: ${it.value}" })
            body = """{"permission": "$permission"}"""
        }
        
        return response.status().code() in 200..299
    }
    
    override suspend fun inviteByEmail(
        owner: String,
        repo: String,
        email: String,
        permission: String
    ): Boolean {
        // GitHub API accepts email in username field for invites
        return addCollaborator(owner, repo, email, permission)
    }
    
    override suspend fun registerWebhook(
        owner: String,
        repo: String,
        webhookUrl: String,
        secret: String
    ): String {
        val response = httpClient.post("$baseUrl/repos/$owner/$repo/hooks") {
            header(headers().entries.joinToString("") { "${it.key}: ${it.value}" })
            body = """
                {
                    "name": "web",
                    "active": true,
                    "events": ["push"],
                    "config": {
                        "url": "$webhookBaseUrl/webhooks/github",
                        "content_type": "json",
                        "secret": "$secret"
                    }
                }
            """.trimIndent()
        }
        
        if (!response.status().isSuccess) {
            throw VcsError.GitHubApiError(response.status().code(), "Failed to register webhook")
        }
        
        val node = Json.decodeFromString<JsonNode>(response.bodyAsText())
        return node["id"].asText()
    }
    
    override suspend fun deleteWebhook(
        owner: String,
        repo: String,
        webhookId: String
    ): Boolean {
        val response = httpClient.delete("$baseUrl/repos/$owner/$repo/hooks/$webhookId") {
            header(headers().entries.joinToString("") { "${it.key}: ${it.value}" })
        }
        
        return response.status().code() in 200..299
    }
    
    override suspend fun deleteRepository(owner: String, repo: String): Boolean {
        val response = httpClient.delete("$baseUrl/repos/$owner/$repo") {
            header(headers().entries.joinToString("") { "${it.key}: ${it.value}" })
        }
        
        return response.status().code() in 200..299
    }
    
    override suspend fun getRepository(owner: String, repo: String): Repository? {
        val response = httpClient.get("$baseUrl/repos/$owner/$repo") {
            header(headers().entries.joinToString("") { "${it.key}: ${it.value}" })
        }
        
        return if (response.status().isSuccess) {
            val node = Json.decodeFromString<JsonNode>(response.bodyAsText())
            Repository(
                id = node["id"].asLong(),
                name = node["name"].asText(),
                fullName = node["full_name"].asText(),
                cloneUrl = node["clone_url"].asText(),
                htmlUrl = node["html_url"].asText(),
                owner = node["owner"]["login"].asText()
            )
        } else null
    }
    
    override suspend fun isValidRepository(url: String): Boolean {
        val parsed = parseRepositoryUrl(url) ?: return false
        return getRepository(parsed.first, parsed.second) != null
    }
    
    override fun parseRepositoryUrl(url: String): Pair<String, String>? {
        // Handles:
        // - https://github.com/owner/repo
        // - https://github.com/owner/repo.git
        // - git@github.com:owner/repo.git
        val pattern = """(?:github\.com[:/]|)([\w-]+)/([\w.-]+?)(?:\.git)?$""".toRegex()
        return pattern.find(url)?.let { Pair(it.groupValues[1], it.groupValues[2]) }
    }
    
    private fun generateRepoName(storeId: String, storeName: String): String {
        val slug = storeName.lowercase()
            .replace(Regex("[^a-z0-9\\s]"), "")
            .replace(Regex("\\s+"), "-")
            .take(50)
        val shortId = storeId.take(8)
        return "store-$shortId-$slug"
    }
}
```

---

### Phase 5: VCS Service Layer

#### VcsService Interface

```kotlin
@Service
interface VcsService {
    suspend fun connectStore(storeId: UUID, request: ConnectVcsRequest): VcsConnection
    suspend fun disconnectStore(storeId: UUID): Boolean
    suspend fun requestCollaboration(storeId: UUID, request: RequestCollaborationRequest): VcsConnection
    suspend fun redeploy(storeId: UUID, request: RedeployRequest?): VcsBuild
    suspend fun getConnection(storeId: UUID): VcsConnection?
    suspend fun getBuildHistory(storeId: UUID, limit: Int = 20): List<VcsBuild>
    suspend fun triggerBuildFromWebhook(payload: WebhookPayload): Boolean
}

data class WebhookPayload(
    val repositoryId: String,
    val repositoryUrl: String,
    val ref: String,
    val commitSha: String,
    val commitMessage: String?,
    val commitAuthor: String?,
    val branch: String
)
```

#### VcsSaveService Implementation

```kotlin
@Service
class VcsSaveServiceImpl(
    private val vcsConnectionRepository: VcsConnectionRepository,
    private val vcsBuildRepository: VcsBuildRepository,
    private val githubApiService: GitHubApiService,
    private val storeRepository: StoreRepository,
    private val buildQueueService: BuildQueueService,
    private val log: EnterpriseLogger = logger(VcsSaveServiceImpl::class.java.name)
) : VcsSaveService {
    
    override suspend fun connectStore(storeId: UUID, request: ConnectVcsRequest): VcsConnection {
        val store = storeRepository.findById(storeId) 
            ?: throw StoreError.NotFoundError("Store", storeId)
        
        val webhookSecret = generateWebhookSecret()
        
        return when {
            // Model A: Platform-owned repository
            request.createPlatformOwned || request.repositoryUrl == null -> {
                createPlatformOwnedRepository(storeId, store.name, request, webhookSecret)
            }
            
            // Model B: User-owned repository
            else -> {
                connectUserRepository(storeId, request, webhookSecret)
            }
        }.also { connection ->
            log.businessEvent("VCS_CONNECTED", mapOf(
                "storeId" to storeId.toString(),
                "repositoryName" to (connection.repositoryName ?: "unknown"),
                "isPlatformOwned" to connection.isPlatformOwned
            ))
        }
    }
    
    private suspend fun createPlatformOwnedRepository(
        storeId: UUID,
        storeName: String,
        request: ConnectVcsRequest,
        webhookSecret: String
    ): VcsConnection {
        // 1. Create repository under platform org
        val repo = githubApiService.createPlatformRepository(
            storeId = storeId.toString(),
            storeName = storeName,
            description = "$storeName - Powered by Entaprenua"
        )
        
        // 2. Register webhook
        val webhookId = githubApiService.registerWebhook(
            owner = githubApiService.githubOrg,
            repo = repo.name,
            webhookUrl = "${webhookBaseUrl}/webhooks/github",
            secret = webhookSecret
        )
        
        // 3. Add collaborator (email or username)
        val collaborator = request.ownerEmail ?: request.ownerUsername
        if (collaborator != null) {
            val isEmail = collaborator.contains("@")
            if (isEmail) {
                githubApiService.inviteByEmail(githubApiService.githubOrg, repo.name, collaborator)
            } else {
                githubApiService.addCollaborator(githubApiService.githubOrg, repo.name, collaborator)
            }
        }
        
        // 4. Save connection
        return vcsConnectionRepository.save(VcsConnection(
            storeId = storeId,
            provider = "github",
            repositoryId = repo.id.toString(),
            repositoryName = repo.name,
            repositoryUrl = repo.htmlUrl,
            repositoryOwner = githubApiService.githubOrg,
            ownerUsername = request.ownerUsername,
            ownerEmail = request.ownerEmail,
            branch = request.branch ?: "main",
            webhookId = webhookId,
            webhookSecret = webhookSecret,
            isPlatformOwned = true
        ))
    }
    
    private suspend fun connectUserRepository(
        storeId: UUID,
        request: ConnectVcsRequest,
        webhookSecret: String
    ): VcsConnection {
        val (owner, repo) = githubApiService.parseRepositoryUrl(request.repositoryUrl!!)
            ?: throw VcsError.RepositoryNotFoundError(request.repositoryUrl)
        
        // Validate repository exists
        val repository = githubApiService.getRepository(owner, repo)
            ?: throw VcsError.RepositoryNotFoundError(request.repositoryUrl)
        
        // Register webhook
        val webhookId = githubApiService.registerWebhook(
            owner = owner,
            repo = repo,
            webhookUrl = "${webhookBaseUrl}/webhooks/github",
            secret = webhookSecret
        )
        
        // Save connection
        return vcsConnectionRepository.save(VcsConnection(
            storeId = storeId,
            provider = "github",
            repositoryId = repository.id.toString(),
            repositoryName = repository.name,
            repositoryUrl = repository.htmlUrl,
            repositoryOwner = owner,
            branch = request.branch ?: "main",
            webhookId = webhookId,
            webhookSecret = webhookSecret,
            isPlatformOwned = false,
            isCollaborationRequested = false,
            collaborationStatus = "not_requested"
        ))
    }
    
    override suspend fun disconnectStore(storeId: UUID): Boolean {
        val connection = vcsConnectionRepository.findByStoreId(storeId)
            ?: return false
        
        // Remove webhook
        if (connection.webhookId != null && connection.repositoryOwner != null && connection.repositoryName != null) {
            try {
                githubApiService.deleteWebhook(
                    connection.repositoryOwner,
                    connection.repositoryName,
                    connection.webhookId
                )
            } catch (e: Exception) {
                log.warn("Failed to delete webhook", e)
            }
        }
        
        // Delete platform-owned repository
        if (connection.isPlatformOwned && connection.repositoryOwner != null && connection.repositoryName != null) {
            try {
                githubApiService.deleteRepository(
                    connection.repositoryOwner,
                    connection.repositoryName
                )
            } catch (e: Exception) {
                log.warn("Failed to delete repository", e)
            }
        }
        
        return vcsConnectionRepository.deleteByStoreId(storeId)
    }
    
    override suspend fun requestCollaboration(storeId: UUID, request: RequestCollaborationRequest): VcsConnection {
        val connection = vcsConnectionRepository.findByStoreId(storeId)
            ?: throw VcsError.NotFoundError(storeId.toString())
        
        if (connection.isPlatformOwned) {
            throw VcsError.CollaborationRequestFailed("Platform-owned repositories don't need collaboration")
        }
        
        val collaborator = request.ownerEmail ?: request.ownerUsername
            ?: throw VcsError.CollaborationRequestFailed("Email or username required")
        
        val success = if (collaborator.contains("@")) {
            githubApiService.inviteByEmail(
                connection.repositoryOwner!!,
                connection.repositoryName!!,
                collaborator
            )
        } else {
            githubApiService.addCollaborator(
                connection.repositoryOwner!!,
                connection.repositoryName!!,
                collaborator,
                request.permission
            )
        }
        
        if (!success) {
            throw VcsError.CollaborationRequestFailed("GitHub API rejected the request")
        }
        
        return vcsConnectionRepository.save(connection.copy(
            isCollaborationRequested = true,
            collaborationStatus = "pending",
            ownerUsername = request.ownerUsername ?: connection.ownerUsername,
            ownerEmail = request.ownerEmail ?: connection.ownerEmail
        ))
    }
    
    override suspend fun redeploy(storeId: UUID, request: RedeployRequest?): VcsBuild {
        val connection = vcsConnectionRepository.findByStoreId(storeId)
            ?: throw VcsError.NotFoundError(storeId.toString())
        
        if (connection.buildStatus == "building") {
            throw VcsError.BuildInProgressError(storeId.toString())
        }
        
        // Update status
        vcsConnectionRepository.updateBuildStatus(storeId, "building")
        
        // Create build record
        val buildNumber = vcsBuildRepository.getNextBuildNumber(connection.id!!)
        val build = vcsBuildRepository.save(VcsBuild(
            vcsConnectionId = connection.id,
            buildNumber = buildNumber,
            branch = request?.branch ?: connection.branch,
            status = "pending"
        ))
        
        // Queue build
        buildQueueService.queueBuild(connection, build)
        
        return build
    }
    
    private fun generateWebhookSecret(): String {
        return UUID.randomUUID().toString().replace("-", "")
    }
}
```

---

### Phase 6: Build Pipeline

#### Build Directory Structure

```
/var/lib/entaprenua/
├── skeleton/                    # Platform-provided template (READ-ONLY for platform files)
│   ├── src/
│   │   ├── components/          # Platform components (NOT overwritten)
│   │   ├── lib/                # Platform lib (NOT overwritten)
│   │   ├── routes/             # User routes (overwritten by VCS)
│   │   └── ...
│   ├── node_modules/            # Platform dependencies (NOT overwritten)
│   ├── package.json
│   ├── app.config.ts
│   ├── .output/                 # Build output
│   └── ...
├── stores/                      # Deployed storefronts
│   └── {storeId}/
│       ├── .output/             # Production build output
│       └── nitro.json
└── temp/                        # Build temp files
    └── {storeId}/               # Per-build temp directory
```

#### Build Process

The build process follows these steps:

```
┌─────────────────────────────────────────────────────────────────┐
│  1. Clone user repository to temp directory                       │
│     - Clone only the tracked branch (depth=1 for efficiency)    │
│     - Use HTTPS with GitHub token for authentication            │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  2. Copy user files to skeleton (PROTECT platform files)        │
│                                                                  │
│  Platform-protected directories (NEVER overwritten):             │
│  - src/components/*                                             │
│  - src/lib/*                                                   │
│  - node_modules/*                                               │
│                                                                  │
│  User-overwritable directories:                                 │
│  - src/routes/*            (user page routes)                   │
│  - src/components/stores/* (store-specific overrides)          │
│  - app.config.ts          (optional override)                   │
│  - package.json            (optional dependency additions)      │
│  - public/*                (user assets)                        │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  3. Run build in skeleton directory                             │
│     npm run build --omit=dev                                     │
│                                                                  │
│  Note: Platform's node_modules is used, user cannot add         │
│  dependencies unless they modify package.json which is allowed   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  4. Copy .output/* to /var/lib/entaprenua/stores/{storeId}/    │
│     - server/              (SSR server output)                 │
│     - public/              (static assets)                     │
│     - nitro.json           (deployment config)                  │
└─────────────────────────────────────────────────────────────────┘
```

#### Protected Platform Files

The following files/directories are NEVER overwritten by user code:

| Path | Reason |
|------|--------|
| `src/components/ui/*` | Platform UI components (Button, Card, etc.) |
| `src/lib/` | Platform API client, utilities, stores |
| `node_modules/` | Platform dependencies (security) |
| `src/lib/db/` | Database configuration |

**User files are allowed to:**
- Add new files to `src/routes/*`
- Create new components in `src/components/stores/`
- Override existing routes in `src/routes/*`
- Add assets in `public/*`
- Extend `package.json` (additional dependencies)

#### Build Queue Service

```kotlin
@Service
class BuildQueueService(
    @Value("\${app.vcs.build.skeleton-path}") private val skeletonPath: String = "/var/lib/entaprenua/skeleton",
    @Value("\${app.vcs.build.stores-path}") private val storesPath: String = "/var/lib/entaprenua/stores",
    @Value("\${app.vcs.build.temp-path}") private val tempPath: String = "/var/lib/entaprenua/temp",
    @Value("\${app.vcs.build.timeout-minutes}") private val timeoutMinutes: Int = 15,
    private val vcsBuildRepository: VcsBuildRepository,
    private val vcsConnectionRepository: VcsConnectionRepository,
    private val log: EnterpriseLogger = logger(BuildQueueService::class.java.name)
) {
    
    companion object {
        // Directories protected from user overwrite
        val PROTECTED_DIRS = setOf(
            "src/components/ui",
            "src/lib/db",
            "node_modules"
        )
        
        // Files protected from user overwrite
        val PROTECTED_FILES = setOf(
            "package.json",  // Users can extend, but not replace entirely
            "app.config.ts"
        )
    }
    
    suspend fun queueBuild(connection: VcsConnection, build: VcsBuild) {
        CoroutineScope(Dispatchers.IO + SupervisorJob()).launch {
            executeBuild(connection, build)
        }
    }
    
    private suspend fun executeBuild(connection: VcsConnection, build: VcsBuild) {
        val startTime = System.currentTimeMillis()
        val logs = StringBuilder()
        
        try {
            logs.appendLine("Starting build #${build.buildNumber}")
            logs.appendLine("Repository: ${connection.repositoryUrl}")
            logs.appendLine("Branch: ${connection.branch}")
            logs.appendLine()
            
            // 1. Clone repository to temp directory
            logs.appendLine("[1/5] Cloning repository...")
            val tempDir = cloneUserRepository(connection, logs)
            
            // 2. Copy user files to skeleton (protecting platform files)
            logs.appendLine("[2/5] Merging user files with platform template...")
            mergeUserFilesToSkeleton(tempDir, logs)
            
            // 3. Build project
            logs.appendLine("[3/5] Building project...")
            runBuild(logs)
            
            // 4. Copy output to stores directory
            logs.appendLine("[4/5] Deploying to storefront...")
            deployBuild(connection.storeId.toString(), logs)
            
            // 5. Cleanup temp directory
            logs.appendLine("[5/5] Cleaning up...")
            cleanupTempDirectory(tempDir)
            
            val duration = System.currentTimeMillis() - startTime
            logs.appendLine()
            logs.appendLine("Build completed successfully in ${duration}ms")
            
            updateBuildSuccess(connection, build, duration, logs.toString())
            
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            logs.appendLine()
            logs.appendLine("Build failed: ${e.message}")
            
            log.error("Build failed for store ${connection.storeId}", e)
            updateBuildFailed(connection, build, e.message ?: "Unknown error", logs.toString())
        }
    }
    
    private fun cloneUserRepository(connection: VcsConnection, logs: StringBuilder): Path {
        val storeId = connection.storeId.toString()
        val tempDir = Paths.get(tempPath, storeId)
        
        // Create temp directory
        Files.createDirectories(tempDir)
        
        // Clone using HTTPS with token
        val cloneUrl = connection.repositoryUrl!!.replace(
            "https://github.com/",
            "https://x-access-token:${connection.webhookSecret}@github.com/"
        )
        
        logs.appendLine("  Cloning from: ${connection.repositoryOwner}/${connection.repositoryName}")
        
        // Clone only the specific branch
        val result = ProcessBuilder(
            "git", "clone",
            "--branch", connection.branch,
            "--depth", "1",
            "--filter=blob:none",
            cloneUrl,
            tempDir.toString()
        )
            .redirectErrorStream(true)
            .start()
            .inputStream
            .bufferedReader()
            .use { reader ->
                reader.lineSequence().forEach { logs.appendLine("  $it") }
            }
        
        if (result.waitFor() != 0) {
            throw IllegalStateException("Git clone failed with exit code ${result.waitFor()}")
        }
        
        return tempDir
    }
    
    private fun mergeUserFilesToSkeleton(userFilesDir: Path, logs: StringBuilder) {
        val skeletonDir = Paths.get(skeletonPath)
        
        // Files to copy from user repo
        val userDirsToCopy = listOf("src/routes", "src/components/stores", "public")
        
        for (dir in userDirsToCopy) {
            val userPath = userFilesDir.resolve(dir)
            val skeletonPath = skeletonDir.resolve(dir)
            
            if (Files.exists(userPath)) {
                logs.appendLine("  Merging: $dir")
                
                // Ensure parent directory exists
                Files.createDirectories(skeletonPath.parent)
                
                // Copy user files (user files will overwrite skeleton defaults)
                copyDirectory(userPath, skeletonPath, logs)
            }
        }
        
        // Copy root-level files (routes.config.ts, etc.)
        val userRootDir = userFilesDir
        val userRootFiles = listOf("routes.config.ts", "middleware.ts")
        
        for (file in userRootFiles) {
            val userFile = userRootDir.resolve(file)
            if (Files.exists(userFile)) {
                Files.copy(userFile, skeletonDir.resolve(file), StandardCopyOption.REPLACE_EXISTING)
                logs.appendLine("  Copied: $file")
            }
        }
    }
    
    private fun copyDirectory(source: Path, target: Path, logs: StringBuilder) {
        if (!Files.exists(target)) {
            Files.createDirectories(target)
        }
        
        Files.walk(source).use { stream ->
            stream.forEach { sourceFile ->
                val relativePath = source.relativize(sourceFile)
                val targetFile = target.resolve(relativePath)
                
                // Check if this file/dir is in a protected directory
                val isProtected = PROTECTED_DIRS.any { protectedDir ->
                    relativePath.toString().startsWith(protectedDir)
                }
                
                if (isProtected) {
                    logs.appendLine("    Skipped (protected): $relativePath")
                    return@forEach
                }
                
                if (Files.isDirectory(sourceFile)) {
                    if (!Files.exists(targetFile)) {
                        Files.createDirectories(targetFile)
                    }
                } else {
                    Files.createDirectories(targetFile.parent)
                    Files.copy(sourceFile, targetFile, StandardCopyOption.REPLACE_EXISTING)
                }
            }
        }
    }
    
    private fun runBuild(logs: StringBuilder) {
        val skeletonDir = Paths.get(skeletonPath)
        
        // Run build (using platform's node_modules, --omit=dev for production)
        val result = ProcessBuilder("npm", "run", "build", "--omit=dev")
            .directory(skeletonDir.toFile())
            .redirectErrorStream(true)
            .start()
        
        result.inputStream.bufferedReader().use { reader ->
            reader.lineSequence().forEach { logs.appendLine("  $it") }
        }
        
        if (result.waitFor() != 0) {
            throw IllegalStateException("Build failed with exit code ${result.waitFor()}")
        }
    }
    
    private fun deployBuild(storeId: String, logs: StringBuilder) {
        val skeletonDir = Paths.get(skeletonPath)
        val storesDir = Paths.get(storesPath, storeId)
        
        // Create store directory if not exists
        Files.createDirectories(storesDir)
        
        // Copy .output directory
        val outputSource = skeletonDir.resolve(".output")
        val outputTarget = storesDir.resolve(".output")
        
        if (Files.exists(outputTarget)) {
            // Clear existing output
            outputTarget.toFile().deleteRecursively()
        }
        
        logs.appendLine("  Copying build output to: $storesDir")
        
        // Copy .output contents
        Files.walk(outputSource).use { stream ->
            stream.forEach { sourceFile ->
                val relativePath = outputSource.relativize(sourceFile)
                val targetFile = outputTarget.resolve(relativePath)
                
                if (Files.isDirectory(sourceFile)) {
                    Files.createDirectories(targetFile)
                } else {
                    Files.createDirectories(targetFile.parent)
                    Files.copy(sourceFile, targetFile, StandardCopyOption.REPLACE_EXISTING)
                }
            }
        }
        
        logs.appendLine("  Build deployed successfully")
    }
    
    private fun cleanupTempDirectory(tempDir: Path) {
        try {
            tempDir.toFile().deleteRecursively()
        } catch (e: Exception) {
            log.warn("Failed to cleanup temp directory", e, mapOf("path" to tempDir.toString()))
        }
    }
    
    private suspend fun updateBuildSuccess(connection: VcsConnection, build: VcsBuild, duration: Long, logs: String) {
        vcsBuildRepository.update(build.markSuccess(duration).copy(logs = logs))
        vcsConnectionRepository.updateBuildStatus(connection.storeId, "success", build.commitSha)
    }
    
    private suspend fun updateBuildFailed(connection: VcsConnection, build: VcsBuild, error: String, logs: String) {
        vcsBuildRepository.update(build.markFailed(error).copy(logs = logs.takeLast(10000)))
        vcsConnectionRepository.updateBuildStatus(connection.storeId, "failed")
    }
}
```

---

### Phase 7: Webhook Handler

#### WebhookService

```kotlin
@Service
class WebhookService(
    private val vcsConnectionRepository: VcsConnectionRepository,
    private val vcsBuildRepository: VcsBuildRepository,
    private val buildQueueService: BuildQueueService,
    private val log: EnterpriseLogger = logger(WebhookService::class.java.name)
) {
    
    data class GitHubPushEvent(
        val ref: String,
        val repository: Repository,
        val commits: List<Commit>,
        val sender: Sender
    ) {
        data class Repository(
            val id: Long,
            val fullName: String,
            val cloneUrl: String,
            val htmlUrl: String
        )
        data class Commit(
            val id: String,
            val message: String,
            val author: Author
        ) {
            data class Author(val name: String, val email: String)
        }
        data class Sender(val login: String)
    }
    
    suspend fun handleGitHubPush(request: ServerRequest): ServerResponse {
        // 1. Verify signature
        val signature = request.headers().firstHeader("X-Hub-Signature-256")
        val event = request.headers().firstHeader("X-GitHub-Event")
        val payload = request.awaitBody<String>()
        
        if (event != "push") {
            return ServerResponse.ok().bodyValueAndAwait(mapOf("status" to "ignored"))
        }
        
        // Verify webhook secret
        val connection = verifyAndFindConnection(payload, signature)
            ?: return ServerResponse.status(401).bodyValueAndAwait(mapOf("error" to "Invalid signature"))
        
        // Parse payload
        val pushEvent = Json.decodeFromString<GitHubPushEvent>(payload)
        
        // Check if push to tracked branch
        if (pushEvent.ref != "refs/heads/${connection.branch}") {
            return ServerResponse.ok().bodyValueAndAwait(mapOf("status" to "ignored", "reason" to "Different branch"))
        }
        
        val latestCommit = pushEvent.commits.lastOrNull()
        
        // Check if build is already running
        if (connection.buildStatus == "building") {
            log.warn("Build already in progress for store ${connection.storeId}")
            return ServerResponse.ok().bodyValueAndAwait(mapOf("status" to "ignored", "reason" to "Build in progress"))
        }
        
        // Update status
        vcsConnectionRepository.updateBuildStatus(connection.storeId, "building", latestCommit?.id)
        
        // Create build record
        val buildNumber = vcsBuildRepository.getNextBuildNumber(connection.id!!)
        val build = vcsBuildRepository.save(VcsBuild(
            vcsConnectionId = connection.id,
            buildNumber = buildNumber,
            commitSha = latestCommit?.id,
            commitMessage = latestCommit?.message,
            commitAuthor = latestCommit?.author?.name,
            branch = connection.branch,
            status = "pending"
        ))
        
        // Queue build
        buildQueueService.queueBuild(connection, build)
        
        log.info("Build queued for store ${connection.storeId}", mapOf(
            "commit" to (latestCommit?.id ?: "unknown"),
            "buildNumber" to buildNumber
        ))
        
        return ServerResponse.ok().bodyValueAndAwait(mapOf("status" to "queued", "buildNumber" to buildNumber))
    }
    
    private suspend fun verifyAndFindConnection(payload: String, signature: String?): VcsConnection? {
        val connections = vcsConnectionRepository.findAll()  // Or use indexed lookup
        
        for (connection in connections) {
            if (connection.webhookSecret != null && signature != null) {
                val expected = "sha256=" + hmacSha256(connection.webhookSecret, payload)
                if (crypto.timingSafeEqual(signature.toByteArray(), expected.toByteArray())) {
                    return connection
                }
            }
        }
        
        return null
    }
    
    private fun hmacSha256(secret: String, payload: String): String {
        val key = SecretKeySpec(secret.toByteArray(), "HmacSHA256")
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(key)
        return mac.doFinal(payload.toByteArray()).toHexString()
    }
}
```

---

### Phase 8: REST API Routes

Add to `config/ApiRouterConfig.kt`:

```kotlin
@Configuration
class VcsRouterConfig(
    private val vcsGetService: VcsGetService,
    private val vcsSaveService: VcsSaveService
) {
    @Bean
    fun vcsRouter(): RouterFunction<ServerResponse> = coRouter {
        path("/api/v1/stores/{storeId}/vcs").nest {
            GET("") { request -> vcsGetService.getConnection(request) }
            POST("/connect") { request -> vcsSaveService.connectStore(request) }
            POST("/request-collaboration") { request -> vcsSaveService.requestCollaboration(request) }
            DELETE("") { request -> vcsSaveService.disconnectStore(request) }
            POST("/redeploy") { request -> vcsSaveService.redeploy(request) }
            GET("/builds") { request -> vcsGetService.getBuilds(request) }
        }
    }
    
    @Bean
    @Order(1)
    fun webhookRouter(
        webhookService: WebhookService
    ): RouterFunction<ServerResponse> = coRouter {
        POST("/webhooks/github") { request -> webhookService.handleGitHubPush(request) }
    }
}
```

#### Service Handlers

```kotlin
@Service
class VcsGetServiceImpl(
    private val vcsConnectionRepository: VcsConnectionRepository,
    private val vcsBuildRepository: VcsBuildRepository,
    private val storeRepository: StoreRepository
) : VcsGetService {
    
    override suspend fun getConnection(request: ServerRequest): ServerResponse {
        return try {
            val storeId = UUID.fromString(request.pathVariable("storeId"))
            val connection = vcsConnectionRepository.findByStoreId(storeId)
            
            if (connection == null) {
                apiNotFound("VCS not configured").toServerResponse()
            } else {
                val builds = vcsBuildRepository.findByConnectionId(connection.id!!, 10)
                val dto = VcsConnectionDto(
                    id = connection.id.toString(),
                    provider = connection.provider,
                    repositoryName = connection.repositoryName,
                    repositoryUrl = connection.repositoryUrl,
                    branch = connection.branch,
                    isPlatformOwned = connection.isPlatformOwned,
                    collaborationStatus = connection.collaborationStatus,
                    lastDeployCommit = connection.lastDeployCommit,
                    lastDeployTime = connection.lastDeployTime?.toString(),
                    buildStatus = connection.buildStatus,
                    buildHistory = builds.map { it.toDto() }
                )
                ServerResponse.ok().bodyValueAndAwait(apiSuccess(dto))
            }
        } catch (e: Exception) {
            log.error("Failed to get VCS connection", e)
            apiError("Failed to get VCS connection").toServerResponse()
        }
    }
    
    override suspend fun getBuilds(request: ServerRequest): ServerResponse {
        return try {
            val storeId = UUID.fromString(request.pathVariable("storeId"))
            val limit = request.queryParam("limit").map { it.toInt() }.orElse(20)
            
            val connection = vcsConnectionRepository.findByStoreId(storeId)
                ?: return apiNotFound("VCS not configured").toServerResponse()
            
            val builds = vcsBuildRepository.findByConnectionId(connection.id!!, limit)
            val dtos = builds.map { it.toDto() }
            
            ServerResponse.ok().bodyValueAndAwait(apiSuccess(PagedResponse(
                content = dtos,
                page = 0,
                size = dtos.size,
                totalElements = dtos.size.toLong(),
                totalPages = 1
            )))
        } catch (e: Exception) {
            log.error("Failed to get build history", e)
            apiError("Failed to get build history").toServerResponse()
        }
    }
}
```

---

### Phase 9: Configuration

#### application.properties

```properties
# GitHub Platform Organization
app.vcs.github.org=entaprenua-stores
app.vcs.github.pat-token=${GITHUB_PAT_TOKEN:}

# Webhook
app.vcs.webhook.base-url=${APP_BASE_URL:https://api.entaprenua.com}

# Encryption (for webhook secrets at rest)
# Generate key with: openssl rand -base64 32
app.vcs.encryption.master-key=${VCS_ENCRYPTION_MASTER_KEY:}

# Build Settings
app.vcs.build.skeleton-path=/var/lib/entaprenua/skeleton
app.vcs.build.stores-path=/var/lib/entaprenua/stores
app.vcs.build.temp-path=/var/lib/entaprenua/temp
app.vcs.build.timeout-minutes=15
```

---

## File Structure Summary

```
runtime/src/main/kotlin/com/entaprenua/
├── vcs/
│   ├── entities/
│   │   ├── VcsConnection.kt
│   │   ├── VcsBuild.kt
│   │   └── VcsEnums.kt           # CollaborationStatus, BuildStatus
│   ├── dtos/
│   │   └── VcsDtos.kt           # All DTOs
│   ├── errors/
│   │   └── VcsError.kt
│   ├── repositories/
│   │   ├── VcsConnectionRepository.kt
│   │   └── VcsBuildRepository.kt
│   └── services/
│       ├── VcsService.kt         # Core business logic
│       ├── VcsHandlers.kt       # Handler interfaces
│       ├── VcsHandlerServices.kt # Handler implementations
│       ├── GitHubApiService.kt  # GitHub API client
│       ├── BuildQueueService.kt # Build pipeline
│       ├── WebhookService.kt    # Webhook handler
│       └── EncryptionService.kt  # AES-256-GCM encryption
├── storefront/              # Existing module - serves deployed stores
│   ├── StorefrontConfig.kt
│   ├── StorefrontRouterConfig.kt
│   ├── StorefrontProxyHandler.kt
│   ├── StoreRegistry.kt
│   └── ProcessManagerService.kt
└── config/
    └── ApiRouterConfig.kt       # All API routes (including VCS)

src/main/resources/
├── db/migration/
│   └── V{n}__Add_vcs_tables.sql
└── application.properties
```
```

### Build Directory Structure (Server Filesystem)

```
/var/lib/entaprenua/
├── platform/                    # Platform code (git repo, versioned)
│   ├── .git/                   # Git repository for version control
│   ├── src/
│   │   ├── components/ui/       # Platform UI (PROTECTED)
│   │   ├── lib/                # Platform lib (PROTECTED)
│   │   └── routes/             # Default routes
│   ├── public/                 # Default public assets
│   ├── package*.json           # Platform deps (PROTECTED)
│   ├── app.tsx                 # App entry
│   ├── entry-client.tsx        # Client entry
│   ├── entry-server.tsx        # Server entry
│   └── .output/                # Build output
│
├── stores/                      # Deployed stores
│   └── {storeId}/
│       ├── .output/
│       │   ├── server/
│       │   ├── public/
│       │   └── nitro.json
│       └── (runtime files)
└── temp/                        # Build temp (cloned repos)
    └── {storeId}/
        ├── platform/           # Cloned platform repo
        └── user/              # Cloned user repository
```
```

### Integration with Storefront Module

The VCS build pipeline integrates with existing `storefront/` module:

1. **Build Completion** → `BuildQueueService.deployBuild()` copies `.output/` to stores path
2. **Store Process** → `ProcessManagerService.startStore()` runs `node server/index.mjs` from store directory
3. **Request Routing** → `StorefrontProxyHandler` proxies requests to running store process by domain
4. **Process Management** → `StoreRegistry` tracks running stores with their ports

```
┌─────────────────────────────────────────────────────────────────┐
│  Build Complete (.output/ → /var/lib/entaprenua/stores/{id}/)  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  ProcessManagerService.startStore(id, domain, storePath)        │
│  - Runs: node server/index.mjs (from .output/)                 │
│  - Sets PORT env var                                            │
│  - Registers with StoreRegistry                                 │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  StorefrontProxyHandler.proxy(request)                          │
│  - Routes by domain to running store port                       │
└─────────────────────────────────────────────────────────────────┘
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/stores/{storeId}/vcs` | Get VCS connection info |
| POST | `/api/v1/stores/{storeId}/vcs/connect` | Connect/create repository |
| POST | `/api/v1/stores/{storeId}/vcs/request-collaboration` | Request collaboration access |
| POST | `/api/v1/stores/{storeId}/vcs/verify-collaboration` | Verify user is collaborator |
| DELETE | `/api/v1/stores/{storeId}/vcs` | Disconnect VCS |
| POST | `/api/v1/stores/{storeId}/vcs/redeploy` | Trigger manual redeploy |
| GET | `/api/v1/stores/{storeId}/vcs/builds` | Get build history |
| POST | `/api/v1/stores/{storeId}/vcs/clone-from-template` | Clone template to new store |
| POST | `/webhooks/github` | GitHub webhook receiver |

### Collaboration Flow

```
1. User connects repo → status = 'owner' or 'not_applicable'
                         ↓
2. If not owner → POST /request-collaboration
                         ↓
3. User accepts GitHub invite
                         ↓
4. User calls POST /verify-collaboration
                         ↓
5. We call GitHub API to verify → status = 'collaborator'
```

---

## User Repository Structure

User repositories are created by cloning templates. They contain:

### Required Files

| File/Directory | Source | Description |
|---------------|--------|-------------|
| `platform-version.json` | Template | Platform version for build compatibility |
| `src/routes/*` | User | User's page routes |
| `src/components/stores/*` | User | Store-specific component overrides |
| `public/*` | User | User assets |

### Platform Files (Never from User Repo)

| Protected | Description |
|-----------|-------------|
| `src/components/ui/*` | Platform UI components |
| `src/lib/*` | Platform lib |
| `package.json` / `package-lock.json` | Dependencies |
| `node_modules` | Generated on npm install |
| `.output` | Generated on npm build |

**Everything else is trusted from user's repo:** `src/routes/*`, `src/components/*` (except ui/), `public/*`, `app.tsx`, `entry-client.tsx`, `entry-server.tsx`, etc.

### Example User Repository

```
my-store/
├── platform-version.json        # {"version": "1.2.3"}
├── src/
│   ├── components/
│   │   └── stores/               # Store-specific components
│   │       ├── MyCustomHero.tsx
│   │       └── ProductBanner.tsx
│   └── routes/                   # User pages
│       ├── index.tsx             # Home page
│       ├── products.tsx          # Products page
│       └── contact.tsx           # Contact page
├── public/
│   └── images/
│       └── logo.png
├── routes.config.ts              # Optional: Route configuration
└── README.md
```

**Note:** Platform files (src/components/ui, src/lib, package.json, etc.) are NOT in the user's repository. They are fetched from `entaprenua/platform` at the version specified in `platform-version.json`.

### Build-Time Merge Process

1. Read `platform-version.json` → get platform version (e.g., "1.2.3")
2. Clone `entaprenua/platform` @ v1.2.3 to temp directory
3. Clone user's repository to temp directory
4. Merge files:
   - `platform/src/components/ui/*` → Used (protected)
   - `platform/src/lib/*` → Used (protected)
   - `platform/package*.json` → Used (protected)
   - `user/src/routes/*` → Used (trusted)
   - `user/src/components/*` → Used (trusted, except ui/)
   - `user/public/*` → Used (trusted)
   - All other user files → Used (trusted)
5. Runs `npm run build --omit=dev` using platform's node_modules
6. Copies `.output/` to `/var/lib/entaprenua/stores/{storeId}/`

**Security:** Protected platform files are ALWAYS fetched from `entaprenua/platform`. Everything else is trusted from user's repo.

---

## Security Considerations

1. **Webhook Verification**: HMAC-SHA256 signature validation on all webhook requests
2. **Webhook Secret Encryption**: Stored encrypted with AES-256-GCM, master key in environment variable
3. **Repository Access**: Use GitHub PAT with minimal required scopes
4. **Build Isolation**: Builds run in isolated temporary directories
5. **Protected Files**: Only `src/components/ui/*`, `src/lib/*`, and `package*.json` are protected (fetched from platform repo)
6. **Rate Limiting**: Respect GitHub API rate limits
7. **Collaboration Verification**: Always verify user access before enabling webhooks
8. **Platform Version Trust**: Only trust `platform-version.json` for version info; protected files always fetched from `entaprenua/platform`

---

## GitHub Setup

### Required Repositories

Create these repositories in the `entaprenua` GitHub organization (slug-based naming):

1. **`platform`** (Private)
   - Platform base code
   - Tag versions: `v1.0.0`, `v1.1.0`, `v1.2.0`, etc.

2. **`basic`** (Public)
   - Basic template
   - Includes `platform-version.json`

3. **`ecommerce`** (Public)
   - E-commerce template
   - Includes `platform-version.json`

4. **`premium`** (Public)
   - Premium template
   - Includes `platform-version.json`

**Naming Convention:**
- Repo name = slug (URL-safe, lowercase, hyphens)
- Display name = human-readable (e.g., "Fashion Store" → `fashion-store`)
- Template unique by name/slug

### Required GitHub App Permissions

Create a GitHub App with these permissions:

| Permission | Access |
|------------|--------|
| Contents | Read & Write (for cloning/forking) |
| Repository administration | Read & Write (for webhook management) |
| Single file | Read (for platform-version.json) |

### Required PAT Scopes (Alternative)

If using PAT instead of GitHub App:

- `repo` - Full control of repositories
- `read:user` - Access user info

---

## Related Documentation

- [VCS Integration Overview](../VCS_INTEGRATION.md)
- [SSR Implementation](SSR_IMPLEMENTATION.md)
- [Storefront Architecture](STOREFRONT.md)
- [Template Marketplace](./TEMPLATE_MARKETPLACE.md) (Future)
