# Plan: Move Verification Fields to `store_email_settings` Table

## Overview

Refactor email verification customization from `stores` table to a separate `store_email_settings` table with cleaner naming and consolidated domain configuration.

## Rationale

1. **Remove `verification_` prefix redundancy** - All fields are already scoped to email configs
2. **Consolidate domain fields** - `verification_subdomain` + `verification_custom_domain` → single `domain` field
3. **Better separation of concerns** - Store identity vs email configuration

## Database Changes

### New Table: `store_email_settings`

```sql
CREATE TABLE store_email_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE UNIQUE,
    
    -- Redirects
    redirect_url VARCHAR(500),
    success_redirect_url VARCHAR(500),
    
    -- Email content
    email_subject VARCHAR(200) DEFAULT 'Verify your account',
    sender_name VARCHAR(100) DEFAULT 'Store Team',
    sender_email VARCHAR(255),
    verification_template TEXT,
    
    -- Token
    token_expiry_hours INT DEFAULT 24,
    
    -- Domain
    -- User sets full sender email (e.g., @myemail.com or mysubdomain@entaprenua.com)
    -- If not supplied, auto-generated from store name at save time
    domain VARCHAR(255),
    
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);
```

### Drop Old Columns from `stores`

```sql
ALTER TABLE stores DROP COLUMN IF EXISTS verification_redirect_url;
ALTER TABLE stores DROP COLUMN IF EXISTS verification_email_subject;
ALTER TABLE stores DROP COLUMN IF EXISTS verification_success_redirect_url;
ALTER TABLE stores DROP COLUMN IF EXISTS verification_sender_name;
ALTER TABLE stores DROP COLUMN IF EXISTS verification_sender_email;
ALTER TABLE stores DROP COLUMN IF EXISTS verification_email_template;
ALTER TABLE stores DROP COLUMN IF EXISTS verification_expiry_hours;
ALTER TABLE stores DROP COLUMN IF EXISTS verification_subdomain;
ALTER TABLE stores DROP COLUMN IF EXISTS verification_custom_domain;
```

## Field Name Mapping

| Old (stores) | New (store_email_settings) | Notes |
|--------------|---------------------------|-------|
| `verification_redirect_url` | `redirect_url` | |
| `verification_email_subject` | `email_subject` | |
| `verification_success_redirect_url` | `success_redirect_url` | |
| `verification_sender_name` | `sender_name` | |
| `verification_sender_email` | `sender_email` | |
| `verification_email_template` | `verification_template` | Keep prefix - distinguishes from other templates |
| `verification_expiry_hours` | `token_expiry_hours` | |
| `verification_subdomain` | `domain` | Consolidated |
| `verification_custom_domain` | `domain` | Consolidated |

## Domain Handling

The `domain` field stores the full sender email as-is. User sets it in dashboard or it is auto-generated.

### Auto-generation at Save Time

```kotlin
fun resolveDomain(domain: String?, storeName: String): String {
    if (domain.isNullOrBlank()) {
        // Auto-generate from store name
        val prefix = storeName.lowercase().replace(Regex("[^a-z0-9]"), "")
        return "$prefix@entaprenua.com"
    }
    return domain  // Use as-is
}
```

## Settings Architecture

### Directory Structure
```
store/
├── settings/
│   ├── StoreSettingsService.kt          # Interface (generic)
│   ├── email/
│   │   ├── StoreEmailSettingsService.kt # Email settings interface
│   │   ├── StoreEmailSettingsServiceImpl.kt
│   │   └── StoreEmailSettingsRepository.kt
```

### StoreContext Integration
- Store ID inferred from request context (`/stores/{publicId}/settings/...`)
- Uses existing `request.requireStoreId()` pattern

### API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/stores/{publicId}/settings/email` | Get email settings |
| PUT | `/api/v1/stores/{publicId}/settings/email` | Update email settings |

## Files to Modify/Create

### 1. Migration
- `db/migration/V44__store_email_settings.sql` - **NEW**

### 2. Entities
- `entities/StoreEmailSettings.kt` - **NEW**
- `entities/Store.kt` - Remove verification fields

### 3. DTOs
- `store/dtos/StoreSettingsDto.kt` - Update field names

### 4. Settings Module
- `store/settings/StoreSettingsService.kt` - **NEW** (generic interface)
- `store/settings/email/StoreEmailSettingsService.kt` - **NEW** (email interface)
- `store/settings/email/StoreEmailSettingsServiceImpl.kt` - **NEW**
- `store/settings/email/StoreEmailSettingsRepository.kt` - **NEW**

### 5. Repositories
- `repositories/StoreRepository.kt` - Remove verification handling

### 6. Services
- `store/impl/StoreServiceImpl.kt` - Remove settings methods

### 7. Router
- `config/ApiRouterConfig.kt` - Add settings routes

## Implementation Steps

1. **Create migration V44** - Create table, drop old columns
2. **Create `StoreEmailSettings.kt`** - Entity
3. **Update `Store.kt`** - Remove verification fields
4. **Create `StoreEmailSettingsRepository.kt`** - Upsert by store_id
5. **Create `StoreSettingsService.kt`** - Generic interface
6. **Create `StoreEmailSettingsService.kt`** - Email settings interface
7. **Create `StoreEmailSettingsServiceImpl.kt`** - Implementation
8. **Update `StoreSettingsDto.kt`** - New field names
9. **Update `StoreRepository.kt`** - Remove verification handling
10. **Remove settings methods from `StoreServiceImpl.kt`**
11. **Add settings routes to `ApiRouterConfig.kt`**
12. **Run JOOQ codegen** - Regenerate after schema change
13. **Test all flows**

## API Response Format

Settings API (`/api/v1/stores/{publicId}/settings/email`):

```json
{
  "success": true,
  "data": {
    "redirectUrl": "...",
    "emailSubject": "...",
    "successRedirectUrl": "...",
    "senderName": "...",
    "senderEmail": "...",
    "verificationTemplate": "...",
    "tokenExpiryHours": 24,
    "domain": "mystore@entaprenua.com"
  }
}
```

## Notes

- Rows in `store_email_settings` created on-demand (when store owner saves settings)
- Domain auto-generated from store name if not supplied during save
- Store entity no longer holds email configuration
- `store_customers` table unchanged (has its own `verification_token`, `verification_expires_at`)
- Frontend will need to update settings form field names
- Future: Add `payment`, `shipping` settings under same structure
