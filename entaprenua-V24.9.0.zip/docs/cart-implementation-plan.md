# Enterprise Cart Implementation Plan

## Overview

This document outlines the implementation of a production-ready, enterprise-grade cart system for the entaprenua e-commerce platform.

---

## 1. Architecture

### Layered Architecture

```
┌─────────────────────────────────────────────────────┐
│              UI Components (components/ui/cart)       │
├─────────────────────────────────────────────────────┤
│         Cart Hooks (lib/hooks/useCart.ts)            │
│    - useCart(), useCartItem(), useCartActions()     │
├─────────────────────────────────────────────────────┤
│       Cart Store (lib/stores/cart.tsx)              │
│    - Server sync, validation, optimistic updates     │
├─────────────────────────────────────────────────────┤
│      createItemList (lib/item-list.ts)              │
│    - Client-side state management                  │
├─────────────────────────────────────────────────────┤
│           SolidJS Signals/Stores                    │
└─────────────────────────────────────────────────────┘
```

### Key Principles

1. **Local-first with optimistic updates** - Immediate UI feedback, background sync
2. **Per-store isolation** - Cart is scoped to storeId
3. **TanStack Query** - Industry-standard data fetching
4. **Extend, don't replace** - Keep existing `createItemList` core logic

---

## 2. TanStack Query Integration

### Query Keys

```typescript
// Query key structure
const cartKeys = {
  all: ['cart'] as const,
  store: (storeId: string) => ['cart', 'store', storeId] as const,
  items: (storeId: string) => ['cart', 'store', storeId, 'items'] as const,
}
```

### Cart Hooks (new file: lib/hooks/useCart.ts)

```typescript
import { useQuery, useMutation, useQueryClient } from '@tanstack/solid-query'
import { cartApi } from '~/lib/api/cart'
import { cartKeys } from '~/lib/query-keys'
import { createItemList, type ProductInput } from '~/lib/item-list'

// Fetch cart for a store
export function useCart(storeId: () => string) {
  return useQuery({
    queryKey: cartKeys.store(storeId()),
    queryFn: () => cartApi.get(storeId()),
    enabled: !!storeId(),
  })
}

// Add item to cart with optimistic update
export function useAddToCart() {
  const queryClient = useQueryClient()
  
  return useMutation({
    mutationFn: ({ storeId, product, quantity }: { 
      storeId: string
      product: ProductInput
      quantity?: number 
    }) => cartApi.addItem(storeId, product, quantity),
    
    onMutate: async ({ storeId, product, quantity = 1 }) => {
      // 1. Cancel outgoing refetches
      await queryClient.cancelQueries(cartKeys.store(storeId))
      
      // 2. Snapshot previous cart
      const previousCart = queryClient.getQueryData(cartKeys.store(storeId))
      
      // 3. Optimistically update
      queryClient.setQueryData(cartKeys.store(storeId), (old: any) => ({
        ...old,
        items: [...(old?.items ?? []), { 
          productId: product.id, 
          quantity,
          price: product.price,
          name: product.name,
          image: product.image 
        }]
      }))
      
      return { previousCart }
    },
    
    onError: (err, variables, context) => {
      // Rollback on error
      if (context?.previousCart) {
        queryClient.setQueryData(
          cartKeys.store(variables.storeId), 
          context.previousCart
        )
      }
    },
    
    onSettled: (data, error, variables) => {
      // Invalidate to sync with server
      queryClient.invalidateQueries(cartKeys.store(variables.storeId))
    },
  })
}

// Update item quantity
export function useUpdateCartItem() {
  const queryClient = useQueryClient()
  
  return useMutation({
    mutationFn: ({ storeId, itemId, quantity }: {
      storeId: string
      itemId: string
      quantity: number
    }) => cartApi.updateItem(storeId, itemId, quantity),
    
    onMutate: async ({ storeId, itemId, quantity }) => {
      await queryClient.cancelQueries(cartKeys.store(storeId))
      const previousCart = queryClient.getQueryData(cartKeys.store(storeId))
      
      queryClient.setQueryData(cartKeys.store(storeId), (old: any) => ({
        ...old,
        items: old.items?.map((item: any) => 
          item.id === itemId ? { ...item, quantity } : item
        )
      }))
      
      return { previousCart }
    },
    
    onError: (err, variables, context) => {
      queryClient.setQueryData(
        cartKeys.store(variables.storeId), 
        context?.previousCart
      )
    },
    
    onSettled: (data, error, variables) => {
      queryClient.invalidateQueries(cartKeys.store(variables.storeId))
    },
  })
}

// Remove item from cart
export function useRemoveFromCart() {
  const queryClient = useQueryClient()
  
  return useMutation({
    mutationFn: ({ storeId, itemId }: { storeId: string; itemId: string }) => 
      cartApi.removeItem(storeId, itemId),
    
    onMutate: async ({ storeId, itemId }) => {
      await queryClient.cancelQueries(cartKeys.store(storeId))
      const previousCart = queryClient.getQueryData(cartKeys.store(storeId))
      
      queryClient.setQueryData(cartKeys.store(storeId), (old: any) => ({
        ...old,
        items: old.items?.filter((item: any) => item.id !== itemId)
      }))
      
      return { previousCart }
    },
    
    onError: (err, variables, context) => {
      queryClient.setQueryData(
        cartKeys.store(variables.storeId), 
        context?.previousCart
      )
    },
    
    onSettled: (data, error, variables) => {
      queryClient.invalidateQueries(cartKeys.store(variables.storeId))
    },
  })
}

// Clear entire cart
export function useClearCart() {
  const queryClient = useQueryClient()
  
  return useMutation({
    mutationFn: (storeId: string) => cartApi.clear(storeId),
    
    onMutate: async (storeId) => {
      await queryClient.cancelQueries(cartKeys.store(storeId))
      const previousCart = queryClient.getQueryData(cartKeys.store(storeId))
      
      queryClient.setQueryData(cartKeys.store(storeId), (old: any) => ({
        ...old,
        items: []
      }))
      
      return { previousCart }
    },
    
    onError: (err, variables, context) => {
      queryClient.setQueryData(cartKeys.store(variables), context?.previousCart)
    },
    
    onSettled: (data, error, variables) => {
      queryClient.invalidateQueries(cartKeys.store(variables))
    },
  })
}

// Validate cart (check stock, pricing)
export function useValidateCart() {
  const queryClient = useQueryClient()
  
  return useMutation({
    mutationFn: (storeId: string) => cartApi.validate(storeId),
    
    onSuccess: (data) => {
      // Update cart with validation results (pricing changes, out of stock items)
      return data
    },
  })
}
```

---

## 3. Cart API Endpoints (lib/api/cart.ts)

```typescript
import { api, getCsrfToken } from './api'
import type { Cart, CartItem, Product } from '~/lib/types'

export const cartApi = {
  // Fetch cart for store
  get: async (storeId: string): Promise<Cart> => {
    const csrfToken = getCsrfToken()
    return api.get(`/stores/${storeId}/cart`, csrfToken ?? undefined)
  },

  // Add item to cart
  addItem: async (
    storeId: string, 
    product: { productId: string; quantity: number },
    csrfToken?: string
  ): Promise<Cart> => {
    return api.post(`/stores/${storeId}/cart/items`, product, csrfToken)
  },

  // Update item quantity
  updateItem: async (
    storeId: string,
    itemId: string,
    quantity: number,
    csrfToken?: string
  ): Promise<Cart> => {
    return api.put(
      `/stores/${storeId}/cart/items/${itemId}`, 
      { quantity }, 
      csrfToken
    )
  },

  // Remove item from cart
  removeItem: async (
    storeId: string,
    itemId: string,
    csrfToken?: string
  ): Promise<Cart> => {
    return api.delete(
      `/stores/${storeId}/cart/items/${itemId}`, 
      csrfToken
    )
  },

  // Clear entire cart
  clear: async (storeId: string, csrfToken?: string): Promise<Cart> => {
    return api.delete(`/stores/${storeId}/cart`, csrfToken)
  },

  // Validate cart (check stock, pricing)
  validate: async (storeId: string, csrfToken?: string): Promise<{
    valid: boolean
    issues: Array<{ itemId: string; type: 'out_of_stock' | 'price_changed' | 'unavailable'; message: string }>
  }> => {
    return api.post(`/stores/${storeId}/cart/validate`, {}, csrfToken)
  },

  // Apply promo code
  applyPromo: async (
    storeId: string, 
    code: string,
    csrfToken?: string
  ): Promise<Cart> => {
    return api.post(
      `/stores/${storeId}/cart/promo`, 
      { code }, 
      csrfToken
    )
  },

  // Remove promo code
  removePromo: async (storeId: string, csrfToken?: string): Promise<Cart> => {
    return api.delete(`/stores/${storeId}/cart/promo`, csrfToken)
  },
}
```

---

## 4. Cart Store Enhancement (lib/stores/cart.tsx)

```typescript
import { createContext, useContext, ParentComponent, createSignal } from 'solid-js'
import { useQueryClient } from '@tanstack/solid-query'
import { cartKeys } from '~/lib/query-keys'
import { cartApi } from '~/lib/api/cart'
import { createItemList, productToEntry, type ProductInput } from '~/lib/item-list'
import type { Cart, CartItem } from '~/lib/types'

type CartStore = {
  // Local state (from createItemList)
  items: any[]
  count: number
  subtotal: number
  isEmpty: boolean
  
  // Actions
  addProduct: (product: ProductInput, quantity?: number) => void
  updateQuantity: (itemId: string, quantity: number) => void
  removeItem: (itemId: string) => void
  clear: () => void
  
  // Server sync
  sync: (cart: Cart) => void
}

const CartContext = createContext<CartStore>()

export const useCart = () => {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error('useCart must be used within CartProvider')
  return ctx
}

export const CartProvider: ParentComponent<{ 
  storeId: string
  initialCart?: Cart 
}> = (props) => {
  const queryClient = useQueryClient()
  const list = createItemList(undefined, { defaultQuantity: 1 })
  
  // Sync from server
  const sync = (cart: Cart) => {
    list.setSnapshot({
      id: cart.id,
      storeId: cart.storeId,
      items: cart.items?.map(item => ({
        id: item.id,
        productId: item.productId,
        quantity: item.quantity,
        price: item.price,
        name: '',
        image: undefined,
        selected: true,
        subtotal: item.subtotal,
      }))
    })
  }

  // Add product (optimistic via useMutation in component)
  const addProduct = (product: ProductInput, quantity = 1) => {
    const entry = productToEntry(product, { quantity, selected: true })
    if (entry) list.add(entry)
  }

  const store: CartStore = {
    ...list,
    sync,
    addProduct,
  }

  return (
    <CartContext.Provider value={store}>
      {props.children}
    </CartContext.Provider>
  )
}
```

---

## 5. UI Components Structure

```
components/ui/cart/
├── index.ts                    # Barrel exports
├── cart.tsx                   # Main cart wrapper
├── cart-item.tsx              # Single cart item
├── cart-items.tsx            # List of items
├── cart-summary.tsx          # Totals display
├── cart-empty.tsx            # Empty state
├── cart-loading.tsx          # Loading skeleton
├── cart-error.tsx             # Error state
├── cart-quantity-selector.tsx # Quantity picker
├── cart-remove-button.tsx    # Remove item
├── cart-checkbox.tsx         # Select item
├── cart-checkout-button.tsx  # Checkout CTA
├── cart-promo-input.tsx       # Discount code
└── cart-validate-banner.tsx  # Stock warnings
```

---

## 6. Component Examples

### Cart Items (components/ui/cart/cart-items.tsx)

```typescript
import { For, Show } from 'solid-js'
import { useCart } from '~/lib/stores/cart'
import { useStoreContext } from '~/lib/stores/store-context'
import { useAddToCart, useUpdateCartItem, useRemoveFromCart } from '~/lib/hooks/useCart'
import { CartItem } from './cart-item'
import { CartLoading } from './cart-loading'
import { CartEmpty } from './cart-empty'

export function CartItems(props: { class?: string }) {
  const cart = useCart()
  const storeId = useCurrentStoreId()
  
  const addMutation = useAddToCart()
  const updateMutation = useUpdateCartItem()
  const removeMutation = useRemoveFromCart()
  
  return (
    <div class={props.class}>
      <Show when={!addMutation.isPending} fallback={<CartLoading />}>
        <Show when={cart.items().length > 0} fallback={<CartEmpty />}>
          <For each={cart.items()}>
            {(item) => (
              <CartItem
                item={item}
                onQuantityChange={(qty) => 
                  updateMutation.mutate({ 
                    storeId: storeId(), 
                    itemId: item.id, 
                    quantity: qty 
                  })
                }
                onRemove={() => 
                  removeMutation.mutate({ 
                    storeId: storeId(), 
                    itemId: item.id 
                  })
                }
              />
            )}
          </For>
        </Show>
      </Show>
    </div>
  )
}
```

### Add to Cart Button (components/ui/product/ProductAddToCartTrigger.tsx)

```typescript
import { Button } from '../button'
import { useStoreContext } from '~/lib/stores/store-context'
import { useAddToCart } from '~/lib/hooks/useCart'
import { useProduct } from './product-context'

export function ProductAddToCartTrigger(props: { class?: string }) {
  const product = useProduct()
  const storeId = useCurrentStoreId()
  const addMutation = useAddToCart()
  
  const handleClick = () => {
    addMutation.mutate({
      storeId: storeId(),
      product: {
        id: product.data.id,
        name: product.data.name,
        price: product.data.price,
        image: product.data.image,
      },
      quantity: 1,
    })
  }
  
  return (
    <Button 
      class={props.class}
      onClick={handleClick}
      disabled={addMutation.isPending}
    >
      {addMutation.isPending ? 'Adding...' : 'Add to Cart'}
    </Button>
  )
}
```

---

## 7. Query Keys (lib/query-keys.ts)

```typescript
export const cartKeys = {
  all: ['cart'] as const,
  store: (storeId: string) => ['cart', 'store', storeId] as const,
  items: (storeId: string) => ['cart', 'store', storeId, 'items'] as const,
  summary: (storeId: string) => ['cart', 'store', storeId, 'summary'] as const,
}

export const productKeys = {
  all: ['products'] as const,
  list: (storeId: string, filters?: object) => 
    ['products', 'list', storeId, filters] as const,
  detail: (storeId: string, productId: string) => 
    ['products', 'detail', storeId, productId] as const,
}
```

---

## 8. Implementation Phases

### Phase 1: Core Infrastructure
- [x] Create `lib/hooks/useCart.ts` with cart API functions (simplified, no TanStack Query mutations)
- [x] Create `lib/hooks/useCartGuestId.ts` for guest ID management
- [x] Create `lib/query-keys.ts`
- [x] Create `components/ui/cart/cart-context.tsx` - Cart context with server sync
- [x] Create `components/ui/cart/cart-sections.tsx` - UI components
- [x] Create `components/ui/cart/index.ts` - Barrel exports
- [ ] **INCOMPLETE**: TanStack Query mutations with optimistic updates (using simpler async/await instead)
- [ ] **INCOMPLETE**: Full guest cart merge on login (basic guest ID only)

### Phase 2: UI Components
- [x] Create `components/ui/cart/` structure (combined in cart-sections.tsx)
- [x] Implement CartItems, CartItem components
- [x] Add CartIcon with badge count
- [x] Add loading/error states via CartProvider
- [x] Add quantity controls (CartItemQuantity)
- [x] Add CartSummary, CartEmpty, CartCheckoutTrigger, CartClearTrigger
- [ ] **INCOMPLETE**: CartValidateBanner (stock warnings)
- [ ] **INCOMPLETE**: CartPromoInput full implementation

### Phase 3: Validation & Errors
- [ ] Implement cart validation
- [ ] Add stock checking
- [ ] Handle price changes
- [ ] Add error banners

### Phase 4: Enterprise Features
- [ ] Promo codes (basic UI exists, not connected to API)
- [ ] Multi-currency support
- [ ] Cart persistence (offline)
- [ ] Analytics/events

---

## 9. Server Endpoints Required

```
GET    /stores/:storeId/cart                    # Get cart
POST   /stores/:storeId/cart/items              # Add item
PUT    /stores/:storeId/cart/items/:id          # Update quantity
DELETE /stores/:storeId/cart/items/:id         # Remove item
DELETE /stores/:storeId/cart                    # Clear cart
POST   /stores/:storeId/cart/validate           # Validate cart
POST   /stores/:storeId/cart/promo              # Apply promo
DELETE /stores/:storeId/cart/promo              # Remove promo
```

---

## 10. Testing Strategy

### Unit Tests
- Cart store actions
- Item list calculations
- Optimistic update logic

### Integration Tests
- Cart API calls
- Server sync
- Error handling

### E2E Tests
- Add to cart flow
- Update quantity
- Remove item
- Checkout flow
- Offline behavior

---

## 11. Guest Cart Support

### Overview

Guest carts allow users to add items without authentication. On login/signup, the guest cart is merged with the user's cart.

### Implementation

```typescript
// lib/stores/cart.tsx - Guest cart support

const GUEST_CART_KEY = 'guest_cart_id'

// Generate or retrieve guest ID
function getGuestId(): string {
  const stored = localStorage.getItem(GUEST_CART_KEY)
  if (stored) return stored
  
  const newId = crypto.randomUUID()
  localStorage.setItem(GUEST_CART_KEY, newId)
  return newId
}

export const CartProvider: ParentComponent<{ 
  storeId: string
  initialCart?: Cart 
}> = (props) => {
  const [isGuest, setIsGuest] = createSignal(false)
  const [guestId] = createSignal(getGuestId())
  
  // Determine if authenticated
  const auth = useAuth() // Your auth context
  
  // Fetch appropriate cart based on auth status
  const cartQuery = createQuery(() => ({
    queryKey: cartKeys.store(props.storeId),
    queryFn: () => {
      if (auth.isAuthenticated()) {
        return cartApi.getForUser(props.storeId)
      }
      return cartApi.getForGuest(props.storeId, guestId())
    },
  }))
  
  // Merge guest cart on login
  const mergeGuestCart = useMutation({
    mutationFn: () => cartApi.mergeGuestCart(props.storeId, guestId()),
    onSuccess: () => {
      localStorage.removeItem(GUEST_CART_KEY)
      setIsGuest(false)
    }
  })
  
  // Watch for auth changes
  createEffect(() => {
    if (auth.isAuthenticated() && isGuest()) {
      mergeGuestCart.mutate()
    }
  })
}
```

### Guest Cart API Endpoints

```typescript
// lib/api/cart.ts

export const cartApi = {
  // ... existing methods
  
  // Guest-specific
  getForGuest: async (storeId: string, guestId: string): Promise<Cart> => {
    const csrfToken = getCsrfToken()
    return api.get(
      `/stores/${storeId}/cart/guest/${guestId}`, 
      csrfToken ?? undefined
    )
  },
  
  createGuestCart: async (storeId: string, guestId: string): Promise<Cart> => {
    const csrfToken = getCsrfToken()
    return api.post(
      `/stores/${storeId}/cart/guest`,
      { guestId },
      csrfToken ?? undefined
    )
  },
  
  mergeGuestCart: async (storeId: string, guestId: string): Promise<Cart> => {
    const csrfToken = getCsrfToken()
    return api.post(
      `/stores/${storeId}/cart/merge`,
      { guestId },
      csrfToken ?? undefined
    )
  },
}
```

### Cart Provider with Guest Support

```typescript
// Complete cart provider with guest support

export const CartProvider: ParentComponent<{ 
  storeId: string
}> = (props) => {
  const queryClient = useQueryClient()
  const auth = useAuth()
  const [guestId] = createSignal(getOrCreateGuestId())
  
  // Fetch cart based on auth status
  const cartQuery = createQuery(() => ({
    queryKey: cartKeys.store(props.storeId),
    queryFn: () => {
      if (auth.isAuthenticated()) {
        return cartApi.getForUser(props.storeId)
      }
      // Try to get guest cart, or create one
      return cartApi.getForGuest(props.storeId, guestId())
        .catch(() => cartApi.createGuestCart(props.storeId, guestId()))
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  }))
  
  // Mutations with optimistic updates
  const addItem = useAddToCart(props.storeId, guestId())
  const updateItem = useUpdateCartItem(props.storeId)
  const removeItem = useRemoveFromCart(props.storeId)
  const clearCart = useClearCart(props.storeId)
  
  // Merge on login
  createEffect(() => {
    if (auth.isAuthenticated()) {
      cartApi.mergeGuestCart(props.storeId, guestId())
        .then((mergedCart) => {
          queryClient.setQueryData(cartKeys.store(props.storeId), mergedCart)
          localStorage.removeItem(GUEST_CART_KEY)
        })
    }
  })
  
  // Provide cart context
  const store: CartStore = {
    get items() { return cartQuery.data?.items ?? [] },
    get count() { return store.items.length },
    get subtotal() { return calculateSubtotal(store.items) },
    get isEmpty() { return store.count === 0 },
    addProduct: (product) => addItem.mutate({ product }),
    updateQuantity: (itemId, qty) => updateItem.mutate({ itemId, quantity: qty }),
    removeItem: (itemId) => removeItem.mutate({ itemId }),
    clear: () => clearCart.mutate(),
  }
  
  return (
    <CartContext.Provider value={store}>
      {props.children}
    </CartContext.Provider>
  )
}
```

### Guest Cart Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    Guest Cart Flow                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. User visits site (not logged in)                     │
│     ↓                                                      │
│  2. Generate guest ID (or retrieve from localStorage)      │
│     ↓                                                      │
│  3. Create/fetch guest cart via API                       │
│     ↓                                                      │
│  4. User adds items → Optimistic update → Server sync     │
│     ↓                                                      │
│  5. User logs in / signs up                               │
│     ↓                                                      │
│  6. Merge guest cart with user cart                       │
│     ↓                                                      │
│  7. Clear guest ID from localStorage                       │
│     ↓                                                      │
│  8. Continue with user cart                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Server Endpoints for Guest Cart

```
GET    /stores/:storeId/cart/guest/:guestId    # Get guest cart
POST   /stores/:storeId/cart/guest              # Create guest cart
POST   /stores/:storeId/cart/merge             # Merge guest → user cart
```

### Summary: Guest Cart Features

| Feature | Implementation |
|---------|----------------|
| Guest ID generation | crypto.randomUUID() stored in localStorage |
| Cart persistence | Server-side with guestId |
| Merge on login | Automatic merge mutation |
| Offline support | localStorage + TanStack persist |
| Multiple devices | Not supported (guest cart is device-specific) |

| Component | Status | Notes |
|-----------|--------|-------|
| State Management | ✅ Done | cart-context.tsx with signals |
| Server Sync | ✅ Done | Basic async/await (no TanStack Query mutations) |
| Guest Support | ⚠️ Partial | Guest ID in localStorage, no auto-merge on login |
| Optimistic Updates | ❌ Not Done | Using simple async/await |
| Error Handling | ⚠️ Basic | Error state in context, no rollback |
| Offline | ❌ Not Done | Not implemented |
| Cart Scope | ✅ Done | Per-store via storeId |
| UI Components | ✅ Done | Most components in cart-sections.tsx |

## Current Implementation Summary

### Files Created:
- `lib/query-keys.ts` - Query key factory
- `lib/hooks/useCart.ts` - Cart API functions (simplified)
- `lib/hooks/useCartGuestId.ts` - Guest ID management
- `components/ui/cart/cart-context.tsx` - Cart context with server sync
- `components/ui/cart/cart-sections.tsx` - All UI components
- `components/ui/cart/index.ts` - Exports

### Demo Routes:
- `/store` - Product listing with CartIcon
- `/store/product/[id]` - Product detail
- `/store/cart` - Cart page

### What's Missing for Full Production:
1. TanStack Query mutations with optimistic updates
2. Auto-merge guest cart on user login
3. Cart validation API integration
4. Full promo code support
5. Offline persistence
