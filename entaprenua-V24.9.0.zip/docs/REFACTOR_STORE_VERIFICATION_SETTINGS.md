# Store Verification Settings Refactor Plan

**Date:** 2026-04-05  
**Status:** Planned (Not Started)  
**Priority:** Medium (Post-MVP)  
**Reason:** Storefronts will use guest checkouts at start, so verification settings not needed initially.

---

## Overview

Move verification-related settings from the `stores` table to a separate `store_verification_settings` table for better organization and scalability.

## Current State

Verification fields currently in `stores` table (lines 36-45 in `Store.kt`):

| Field | Type | Purpose |
|-------|------|---------|
| `verificationRedirectUrl` | String | Redirect URL after verification |
| `verificationEmailSubject` | String | Custom email subject |
| `verificationSuccessRedirectUrl` | String | Redirect after successful verification |
| `verificationSenderName` | String | Sender name for emails |
| `verificationSenderEmail` | String | Sender email |
| `verificationEmailTemplate` | String | Custom email template (JSON/text) |
| `verificationExpiryHours` | Int | Token expiry time |
| `verificationSubdomain` | String | Verification subdomain |
| `verificationCustomDomain` | String | Custom domain |

## Proposed Schema

```sql
CREATE TABLE store_verification_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    enabled BOOLEAN DEFAULT true,
    redirect_url VARCHAR(500),
    email_subject VARCHAR(255),
    success_redirect_url VARCHAR(500),
    sender_name VARCHAR(100),
    sender_email VARCHAR(255),
    email_template TEXT,
    expiry_hours INT DEFAULT 24,
    subdomain VARCHAR(100),
    custom_domain VARCHAR(255),
    callback_url VARCHAR(500),           -- NEW: email verification callback URL
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(store_id)
);

CREATE INDEX idx_verification_settings_store_id ON store_verification_settings(store_id);
```

## Column Renames (removing `verification` prefix)

| Old Column (in stores) | New Column |
|------------------------|------------|
| `verificationRedirectUrl` | `redirect_url` |
| `verificationEmailSubject` | `email_subject` |
| `verificationSuccessRedirectUrl` | `success_redirect_url` |
| `verificationSenderName` | `sender_name` |
| `verificationSenderEmail` | `sender_email` |
| `verificationEmailTemplate` | `email_template` |
| `verificationExpiryHours` | `expiry_hours` |
| `verificationSubdomain` | `subdomain` |
| `verificationCustomDomain` | `custom_domain` |

## New Field

| Field | Type | Description |
|-------|------|-------------|
| `callback_url` | VARCHAR(500) | URL for email verification callbacks |

## API Endpoints

```
GET    /settings/verification    - Get verification settings
PUT    /settings/verification    - Update verification settings
DELETE /settings/verification    - Delete (reset to defaults)
```

## Migration Steps

### Phase 1: Database
1. Create `store_verification_settings` table (V__store_verification_settings.sql)
2. Create migration to copy data from `stores` to new table (V__migrate_verification_settings.sql)
3. Remove old columns from `stores` table (V__remove_stores_verification_columns.sql)

### Phase 2: Backend
1. Create `VerificationSettings.kt` entity
2. Create `VerificationSettingsDto.kt` DTOs
3. Create `VerificationSettingsRepository.kt`
4. Create `VerificationSettingsService.kt`
5. Add API routes in `ApiRouterConfig.kt`
6. Update `StoreServiceImpl.kt` to use new table
7. Update `EmailVerificationService.kt` to use new table
8. Update `Store.kt` entity to remove old columns

### Phase 3: Frontend (if needed)
1. Create/update settings UI for verification configuration

## Files to Create/Modify

### New Files
- `db/migration/V__store_verification_settings.sql`
- `db/migration/V__migrate_verification_settings.sql`
- `db/migration/V__remove_stores_verification_columns.sql`
- `src/main/kotlin/.../entities/VerificationSettings.kt`
- `src/main/kotlin/.../dtos/VerificationSettingsDto.kt`
- `src/main/kotlin/.../repositories/VerificationSettingsRepository.kt`
- `src/main/kotlin/.../services/VerificationSettingsService.kt`

### Files to Modify
- `src/main/kotlin/.../entities/Store.kt` (remove verification columns)
- `src/main/kotlin/.../services/EmailVerificationService.kt` (use new table)
- `src/main/kotlin/.../store/impl/StoreServiceImpl.kt` (use new table)
- `src/main/kotlin/.../config/ApiRouterConfig.kt` (add routes)

## Notes

- Pattern follows `store_payment_credentials` table design
- Credentials (if any) should stay in separate encrypted table
- Consider unifying with generic `store_settings` table in future for all non-credential settings
