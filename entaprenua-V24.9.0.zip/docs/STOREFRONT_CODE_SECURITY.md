# Storefront Code Security

**Last Updated**: 2026-03-31  
**Status**: 📋 Planned

---

## Overview

Storefront code is restricted to UI-only (JSX) with no scripting. This ensures:
1. **Security**: No malicious code can execute
2. **Safety**: Users can't break the platform
3. **Simplicity**: Non-technical users can build stores
4. **Consistency**: All storefronts follow the same patterns

---

## What Users Can Write

Users can only write **JSX/TSX files** that define page layouts using allowed components.

### Allowed

```
✅ .tsx and .jsx files only
✅ JSX elements (components)
✅ Component props (typed by our components)
✅ HTML element string/number attributes (src, href, alt, width, etc.)
✅ Text content
✅ Basic imports from ~/ paths
✅ The `class` prop for styling
```

### Disallowed

```
❌ .ts, .js, .mjs files
❌ Script code (functions, variables, etc.)
❌ React/Solid hooks (useState, useEffect, etc.)
❌ Imports from external packages (no 'solid-js', 'react', etc.)
❌ Event handlers (onClick, onChange, etc.)
❌ Dynamic expressions (ternary, &&, ||, function calls, etc.)
❌ eval() or Function()
❌ Access to process, console, global, window
```

---

## Why String/Number Attributes Are Safe

### The Attack Surface

Many security concerns only apply when **user input** flows into attributes:

| Attribute | User Input? | Risk |
|-----------|-------------|------|
| `src="/image.png"` | Hardcoded string | ✅ Safe |
| `src={userValue}` | User input | ⚠️ Could load tracking pixel |
| `href="/page"` | Hardcoded string | ✅ Safe |
| `href={url}` | User input | ⚠️ Could link to malicious site |
| `onClick={handler}` | Function | ❌ Blocked - event handlers |

### In Our Model

- **Hardcoded strings/numbers** → Safe, allowed
- **User input flowing into attributes** → Blocked by design (no variables in props)
- **Event handlers** → Blocked (no functions allowed)
- **Function calls** → Blocked (no script code)

### What String/Number Attributes Can Do

```html
<!-- All safe - hardcoded values only -->
<img src="/logo.png" alt="Company Logo" width="200" height="100" />
<a href="/products" title="View all products">Shop Now</a>
<input type="email" name="email" placeholder="Enter email" maxlength="50" />
<video src="/intro.mp4" width="640" height="360" poster="/thumb.jpg" />
```

**Nothing malicious can happen** — strings are just text, numbers are just values. No execution, no network requests without our validation, no DOM manipulation.

---

## Component Model

### Two Types of Elements

#### 1. Allowed Components (Typed Props)

Components from our library have **TypeScript-validated props**:

```tsx
// ✅ VALID - Image is an allowed component with typed props
import { Image } from '~/components/Image'
import { ProductCard } from '~/components/ProductCard'

function ProductPage() {
  return (
    <div class="p-4">
      <Image src="/product.jpg" alt="Product" width={400} height={300} />
      <ProductCard 
        name="T-Shirt"
        price={29.99}
        image="/tshirt.jpg"
      />
    </div>
  )
}
```

**TypeScript enforces:**
- `Image` only accepts valid props (`src`, `alt`, `width`, `height`, etc.)
- `ProductCard` only accepts `name`, `price`, `image`, etc.
- Invalid props cause a **compile error**, not runtime issue

#### 2. HTML Elements (String/Number Props)

Standard HTML elements allow **string and number attributes**:

```tsx
// ✅ VALID - HTML elements allow string/number attributes
<img src="/image.png" alt="Product image" width={200} height={150} />
<a href="/products" title="View products">Shop Now</a>
<input type="text" name="search" placeholder="Search..." maxlength={100} />
<video src="/video.mp4" width={640} poster="/thumb.jpg" controls />

// ❌ INVALID - No event handlers
<button onClick={handleClick}>Click</button>

// ❌ INVALID - No function calls in attributes
<img src={getImageUrl()} />

// ❌ INVALID - No expressions
<div data-value={count + 1} />
```

---

## Import Rules

### Allowed Imports

```
solid-js                   # Control flow (Show, Switch, Match)
@solidjs/meta             # SEO metadata (Title, Meta, Link)
lucide-solid              # Icons
~/lib/utils               # Utilities (cn, splitProps, mergeProps)
~/components/...           # Our component library
~/components/layout/...
~/components/product/...
~/components/cart/...
~/icons/...                # Icon library
```
~/lib/utils                 # Utilities (cn, splitProps, mergeProps)
~/lib/utils                 # Utilities (splitProps, mergeProps, cn)
~/components/...            # Our component library
~/components/layout/...
~/components/product/...
~/components/cart/...
~/icons/...                 # Icon library
```

### Disallowed Imports

```
❌ 'solid-js' (reactive)   // No hooks (useState, useEffect, etc.)
❌ 'react'                   // No React
❌ '@solidjs/router'         // No router config
❌ '@solidjs/meta' Script    // No <Script> tags
❌ 'axios'                   // No HTTP requests
❌ Any npm package           // Only our allowed imports
❌ Relative paths except ~/  // No ../../ paths
```

### Allowed solid-js Imports

Only these are allowed from `solid-js`:

| Import | Purpose |
|--------|---------|
| `Show` | Conditional rendering (replaces `&&`) |
| `Switch` / `Match` | Branching (replaces `? :`) |
| `splitProps` | Destructure props |
| `mergeProps` | Merge prop objects |

### Allowed @solidjs/meta Imports

Only these are allowed from `@solidjs/meta`:

| Import | Purpose |
|--------|---------|
| `Title` | Page title for SEO |
| `Meta` | Meta tags (description, keywords) |
| `Link` | Link tags (favicon, stylesheets) |
| `Style` | Inline styles |
| `JsonLd` | Structured data |

**Note**: `<Script>` is not allowed. No external scripts from user code.

### Import Examples

```tsx
// ✅ VALID
import { Show, Switch, Match } from 'solid-js'
import { cn, splitProps, mergeProps } from '~/lib/utils'
import { Button, Card, Container } from '~/components/ui'
import { ProductCard } from '~/components/product/ProductCard'
import { ShoppingCartIcon } from '~/icons'
import { StoreSection } from '~/components/StoreSection'  // User component
import { HeroBanner } from '~/components/HeroBanner'       // User component

// ❌ INVALID - No hooks or reactive primitives
import { createSignal, createEffect } from 'solid-js'
import axios from 'axios'
import { useNavigate } from '@solidjs/router'
import { formatPrice } from '../../utils'
```

---

## User-Created Reusable Components

### Location

User-created components go in `src/components/`:

```
src/
├── components/
│   ├── ui/                    # Platform components
│   │   ├── Button.tsx
│   │   ├── Card.tsx
│   │   └── Container.tsx
│   ├── layout/                # Platform layout components
│   │   ├── Header.tsx
│   │   └── Footer.tsx
│   ├── product/               # Platform product components
│   │   └── ProductCard.tsx
│   ├── StoreSection.tsx       # User component (root level)
│   ├── HeroBanner.tsx         # User component
│   └── CustomCard.tsx         # User component
├── lib/
│   └── cn.ts                  # Utilities
└── routes/
    └── index.tsx              # Pages
```

### Allowed Props for User Components

User components can define props with these types:

| Type | Example | Allowed |
|------|---------|---------|
| `string` | `title: string` | ✅ |
| `number` | `count: number` | ✅ |
| `boolean` | `show: boolean` | ✅ |
| `children` | `children: any` | ✅ |
| Optional modifier | `class?: string` | ✅ |

### Example: User Component

```tsx
// src/components/StoreSection.tsx
import { Container } from '~/components/ui'
import { SectionHeading } from '~/components/SectionHeading'
import { cn } from '~/lib/utils'

// Props: string, children, and optional class
function StoreSection(props: { 
  title: string
  children: any
  class?: string
}) {
  return (
    <section class={cn('py-16', props.class)}>
      <Container>
        <SectionHeading title={props.title} />
        <div class={cn('grid grid-cols-1 md:grid-cols-3 gap-6')}>
          {props.children}
        </div>
      </Container>
    </section>
  )
}
```

### Example: User Component Usage

```tsx
// src/routes/index.tsx
import { StoreSection } from '~/components/StoreSection'
import { HeroBanner } from '~/components/HeroBanner'
import { ProductCard } from '~/components/product/ProductCard'

function HomePage() {
  return (
    <div>
      <HeroBanner 
        title="Welcome"
        subtitle="Shop the best products"
        image="/hero.jpg"
      />
      
      <StoreSection 
        title="Featured Products"
        class="bg-gray-50"
      >
        <ProductCard name="T-Shirt" price={29.99} image="/img.jpg" />
        <ProductCard name="Jeans" price={59.99} image="/img2.jpg" />
        <ProductCard name="Shoes" price={89.99} image="/img3.jpg" />
      </StoreSection>
    </div>
  )
}
```

### What's Allowed in User Components

```
✅ Props with string, number, boolean, children
✅ Optional class prop (for styling)
✅ Allowed component imports (~/components/*)
✅ Allowed utility imports (~/lib/utils)
✅ solid-js control flow (Show, Switch, Match)
✅ Text content
✅ Spread props {...props} (passes through to final usage)
✅ Conditional rendering with Show
```

### What's NOT Allowed in User Components

```
❌ Function declarations
❌ Hooks (createSignal, createEffect, createMemo, etc.)
❌ Reactive primitives from solid-js
❌ Event handlers (explicit, at final usage)
❌ Function calls in JSX (except platform components)
❌ Variables (const, let, var)
❌ && operator (use <Show> instead)
❌ Ternary operator ? : (use <Switch>/<Match> instead)
```

---

## Validation Rules

### 1. File Extension Validation

```typescript
const ALLOWED_EXTENSIONS = ['.tsx', '.jsx']
const DISALLOWED_EXTENSIONS = ['.ts', '.js', '.mjs', '.cjs']

function validateExtension(filename: string): boolean {
  return ALLOWED_EXTENSIONS.some(ext => filename.endsWith(ext))
}
```

### 2. Import Validation

```typescript
const ALLOWED_IMPORT_PREFIXES = ['~/']
const ALLOWED_NAMED_IMPORTS = new Set([
  // solid-js control flow
  'Show', 'Switch', 'Match',
  // solid-js utilities
  'splitProps', 'mergeProps',
])

function validateImports(ast): string[] {
  const errors = []
  
  traverse(ast, {
    ImportDeclaration(path) {
      const source = path.node.source.value
      
      // Allow ~/ imports
      if (ALLOWED_IMPORT_PREFIXES.some(prefix => source.startsWith(prefix))) {
        return
      }
      
      // Allow solid-js for specific imports only
      if (source === 'solid-js') {
        for (const spec of path.node.specifiers) {
          const name = spec.local?.name || spec.imported?.name
          if (!ALLOWED_NAMED_IMPORTS.has(name)) {
            errors.push(`'${name}' not allowed from 'solid-js'. Allowed: ${[...ALLOWED_NAMED_IMPORTS].join(', ')}`)
          }
        }
        return
      }
      
      errors.push(`Only ~/ imports or allowed solid-js imports. Found: "${source}"`)
    }
  })
  
  return errors
}
```

### 3. No Script Code

```typescript
const DISALLOWED_PATTERNS = [
  { pattern: /use[A-Z]\w+\s*\(/, message: 'Hooks not allowed' },
  { pattern: /\bfunction\s+\w+/, message: 'Function declarations not allowed' },
  { pattern: /const\s+\w+\s*=\s*(?:function|\(|\d)/, message: 'Function expressions not allowed' },
  { pattern: /=>\s*(?:function|\(|\d)/, message: 'Arrow functions not allowed' },
  { pattern: /\bconsole\./, message: 'console not allowed' },
  { pattern: /\bprocess\./, message: 'process not allowed' },
  { pattern: /\bglobal\./, message: 'global not allowed' },
  { pattern: /\bwindow\./, message: 'window not allowed' },
]

function validateNoScript(code: string): string[] {
  const errors = []
  
  for (const { pattern, message } of DISALLOWED_PATTERNS) {
    if (pattern.test(code)) {
      errors.push(message)
    }
  }
  
  return errors
}
```

### 4. Props Validation

```typescript
// Allowed components have their props validated by TypeScript
// HTML elements allow string/number attributes only

const HTML_ELEMENTS = new Set([
  'div', 'span', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
  'ul', 'ol', 'li', 'a', 'img', 'br', 'hr', 'form', 'input',
  'button', 'table', 'thead', 'tbody', 'tr', 'td', 'th',
  'section', 'header', 'footer', 'nav', 'main', 'aside',
  'video', 'audio', 'source', 'track', 'embed', 'object', 'param',
  'canvas', 'map', 'area', 'svg', 'path', 'circle', 'rect', 'line',
  'polyline', 'polygon', 'text', 'tspan', 'use', 'defs', 'g',
  'meta', 'link', 'style', 'base', 'title', 'script', 'noscript',
  'template', 'slot', 'slot',
])

// String/number attribute names (allowed on HTML elements)
const ALLOWED_HTML_ATTRS = new Set([
  // Global
  'id', 'class', 'className', 'style', 'title', 'lang', 'dir',
  'accesskey', 'tabindex', 'translate', 'draggable', 'spellcheck',
  'hidden', 'slot', 'part', 'exportparts',
  
  // Content
  'name', 'value', 'placeholder', 'autocomplete', 'autocapitalize',
  
  // Media
  'src', 'alt', 'width', 'height', 'href', 'target', 'rel',
  'poster', 'controls', 'autoplay', 'loop', 'muted', 'preload',
  'crossorigin', 'usemap', 'ismap', 'loading', 'decoding',
  
  // Form
  'type', 'checked', 'selected', 'disabled', 'readonly', 'required',
  'multiple', 'size', 'maxlength', 'minlength', 'min', 'max',
  'step', 'pattern', 'accept', 'capture', 'form', 'formaction',
  'formenctype', 'formmethod', 'formnovalidate', 'formtarget',
  
  // Table
  'colspan', 'rowspan', 'headers', 'scope', 'span',
  
  // Lists
  'start', 'reversed', 'type', // ol type
  
  // ARIA & Accessibility
  'role', 'aria-label', 'aria-labelledby', 'aria-describedby',
  'aria-hidden', 'aria-expanded', 'aria-pressed', 'aria-checked',
  'aria-disabled', 'aria-selected', 'aria-current', 'aria-controls',
  'aria-flowto', 'aria-orientation',
  
  // Data attributes
  'data-*',
  
  // SVG specific (geometry - not style)
  'viewBox', 'd', 'cx', 'cy', 'r', 'rx', 'ry', 'x', 'y',
  'x1', 'y1', 'x2', 'y2', 'points', 'pathLength',
  'preserveaspectratio', 'transform', 'fill', 'stroke', 'stroke-width',
  'stroke-dasharray', 'stroke-dashoffset', 'stroke-linecap', 'stroke-linejoin',
  'fill-rule', 'clip-rule', 'opacity', 'stroke-opacity', 'fill-opacity',
  'clip-path', 'mask', 'filter', 'marker-start', 'marker-end', 'marker-mid',
])

function validateProps(ast): string[] {
  const errors = []
  
  traverse(ast, {
    JSXElement(path) {
      const name = getElementName(path.node)
      
      // HTML elements - allow string/number attributes
      if (HTML_ELEMENTS.has(name)) {
        for (const attr of path.node.attributes) {
          if (attr.type === 'JSXAttribute') {
            const attrName = attr.name.name
            
            // Allow known safe attributes
            if (ALLOWED_HTML_ATTRS.has(attrName)) {
              continue
            }
            
            // Allow data-* attributes
            if (attrName.startsWith('data-')) {
              continue
            }
            
          // Block event handlers and expressions
          if (attrName.startsWith('on')) {
            errors.push(`Event handlers not allowed: '${attrName}'`)
          } else if (attrName.startsWith('aria-')) {
            // aria-* allowed if not handled above
            continue
          } else {
            errors.push(`Unknown attribute on '<${name}>': '${attrName}'`)
          }
        }
          
        // Allow spread props - they pass through to somewhere else
        // Final usage will be validated when explicit attributes are passed
        // e.g., <Card {...props} /> is not final, but <Card onClick={x} /> is
        if (attr.type === 'JSXSpreadAttribute') {
          continue
        }
      }
      }
      // Allowed components - TypeScript handles prop validation
    }
  })
  
  return errors
}
```

### 5. Children Validation

```typescript
function validateChildren(ast): string[] {
  const errors = []
  
  traverse(ast, {
    JSXChild(path) {
      if (path.node.type === 'JSXExpressionContainer') {
        const expr = path.node.expression
        
        // Allow simple values
        const allowedTypes = ['Identifier', 'StringLiteral', 'NumericLiteral']
        
        // Disallow expressions
        const disallowedTypes = [
          'BinaryExpression',    // a + b
          'UnaryExpression',     // !a
          'ConditionalExpression', // a ? b : c
          'LogicalExpression',    // a && b
          'CallExpression',      // func()
          'MemberExpression',    // obj.prop (except simple identifiers)
          'ArrayExpression',     // [a, b]
          'ObjectExpression',    // {a: b}
        ]
        
        if (disallowedTypes.includes(expr.type)) {
          errors.push(`Complex expressions not allowed in JSX children. Found: ${expr.type}`)
        }
      }
    }
  })
  
  return errors
}
```

---

## Example: Valid Storefront Code

### User-Created Component

```tsx
// src/components/PromoBanner.tsx
import { Show } from 'solid-js'
import { Container } from '~/components/ui'
import { Button } from '~/components/ui'
import { cn, splitProps } from '~/lib/utils'

function PromoBanner(props: {
  title: string
  subtitle?: string
  image: string
  buttonText?: string
  class?: string
}) {
  const [local] = splitProps(props, ['title', 'subtitle', 'image', 'buttonText', 'class'])
  
  return (
    <div class={cn('relative bg-gray-900 text-white', local.class)}>
      <img 
        src={local.image} 
        alt={local.title}
        width={1200}
        height={400}
        class="w-full h-64 object-cover opacity-50"
      />
      <Container class="absolute inset-0 flex items-center">
        <div class="max-w-2xl">
          <h2 class="text-4xl font-bold mb-2">{local.title}</h2>
          <Show when={local.subtitle}>
            <p class="text-lg mb-4">{local.subtitle}</p>
          </Show>
          <Show when={local.buttonText}>
            <Button variant="primary">{local.buttonText}</Button>
          </Show>
        </div>
      </Container>
    </div>
  )
}
```

### Page File Using User Component

```tsx
// src/routes/index.tsx
import { PromoBanner } from '~/components/PromoBanner'
import { StoreSection } from '~/components/StoreSection'
import { ProductCard } from '~/components/product/ProductCard'

function HomePage() {
  return (
    <div>
      <PromoBanner 
        title="Summer Sale"
        subtitle="Up to 50% off"
        image="/summer-sale.jpg"
        buttonText="Shop Now"
      />
      
      <StoreSection title="Featured Products">
        <ProductCard name="T-Shirt" price={29.99} image="/img.jpg" />
        <ProductCard name="Jeans" price={59.99} image="/img2.jpg" />
        <ProductCard name="Shoes" price={89.99} image="/img3.jpg" />
      </StoreSection>
    </div>
  )
}
```

### HTML Elements with String/Number Props

```tsx
// ✅ VALID - All string/number attributes
<div class="p-4">
  <img src="/hero.jpg" alt="Hero image" width={1200} height={600} />
  <a href="/products" title="View all products">Shop Now</a>
  <input 
    type="email" 
    name="email" 
    placeholder="Enter your email"
    maxlength={100}
    autocomplete="email"
  />
  <video 
    src="/intro.mp4" 
    width={640} 
    height={360} 
    poster="/poster.jpg"
    controls
    autoplay
    muted
  />
</div>
```

---

## Example: Invalid Code

```tsx
// ✅ VALID - Using Show instead of &&
<Show when={local.subtitle}>
  <p class="text-lg mb-4">{local.subtitle}</p>
</Show>

// ✅ VALID - Using Switch/Match instead of ternary
<Switch>
  <Match when={type === 'success'}>
    <Alert variant="success">Success!</Alert>
  </Match>
  <Match when={type === 'error'}>
    <Alert variant="error">Error!</Alert>
  </Match>
</Switch>

// ❌ INVALID - Using && (not recommended in SolidJS)
{local.subtitle && <p>{local.subtitle}</p>}

// ❌ INVALID - Using ternary
{isLoggedIn ? <span>Hi</span> : <span>Bye</span>}

// ❌ INVALID - Has function declaration
function helper() {
  return 'value'
}

// ❌ INVALID - Has hook (createSignal, etc.)
import { createSignal } from 'solid-js'
const [count, setCount] = createSignal(0)

// ❌ INVALID - Has event handler
<button onClick={() => alert('hi')}>Click</button>

// ❌ INVALID - Has function call in attribute
<img src={getImageUrl()} />
```

### Using Show Correctly

```tsx
import { Show } from 'solid-js'

// ✅ VALID - Show with fallback
<Show when={local.subtitle} fallback={<DefaultText />}>
  <p class="text-lg mb-4">{local.subtitle}</p>
</Show>

// ✅ VALID - Show without fallback
<Show when={local.subtitle}>
  <p class="text-lg mb-4">{local.subtitle}</p>
</Show>
```

---

## Allowed Components Library

### Layout

```tsx
<Container>           // Max-width wrapper
<Section>             // Section with padding
<Flex>                // Flexbox wrapper
<Grid>                // CSS Grid wrapper
<Box>                 // Generic wrapper
```

### Typography

```tsx
<Heading level={1-6}>
<Text>
<Badge variant="success|warning|error|info">
<Link href="/products">
```

### Form

```tsx
<Input type="text|email|password" placeholder>
<Textarea placeholder>
<Select>
  <option>Option 1</option>
</Select>
<Checkbox label="Accept terms">
<Radio name="option" label="Option 1">
<Button variant="primary|secondary|ghost">
```

### Media

```tsx
<Image src alt width height>
<Icon name="shopping-cart">
<Video src poster width height controls>
<Audio src controls>
```

### Display

```tsx
<Card>
<CardHeader>
<CardContent>
<CardFooter>
<Table>
<TableRow>
<TableCell>
```

### Feedback

```tsx
<Spinner>
<Skeleton>
<Alert variant="success|warning|error|info">
<Tooltip content="Help text">
```

### Navigation

```tsx
<Nav>
<Menu>
<Breadcrumbs>
<Pagination>
```

### E-Commerce

```tsx
<ProductCard name price image>
<ProductGrid limit showFilters>
<CartDrawer>
<Navbar>
<Price amount currency>
<CategoryList>
```

---

## Build-Time Enforcement

### TypeScript Compilation

```json
// tsconfig.json in store template
{
  "compilerOptions": {
    "strict": true,
    "jsx": "preserve",
    "jsxImportSource": "solid-js",
    "types": ["@entaprenua/storefront-types"]
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules"]
}
```

### ESLint Rules

```javascript
// .eslintrc.json
{
  "rules": {
    // Allow ~/ imports and solid-js (control flow only)
    "no-restricted-imports": [
      "error",
      {
        "patterns": [
          "!*~/**",           // Allow ~/ imports
          "solid-js"          // Allow solid-js (but we check named imports)
        ]
      }
    ],
    "no-restricted-exports": [
      "error",
      {
        "names": [
          "createSignal", "createEffect", "createMemo", "createResource",
          "createStore", "createContext", "useContext",
          "batch", "untrack", "on", "createRoot", "createRenderEffect"
        ],
        "message": "This export is not allowed from solid-js"
      }
    ],
    "no-restricted-syntax": [
      "error",
      {
        "selector": "CallExpression[callee.name=/^create[A-Z]/]",
        "message": "SolidJS reactive primitives are not allowed"
      },
      {
        "selector": "CallExpression[callee.name=/^use[A-Z]/]",
        "message": "SolidJS hooks are not allowed"
      },
      {
        "selector": "FunctionDeclaration",
        "message": "Function declarations are not allowed"
      },
      {
        "selector": "VariableDeclaration[kind='let']",
        "message": "Variables (let) are not allowed"
      },
      {
        "selector": "VariableDeclaration[kind='const']",
        "message": "Variables (const) are not allowed"
      },
      {
        "selector": "JSXAttribute[name.name=/^on[A-Z]/]",
        "message": "Event handlers are not allowed"
      },
      {
        "selector": "LogicalExpression[operator='&&']",
        "message": "Use <Show> instead of && for conditional rendering"
      },
      {
        "selector": "ConditionalExpression",
        "message": "Use <Switch>/<Match> instead of ternary operator"
      }
    ],
    "no-console": "error",
    "no-new-func": "error",
    "no-eval": "error"
  }
}
```

### Build Pipeline Validation

```typescript
async function validateStorefrontBuild(repoPath: string) {
  const errors = []
  
  // 1. Check all files are .tsx or .jsx
  const files = await glob(`${repoPath}/src/**/*.{ts,js,tsx,jsx}`)
  for (const file of files) {
    if (file.endsWith('.ts') || file.endsWith('.js')) {
      errors.push(`Only .tsx and .jsx files allowed. Found: ${file}`)
    }
  }
  
  // 2. Parse and validate each JSX file
  for (const file of files.filter(f => f.endsWith('.tsx') || f.endsWith('.jsx'))) {
    const code = await readFile(file)
    const result = validateStorefrontCode(code, file)
    errors.push(...result.errors)
  }
  
  // 3. Run TypeScript check
  const tsResult = await exec('npx tsc --noEmit', { cwd: repoPath })
  if (tsResult.exitCode !== 0) {
    errors.push(...tsResult.stdout.split('\n'))
  }
  
  // 4. Run ESLint
  const eslintResult = await exec('npx eslint src/', { cwd: repoPath })
  if (eslintResult.exitCode !== 0) {
    errors.push(...eslintResult.stdout.split('\n'))
  }
  
  if (errors.length > 0) {
    throw new BuildValidationError(errors)
  }
}
```

---

## Error Messages

When validation fails, show clear messages:

```
┌─────────────────────────────────────────────────────────────┐
│  Build Failed                                                │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ✗ src/routes/index.tsx                                    │
│    │ Line 5: Imports from 'solid-js' are not allowed       │
│                                                             │
│  ✗ src/components/MyComponent.tsx                          │
│    │ Line 12: Function declarations are not allowed         │
│                                                             │
│  ✗ src/components/Button.tsx                               │
│    │ Line 8: 'onClick' prop not allowed                    │
│                                                             │
│  ✗ src/utils/helper.ts                                     │
│    │ .ts files are not allowed. Use .tsx instead.          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Related Documentation

- [VCS Integration](VCS_INTEGRATION.md) — Repository setup
- [Storefront Monitoring](STOREFRONT_MONITORING.md) — Resource monitoring

---

## Future Enhancements

1. **Visual error markers** — Show errors inline in GitHub web editor
2. **Component preview** — Live preview as user types
3. **Prop suggestions** — Autocomplete for component props
4. **Accessibility warnings** — Alert on missing alt text, etc.
