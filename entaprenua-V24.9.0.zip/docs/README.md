# Entaprenua Client Documentation

## Pages

| Route | Page | Description |
|-------|------|-------------|
| `/` | Home | Landing page with features showcase |
| `/templates` | Templates | Browse marketplace templates |
| `/templates/:id` | Template Detail | Preview and use template |
| `/log-in` | Login | User authentication |
| `/sign-up` | Signup | User registration |
| `/stores` | Stores | User's stores management |
| `/stores/new` | New Store | Create new store (wizard) |
| `/stores/:id` | Store Detail | View/store settings |
| `/stores/:id/settings` | Store Settings | Configure store |
| `/stores/:id/build` | Store Build | Export/import store |
| `/admin` | Admin | Dashboard with store management |
| `/admin/products` | Products | Product management list |
| `/admin/products/new` | New Product | Create product |
| `/admin/products/:id` | Edit Product | Edit product with media/metadata |
| `/admin/categories` | Categories | Category management list |
| `/admin/categories/new` | New Category | Create category |
| `/admin/categories/:id` | Edit Category | Edit category with children |
| `/admin/orders` | Orders | Order management |
| `/admin/orders/:id` | Order Detail | View order details |
| `/admin/media` | Media | Media file management |
| `/admin/settings` | Settings | Store settings |
| `/docs` | Docs | Documentation |

## Routes

```typescript
import { routes } from '~/lib/utils/routes'

// Auth
routes.home         // "/"
routes.templates    // "/templates"
routes.templateDetails(id) // "/templates/:id"

// Stores
routes.stores         // "/stores"
routes.newStore       // "/stores/new"
routes.storeDetails(id)    // "/stores/:id"
routes.storeSettings(id)   // "/stores/:id/settings"
routes.storeBuild(id)     // "/stores/:id/build"
routes.storeClone(id)     // "/stores/:id/clone"

// Admin
routes.admin        // "/admin"
routes.adminProducts
routes.adminProduct(id)
routes.adminNewProduct
routes.adminCategories
routes.adminCategory(id)
routes.adminNewCategory
routes.adminOrders
routes.adminOrder(id)
routes.adminMedia
routes.adminSettings
```

## Authentication

### Cookie-Based Auth (HttpOnly)

The client uses HttpOnly cookies for secure authentication:

```typescript
import { AuthProvider, useAuth } from '~/lib/guards/auth'

// Wrap your app
<AuthProvider>
  <App />
</AuthProvider>

// Use in components
const { user, isAuthenticated, login, logout } = useAuth()
```

### Login
```typescript
const result = await login(email, password, rememberMe)
if (result.success) {
  navigate(routes.admin)
}
```

### Logout
```typescript
await logout()
```

## API Integration

All API calls use cookie-based authentication (credentials: 'include'):

```typescript
import { storesApi, productsApi, categoriesApi, ordersApi, mediaApi } from '~/lib/api'

// Stores
const stores = await storesApi.getAll()

// Products
const products = await productsApi.getAll(storeId, page, size)
const product = await productsApi.getById(id)
await productsApi.create(data)
await productsApi.update(id, data)
await productsApi.delete(id)

// Categories
const categories = await categoriesApi.getAll(storeId)
const category = await categoriesApi.getById(id, true) // with children
await categoriesApi.create(data)
await categoriesApi.update(id, data)
await categoriesApi.delete(id)
const rootCategories = await categoriesApi.getRootCategories(storeId)
const subcategories = await categoriesApi.getSubcategories(parentId)

// Orders
const orders = await ordersApi.getAll(storeId, page, size)
await ordersApi.updateStatus(id, status)

// Media
const media = await mediaApi.getByStore(storeId)
await mediaApi.upload(files, storeId)
```

## State Management

### Admin Panel Store

```typescript
import { AdminPanelProvider, useAdminPanel } from '~/lib/stores/admin-panel'

<AdminPanelProvider>
  <AdminDashboard />
</AdminPanelProvider>

// In component
const state = useAdminPanel()
const actions = useAdminPanel as Record<string, any>

// Access state
state.stores           // All user's stores
state.currentStore     // Currently selected store
state.products         // Products in current store
state.categories       // Categories in current store
state.orders           // Orders in current store
state.media            // Media in current store
state.isLoading        // Global loading state
state.error            // Global error state

// Use actions
actions.loadStores()
actions.switchStore(storeId)
actions.loadProducts()
actions.loadCategories()
actions.createProduct(data)
actions.updateProduct(id, data)
actions.deleteProduct(id)
actions.createCategory(data)
actions.updateCategory(id, data)
actions.deleteCategory(id)
```

### Cart, Wishlist, Order Stores

```typescript
import { CartProvider, useCart } from '~/lib/stores'
import { WishlistProvider, useWishlist } from '~/lib/stores'
import { OrderProvider, useOrder } from '~/lib/stores'
```

## Color Mode (Dark/Light Theme)

The app uses Kobalte's color-mode with cookie-based SSR support:

```typescript
import { ColorMode } from '~/components/ui/color-mode'
import { useColorMode } from '~/components/ui/color-mode'

// Wrap your app (already done in app.tsx)
<ColorMode>
  <App />
</ColorMode>

// Use in components
const { colorMode, toggleColorMode } = useColorMode()
```

The color mode is persisted in cookies (`kb-color-mode`) for proper SSR hydration.

## Components

### Auth Components
- `LoginForm`, `RegisterForm`, `PasswordResetForm`
- `EmailField`, `PasswordField`, `UsernameField`, `ConfirmPasswordField`
- `IdentityProviderButtons` (OAuth)

### UI Components
- `Card`, `Button`, `Input`, `Badge`
- `Flex`, `Grid`, `Box`
- `Text`, `Heading`, `Paragraph`

### Payment Components
- `PaymentRoot`, `PaymentAmount`, `PaymentStatusBadge`
- `PaymentMethodSelector`, `CheckoutForm`

## Architecture

```
src/
├── routes/
│   ├── index.tsx      # Home page
│   ├── admin.tsx      # Admin dashboard
│   ├── log-in.tsx    # Login page
│   ├── sign-up.tsx   # Signup page
│   └── demos/        # Demo pages
├── lib/
│   ├── api/          # API clients (cookie-based)
│   ├── stores/       # State management
│   ├── guards/       # Auth provider
│   ├── types/        # TypeScript types
│   └── utils/        # Utilities
├── components/ui/    # UI components
└── icons/           # Icon components
```

## Environment Variables

```env
VITE_API_URL=http://localhost:8080
```

## Best Practices

### Using Routes
```typescript
import { routes } from '~/lib/utils/routes'
import { A } from '@solidjs/router'

// Navigation
<A href={routes.admin}>Dashboard</A>

// Programmatic navigation
const navigate = useNavigate()
navigate(routes.adminProducts)
```

### Icons
Import icons from `~/icons`:
```typescript
import { ShoppingCartIcon, UserIcon, SettingsIcon } from '~/icons'
```

## Related Documentation

- [Store Creation Flow](pages/stores-creation.md) - Complete guide to creating stores
- [Server Auth Module](../../server/entaprenua/docs/AUTH_MODULE.md)
- [Server Payment Module](../../server/entaprenua/docs/PAYMENT_MODULE.md)
- [Cloudflare Setup](../../server/entaprenua/docs/CLOUDFLARE_SETUP.md)
- [Products Admin](pages/products-admin.md)
- [Categories Admin](pages/categories-admin.md)
- [AdminHeader Component](components/admin-header.md)
