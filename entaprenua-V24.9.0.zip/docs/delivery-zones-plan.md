# Delivery Zones Plan

## Model

Inspired by Shopify's zone-based shipping with shipping classes. Everything is a zone. City-level restriction is achieved by creating narrower zones — no per-product city overrides.

### Naming Convention

- **Zone** = a named group of destinations (countries + optional cities) that share the same shipping methods
- **Location** = a specific country row within a zone, with optional city restriction (empty = all cities)
- **Method** = a shipping option scoped to a zone (label + base price + conditions + delivery estimate)
- **Shipping Class** = a category for products that affect shipping price (e.g. "Heavy", "Fragile"). Products with no class use the method's base price.
- **Class Price Override** = a different price for a given method when applied to a specific shipping class
- **Product restriction**: a product is assigned to zones. It ships only to those zones' locations. No zones assigned = ships everywhere (default).

### Database Tables

```sql
-- V70__Create_delivery_zones.sql

-- 1. Shipping classes
CREATE TABLE shipping_classes (
    id UUID DEFAULT gen_random_uuid() NOT NULL,
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    position INTEGER DEFAULT 0,
    is_deleted BOOLEAN DEFAULT false,               -- soft delete: products FK to this
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    CONSTRAINT shipping_classes_pkey PRIMARY KEY (id)
);
CREATE INDEX idx_shipping_classes_store ON shipping_classes(store_id) WHERE is_deleted = false;

-- Add shipping_class_id + weight to products
ALTER TABLE products ADD COLUMN shipping_class_id UUID REFERENCES shipping_classes(id);
ALTER TABLE products ADD COLUMN weight DECIMAL(10,2);   -- kg, for weight-based conditions

-- 2. Delivery zones
CREATE TABLE delivery_zones (
    id UUID DEFAULT gen_random_uuid() NOT NULL,
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    position INTEGER DEFAULT 0,
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    CONSTRAINT delivery_zones_pkey PRIMARY KEY (id)
);
CREATE INDEX idx_delivery_zones_store ON delivery_zones(store_id);

-- 3. Zone locations
CREATE TABLE delivery_zone_locations (
    id UUID DEFAULT gen_random_uuid() NOT NULL,
    zone_id UUID NOT NULL REFERENCES delivery_zones(id) ON DELETE CASCADE,
    country VARCHAR(2) NOT NULL,                       -- ISO 3166-1 alpha-2
    cities JSONB DEFAULT '[]'::jsonb,                  -- [] = all cities, ["Nairobi"] = restricted
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    CONSTRAINT delivery_zone_locations_pkey PRIMARY KEY (id)
);
CREATE INDEX idx_delivery_zone_locations_zone ON delivery_zone_locations(zone_id);
CREATE INDEX idx_delivery_zone_locations_country ON delivery_zone_locations(country);

-- 4. Zone methods
CREATE TABLE delivery_zone_methods (
    id UUID DEFAULT gen_random_uuid() NOT NULL,
    zone_id UUID NOT NULL REFERENCES delivery_zones(id) ON DELETE CASCADE,
    method_id VARCHAR(50) NOT NULL,                   -- "standard", "express"
    label VARCHAR(255) NOT NULL,                      -- "Standard Delivery"
    price DECIMAL(10,2) NOT NULL,                     -- base price (used when product has no shipping class)
    conditions JSONB DEFAULT '{}'::jsonb,             -- {"minOrderAmount":5000,"freeShippingAbove":10000,"maxWeight":20,"minItems":1}
    est_min_days INTEGER,                             -- null = no estimate shown (e.g. pickup)
    est_max_days INTEGER,
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    CONSTRAINT delivery_zone_methods_pkey PRIMARY KEY (id)
);
CREATE INDEX idx_delivery_zone_methods_zone ON delivery_zone_methods(zone_id);

-- 5. Per-class price overrides (optional)
CREATE TABLE delivery_zone_method_class_prices (
    method_id UUID NOT NULL REFERENCES delivery_zone_methods(id) ON DELETE CASCADE,
    class_id UUID NOT NULL REFERENCES shipping_classes(id) ON DELETE CASCADE,
    price DECIMAL(10,2) NOT NULL,
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    CONSTRAINT method_class_prices_pkey PRIMARY KEY (method_id, class_id)
);

-- 6. Product↔zone junction
CREATE TABLE product_delivery_zones (
    id UUID DEFAULT gen_random_uuid() NOT NULL,
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    zone_id UUID NOT NULL REFERENCES delivery_zones(id) ON DELETE CASCADE,
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    CONSTRAINT product_delivery_zones_pkey PRIMARY KEY (id),
    CONSTRAINT product_delivery_zones_unique UNIQUE (product_id, zone_id)
);
CREATE INDEX idx_product_delivery_zones_product ON product_delivery_zones(product_id);
CREATE INDEX idx_product_delivery_zones_zone ON product_delivery_zones(zone_id);
```

No `cities` column on `product_delivery_zones`. City-level product restriction is done by creating a narrower zone and assigning the product to it.

### Conditions Structure

```json
{
  "minOrderAmount": 5000,
  "maxOrderAmount": null,
  "minWeight": null,
  "maxWeight": 20,
  "freeShippingAbove": 10000,
  "minItemCount": null
}
```

Empty object `{}` = no conditions, method always available.

- `minOrderAmount` / `maxOrderAmount` — cart subtotal thresholds
- `minWeight` / `maxWeight` — cart total weight (SUM of product.weight × quantity)
- `freeShippingAbove` — if cart subtotal >= this, price = 0 (overrides base + class)
- `minItemCount` — minimum number of items in cart

### Price Resolution Logic

```
For a cart item, given (method, product):
  1. Does product have a shipping_class_id?
     NO  → use method.price (base price)
     YES → look up delivery_zone_method_class_prices for (method.id, product.shipping_class_id)
              found → use that per-class price
              not found → use method.price (base price)

For a cart with multiple items:
  - Each item calculates its own shipping cost per method
  - Total shipping for a method = SUM of all items' prices for that method

Condition check (before offering method):
  1. cart.subtotal >= method.conditions.minOrderAmount?        → hide if not met
  2. cart.subtotal <= method.conditions.maxOrderAmount?        → hide if not met (if set)
  3. cart.totalWeight >= method.conditions.minWeight?          → hide if not met (if set)
  4. cart.totalWeight <= method.conditions.maxWeight?          → hide if not met (if set)
  5. cart.itemCount >= method.conditions.minItemCount?         → hide if not met (if set)

Free shipping override:
  - If conditions.freeShippingAbove is set AND cart.subtotal >= threshold
    → price = 0 (regardless of class/overrides)
```

### Example

```
Shipping Classes:
  "Standard"    (default for most products)
  "Heavy"       (extra fee for bulky items)

Products:
  T-Shirt       → class: Standard,  weight: 0.2 kg
  Refrigerator  → class: Heavy,     weight: 45 kg

Zone "Kenya Nationwide":
  Location: KE, cities=[]
  Methods:
    Standard Delivery   KSh 200
      → Heavy override: KSh 1,000
      → conditions: {}
      → est: 3-5 days

    Express Delivery    KSh 500
      → Heavy override: KSh 2,000
      → conditions: {}
      → est: 1-2 days

Zone "Kenya Heavy Items":
  Location: KE, cities=[]   (same country, different zone)
  Methods:
    Freight               KSh 1,500
      → conditions: { "maxWeight": null }  (no weight cap)
      → est: 5-10 days

Checkout: T-Shirt + Refrigerator
  → T-Shirt matches: Kenya Nationwide
  → Fridge matches: Kenya Nationwide, Kenya Heavy Items
  → Intersection: Kenya Nationwide (both match)
  → Available: Standard = 200 + 1,000 = KSh 1,200
               Express  = 500 + 2,000 = KSh 2,500
```

## Backend

### Schema File — `delivery-zone.json`

Registered in `SchemaRegistry.kt` for admin form validation:

```json
{
  "type": "delivery-zone",
  "label": "Delivery Zone",
  "description": "Define a delivery zone with locations, shipping methods, and per-class pricing",
  "fields": [
    { "key": "name", "type": "STRING", "label": "Zone Name", "required": true },
    { "key": "locations", "type": "OBJECT_ARRAY", "label": "Locations",
      "children": [
        { "key": "country", "type": "STRING", "label": "Country Code", "required": true },
        { "key": "cities", "type": "LIST", "label": "Cities (leave empty for all)", "itemType": "STRING" }
      ]
    },
    { "key": "methods", "type": "OBJECT_ARRAY", "label": "Shipping Methods",
      "children": [
        { "key": "methodId", "type": "STRING", "label": "Method ID", "required": true },
        { "key": "label", "type": "STRING", "label": "Label", "required": true },
        { "key": "price", "type": "NUMBER", "label": "Base Price", "required": true }
      ]
    }
  ]
}
```

Note: Conditions, estimates, and class prices are NOT configured via SchemaForm — they're managed through dedicated UI on the zone detail page.

### New Kotlin Files

| File | Description |
|------|-------------|
| `ShippingClass.kt` | Entity: id, storeId, name, description, position, isDeleted, version, timestamps |
| `DeliveryZone.kt` | Entity: id, storeId, name, position, timestamps |
| `DeliveryZoneLocation.kt` | Entity: id, zoneId, country, cities (List<String>), timestamps |
| `DeliveryZoneMethod.kt` | Entity: id, zoneId, methodId, label, price (BigDecimal), conditions (Map<String,Any?>), estMinDays, estMaxDays, timestamps |
| `DeliveryZoneMethodClassPrice.kt` | Entity: methodId, classId, price (BigDecimal), timestamps |
| `ProductDeliveryZone.kt` | Entity: id, productId, zoneId, timestamps |
| `ShippingClassRepository.kt` | CRUD for shipping classes |
| `DeliveryZoneRepository.kt` | CRUD for zones + eager-load children + class prices |
| `ProductDeliveryZoneRepository.kt` | M:N management for product↔zone |
| `DeliveryZoneSettingsService.kt` | Bridge between SchemaForm + dedicated tables |

### `DeliveryZoneSettingsService` Endpoints

| Method | Route | Auth | Purpose |
|--------|-------|------|---------|
| GET | `/{publicId}/settings/delivery/zones` | ADMIN | List all zones (with locations + methods + class prices) |
| POST | `/{publicId}/settings/delivery/zones` | ADMIN | Create zone + children |
| GET | `/{publicId}/settings/delivery/zones/{id}` | ADMIN | Read one zone with children |
| PUT | `/{publicId}/settings/delivery/zones/{id}` | ADMIN | Replace zone + children atomically |
| DELETE | `/{publicId}/settings/delivery/zones/{id}` | ADMIN | Hard delete zone (cascades) |
| PUT | `/{publicId}/settings/delivery/zones/{id}/class-prices` | ADMIN | Batch replace per-class price overrides for zone methods |
| GET | `/{publicId}/settings/delivery` | API key | Flattened checkout data (includes class prices + conditions + estimates) |

### Shipping Class Endpoints

| Method | Route | Auth | Purpose |
|--------|-------|------|---------|
| GET | `/{publicId}/settings/shipping-classes` | ADMIN | List all classes |
| POST | `/{publicId}/settings/shipping-classes` | ADMIN | Create class |
| PUT | `/{publicId}/settings/shipping-classes/{id}` | ADMIN | Update class |
| DELETE | `/{publicId}/settings/shipping-classes/{id}` | ADMIN | Soft delete class |

### `DeliveryZoneRepository`

- `findByStoreId(storeId)` → `Flow<ZoneWithRelations>` — uses multiset for eager loading locations + methods + class prices
- `findByIdWithRelations(id)` → `ZoneWithRelations?`
- `save(zone, locations, methods)` — batch upsert (follows `ProductRepository.save()` pattern)
- `replaceClassPrices(zoneId, prices: List<MethodClassPrice>)` — DELETE existing + INSERT new
- `delete(id)` — hard delete (cascades to children)

### `ProductDeliveryZoneRepository`

- `findZonesByProductId(productId)` → `Flow<ProductDeliveryZone>`
- `replaceForProduct(productId, zoneIds)` — DELETE existing + INSERT new in batch
- `findZoneIdsForProducts(productIds)` → `Flow<Pair<UUID, UUID>>` — (productId, zoneId) pairs for checkout

### Product Integration

- `ProductInput` — add `shippingClassId: String?`, `weight: Double?`, and `deliveryZoneIds: List<String>?`
- `ProductDto` — add `shippingClassId: String?`, `weight: Double?`, and `deliveryZoneIds: List<String>`
- `ProductSaveServiceImpl` — save `shippingClassId` + `weight` to product, call `ProductDeliveryZoneRepository.replaceForProduct()`

### Route Registration — `ApiRouterConfig.kt`

Registered **before** the generic `settings/{type}` catch-all (line 249):

```
path("/settings").nest {
    path("/shipping-classes").nest {
        GET("", deliveryZoneSettingsService::listClasses)
        POST("") { it.requireRole(MemberRole.ADMIN); deliveryZoneSettingsService.createClass(it) }
        PUT("/{id}") { it.requireRole(MemberRole.ADMIN); deliveryZoneSettingsService.updateClass(it) }
        DELETE("/{id}") { it.requireRole(MemberRole.ADMIN); deliveryZoneSettingsService.deleteClass(it) }
    }
    path("/delivery/zones").nest {
        GET("", deliveryZoneSettingsService::listZones)
        POST("") { it.requireRole(MemberRole.ADMIN); deliveryZoneSettingsService.createZone(it) }
        GET("/{id}", deliveryZoneSettingsService::getZone)
        PUT("/{id}") { it.requireRole(MemberRole.ADMIN); deliveryZoneSettingsService.updateZone(it) }
        DELETE("/{id}") { it.requireRole(MemberRole.ADMIN); deliveryZoneSettingsService.deleteZone(it) }
        PUT("/{id}/class-prices") { it.requireRole(MemberRole.ADMIN); deliveryZoneSettingsService.replaceClassPrices(it) }
    }
    GET("/delivery", deliveryZoneSettingsService::getCheckoutData)
}
```

### Checkout Flattened Endpoint

`GET /{publicId}/settings/delivery` returns:

```json
{
  "countries": ["KE", "UG", "TZ"],
  "citiesByCountry": {
    "KE": ["Nairobi", "Kiambu", "Mombasa"],
    "UG": ["Kampala"]
  },
  "deliveryTypes": [
    {
      "zoneId": "uuid",
      "methodId": "standard",
      "label": "Standard",
      "basePrice": 200,
      "classPrices": {
        "class-uuid-1": 1000,
        "class-uuid-2": 500
      },
      "conditions": {
        "minOrderAmount": 5000,
        "freeShippingAbove": 10000
      },
      "estMinDays": 3,
      "estMaxDays": 5
    }
  ]
}
```

### Checkout Validation Flow

```
1. Load cart → get product IDs + shippingClassId + weight per item
2. Query product_delivery_zones for all cart items → zoneIds per product
3. Compute cart-level aggregates:
     subtotal = SUM(item.price * quantity)
     totalWeight = SUM(item.weight * quantity)
     itemCount = SUM(quantity)
4. Customer enters (country, city)
5. For each cart item:
     Get item's zones' locations
     Match (country, city) against each location's effective cities
     If NO matching location for any item → error "X cannot ship to Y"
6. Intersect all items' matching zones' methods
7. For each method in the intersection:
     a. Check conditions against cart subtotal/totalWeight/itemCount
        → FAIL: hide method (not applicable)
     b. For each item, calculate per-item price:
          item has shippingClassId?
            → lookup class price override for (method, class)
                 found → use override
                 not found → use base price
            → no class → use base price
     c. If conditions.freeShippingAbove is set AND subtotal >= threshold
          → total = 0
        else
          → total = SUM of per-item prices
8. Offer only passing methods (with estimates + per-item breakdown) to customer
```

## Frontend — Admin

### Shipping Classes

| Page | Route | What it does |
|------|-------|-------------|
| List | `/admin/settings/shipping-classes` | Lists all classes. Add/Edit/Delete. |
| Detail | `/admin/settings/shipping-classes/[id]` | Form: name, description |

### Zone Management

| Page | Route | What it does |
|------|-------|-------------|
| List | `/admin/settings/delivery` | Lists all zones with name, countries, methods. Add/Edit/Delete. |
| Detail | `/admin/settings/delivery/[zoneId]` | SchemaForm + class price matrix + conditions/estimates per method |

Zone detail has three sections:

1. **SchemaForm** — zone name, locations (country + cities), methods (methodId + label + base price)
2. **Method Settings** (per method row) — delivery estimates + conditions toggles
3. **Class Price Matrix** — table rows = shipping classes, columns = methods, cells = price override (leave blank = use base price)

```
Zone: Kenya Nationwide
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Name:  Kenya Nationwide

Locations:
  KE, cities: [all]
  UG, cities: [Kampala]

Methods:
  Label              Base   Est.     Conditions
  Standard           200    3-5d     —
  Express            500    1-2d     —
  Free Shipping        0    5-10d    Min order: 5,000

Per-Class Prices:
                Standard    Express
  Standard       200          500
  Heavy        1,000        2,000
  Fragile        800        1,500
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Product Page

Product edit page gains three fields:

```
Product: "Refrigerator"
━━━━━━━━━━━━━━━━━━━━━━━━━━━
Name:  Refrigerator
Price: 45000
Weight: 45 kg
Shipping Class:  [Heavy ▼]
...
Delivery Zones:
  [✓] Kenya Nationwide
  [ ] Nairobi Only
━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Sends `shippingClassId`, `weight`, and `deliveryZoneIds` in the product save payload.

## Frontend — Storefront Checkout

### CheckoutSettingsProvider

Fetches `GET /settings/delivery` (flattened), provides through context:
- `countries: string[]`
- `citiesByCountry: Record<string, string[]>`
- `deliveryTypes: DeliveryType[]` — with per-class prices, conditions, estimates embedded
- `getAvailableMethods(cartItems, subtotal, totalWeight): DeliveryType[]` — filters by conditions + zone intersection, computes prices
- `calculateShipping(method, cartItems): { total, perItem, isFree }`

### Component Changes

- `checkout-country.tsx` — remove `countryCodes` prop, read countries from context
- `checkout-delivery-type.tsx` — remove `options` prop, read available methods from context. Shows label, price, estimate. Marks free shipping.
- `address-fields.tsx` — city field: dropdown if cities exist for selected country, free-text otherwise

### Restriction UI

- If a cart item can't ship to the entered address → inline error: *"Refrigerator does not ship to Mombasa"*
- If a method is hidden due to conditions → method simply doesn't appear (no error)
- If no methods pass → generic error: *"No shipping methods available for this address"*

## Implementation Order

| # | Layer | Task |
|---|-------|------|
| 1 | Backend | Write `V70__Create_delivery_zones.sql` migration (6 tables + product alters) |
| 2 | Backend | Create entities: `ShippingClass`, `DeliveryZone`, `DeliveryZoneLocation`, `DeliveryZoneMethod`, `DeliveryZoneMethodClassPrice`, `ProductDeliveryZone` |
| 3 | Backend | Create `ShippingClassRepository` |
| 4 | Backend | Create `DeliveryZoneRepository` with multiset eager loading |
| 5 | Backend | Create `ProductDeliveryZoneRepository` with batch replace |
| 6 | Backend | Create `delivery-zone.json` schema, register in `SchemaRegistry` |
| 7 | Backend | Create `DeliveryZoneSettingsService` with all endpoints + condition checking |
| 8 | Backend | Register routes in `ApiRouterConfig` (before generic catch-all) |
| 9 | Backend | Extend `ProductInput`/`ProductDto`/`ProductSaveServiceImpl` for shippingClassId + weight + zoneIds |
| 10 | Frontend | Admin shipping classes page (list + form) |
| 11 | Frontend | Admin zone list page (`delivery/index.tsx`) |
| 12 | Frontend | Admin zone detail page (`delivery/[zoneId].tsx`) with SchemaForm + conditions/estimates + class price matrix |
| 13 | Frontend | Product edit page — shipping class dropdown + weight + zone multi-select |
| 14 | Frontend | `CheckoutSettingsProvider` + `checkout-settings.tsx` with condition-aware method filtering |
| 15 | Frontend | Update checkout country/delivery-type/city components for context |
| 16 | Frontend | Checkout restriction validation with inline errors |
