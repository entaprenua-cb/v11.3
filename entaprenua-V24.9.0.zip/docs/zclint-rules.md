1) Allowed imports:
  @ from 'lucide-solid' 
  @) from 'solid-js' 
    * splitProps
    * mergeProps
    * Suspense
    * 
  @) from '@solidjs/meta' 
     * MetaProvider   // Context provider
     * Title          // <title> tag
     * Meta           // <meta> tag
     * Link           // <link> tag
     * Base           // <base> tag* Meta
  
  @) from "@solidjs/router"
       * Router 
       * Routes 
       * A
  @ from '@solidjs/start'
     * clientOnly

  @) from "@solidjs/start/router"
     * FileRoutes

2) Check strings that are not allowed:
   * fetch
   * window  
   * document
   * *.target.*
   * *.currentTarget.*
   * component props handlers(or starting with on*) -> eg 
      <Button onDoThis={}, on={} />

   
