# zclint - Zero-Code Lint

**Last Updated**: 2026-04-11  
**Status**: Planned  
**Language**: TypeScript + Rust (CLI/LSP binary)

---

## Overview

zclint is a CLI + LSP tool for validating storefront code in a codeless component architecture. It enforces coding rules while allowing users to create reusable components.

**Key principle:** Works offline, fast, and friendly for both humans and AI coding models.

---

## Why zclint?

| Approach | Pros | Cons |
|----------|------|------|
| ESLint in CI | Works | Too late - after commit |
| VS Code Extension | Real-time | Not everyone uses VS Code |
| Custom Editor | Best UX | Lots of work |
| **zclint (CLI + LSP)** | ✅ Simple, fast, offline, AI-friendly, multi-editor | - |

### Benefits

- **Offline-first** — no internet required
- **Fast** — local validation, no network latency
- **LSP support** — real-time diagnostics in any editor
- **AI-friendly** — JSON output, clear error messages
- **Simple** — one binary, multiple editors

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    zclint Binary                        │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐   │
│  │   CLI       │  │   LSP       │  │  Rule       │   │
│  │  (clap)     │  │  Server     │  │  Engine     │   │
│  └─────────────┘  └─────────────┘  └─────────────┘   │
│                                              │         │
│  ┌─────────────────────────────────────────┐ │         │
│  │       TypeScript Core (bundled)         │ │         │
│  │  - @typescript-eslint/parser            │ │         │
│  │  - Rule definitions                     │ │         │
│  │  - fast-glob for file discovery         │ │         │
│  └─────────────────────────────────────────┘ │         │
└─────────────────────────────────────────────────────────┘
```

---

## Installation

### Binary (Recommended)

```bash
# Linux/macOS
curl -fsSL https://get.zclint.dev | sudo install

# Or download from releases
curl -L https://github.com/entaprenua/zclint/releases/latest/download/zclint -o zclint
chmod +x zclint
sudo mv zclint /usr/local/bin/
```

### Local install (No sudo required)

```bash
# Install to ~/.local/bin (user-local)
mkdir -p ~/.local/bin
cp /path/to/zclint ~/.local/bin/zclint
chmod +x ~/.local/bin/zclint

# Add to PATH (add to ~/.bashrc or ~/.zshrc)
export PATH="$HOME/.local/bin:$PATH"
```

### npm (Node.js required)

```bash
npm install -g @entaprenua/zclint
```

### Build from source

```bash
git clone https://github.com/entaprenua/zclint.git
cd zclint
cargo build --release
./target/release/zclint --help
```

### Homebrew

```bash
brew install entaprenua/tap/zclint
```

---

## Usage

### CLI

```bash
# Validate directory
zclint ./src

# Validate specific files
zclint ./src/components/Header.tsx

# Validate staged files (for pre-commit)
zclint --staged

# JSON output (for CI/AI)
zclint ./src --json

# Watch mode
zclint ./src --watch

# Install pre-commit hook
zclint install
```

### LSP

```bash
# Start LSP server
zclint lsp

# Or with LSP config in editor
# (See "Editor Integration" below)
```

### Editor Integration

**VS Code** (VSIX coming soon)
```json
{
  "lsp": {
    "enable": true,
    "command": "zclint",
    "args": ["lsp"]
  }
}
```

**Neovim** (lspconfig)
```lua
require('lspconfig').zclint.setup({})
```

**Emacs** (eglot)
```elisp
(add-to-list 'eglot-server-programs '((tsx-tsx-mode) . ("zclint" "lsp")))
```

---

## Output

### Human-Readable (Default)

```
✗ src/components/Button.tsx:15
  Event handler not allowed: 'onClick'
  Fix: Use <Button> platform component for click actions

✗ src/routes/index.tsx:8
  Ternary operator not allowed
  Fix: Use <Switch>/<Match> for conditional rendering

✗ src/utils/helpers.ts:3
  Plain .ts file not allowed
  Fix: Rename to .tsx extension
```

### JSON Output (for CI/AI)

```json
{
  "valid": false,
  "errors": [
    {
      "file": "src/components/Button.tsx",
      "line": 15,
      "column": 8,
      "rule": "no-event-handlers",
      "message": "Event handler not allowed: 'onClick'",
      "fix": "Use <Button> platform component for click actions"
    }
  ],
  "summary": {
    "total_files": 24,
    "total_errors": 3,
    "errors_by_rule": {
      "no-event-handlers": 1,
      "no-ternary": 1,
      "no-plain-ts": 1
    }
  }
}
```

---

## Rules

### 1. Allowed Imports

Only specific imports are permitted. All other imports are blocked.

| Package | Allowed Imports |
|---------|-----------------|
| `lucide-solid` | Any |
| `solid-js` | `splitProps`, `mergeProps`, `Suspense` |
| `@solidjs/meta` | `MetaProvider`, `Title`, `Meta`, `Link`, `Base` |
| `@solidjs/router` | `Router`, `Routes`, `A` |
| `@solidjs/start` | `clientOnly` |
| `@solidjs/start/router` | `FileRoutes` |

### 2. Disallowed Patterns

#### Browser APIs
| Pattern | Reason |
|---------|--------|
| `window` | No direct browser API access |
| `document` | No direct DOM access |
| `*.target.*` | No event target access |
| `*.currentTarget.*` | No event target access |
| `localStorage` | No client storage |
| `sessionStorage` | No client storage |
| `document.cookie` | No cookie manipulation |

#### Dynamic Code
| Pattern | Reason |
|---------|--------|
| `eval` | Arbitrary code execution |
| `new Function` | Dynamic code creation |
| `setTimeout` | Dynamic code execution |
| `setInterval` | Dynamic code execution |
| `import(` | Dynamic imports |
| `with (` | Confusing scoping |

#### HTML Injection / XSS
| Pattern | Reason |
|---------|--------|
| `.innerHTML` | XSS vulnerability |
| `.outerHTML` | XSS vulnerability |
| `dangerouslySetInnerHTML` | XSS vulnerability |
| `<script` | Script injection |
| `<iframe` | Clickjacking / embedding |
| `<embed` | Malicious content |
| `<object` | Malicious content |
| `javascript:` | XSS in URLs |
| `data:` | Data URI attacks |

#### Event Handlers
```
❌ Blocked
onClick, onChange, onSubmit, onInput, onMouseEnter, onMouseLeave,
onFocus, onBlur, onKeyDown, onKeyUp, onScroll, etc.

Also blocked: component props like <Button onDoThis={} />

✅ Fix
Use platform components: <Button>, <Input>, <Select>, etc.
```

#### Networking
| Pattern | Reason |
|---------|--------|
| `fetch` | No data fetching |
| `WebSocket` | No websockets |
| `postMessage` | No cross-origin messaging |

#### Debugging / Logging
| Pattern | Reason |
|---------|--------|
| `console` | No logging allowed |
| `debugger` | Developer artifact |

### 3. No Inline Functions

Only JSX composition is allowed:

```
❌ Blocked
{() => { return <p>hello</p> }}
<button onClick={() => handleClick()}>
```

```
✅ Allowed
<Button>Click</Button>
```

### 4. Plain TypeScript Files

```
❌ Blocked
*.ts, *.js files

✅ Fix
Rename to .tsx or .jsx extension.
```

### Protected Directories

```
✅ Skipped (not linted)
components/ui/**   - Platform UI components
lib/**             - Platform library code

✅ Linted (user space)
**/** (except protected dirs) - User space
```

---

## Component Definitions

In user space, users **can** create reusable components:

```tsx
✅ Allowed
const Card = (props) => <div>{props.title}</div>;
const Button = () => <div>hello</div>;
function ProductCard(props) { return <div>{props.name}</div>; }
```

### Why allow component definitions?

1. **Reusability** - Users can create custom components once and use them multiple times
2. **Composition** - Components can compose platform components
3. **No harm** - Other rules block dangerous patterns inside components

### Example

```tsx
// src/components/CustomCard.tsx

// ✅ Allowed - Reusable component
const CustomCard = (props) => (
  <Card title={props.title}>
    <p>{props.description}</p>
  </Card>
);

// ✅ Allowed - Using the component
<CustomCard title="Hello" description="World" />

// ❌ Blocked - Inline functions
<div> {() => { return <span>hi</span>; }} </div>

// ❌ Blocked - Event handlers
<button onClick={handleClick}>Click</button>
```

---

## Directory Structure

```
storefront/
├── components/
│   ├── ui/                    # Protected (not linted)
│   │   ├── Button.tsx
│   │   ├── Card.tsx
│   │   └── ...
│   │
│   └── my-components/         # User space (linted)
│       ├── CustomButton.tsx
│       └── ProductCard.tsx
│
├── routes/                    # User space (linted)
│   ├── index.tsx
│   ├── products.tsx
│   └── ...
│
└── lib/                       # Protected (not linted)
    └── utils.tsx
```

---

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | No errors |
| 1 | Validation errors found |
| 2 | File not found or other error |

---

## Configuration

### zclint.config.json

```json
{
  "include": ["src/**"],
  "exclude": ["**/node_modules/**", "**/dist/**"],
  "rules": {
    "no-disallowed-imports": "error",
    "no-disallowed-patterns": "error",
    "no-inline-functions": "error",
    "no-unsafe-execution": "error",
    "no-inner-html": "error",
    "no-javascript-url": "error",
    "no-data-uri": "error",
    "no-script-tag": "error",
    "no-iframe": "error",
    "no-embed": "error",
    "no-object": "error",
    "no-local-storage": "error",
    "no-session-storage": "error",
    "no-cookie-access": "error",
    "no-websocket": "error",
    "no-postmessage": "error",
    "no-debugger": "error",
    "no-dynamic-import": "error",
    "no-with-statement": "error",
    "no-plain-ts": "error"
  }
}
```

### Per-file overrides

```json
{
  "src/legacy/**/*.tsx": {
    "rules": {
      "no-debugger": "off"
    }
  }
}
```

---

## Tech Stack

| Component | Technology |
|-----------|------------|
| CLI | Rust + clap |
| LSP Server | Rust + tower-lsp |
| Rule Engine | TypeScript (bundled) |
| Parser | @typescript-eslint/parser |
| File Discovery | fast-glob |
| Binary Bundling | wasm-pack or tauri |

---

## Future Enhancements

1. **Auto-fix** - Add `--fix` flag to auto-correct violations
2. **GitHub App** - Comment errors on PRs
3. **Configurable rules** - Allow disabling rules per-project
4. **Custom rules** - Plugin system for project-specific rules
5. **Language support** - Vue, Svelte templates

---

## Related Documentation

- [Storefront Code Security](STOREFRONT_CODE_SECURITY.md) - Security rules
- [VCS Integration](VCS_INTEGRATION.md) - Repository setup

---

## License

MIT
