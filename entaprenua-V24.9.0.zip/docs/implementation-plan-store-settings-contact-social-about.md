# Plan: Store Settings - Contact, Social Links, and About

## Overview

Create three new settings tables for store information:

1. `store_contact_settings` - Contact information
2. `store_social_links` - Social media links
3. `store_about` - About page content with team members

## Database Schema

### 1. store_contact_settings

```sql
CREATE TABLE store_contact_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE UNIQUE,
    
    -- Contact info
    email VARCHAR(255),
    phone VARCHAR(50),
    address TEXT,
    city VARCHAR(100),
    country VARCHAR(100),
    whatsapp VARCHAR(50),
    
    -- Map coordinates
    map_lat DECIMAL(10, 8),
    map_lng DECIMAL(11, 8),
    
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);
```

### 2. store_social_links

```sql
CREATE TABLE store_social_links (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    
    -- Social platforms
    twitter VARCHAR(500),
    facebook VARCHAR(500),
    instagram VARCHAR(500),
    tiktok VARCHAR(500),
    linkedin VARCHAR(500),
    youtube VARCHAR(500),
    pinterest VARCHAR(500),
    snapchat VARCHAR(500),
    
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);
```

### 3. store_about

```sql
CREATE TABLE store_about (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE UNIQUE,
    
    -- About content
    story TEXT,
    mission TEXT,
    vision TEXT,
    values TEXT[],  -- Array of core values
    why_us TEXT,
    
    -- Team members (JSONB)
    team JSONB DEFAULT '[]'::jsonb,
    -- Example: [{"name": "John Doe", "role": "CEO", "bio": "...", "photo": "url"}]
    
    inserted_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/stores/{publicId}/settings/contact` | Get contact settings |
| PUT | `/api/v1/stores/{publicId}/settings/contact` | Update contact settings |
| GET | `/api/v1/stores/{publicId}/settings/social` | Get social links |
| PUT | `/api/v1/stores/{publicId}/settings/social` | Update social links |
| GET | `/api/v1/stores/{publicId}/settings/about` | Get about content |
| PUT | `/api/v1/stores/{publicId}/settings/about` | Update about content |

## File Structure

```
store/settings/
├── email/
│   ├── StoreEmailSettingsService.kt
│   ├── StoreEmailSettingsServiceImpl.kt
│   └── StoreEmailSettingsRepository.kt
├── contact/
│   ├── StoreContactSettingsService.kt      # Interface
│   ├── StoreContactSettingsServiceImpl.kt   # Implementation
│   └── StoreContactSettingsRepository.kt   # Repository
├── social/
│   ├── StoreSocialLinksService.kt
│   ├── StoreSocialLinksServiceImpl.kt
│   └── StoreSocialLinksRepository.kt
└── about/
    ├── StoreAboutService.kt
    ├── StoreAboutServiceImpl.kt
    └── StoreAboutRepository.kt
```

## Entities

### StoreContactSettings

```kotlin
data class StoreContactSettings(
    val id: UUID? = null,
    val storeId: UUID,
    val email: String? = null,
    val phone: String? = null,
    val address: String? = null,
    val city: String? = null,
    val country: String? = null,
    val whatsapp: String? = null,
    val mapLat: Double? = null,
    val mapLng: Double? = null,
    val insertedAt: OffsetDateTime? = null,
    val updatedAt: OffsetDateTime? = null
)
```

### StoreSocialLinks

```kotlin
data class StoreSocialLinks(
    val id: UUID? = null,
    val storeId: UUID,
    val twitter: String? = null,
    val facebook: String? = null,
    val instagram: String? = null,
    val tiktok: String? = null,
    val linkedin: String? = null,
    val youtube: String? = null,
    val pinterest: String? = null,
    val snapchat: String? = null,
    val insertedAt: OffsetDateTime? = null,
    val updatedAt: OffsetDateTime? = null
)
```

### StoreAbout

```kotlin
data class TeamMember(
    val name: String,
    val role: String,
    val bio: String? = null,
    val photo: String? = null
)

data class StoreAbout(
    val id: UUID? = null,
    val storeId: UUID,
    val story: String? = null,
    val mission: String? = null,
    val vision: String? = null,
    val values: List<String> = emptyList(),
    val whyUs: String? = null,
    val team: List<TeamMember> = emptyList(),
    val insertedAt: OffsetDateTime? = null,
    val updatedAt: OffsetDateTime? = null
)
```

## DTOs

### Contact Settings

```kotlin
data class StoreContactSettingsUpdate(
    val email: String? = null,
    val phone: String? = null,
    val address: String? = null,
    val city: String? = null,
    val country: String? = null,
    val whatsapp: String? = null,
    val mapLat: Double? = null,
    val mapLng: Double? = null
)
```

### Social Links

```kotlin
data class StoreSocialLinksUpdate(
    val twitter: String? = null,
    val facebook: String? = null,
    val instagram: String? = null,
    val tiktok: String? = null,
    val linkedin: String? = null,
    val youtube: String? = null,
    val pinterest: String? = null,
    val snapchat: String? = null
)
```

### About

```kotlin
data class StoreAboutUpdate(
    val story: String? = null,
    val mission: String? = null,
    val vision: String? = null,
    val values: List<String>? = null,
    val whyUs: String? = null,
    val team: List<TeamMember>? = null
)
```

## API Response Examples

### GET /stores/{publicId}/settings/contact

```json
{
  "success": true,
  "data": {
    "email": "contact@mystore.com",
    "phone": "+254712345678",
    "address": "123 Main Street",
    "city": "Nairobi",
    "country": "Kenya",
    "whatsapp": "+254712345678",
    "mapLat": -1.286389,
    "mapLng": 36.817223
  }
}
```

### GET /stores/{publicId}/settings/social

```json
{
  "success": true,
  "data": {
    "twitter": "https://twitter.com/mystore",
    "facebook": "https://facebook.com/mystore",
    "instagram": "https://instagram.com/mystore",
    "tiktok": null,
    "linkedin": null,
    "youtube": null,
    "pinterest": null,
    "snapchat": null
  }
}
```

### GET /stores/{publicId}/settings/about

```json
{
  "success": true,
  "data": {
    "story": "Founded in 2020, we provide quality products...",
    "mission": "To deliver excellence to every customer...",
    "vision": "To be East Africa's leading online store...",
    "values": ["Quality", "Integrity", "Innovation"],
    "whyUs": "10+ years experience, fast delivery...",
    "team": [
      {
        "name": "John Doe",
        "role": "Founder & CEO",
        "bio": "15 years in retail...",
        "photo": "https://cdn.store.com/team/john.jpg"
      }
    ]
  }
}
```

## Implementation Steps

### Phase 1: Database & Entities

1. Create migration `V46__store_settings.sql`
2. Create entities: `StoreContactSettings.kt`, `StoreSocialLinks.kt`, `StoreAbout.kt`
3. Run JOOQ codegen

### Phase 2: Repositories

4. Create `StoreContactSettingsRepository.kt`
5. Create `StoreSocialLinksRepository.kt`
6. Create `StoreAboutRepository.kt`

### Phase 3: Services

7. Create `StoreContactSettingsService.kt` + `Impl`
8. Create `StoreSocialLinksService.kt` + `Impl`
9. Create `StoreAboutService.kt` + `Impl`

### Phase 4: Routes

10. Update `ApiRouterConfig.kt` to add new routes
11. Compile and test

## Notes

- Use StoreContext for store ID (same pattern as email settings)
- Team members stored as JSONB for flexibility
- All settings created on-demand (not auto-created with store)
- Frontend will need to update forms for new settings
