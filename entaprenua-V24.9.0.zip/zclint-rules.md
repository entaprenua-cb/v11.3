1) Allowed imports:
  @ from 'lucide-solid' 
  @) from 'solid-js' 
    * splitProps
    * mergeProps
    * Suspense
    * 
  @) from '@solidjs/meta' 
     * MetaProvider   // Context provider
     * Title          // <title> tag
     * Meta           // <meta> tag
     * Link           // <link> tag
     * Base           // <base> tag* Meta
  
  @) from "@solidjs/router"
       * Router 
       * Routes 
       * A
  @ from '@solidjs/start'
     * clientOnly

  @) from "@solidjs/start/router"
     * FileRoutes

2) Check strings that are not allowed:
   * fetch
   * window  
   * document
   * *.target.*
   * *.currentTarget.*
   * console* - no logging 
   * html script tag 
   * component props handlers(or starting with on*) -> eg 
      <Button onDoThis={}, on={} />
3) No inline functions, only jsx:
  <div> 
    {() => {
       return <p> hello </p>
    }}
  </div>

   
