# Deployment Tasks Completed

## 2026-03-30

### Deploy Script (`./deploy`)
- Created `/home/nesh/repos/Applications/entaprenua/deploy`
- Syncs `.output/` and JAR files to VPS at `/opt/entaprenua`
- Includes `npm install --omit=dev` for dependencies
- Sets up systemd service (`entaprenua.service`)
- Restarts service after deployment

### Zip/Git Scripts ✅
- Updated `./zip` script with explicit file list
- Added automatic backup to `~/backups`
- Git push working via `./git`

### SSH Key for GitHub ✅
- Added existing key `~/.ssh/id_ed25519` to GitHub
- Email: `martinmunene018@gmail.com`
- Git push working

### VPS Setup ✅
- DNS records configured at Hostinger:
  - A record `@` → `187.124.17.59`
  - A record `*` → `187.124.17.59` (for store subdomains)
  - CNAME `www` → `entaprenua.com`
- Nginx config: `/etc/nginx/sites-available/entaprenua`
- SSL: ✅ Configured via Certbot (`/etc/letsencrypt/live/entaprenua.com/`)
- App deployed and running at `https://entaprenua.com`
- VPS SSH timeout fixed: `ClientAliveInterval 300`, `ClientAliveCountMax 10`

### Missing Function Fix
- Added `importCodebaseToStore()` function to `src/lib/server/upload.ts`
- Function imports ZIP files, parses JSX pages, saves to store via `saveStoreWithPages()`
