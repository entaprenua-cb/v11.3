study docs/implementation-plan-storefront-customer-registration.md
, backend/** and make plan to move verification* fields from store table to separate table without redudance of verification* prefix, also consolidate verificatationSubdomain with verificationCustomDomain to domain, don't worry about backward compatibility, we are in dev stage.
