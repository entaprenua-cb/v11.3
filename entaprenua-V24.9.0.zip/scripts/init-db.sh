#!/bin/bash
# Script to initialize PostgreSQL database with user and database creation
# Usage: ./init-db.sh

set -e

# Database credentials
DB_USER="nesh"
DB_PASSWORD='@martoh2551#'
DB_NAME="entaprenua"
DB_HOST="localhost"
DB_PORT="5432"

echo "Initializing PostgreSQL database..."

# Connect as postgres user and create user and database
su - postgres -c "psql -p $DB_PORT" <<EOF
-- Create user if not exists
DO \$$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '$DB_USER') THEN
      CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';
   END IF;
END
\$$;

-- Create database if not exists
SELECT 'create database $DB_NAME'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '$DB_NAME')\gexec

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;

-- Grant schema privileges
\c $DB_NAME
GRANT ALL ON SCHEMA public TO $DB_USER;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO $DB_USER;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO $DB_USER;

\echo 'Database initialization complete!'
\echo 'User: $DB_USER'
\echo 'Database: $DB_NAME'
\echo 'Host: $DB_HOST:$DB_PORT'
EOF

echo "Done!"
