#!/bin/bash

# =============================================================================
# Entaprenua Backend Deployment Script
# =============================================================================
# Deploys the Spring Boot backend to a configured VPS.
#
# PREREQUISITES:
#   1. Run setup-vps.sh first (installs Java, Gradle, PostgreSQL, Redis, etc.)
#   2. Obtain SSL certificates via certbot
#   3. Add GitHub SSH key to your GitHub organization
#
# USAGE:
#   ./deploy-backend.sh
#
# ENVIRONMENT VARIABLES (optional):
#   VPS_HOST - SSH host alias (default: vps) set in ~/.ssh/config
#   APP_USER - System user running the backend (default: martinmunene018)
# =============================================================================

set -e

VPS_HOST="${VPS_HOST:-vps}"
APP_USER="${APP_USER:-martinmunene018}"
APP_DIR="/opt/entaprenua/backend"
DB_DIR="/repos/Apps/entaprenua/db"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

spinner() {
    local pid=$1
    local delay=0.1
    local spinstr='|/-\'
    while kill -0 $pid 2>/dev/null; do
        local temp=${spinstr#?}
        printf " [%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

step() {
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo " STEP $1: $2"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

info() {
    echo "  ➜ $1"
}

success() {
    echo "  ✓ $1"
}

error() {
    echo "  ✗ $1"
}

section() {
    echo ""
    echo "██████╗ ███████╗███████╗ ██████╗██╗   ██╗███████╗"
    echo "██╔══██╗██╔════╝██╔════╝██╔════╝██║   ██║██╔════╝"
    echo "██████╔╝█████╗  ███████╗██║     ██║   ██║█████╗  "
    echo "██╔══██╗██╔══╝  ╚════██║██║     ██║   ██║██╔══╝  "
    echo "██║  ██║███████╗███████║╚██████╗╚██████╔╝███████╗"
    echo "╚═╝  ╚═╝╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚══════╝"
    echo "██████╗  ██████╗ ████████╗ ██████╗  ██████╗ ██████╗ "
    echo "██╔══██╗██╔═══██╗╚══██╔══╝██╔═══██╗██╔════╝██╔═══██╗"
    echo "██████╔╝██║   ██║   ██║   ██║   ██║██║     ██║   ██║"
    echo "██╔══██╗██║   ██║   ██║   ██║   ██║██║     ██║   ██║"
    echo "██████╔╝╚██████╔╝   ██║   ╚██████╔╝╚██████╗╚██████╔╝"
    echo "╚═════╝  ╚═════╝    ╚═╝    ╚═════╝  ╚═════╝ ╚═════╝ "
    echo ""
}

section "1" "BUILDING BACKEND"

cd "$SCRIPT_DIR/../backend"

info "Setting up Java environment..."
export JAVA_HOME=/usr/local/jdk-21.0.2
export PATH=$JAVA_HOME/bin:/usr/local/gradle-8.6/bin:$PATH

info "Running Gradle build..."
echo -n "  Building"
gradle bootJar --no-daemon 2>&1 | grep -E "(BUILD|Compiling|Downloading|Resolved)" | while read line; do
    echo -n "."
done
echo ""

if [ -f build/libs/entaprenua.jar ]; then
    JAR_SIZE=$(du -h build/libs/entaprenua.jar | cut -f1)
    success "Build complete (JAR: $JAR_SIZE)"
else
    error "Build failed - JAR not found"
    exit 1
fi

section "2" "SYNCING TO VPS"

info "Uploading backend to $VPS_HOST:$APP_DIR/"
rsync -avz --delete \
  -e "ssh" \
  build/libs/entaprenua.jar \
  $VPS_HOST:$APP_DIR/ &

PID=$!
spinner $PID
wait $PID
if [ $? -eq 0 ]; then
    success "Backend synced successfully"
else
    error "Sync failed"
    exit 1
fi

APP_HOME="/home/$APP_USER"

section "2b" "SYNCING SSH DIRECTORY"

info "Syncing SSH directory to $APP_HOME/.ssh..."
ssh $VPS_HOST "mkdir -p $APP_HOME/.ssh && chmod 700 $APP_HOME/.ssh"
rsync -avz --chmod=700 \
  -e "ssh" \
  ~/.ssh/ \
  $VPS_HOST:$APP_HOME/.ssh/ &

PID=$!
spinner $PID
wait $PID
if [ $? -eq 0 ]; then
    ssh $VPS_HOST "chown -R $APP_USER:$APP_USER $APP_HOME/.ssh"
    success "SSH directory synced"
else
    error "SSH sync failed"
    exit 1
fi

section "2c" "CONFIGURING SSH"

info "Checking prerequisites on VPS..."
ssh $VPS_HOST "if ! id $APP_USER &>/dev/null; then useradd -m -s /bin/bash $APP_USER; usermod -aG sudo $APP_USER; fi"
ssh $VPS_HOST "which rsync &>/dev/null || sudo apt install rsync unzip -y -qq"
success "User and prerequisites verified"

section "2d" "CREATING APP DIRECTORIES"

info "Creating application directories..."
ssh $VPS_HOST "mkdir -p /opt/entaprenua/backend /opt/entaprenua/media /var/lib/entaprenua/stores /var/lib/entaprenua/platform /var/lib/entaprenua/temp $DB_DIR && chown -R $APP_USER:$APP_USER /opt/entaprenua /var/lib/entaprenua /repos/Apps"
success "App directories created"

section "3" "UPLOADING .ENV FILE"

ENV_FILE="$SCRIPT_DIR/../backend/.env"
if [ -f "$ENV_FILE" ]; then
    info "Uploading .env to $VPS_HOST:$APP_DIR/.env"
    rsync -avz --chmod=600 \
      -e "ssh" \
      "$ENV_FILE" \
      $VPS_HOST:$APP_DIR/.env &
    
    PID=$!
    spinner $PID
    wait $PID
    if [ $? -eq 0 ]; then
        success ".env uploaded to $APP_DIR/.env"
    else
        error ".env upload failed"
        exit 1
    fi
    
    info "Setting .env ownership..."
    ssh $VPS_HOST "chown $APP_USER:$APP_USER $APP_DIR/.env && chmod 600 $APP_DIR/.env"
else
    error ".env file not found at $ENV_FILE"
    exit 1
fi

section "4" "CONFIGURING SYSTEMD SERVICE"

info "Setting up systemd service for user $APP_USER..."
ssh $VPS_HOST "mkdir -p /etc/systemd/system"

SERVICE_FILE="$SCRIPT_DIR/config/entaprenua-backend.service"
if [ -f "$SERVICE_FILE" ]; then
    TEMP_SERVICE="/tmp/entaprenua-backend.service"
    sed "s/__APP_USER__/$APP_USER/g" "$SERVICE_FILE" > "$TEMP_SERVICE"
    rsync -avz --chmod=644 \
      -e "ssh" \
      "$TEMP_SERVICE" \
      $VPS_HOST:$TEMP_SERVICE
    rm -f "$TEMP_SERVICE"
    
    ssh $VPS_HOST << ENDSSH
        sudo mv $TEMP_SERVICE /etc/systemd/system/entaprenua-backend.service
        sudo systemctl daemon-reload
        sudo systemctl enable entaprenua-backend 2>/dev/null || true
        sudo systemctl restart entaprenua-backend
ENDSSH
    success "Service configured and started"
else
    error "Service file not found at $SERVICE_FILE"
fi

section "5" "INSTALLING AND CONFIGURING OPENRESTY WITH LUA"

OPENRESTY_INSTALL="$SCRIPT_DIR/config/openresty-install.sh"
OPENRESTY_CONF="$SCRIPT_DIR/openresty.conf"
OPENRESTY_ENV="$SCRIPT_DIR/config/openresty-env.conf"
OPENRESTY_OVERRIDE="$SCRIPT_DIR/config/openresty-service-override.conf"

# Check if OpenResty is installed
info "Checking OpenResty installation..."
OPENRESTY_PATH=$(ssh $VPS_HOST "which openresty" 2>/dev/null || echo "")

if [ -z "$OPENRESTY_PATH" ]; then
    info "Installing OpenResty..."
    
    # Upload install script and configs
    rsync -avz --chmod=755 -e "ssh" "$OPENRESTY_INSTALL" $VPS_HOST:/tmp/openresty-install.sh
    rsync -avz --chmod=644 -e "ssh" "$OPENRESTY_CONF" $VPS_HOST:/tmp/openresty.conf
    
    # Substitute env variables
    envsubst < "$OPENRESTY_ENV" > /tmp/openresty-env.conf
    rsync -avz --chmod=644 -e "ssh" /tmp/openresty-env.conf $VPS_HOST:/tmp/
    
    rsync -avz --chmod=644 -e "ssh" "$OPENRESTY_OVERRIDE" $VPS_HOST:/tmp/
    
    # Run install script
    ssh $VPS_HOST "chmod +x /tmp/openresty-install.sh && /tmp/openresty-install.sh && rm -f /tmp/openresty*.sh /tmp/openresty*.conf"
    
    success "OpenResty installed"
else
    info "OpenResty already installed at $OPENRESTY_PATH"
    
    # Still upload configs for update
    rsync -avz --chmod=644 -e "ssh" "$OPENRESTY_CONF" $VPS_HOST:/tmp/openresty.conf
    envsubst < "$OPENRESTY_ENV" > /tmp/openresty-env.conf
    rsync -avz --chmod=644 -e "ssh" /tmp/openresty-env.conf $VPS_HOST:/tmp/
    rsync -avz --chmod=644 -e "ssh" "$OPENRESTY_OVERRIDE" $VPS_HOST:/tmp/
    
    ssh $VPS_HOST "
        cp /usr/local/openresty/nginx/conf/nginx.conf /usr/local/openresty/nginx/conf/nginx.conf.bak
        cp /tmp/openresty.conf /usr/local/openresty/nginx/conf/nginx.conf
        cp /tmp/openresty-env.conf /etc/openresty/env.conf
        cp /tmp/openresty-service-override.conf /etc/systemd/system/openresty.service.d/env.conf
        systemctl daemon-reload
        
        # Stop regular Nginx and start OpenResty
        systemctl stop nginx 2>/dev/null || true
        systemctl disable nginx 2>/dev/null || true
        systemctl restart openresty
        rm -f /tmp/openresty*.conf
    "
    
    success "OpenResty configuration updated"
fi

info "Configuring OpenResty with Redis environment..."
OPENRESTY_ENV="$SCRIPT_DIR/config/openresty-env.conf"
OPENRESTY_OVERRIDE="$SCRIPT_DIR/config/openresty-service-override.conf"

# Read Redis config from .env
ENV_FILE="$SCRIPT_DIR/../backend/.env"
REDIS_HOST="127.0.0.1"
REDIS_PORT="6379"
REDIS_AUTH=""

if [ -f "$ENV_FILE" ]; then
    source "$ENV_FILE"
fi

ssh $VPS_HOST "mkdir -p /etc/openresty /etc/systemd/system/openresty.service.d"

if [ -f "$OPENRESTY_ENV" ]; then
    # Substitute variables and upload
    envsubst < "$OPENRESTY_ENV" | ssh $VPS_HOST "cat > /etc/openresty/env.conf"
    success "OpenResty env file created"
else
    error "OpenResty env template not found"
fi

if [ -f "$OPENRESTY_OVERRIDE" ]; then
    rsync -avz --chmod=644 \
      -e "ssh" \
      "$OPENRESTY_OVERRIDE" \
      $VPS_HOST:/etc/systemd/system/openresty.service.d/env.conf
    ssh $VPS_HOST "systemctl daemon-reload"
    success "OpenResty systemd override created"
else
    error "OpenResty override not found"
fi

section "6" "SETTING UP LETS ENCRYPT WILDCARD CERTIFICATE"

info "Checking if Let's Encrypt wildcard cert exists..."
CERT_EXISTS=$(ssh $VPS_HOST "[ -d /etc/letsencrypt/live/entaprenua.com-0001 ] && echo 'yes'" 2>/dev/null || echo "no")

if [ "$CERT_EXISTS" = "yes" ]; then
    success "Let's Encrypt wildcard certificate already exists"
    info "Certificate at: /etc/letsencrypt/live/entaprenua.com-0001/"
else
    info "Obtaining Let's Encrypt wildcard certificate..."
    
    # Install certbot and Cloudflare plugin
    info "Installing certbot-dns-cloudflare..."
    ssh $VPS_HOST "apt-get install -y python3-certbot-dns-cloudflare certbot" 2>/dev/null
    
    # Upload Cloudflare credentials
    info "Uploading Cloudflare credentials..."
    rsync -avz --chmod=600 \
      -e "ssh" \
      "$SCRIPT_DIR/ssl/cloudflare.ini" \
      $VPS_HOST:/etc/letsencrypt/cloudflare.ini
    ssh $VPS_HOST "chmod 600 /etc/letsencrypt/cloudflare.ini"
    
    # Upload certbot config
    info "Uploading certbot configuration..."
    rsync -avz --chmod=644 \
      -e "ssh" \
      "$SCRIPT_DIR/ssl/certbot.ini" \
      $VPS_HOST:/etc/letsencrypt/certbot.ini
    
    # Request certificate using ini file
    info "Requesting wildcard certificate..."
    ssh $VPS_HOST "certbot certonly -c /etc/letsencrypt/certbot.ini" 2>/dev/null
    
    CERT_RESULT=$?
    if [ $CERT_RESULT -eq 0 ]; then
        success "Let's Encrypt wildcard certificate obtained"
    else
        error "Failed to obtain certificate (exit code: $CERT_RESULT)"
        info "Check logs: ssh $VPS_HOST 'certbot certificates'"
    fi
fi

success "Let's Encrypt setup complete"

section "7" "DEPLOYING NGINX/LUA CONFIGURATION"

info "Backing up existing nginx config..."
ssh $VPS_HOST << 'ENDSSH' 2>/dev/null
    cp /etc/nginx/sites-available/nginx-entaprenua.conf /etc/nginx/sites-available/nginx-entaprenua.conf.bak 2>/dev/null || true
    cp /usr/local/openresty/nginx/conf/nginx.conf /usr/local/openresty/nginx/conf/nginx.conf.bak 2>/dev/null || true
    echo "Backup created"
ENDSSH

info "Creating directories..."
ssh $VPS_HOST "mkdir -p /etc/nginx/lua /etc/ssl/certs /etc/ssl/private"

info "Uploading Lua scripts..."
rsync -avz --chmod=644 \
  -e "ssh" \
  "$SCRIPT_DIR/storefront/redis-helpers.lua" \
  "$SCRIPT_DIR/storefront/storefront-lookup.lua" \
  $VPS_HOST:/etc/nginx/lua/ &

PID=$!
spinner $PID
wait $PID
if [ $? -eq 0 ]; then
    success "Lua scripts uploaded successfully"
else
    error "Lua scripts upload failed"
fi

info "Rewriting OpenResty nginx.conf..."
OPENRESTY_CONFIG="$SCRIPT_DIR/openresty.conf"
if [ -f "$OPENRESTY_CONFIG" ]; then
    rsync -avz --chmod=644 \
      -e "ssh" \
      "$OPENRESTY_CONFIG" \
      $VPS_HOST:/usr/local/openresty/nginx/conf/nginx.conf &
    PID=$!
    spinner $PID
    wait $PID
    if [ $? -eq 0 ]; then
        success "OpenResty nginx.conf rewritten"
    else
        error "Failed to rewrite OpenResty nginx.conf"
    fi
else
    error "OpenResty config not found at $OPENRESTY_CONFIG"
fi

# Upload Nginx site config with SSL (Let's Encrypt wildcard)
NGINX_CONFIG="$SCRIPT_DIR/nginx-entaprenua.conf"
if [ -f "$NGINX_CONFIG" ]; then
    info "Uploading nginx SSL config..."
    rsync -avz --chmod=644 \
      -e "ssh" \
      "$NGINX_CONFIG" \
      $VPS_HOST:/etc/nginx/sites-available/nginx-entaprenua.conf &

    PID=$!
    spinner $PID
    wait $PID
    if [ $? -eq 0 ]; then
        success "Nginx SSL config uploaded"
    else
        error "Nginx config upload failed"
    fi

    info "Enabling site and reloading OpenResty..."
    ssh $VPS_HOST << 'ENDSSH' 2>/dev/null
        rm -f /etc/nginx/sites-enabled/default
        rm -f /etc/nginx/sites-enabled/nginx-entaprenua.conf
        ln -sf /etc/nginx/sites-available/nginx-entaprenua.conf /etc/nginx/sites-enabled/nginx-entaprenua.conf
        
        # Test config - if fails, keep old config running
        if /usr/local/openresty/nginx/sbin/nginx -t; then
            # Try reload first
            systemctl reload openresty || true
            sleep 1
            # If reload didn't work, restart
            if ! systemctl is-active --quiet openresty; then
                systemctl restart openresty
            fi
        else
            echo "Config test failed - not reloading"
            exit 1
        fi
ENDSSH
    if [ $? -eq 0 ]; then
        success "OpenResty configured and reloaded"
    else
        error "OpenResty configuration failed - check with: /usr/local/openresty/nginx/sbin/nginx -t"
    fi
else
    error "Nginx config not found at $NGINX_CONFIG"
fi

section "8" "VERIFYING DEPLOYMENT"

info "Checking backend service status..."
STATUS=$(ssh $VPS_HOST "systemctl is-active entaprenua-backend" 2>/dev/null)
if [ "$STATUS" = "active" ]; then
    success "Backend service is running"
else
    error "Backend service status: $STATUS"
fi

info "Checking OpenResty status..."
NGINX_STATUS=$(ssh $VPS_HOST "systemctl is-active openresty" 2>/dev/null)
if [ "$NGINX_STATUS" = "active" ]; then
    success "OpenResty is running"
else
    error "OpenResty status: $NGINX_STATUS"
fi

info "Checking Lua scripts..."
LUA_OK=$(ssh $VPS_HOST "[ -f /etc/nginx/lua/storefront-lookup.lua ] && echo 'ok'" 2>/dev/null)
if [ "$LUA_OK" = "ok" ]; then
    success "Lua scripts installed"
else
    error "Lua scripts not found"
fi

info "Testing Redis connection from backend..."
REDIS_TEST=$(ssh $VPS_HOST "curl -s http://127.0.0.1:8080/api/health 2>/dev/null | grep -o 'redis.*enabled' || echo 'checking'" 2>/dev/null)
if [ -n "$REDIS_TEST" ]; then
    success "Backend responding"
else
    info "Backend health check - check logs if needed"
fi

echo ""
echo "═══════════════════════════════════════════════════"
echo "  ✓ BACKEND DEPLOYED SUCCESSFULLY"
echo "═══════════════════════════════════════════════════"
echo "  JAR Location:  /opt/entaprenua/backend/entaprenua.jar"
echo "  Backend:       entaprenua-backend"
echo "  Nginx:         OpenResty with Lua"
echo "  Lua Scripts:   /etc/nginx/lua/"
echo "  Redis Host:    $REDIS_HOST:$REDIS_PORT"
echo "  Redis Auth:    ${REDIS_AUTH:+yes (set)}"
echo "  Backend:       $STATUS"
echo "  OpenResty:    $NGINX_STATUS"
echo "═══════════════════════════════════════════════════"
echo ""
