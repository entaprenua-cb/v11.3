#!/bin/bash

VPS_HOST="${VPS_HOST:-vps}"

spinner() {
    local pid=$1
    local delay=0.1
    local spinstr='|/-\'
    while kill -0 $pid 2>/dev/null; do
        local temp=${spinstr#?}
        printf " [%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

step() { echo ""; echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"; echo " $1"; echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"; }
info() { echo "  ➜ $1"; }
success() { echo "  ✓ $1"; }
error() { echo "  ✗ $1"; }

echo ""
echo "██╗   ██╗██╗ ██████╗████████╗ ██████╗ ██████╗ ██╗   ██╗"
echo "██║   ██║██║██╔════╝╚══██╔══╝██╔═══██╗██╔══██╗╚██╗ ██╔╝"
echo "██║   ██║██║██║        ██║   ██║   ██║██████╔╝ ╚████╔╝ "
echo "╚██╗ ██╔╝██║██║        ██║   ██║   ██║██╔══██╗  ╚██╔╝  "
echo " ╚████╔╝ ██║╚██████╗   ██║   ╚██████╔╝██║  ██║   ██║   "
echo "  ╚═══╝ ╚═╝ ╚═════╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝   ╚═╝   "
echo ""

step "RELOADING SYSTEMD"

info "Reloading systemd daemon..."
ssh $VPS_HOST "sudo systemctl daemon-reload" &
PID0=$!
spinner $PID0
wait $PID0
success "Systemd reloaded"

step "STARTING SERVICES"

info "Starting entaprenua-backend..."
ssh $VPS_HOST "sudo systemctl start entaprenua-backend" &
PID1=$!
spinner $PID1
wait $PID1

info "Starting entaprenua-admin..."
ssh $VPS_HOST "sudo systemctl start entaprenua-admin" &
PID2=$!
spinner $PID2
wait $PID2

step "CHECKING STATUS"

echo ""
BACKEND_STATUS=$(ssh $VPS_HOST "sudo systemctl is-active entaprenua-backend" 2>/dev/null)
FRONTEND_STATUS=$(ssh $VPS_HOST "sudo systemctl is-active entaprenua-admin" 2>/dev/null)

if [ "$BACKEND_STATUS" = "active" ]; then
    success "Backend: active"
else
    error "Backend: $BACKEND_STATUS"
fi

if [ "$FRONTEND_STATUS" = "active" ]; then
    success "Admin: active"
else
    error "Admin: $FRONTEND_STATUS"
fi

echo ""
echo "═══════════════════════════════════════════════════"
echo "  Services started successfully"
echo "═══════════════════════════════════════════════════"
echo ""
