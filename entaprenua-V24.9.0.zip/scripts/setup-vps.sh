#!/bin/bash

set -e

# =============================================================================
# VPS Prerequisites Setup Script
# =============================================================================
# This script sets up all prerequisites for running the Entaprenua platform
# on a fresh VPS. Run this BEFORE deploy-backend.sh.
#
# Usage:
#   chmod +x setup-vps.sh
#   ./setup-vps.sh
#
# =============================================================================

set -e

VPS_HOST="${VPS_HOST:-vps}"
DOMAIN="${DOMAIN:-entaprenua.com}"
ADMIN_EMAIL="${ADMIN_EMAIL:-admin@entaprenua.com}"
GITHUB_ORG="${GITHUB_ORG:-entaprenua}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

spinner() {
    local pid=$1
    local delay=0.1
    local spinstr='|/-\'
    while kill -0 $pid 2>/dev/null; do
        local temp=${spinstr#?}
        printf " [%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

section() {
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo " $1"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

# Check if running on local machine or remote
check_vps_connection() {
    if [ -z "$VPS_HOST" ]; then
        read -p "Enter VPS IP address: " VPS_HOST
    fi
    
    info "Testing connection to $VPS_HOST..."
    if ! ssh -o ConnectTimeout=10 "$VPS_HOST" "echo 'Connection OK'" &>/dev/null; then
        error "Cannot connect to VPS. Check IP address and SSH key."
        exit 1
    fi
    info "Connected to VPS successfully"
}

# =============================================================================
# STEP 1: System Update & Prerequisites
# =============================================================================
step1_system_update() {
    section "STEP 1: System Update & Prerequisites"
    
    info "Updating system packages..."
    ssh $VPS_HOST "sudo bash -s" << 'ENDSSH'
        export DEBIAN_FRONTEND=noninteractive
        
        # Update package lists
        apt-get update -qq
        
        # Install essential packages
        apt-get install -y \
            curl \
            wget \
            git \
            vim \
            htop \
            net-tools \
            unzip \
            zip \
            ca-certificates \
            gnupg2 \
            lsb-release \
            software-properties-common \
            apt-transport-https \
            ca-certificates \
            openssl
            
        info "System packages installed"
ENDSSH
    
    success
}

# =============================================================================
# STEP 2: Java JDK 21
# =============================================================================
step2_java() {
    section "STEP 2: Java JDK 21"
    
    info "Checking for existing Java installation..."
    JAVA_EXISTS=$(ssh $VPS_HOST "sudo [ -d /usr/local/jdk-21.0.2 ] && echo 'yes' || echo 'no'")
    
    if [ "$JAVA_EXISTS" = "yes" ]; then
        info "Java JDK 21 already installed"
    else
        info "Installing OpenJDK 21..."
        ssh $VPS_HOST "sudo bash -s" << 'ENDSSH'
            export DEBIAN_FRONTEND=noninteractive
            
            # Download JDK 21
            cd /tmp
            wget -q https://download.java.net/java/GA/jdk21.0.2/f2283984656d49d69e91c558476027ac/13/GPL/openjdk-21.0.2_linux-x64_bin.tar.gz
            
            # Extract to /usr/local
            tar -xzf openjdk-21.0.2_linux-x64_bin.tar.gz
            mv jdk-21.0.2 /usr/local/jdk-21.0.2
            
            # Set up Java alternatives
            update-alternatives --install /usr/bin/java java /usr/local/jdk-21.0.2/bin/java 100
            update-alternatives --install /usr/bin/javac javac /usr/local/jdk-21.0.2/bin/javac 100
            
            # Clean up
            rm -f openjdk-21.0.2_linux-x64_bin.tar.gz
            
            echo "JAVA_HOME=/usr/local/jdk-21.0.2" >> /etc/environment
            export JAVA_HOME=/usr/local/jdk-21.0.2
            echo "export JAVA_HOME=/usr/local/jdk-21.0.2" >> /root/.bashrc
            
            info "Java JDK 21 installed successfully"
ENDSSH
    fi
    
    # Verify Java
    JAVA_VERSION=$(ssh $VPS_HOST "java -version 2>&1 | head -1")
    info "Java version: $JAVA_VERSION"
    success
}

# =============================================================================
# STEP 3: Gradle 8.6
# =============================================================================
step3_gradle() {
    section "STEP 3: Gradle 8.6"
    
    info "Checking for existing Gradle installation..."
    GRADLE_EXISTS=$(ssh $VPS_HOST "sudo [ -d /usr/local/gradle-8.6 ] && echo 'yes' || echo 'no'")
    
    if [ "$GRADLE_EXISTS" = "yes" ]; then
        info "Gradle 8.6 already installed"
    else
        info "Installing Gradle 8.6..."
        ssh $VPS_HOST "sudo bash -s" << 'ENDSSH'
            export DEBIAN_FRONTEND=noninteractive
            
            # Download Gradle 8.6
            cd /tmp
            wget -q https://services.gradle.org/distributions/gradle-8.6-bin.zip
            
            # Extract to /usr/local
            unzip -q gradle-8.6-bin.zip
            mv gradle-8.6 /usr/local/gradle-8.6
            
            # Create symlink
            ln -sf /usr/local/gradle-8.6/bin/gradle /usr/local/bin/gradle
            
            # Clean up
            rm -f gradle-8.6-bin.zip
            
            echo "export PATH=/usr/local/gradle-8.6/bin:\$PATH" >> /root/.bashrc
            
            info "Gradle 8.6 installed successfully"
ENDSSH
    fi
    
    # Verify Gradle
    GRADLE_VERSION=$(ssh $VPS_HOST "gradle --version | head -1")
    info "Gradle version: $GRADLE_VERSION"
    success
}

# =============================================================================
# STEP 4: Node.js 20 LTS
# =============================================================================
step4_nodejs() {
    section "STEP 4: Node.js 20 LTS"
    
    info "Checking for existing Node.js installation..."
    NODE_EXISTS=$(ssh $VPS_HOST "node --version 2>/dev/null | grep -q 'v20' && echo 'yes' || echo 'no'")
    
    if [ "$NODE_EXISTS" = "yes" ]; then
        info "Node.js 20 already installed"
    else
        info "Installing Node.js 20..."
        ssh $VPS_HOST "sudo bash -s" << 'ENDSSH'
            export DEBIAN_FRONTEND=noninteractive
            
            # Install NodeSource Node.js 20 repository
            curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
            
            # Install Node.js
            apt-get install -y nodejs
            
            # Install yarn globally
            npm install -g yarn
            
            info "Node.js $(node --version) installed successfully"
ENDSSH
    fi
    
    # Verify Node.js
    NODE_VERSION=$(ssh $VPS_HOST "node --version")
    NPM_VERSION=$(ssh $VPS_HOST "npm --version")
    info "Node.js $NODE_VERSION, npm $NPM_VERSION"
    success
}

# =============================================================================
# STEP 5: PostgreSQL 18 (Percona with pg_tde)
# =============================================================================
step5_postgresql() {
    section "STEP 5: PostgreSQL 18 (Percona with pg_tde)"
    
    info "Checking for existing PostgreSQL installation..."
    PG_EXISTS=$(ssh $VPS_HOST "pg_isready 2>/dev/null && echo 'yes' || echo 'no'")
    
    if [ "$PG_EXISTS" = "yes" ]; then
        info "PostgreSQL already installed"
    else
        info "Installing Percona PostgreSQL 18 with pg_tde..."
        ssh $VPS_HOST "sudo bash -s" << 'ENDSSH'
            export DEBIAN_FRONTEND=noninteractive
            
            # Install Percona release tooling
            cd /tmp
            wget -q https://repo.percona.com/apt/percona-release_latest.generic_all.deb
            dpkg -i percona-release_latest.generic_all.deb
            percona-release enable-only ppg-18
            apt-get update -qq
            
            # Install Percona PG 18 + pg_tde
            apt-get install -y percona-postgresql-18 percona-postgresql-client-18 percona-postgresql-contrib percona-pg-tde18
            
            # Create cluster
            pg_createcluster 18 main --start -- -U postgres
            
            # Enable pg_tde in shared_preload_libraries
            su - postgres -c "psql -c \"ALTER SYSTEM SET shared_preload_libraries = 'pg_tde';\""
            systemctl restart postgresql
            
            # Create extension in template1
            sleep 2
            su - postgres -c "psql -d template1 -c 'CREATE EXTENSION IF NOT EXISTS pg_tde;'"
            
            info "PostgreSQL 18 (Percona) installed and started with pg_tde"
ENDSSH
    fi
    
    info "Configuring PostgreSQL database and user..."
    ssh $VPS_HOST "sudo bash -s" << 'ENDSSH'
        # Wait for PostgreSQL to be ready
        sleep 2
        
        # Create database user if not exists
        su - postgres -c "psql -c \"CREATE USER nesh WITH PASSWORD '@martoh2551#' SUPERUSER;\"" 2>/dev/null || true
        
        # Create database if not exists
        su - postgres -c "psql -c \"CREATE DATABASE entaprenua OWNER nesh;\"" 2>/dev/null || true
        
        # Enable CITEXT and ltree extensions
        su - postgres -c "psql -d entaprenua -c \"CREATE EXTENSION IF NOT EXISTS citext;\"" 2>/dev/null || true
        su - postgres -c "psql -d entaprenua -c \"CREATE EXTENSION IF NOT EXISTS ltree;\"" 2>/dev/null || true
        
        info "Database configured"
ENDSSH
    
    success
}

# =============================================================================
# STEP 6: Redis
# =============================================================================
step6_redis() {
    section "STEP 6: Redis"
    
    info "Checking for existing Redis installation..."
    REDIS_EXISTS=$(ssh $VPS_HOST "redis-cli ping 2>/dev/null | grep -q PONG && echo 'yes' || echo 'no'")
    
    if [ "$REDIS_EXISTS" = "yes" ]; then
        info "Redis already installed"
    else
        info "Installing Redis..."
        ssh $VPS_HOST "sudo bash -s" << 'ENDSSH'
            export DEBIAN_FRONTEND=noninteractive
            
            # Install Redis
            apt-get install -y redis-server
            
            # Configure Redis to listen on localhost only
            sed -i 's/bind 127.0.0.1 ::1/bind 127.0.0.1/' /etc/redis/redis.conf
            
            # Set password if provided
            if [ -n "${REDIS_PASSWORD:-}" ]; then
                sed -i "s/# requirepass.*/requirepass $REDIS_PASSWORD/" /etc/redis/redis.conf
            fi
            
            # Start and enable Redis
            systemctl restart redis-server
            systemctl enable redis-server
            
            info "Redis installed and started"
ENDSSH
    fi
    
    # Verify Redis
    REDIS_STATUS=$(ssh $VPS_HOST "redis-cli ping 2>/dev/null")
    info "Redis status: $REDIS_STATUS"
    success
}

# =============================================================================
# STEP 7: OpenResty with Lua
# =============================================================================
step7_openresty() {
    section "STEP 7: OpenResty with Lua"
    
    info "Checking for existing OpenResty installation..."
    OPENRESTY_EXISTS=$(ssh $VPS_HOST "which openresty 2>/dev/null")
    
    if [ -n "$OPENRESTY_EXISTS" ]; then
        info "OpenResty already installed"
    else
        info "Installing OpenResty..."
        ssh $VPS_HOST "sudo bash -s" << 'ENDSSH'
            export DEBIAN_FRONTEND=noninteractive
            
            # Stop and disable regular nginx if running
            systemctl stop nginx 2>/dev/null || true
            systemctl disable nginx 2>/dev/null || true
            
            # Install prerequisites
            apt-get install -y curl gnupg2 ca-certificates lsb-release
            
            # Add OpenResty GPG key
            wget -qO - https://openresty.org/package/pubkey.gpg | apt-key add - 2>/dev/null
            
            # Add OpenResty repo
            OS_VERSION=$(lsb_release -sc)
            echo "deb http://openresty.org/package/ubuntu $OS_VERSION main" | tee /etc/apt/sources.list.d/openresty.list
            
            # Install OpenResty
            apt-get update -qq
            apt-get install -y openresty
            
            info "OpenResty installed"
ENDSSH
    fi
    
    info "Configuring OpenResty..."
    ssh $VPS_HOST "sudo bash -s" << 'ENDSSH'
        OPENRESTY_CONF="/usr/local/openresty/nginx/conf/nginx.conf"
        
        # Add sites-enabled include after mime.types include
        if ! grep -q "sites-enabled" "$OPENRESTY_CONF"; then
            sed -i '/include.*mime.types/a\    include /etc/nginx/sites-enabled/*;' "$OPENRESTY_CONF"
        fi
        
        # Add lua_package_path in http block
        if ! grep -q "lua_package_path" "$OPENRESTY_CONF"; then
            sed -i '/include.*sites-enabled/a\    lua_package_path '"'"'\/usr\/local\/openresty\/lualib\/?.lua;;\/etc\/nginx\/lua\/?.lua;'"'"';;' "$OPENRESTY_CONF"
        fi
        
        # Add env directives at the TOP of the file
        if ! grep -q 'env REDIS_HOST' "$OPENRESTY_CONF"; then
            sed -i '1i\env REDIS_HOST;\nenv REDIS_PORT;\nenv REDIS_AUTH;\nenv REDIS_KEY_PREFIX;' "$OPENRESTY_CONF"
        fi
        
        # Create Lua scripts directory
        mkdir -p /etc/nginx/lua
        
        # Enable and start OpenResty
        systemctl enable openresty
        systemctl start openresty
        
        info "OpenResty configured and started"
ENDSSH
    
    success
}

# =============================================================================
# STEP 8: SSL/TLS - Let's Encrypt via deploy-backend.sh
# =============================================================================
step8_ssl() {
    section "STEP 8: SSL/TLS"
    
    info "SSL/TLS is configured automatically by deploy-backend.sh"
    info "  - Let's Encrypt wildcard certificates via certbot"
    info "  - DNS-01 challenge via Cloudflare API"
    info "  - Automatic renewal configured"
    info ""
    info "Prerequisites for SSL:"
    info "  1. Cloudflare account with entaprenua.com added"
    info "  2. DNS records pointing to VPS (see CLOUDFLARE_SETUP.md)"
    info "  3. Cloudflare API token (see scripts/ssl/cloudflare.ini)"
    info ""
    info "SSL will be set up when you run deploy-backend.sh"
    success
}

# =============================================================================
# STEP 8: Cloudflare Origin CA Certificate
# =============================================================================
step8_cloudflare_cert() {
    section "STEP 8: Cloudflare Origin CA Certificate"
    
    info "Creating SSL directories..."
    ssh $VPS_HOST "sudo bash -s" << 'ENDSSH' 2>/dev/null
        mkdir -p /etc/ssl/certs
        mkdir -p /etc/ssl/private
        chmod 700 /etc/ssl/private
        chmod 755 /etc/ssl/certs
        info "SSL directories created"
ENDSSH
    
    info "Cloudflare Origin CA Certificate setup required..."
    warn "IMPORTANT: You need to download the Origin CA Certificate from Cloudflare"
    warn ""
    warn "Steps to get the certificate:"
    warn "  1. Go to: https://dash.cloudflare.com > entaprenua.com > SSL/TLS > Origin Server"
    warn "  2. Click 'Create Certificate'"
    warn "  3. Leave defaults (Hostname: *.your-domain.com)"
    warn "  4. Click 'Create'"
    warn "  5. Copy the Origin Certificate and Private Key"
    warn ""
    warn "Then run these commands on the VPS:"
    warn '  # Create certificate file'
    warn '  cat > /etc/ssl/certs/cloudflare-origin.pem << EOF'
    warn '  <paste your Origin Certificate here>'
    warn '  EOF'
    warn ""
    warn '  # Create private key file'
    warn '  cat > /etc/ssl/private/cloudflare-origin.key << EOF'
    warn '  <paste your Private Key here>'
    warn '  EOF'
    warn ""
    info "Certificate installation will be completed during deploy-backend.sh"
    success
}

# =============================================================================
# STEP 9: GitHub Automation SSH Key
# =============================================================================
step9_github_ssh() {
    section "STEP 9: GitHub Automation SSH Key"
    
    info "Checking for existing GitHub automation SSH key..."
    SSH_KEY_EXISTS=$(ssh $VPS_HOST "sudo [ -f /root/.ssh/github_automation ] && echo 'yes' || echo 'no'")
    
    if [ "$SSH_KEY_EXISTS" = "yes" ]; then
        info "GitHub automation SSH key already exists"
    else
        info "Generating GitHub automation SSH key..."
        warn "IMPORTANT: You need to add this public key to your GitHub organization"
        warn "Navigate to: GitHub > Organization > Settings > SSH Keys"
        
        ssh $VPS_HOST "sudo bash -s" << 'ENDSSH'
            # Generate SSH key
            ssh-keygen -t ed25519 -C "automation@entaprenua" -f /root/.ssh/github_automation -N ""
            
            # Set correct permissions
            chmod 600 /root/.ssh/github_automation
            chmod 644 /root/.ssh/github_automation.pub
            
            # Configure git to use SSH
            git config --global url."git@github.com:".insteadOf "https://github.com/"
            
            # Display public key
            echo ""
            echo "=========================================="
            echo "ADD THIS PUBLIC KEY TO GITHUB:"
            echo "=========================================="
            cat /root/.ssh/github_automation.pub
            echo "=========================================="
            echo ""
ENDSSH
    fi
    
    info "Testing GitHub SSH connection..."
    GITHUB_TEST=$(ssh $VPS_HOST "ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -T git@github.com 2>&1" | grep -q "successfully authenticated" && echo "yes" || echo "no")
    
    if [ "$GITHUB_TEST" = "yes" ]; then
        info "GitHub SSH connection verified"
    else
        warn "GitHub SSH not verified. Make sure you added the public key to GitHub."
    fi
    
    success
}

# =============================================================================
# STEP 10: Create Application Directories
# =============================================================================
step10_directories() {
    section "STEP 10: Application Directories"
    
    info "Creating application directories..."
    ssh $VPS_HOST "sudo bash -s" << 'ENDSSH'
        # Create main application directory
        mkdir -p /opt/entaprenua/backend
        
        # Create VCS directories
        mkdir -p /var/lib/entaprenua/{stores,platform,temp}
        
        # Create database directory
        mkdir -p /repos/Apps/entaprenua/db
        
        # Set ownership (will be updated when nesh user is created)
        chown -R root:root /opt/entaprenua
        chown -R root:root /var/lib/entaprenua
        chown -R root:root /repos/Apps
        
        info "Directories created"
ENDSSH
    
    success
}

# =============================================================================
# STEP 11: Create nesh User
# =============================================================================
step11_user() {
    section "STEP 11: Application User (nesh)"
    
    info "Creating nesh user..."
    ssh $VPS_HOST "sudo bash -s" << 'ENDSSH'
        # Create nesh user if not exists
        if ! id nesh &>/dev/null; then
            useradd -m -s /bin/bash nesh
            echo "nesh:nesh" | chpasswd
        fi
        
        # Add to sudo group
        usermod -aG sudo nesh
        
        # Copy SSH keys from root
        mkdir -p /home/nesh/.ssh
        cp /root/.ssh/authorized_keys /home/nesh/.ssh/ 2>/dev/null || true
        cp /root/.ssh/github_automation* /home/nesh/.ssh/ 2>/dev/null || true
        
        # Set ownership and permissions
        chown -R nesh:nesh /home/nesh
        chmod 700 /home/nesh/.ssh
        chmod 600 /home/nesh/.ssh/* 2>/dev/null || true
        
        # Update application directory ownership
        chown -R nesh:nesh /opt/entaprenua
        chown -R nesh:nesh /var/lib/entaprenua
        
        info "User nesh created and configured"
ENDSSH
    
    success
}

# =============================================================================
# STEP 12: Firewall Setup
# =============================================================================
step12_firewall() {
    section "STEP 12: Firewall Setup (UFW)"
    
    info "Configuring UFW firewall..."
    ssh $VPS_HOST "sudo bash -s" << 'ENDSSH'
        # Install UFW if not installed
        apt-get install -y ufw 2>/dev/null || true
        
        # Default policies
        ufw default deny incoming
        ufw default allow outgoing
        
        # Allow SSH (prevent lockout)
        ufw allow 22/tcp
        
        # Allow HTTP/HTTPS
        ufw allow 80/tcp
        ufw allow 443/tcp
        
        # Enable UFW (with default yes to avoid prompt)
        echo "y" | ufw enable || true
        
        # Show status
        ufw status verbose
        
        info "Firewall configured"
ENDSSH
    
    success
}

# =============================================================================
# MAIN EXECUTION
# =============================================================================
main() {
    echo ""
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║          Entaprenua VPS Prerequisites Setup                  ║"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo ""
    
    # Check VPS connection
    check_vps_connection
    
    # Run setup steps
    step1_system_update
    step2_java
    step3_gradle
    step4_nodejs
    step5_postgresql
    step6_redis
    step7_openresty
    step8_ssl
    step9_github_ssh
    step10_directories
    step11_user
    step12_firewall
    
    echo ""
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║                   SETUP COMPLETE!                            ║"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo ""
    echo "Next steps:"
    echo "  1. Add GitHub SSH public key to your GitHub organization"
    echo "  2. Configure Cloudflare (see docs/CLOUDFLARE_SETUP.md):"
    echo "     - Add entaprenua.com to Cloudflare"
    echo "     - Create DNS A records (*, entaprenua.com, www)"
    echo "     - Set DNS records to 'DNS Only' (not Proxied)"
    echo "     - Set SSL/TLS mode to 'Full'"
    echo "     - Update nameservers at your registrar"
    echo "  3. Update scripts/ssl/cloudflare.ini with your API token"
    echo "  4. Run deploy-backend.sh"
    echo ""
}

# Run main function
main "$@"
