#!/bin/bash

# =============================================================================
# Entaprenua Database Sync Script
# =============================================================================
# Dumps the local PostgreSQL database and restores it to the VPS.
# Drops the existing VPS database and recreates it from the local snapshot.
#
# USAGE:
#   ./sync-db.sh
#
# ENVIRONMENT VARIABLES (optional):
#   VPS_HOST    - SSH host alias (default: vps) set in ~/.ssh/config
#   APP_USER    - System user running the backend (default: martinmunene018)
#   DB_NAME     - Database name (default: entaprenua)
#   DB_USER     - Database user (default: nesh)
#   DB_PASSWORD - Database password (default: @martoh2551#)
# =============================================================================

set -e

CONFIG_FILE="$HOME/.config/vps.ini"
if [ -f "$CONFIG_FILE" ]; then
  source "$CONFIG_FILE"
fi

VPS_HOST="${VPS_HOST:-vps}"
APP_USER="${APP_USER:-martinmunene018}"
DB_NAME="${DB_NAME:-entaprenua}"
DB_USER="${DB_USER:-nesh}"
DB_PASSWORD="${DB_PASSWORD:-@martoh2551#}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

DUMP_PATH="/tmp/${DB_NAME}-dump-$(date +%s).dump"

spinner() {
    local pid=$1
    local delay=0.1
    local spinstr='|/-\'
    while kill -0 $pid 2>/dev/null; do
        local temp=${spinstr#?}
        printf " [%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

step() {
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo " STEP $1: $2"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

info() {
    echo "  ➜ $1"
}

success() {
    echo "  ✓ $1"
}

error() {
    echo "  ✗ $1"
    exit 1
}

# ---------------------------------------------------------------------------
# Confirm
# ---------------------------------------------------------------------------
echo ""
echo "╔═══════════════════════════════════════════════════╗"
echo "║     Entaprenua Database Sync                      ║"
echo "╠═══════════════════════════════════════════════════╣"
echo "║  This will REPLACE the database on $VPS_HOST  ║"
echo "║  with a snapshot of your local database.          ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""
echo "  Local DB:  $DB_NAME on localhost"
echo "  VPS:       $VPS_HOST"
echo "  Backend:   entaprenua-backend (will be restarted)"
echo ""
read -rp "  Continue? [y/N] " confirm
if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
    echo "  Aborted."
    exit 0
fi

# ---------------------------------------------------------------------------
# Step 1: Dump local database
# ---------------------------------------------------------------------------
step "1" "DUMPING LOCAL DATABASE"

info "Dumping $DB_NAME to $DUMP_PATH..."
PGPASSWORD="$DB_PASSWORD" pg_dump -U "$DB_USER" -d "$DB_NAME" --no-owner --no-acl -Fc > "$DUMP_PATH" &
PID=$!
spinner $PID
wait $PID

if [ -f "$DUMP_PATH" ]; then
    DUMP_SIZE=$(du -h "$DUMP_PATH" | cut -f1)
    success "Local database dumped ($DUMP_SIZE)"
else
    error "Dump failed"
fi

# ---------------------------------------------------------------------------
# Step 2: Copy dump to VPS
# ---------------------------------------------------------------------------
step "2" "COPYING DUMP TO VPS"

info "Uploading to $VPS_HOST:$DUMP_PATH..."
rsync -avz --progress -e "ssh" "$DUMP_PATH" "$VPS_HOST:$DUMP_PATH" &
PID=$!
spinner $PID
wait $PID

if [ $? -eq 0 ]; then
    success "Dump uploaded"
else
    error "Upload failed"
fi

# Remove local dump
rm -f "$DUMP_PATH"

# ---------------------------------------------------------------------------
# Step 3: Stop backend service
# ---------------------------------------------------------------------------
step "3" "STOPPING BACKEND SERVICE"

info "Stopping entaprenua-backend..."
ssh $VPS_HOST "sudo systemctl stop entaprenua-backend" &
PID=$!
spinner $PID
wait $PID

STATUS=$(ssh $VPS_HOST "systemctl is-active entaprenua-backend" 2>/dev/null)
if [ "$STATUS" = "inactive" ] || [ "$STATUS" = "dead" ]; then
    success "Backend service stopped"
else
    error "Failed to stop backend service (status: $STATUS)"
fi

# ---------------------------------------------------------------------------
# Step 4: Drop and recreate database on VPS
# ---------------------------------------------------------------------------
step "4" "RECREATING DATABASE ON VPS"

info "Killing active connections, dropping and recreating $DB_NAME..."
ssh $VPS_HOST << ENDSSH
    sudo -i -u postgres psql -c "SELECT pg_terminate_backend(pg_stat_activity.pid) FROM pg_stat_activity WHERE pg_stat_activity.datname = '$DB_NAME' AND pid <> pg_backend_pid();" 2>/dev/null
    sudo -i -u postgres psql -c "DROP DATABASE IF EXISTS $DB_NAME;" 2>/dev/null
    sudo -i -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;" 2>/dev/null
ENDSSH
if [ $? -eq 0 ]; then
    success "Database recreated"
else
    error "Failed to recreate database"
fi

# ---------------------------------------------------------------------------
# Step 5: Restore database on VPS
# ---------------------------------------------------------------------------
step "5" "RESTORING DATABASE ON VPS"

info "Restoring from $DUMP_PATH..."
ssh $VPS_HOST "PGPASSWORD='$DB_PASSWORD' pg_restore -U $DB_USER -d $DB_NAME $DUMP_PATH" &
PID=$!
spinner $PID
wait $PID

if [ $? -eq 0 ]; then
    success "Database restored"
else
    error "Restore failed"
fi

# ---------------------------------------------------------------------------
# Step 6: Start backend service
# ---------------------------------------------------------------------------
step "6" "STARTING BACKEND SERVICE"

info "Starting entaprenua-backend..."
ssh $VPS_HOST "sudo systemctl start entaprenua-backend"
sleep 3

STATUS=$(ssh $VPS_HOST "systemctl is-active entaprenua-backend" 2>/dev/null)
if [ "$STATUS" = "active" ]; then
    success "Backend service is running"
else
    error "Backend service status: $STATUS"
fi

# ---------------------------------------------------------------------------
# Step 7: Cleanup remote dump
# ---------------------------------------------------------------------------
step "7" "CLEANING UP"

info "Removing remote dump..."
ssh $VPS_HOST "sudo rm -f $DUMP_PATH" &
PID=$!
spinner $PID
wait $PID

success "Remote dump removed"

# ---------------------------------------------------------------------------
# Step 8: Verify
# ---------------------------------------------------------------------------
step "8" "VERIFYING"

info "Checking tables on VPS..."
TABLE_COUNT=$(ssh $VPS_HOST "sudo -i -u postgres psql -d $DB_NAME -t -c 'SELECT count(*) FROM information_schema.tables WHERE table_schema = '\''public'\'';'" 2>/dev/null | tr -d ' ')
success "$TABLE_COUNT tables present"

info "Checking site..."
HTTP_CODE=$(curl -s -o /dev/null -w '%{http_code}' "https://$VPS_HOST" 2>/dev/null || echo "unreachable")
success "Site responds: $HTTP_CODE"

echo ""
echo "╔═══════════════════════════════════════════════════╗"
echo "║  ✓ DATABASE SYNCED SUCCESSFULLY                   ║"
echo "╠═══════════════════════════════════════════════════╣"
echo "║  Source:  localhost / $DB_NAME             ║"
echo "║  Target:  $VPS_HOST / $DB_NAME               ║"
echo "║  Tables:  $TABLE_COUNT                              ║"
echo "║  Site:    https://$VPS_HOST ($HTTP_CODE)           ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""
