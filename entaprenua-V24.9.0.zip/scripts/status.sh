#!/bin/bash

VPS_HOST="${VPS_HOST:-vps}"

step() { echo ""; echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"; echo " $1"; echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"; }
success() { echo "  ✓ $1"; }
error() { echo "  ✗ $1"; }
info() { echo "  ➜ $1"; }

echo ""
echo "███████╗██████╗ ███████╗ █████╗ ██████╗ "
echo "██╔════╝██╔══██╗██╔════╝██╔══██╗██╔══██╗"
echo "███████╗██████╔╝█████╗  ███████║██║  ██║"
echo "╚════██║██╔═══╝ ██╔══╝  ██╔══██║██║  ██║"
echo "███████║██║     ███████╗██║  ██║██████╔╝"
echo "╚══════╝╚═╝     ╚══════╝╚═╝  ╚═╝╚═════╝ "
echo ""

BACKEND_STATUS=$(ssh $VPS_HOST "sudo systemctl is-active entaprenua-backend" 2>/dev/null)
FRONTEND_STATUS=$(ssh $VPS_HOST "sudo systemctl is-active entaprenua-admin" 2>/dev/null)

step "SERVICE STATUS"

if [ "$BACKEND_STATUS" = "active" ]; then
    success "Backend (entaprenua-backend): RUNNING"
else
    error "Backend (entaprenua-backend): STOPPED ($BACKEND_STATUS)"
fi

if [ "$FRONTEND_STATUS" = "active" ]; then
    success "Admin (entaprenua-admin): RUNNING"
else
    error "Admin (entaprenua-admin): STOPPED ($FRONTEND_STATUS)"
fi

step "DETAILED STATUS"

echo ""
echo "━━━ BACKEND ━━━"
ssh $VPS_HOST "sudo systemctl status entaprenua-backend --no-pager -l" 2>/dev/null | head -20

echo ""
echo "━━━ FRONTEND ━━━"
ssh $VPS_HOST "sudo systemctl status entaprenua-admin --no-pager -l" 2>/dev/null | head -20

echo ""
echo "═══════════════════════════════════════════════════"
