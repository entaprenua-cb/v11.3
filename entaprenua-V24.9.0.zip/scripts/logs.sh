#!/bin/bash

VPS_HOST="${VPS_HOST:-vps}"

step() { echo ""; echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"; echo " $1"; echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"; }
info() { echo "  ➜ $1"; }

SERVICE="${1:-all}"
LINES="${2:-50}"

echo ""
echo "███████╗██████╗ ███████╗ █████╗ ██████╗ "
echo "██╔════╝██╔══██╗██╔════╝██╔══██╗██╔══██╗"
echo "███████╗██████╔╝█████╗  ███████║██║  ██║"
echo "╚════██║██╔═══╝ ██╔══╝  ██╔══██║██║  ██║"
echo "███████║██║     ███████╗██║  ██║██████╔╝"
echo "╚══════╝╚═╝     ╚══════╝╚═╝  ╚═╝╚═════╝ "
echo ""

case "$SERVICE" in
  backend)
    step "BACKEND LOGS"
    info "Showing last $LINES lines..."
    ssh $VPS_HOST "journalctl -u entaprenua-backend -n $LINES --no-pager"
    ;;
  admin)
    step "FRONTEND LOGS"
    info "Showing last $LINES lines..."
    ssh $VPS_HOST "journalctl -u entaprenua-admin -n $LINES --no-pager"
    ;;
  all)
    step "BACKEND LOGS"
    ssh $VPS_HOST "journalctl -u entaprenua-backend -n $LINES --no-pager"
    echo ""
    step "FRONTEND LOGS"
    ssh $VPS_HOST "journalctl -u entaprenua-admin -n $LINES --no-pager"
    ;;
  -f)
    SERVICE="${2:-all}"
    echo ""
    info "Following logs (Ctrl+C to exit)..."
    if [ "$SERVICE" = "all" ]; then
      ssh $VPS_HOST "journalctl -f -u entaprenua-backend -u entaprenua-admin"
    else
      ssh $VPS_HOST "journalctl -f -u entaprenua-$SERVICE"
    fi
    ;;
  *)
    echo "Usage: $0 [backend|admin|all] [lines]"
    echo "       $0 -f [backend|admin|all]  # Follow logs"
    echo ""
    echo "Examples:"
    echo "  $0              # Show last 50 lines of all logs"
    echo "  $0 backend 100  # Show last 100 lines of backend logs"
    echo "  $0 admin     # Show last 50 lines of admin logs"
    echo "  $0 -f           # Follow all logs"
    echo "  $0 -f backend   # Follow backend logs only"
    ;;
esac
