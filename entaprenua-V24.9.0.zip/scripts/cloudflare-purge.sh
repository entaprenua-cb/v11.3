#!/bin/bash
# =============================================================================
# Cloudflare Cache Purge Script
# =============================================================================
# Purges Cloudflare cache for the entaprenua application.
#
# USAGE:
#   ./scripts/cloudflare-purge.sh [options]
#
# OPTIONS:
#   --media       Purge media cache only
#   --static      Purge static assets cache only
#   --all         Purge entire cache (default)
#   --prefix URL  Purge URL prefix
#
# ENVIRONMENT VARIABLES:
#   CF_ZONE_ID   Cloudflare Zone ID
#   CF_TOKEN     Cloudflare API Token
#
# EXAMPLES:
#   ./scripts/cloudflare-purge.sh --media
#   ./scripts/cloudflare-purge.sh --prefix /media/
#   ./scripts/cloudflare-purge.sh --all
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../backend/.env" 2>/dev/null || true

CF_ZONE_ID="${CF_ZONE_ID:-${CLOUDFLARE_ZONE_ID:-}}"
CF_EMAIL="${CF_EMAIL:-${CLOUDFLARE_EMAIL:-}}"
CF_API_KEY="${CF_API_KEY:-${CLOUDFLARE_API_KEY:-}}"

usage() {
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  --media       Purge media cache only"
    echo "  --static      Purge static assets cache only"
    echo "  --all         Purge entire cache (default)"
    echo "  --prefix URL  Purge URL prefix"
    echo ""
    echo "Environment Variables:"
    echo "  CF_ZONE_ID    Cloudflare Zone ID"
    echo "  CF_TOKEN      Cloudflare API Token"
    exit 1
}

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"
}

error() {
    echo "ERROR: $*" >&2
    exit 1
}

check_config() {
    if [ -z "$CF_ZONE_ID" ]; then
        error "CF_ZONE_ID not set. Set in .env or environment."
    fi
    if [ -z "$CF_EMAIL" ]; then
        error "CF_EMAIL not set. Set in .env or environment."
    fi
    if [ -z "$CF_API_KEY" ]; then
        error "CF_API_KEY not set. Set in .env or environment."
    fi
}

purge_all() {
    log "Purging entire cache..."
    
    response=$(curl -s -X POST "https://api.cloudflare.com/client/v4/zones/$CF_ZONE_ID/purge_cache" \
        -H "X-Auth-Email: $CF_EMAIL" \
        -H "X-Auth-Key: $CF_API_KEY" \
        -H "Content-Type: application/json" \
        -d '{"purge_everything":true}')
    
    if echo "$response" | grep -q '"success":true'; then
        log "✓ Entire cache purged successfully"
    else
        error "Failed to purge cache: $response"
    fi
}

purge_by_tags() {
    local tags="$1"
    log "Purging cache by tags: $tags"
    
    response=$(curl -s -X POST "https://api.cloudflare.com/client/v4/zones/$CF_ZONE_ID/purge_cache" \
        -H "X-Auth-Email: $CF_EMAIL" \
        -H "X-Auth-Key: $CF_API_KEY" \
        -H "Content-Type: application/json" \
        -d "{\"tags\":[$tags]}")
    
    if echo "$response" | grep -q '"success":true'; then
        log "✓ Cache purged successfully for tags: $tags"
    else
        error "Failed to purge cache: $response"
    fi
}

purge_by_prefix() {
    local prefix="$1"
    log "Purging cache by prefix: $prefix"
    
    response=$(curl -s -X POST "https://api.cloudflare.com/client/v4/zones/$CF_ZONE_ID/purge_cache" \
        -H "X-Auth-Email: $CF_EMAIL" \
        -H "X-Auth-Key: $CF_API_KEY" \
        -H "Content-Type: application/json" \
        -d "{\"prefixes\":[\"$prefix\"]}")
    
    if echo "$response" | grep -q '"success":true'; then
        log "✓ Cache purged successfully for prefix: $prefix"
    else
        error "Failed to purge cache: $response"
    fi
}

# Main
MODE="all"

while [[ $# -gt 0 ]]; do
    case $1 in
        --media)
            MODE="media"
            shift
            ;;
        --static)
            MODE="static"
            shift
            ;;
        --all)
            MODE="all"
            shift
            ;;
        --prefix)
            MODE="prefix"
            PREFIX="$2"
            shift 2
            ;;
        -h|--help)
            usage
            ;;
        *)
            echo "Unknown option: $1"
            usage
            ;;
    esac
done

check_config

case $MODE in
    media)
        purge_by_tags '"media","static"'
        ;;
    static)
        purge_by_tags '"static","js","css"'
        ;;
    all)
        purge_all
        ;;
    prefix)
        purge_by_prefix "$PREFIX"
        ;;
esac

log "Done!"