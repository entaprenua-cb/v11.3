#!/bin/bash

# =============================================================================
# Entaprenua Template Sync Script
# =============================================================================
# Applies templates.sql to the VPS database via psql over SSH.
# Does NOT copy files — pipes SQL directly.
#
# USAGE:
#   ./sync-templates.sh
#
# ENVIRONMENT VARIABLES (override vps.ini):
#   VPS_HOST - SSH host alias (default: from vps.ini) set in ~/.ssh/config
#   DB_NAME, DB_USER, DB_PASSWORD
# =============================================================================

set -e

CONFIG_FILE="$HOME/.config/vps.ini"
if [ -f "$CONFIG_FILE" ]; then
  source "$CONFIG_FILE"
fi

VPS_HOST="${VPS_HOST:?}"
DB_NAME="${DB_NAME:-entaprenua}"
DB_USER="${DB_USER:-nesh}"
DB_PASSWORD="${DB_PASSWORD:?}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SQL_FILE="$SCRIPT_DIR/../templates/data/templates.sql"

if [ ! -f "$SQL_FILE" ]; then
  echo "✗ $SQL_FILE not found"
  exit 1
fi

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " Applying templates to $VPS_HOST"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

echo "  ➜ Running templates.sql..."
cat "$SQL_FILE" | ssh $VPS_HOST \
  "PGPASSWORD='$DB_PASSWORD' psql -U $DB_USER -d $DB_NAME -v ON_ERROR_STOP=1"

echo ""
echo "  ✓ templates applied successfully"
echo "  File: templates.sql"
echo ""
