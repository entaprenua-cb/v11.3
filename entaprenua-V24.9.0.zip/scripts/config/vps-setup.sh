#!/bin/bash
# Create nesh user, VCS directories, and configure service
# Called by deploy-backend.sh

set -e

# Create nesh user if not exists
if ! id nesh &>/dev/null; then
    echo "Creating nesh user..."
    useradd -m -s /bin/bash nesh
    echo "nesh:nesh" | chpasswd
fi

# Add to sudo group
usermod -aG sudo nesh

# Set ownership of home directory
chown -R nesh:nesh /home/nesh

echo "User nesh configured"

# Create VCS directories
echo "Creating VCS directories..."
mkdir -p /var/lib/entaprenua/{stores,platform,temp}
chown -R nesh:nesh /var/lib/entaprenua
chmod 755 /var/lib/entaprenua
chmod 755 /var/lib/entaprenua/platform
chmod 750 /var/lib/entaprenua/stores
chmod 750 /var/lib/entaprenua/temp

echo "VCS directories created"

# Update systemd service to run as nesh
echo "Configuring systemd service..."
sed -i 's/User=root/User=nesh/' /etc/systemd/system/entaprenua-backend.service 2>/dev/null || true
chown -R nesh:nesh /opt/entaprenua
systemctl daemon-reload
systemctl restart entaprenua-backend 2>/dev/null || true

echo "Service configured"
