#!/bin/bash
# SSH known_hosts configuration for VCS operations
# Called by deploy-backend.sh

set -e

# Add GitHub to known_hosts if not present
if [ ! -f /home/nesh/.ssh/known_hosts ] || ! grep -q "github.com" /home/nesh/.ssh/known_hosts; then
    echo "Creating known_hosts with GitHub SSH keys..."
    ssh-keyscan -t rsa,ed25519,ecdsa github.com >> /home/nesh/.ssh/known_hosts 2>/dev/null
    chown nesh:nesh /home/nesh/.ssh/known_hosts
    chmod 644 /home/nesh/.ssh/known_hosts
else
    echo "known_hosts already exists and contains GitHub keys"
fi

# Ensure correct ownership on all SSH files
chown -R nesh:nesh /home/nesh/.ssh

# Set all private keys (files without .pub extension) to 600
find /home/nesh/.ssh -type f ! -name "*.pub" ! -name "known_hosts" -exec chmod 600 {} \;

# Set public keys and known_hosts to 644
chmod 644 /home/nesh/.ssh/*.pub 2>/dev/null || true
chmod 644 /home/nesh/.ssh/known_hosts 2>/dev/null || true

# Ensure .ssh directory is 700
chmod 700 /home/nesh/.ssh

echo "SSH known_hosts configured"
