#!/bin/bash
# Install and configure OpenResty with Lua
# Called by deploy-backend.sh

set -e

export DEBIAN_FRONTEND=noninteractive

# Install prerequisites
apt-get update
apt-get install -y curl gnupg2 ca-certificates lsb-release

# Stop and disable regular nginx if running
systemctl stop nginx 2>/dev/null || true
systemctl disable nginx 2>/dev/null || true

# Add OpenResty GPG key
wget -qO - https://openresty.org/package/pubkey.gpg | apt-key add -

# Add OpenResty repo
OS_VERSION=$(lsb_release -sc)
echo "deb http://openresty.org/package/ubuntu $OS_VERSION main" | tee /etc/apt/sources.list.d/openresty.list

# Install OpenResty
apt-get update
apt-get install -y openresty

# Enable OpenResty
systemctl enable openresty

# Create required directories
mkdir -p /etc/openresty
mkdir -p /etc/systemd/system/openresty.service.d
mkdir -p /etc/nginx/lua
mkdir -p /etc/letsencrypt

# Upload and configure OpenResty main config
if [ -f /tmp/openresty.conf ]; then
    cp /usr/local/openresty/nginx/conf/nginx.conf /usr/local/openresty/nginx/conf/nginx.conf.bak
    cp /tmp/openresty.conf /usr/local/openresty/nginx/conf/nginx.conf
    echo "OpenResty nginx.conf uploaded"
fi

# Upload and configure environment file
if [ -f /tmp/openresty-env.conf ]; then
    cp /tmp/openresty-env.conf /etc/openresty/env.conf
    echo "OpenResty env.conf uploaded"
fi

# Upload and configure systemd override
if [ -f /tmp/openresty-service-override.conf ]; then
    cp /tmp/openresty-service-override.conf /etc/systemd/system/openresty.service.d/env.conf
    echo "OpenResty systemd override uploaded"
fi

# Reload systemd and restart OpenResty
systemctl daemon-reload
systemctl restart openresty

echo "OpenResty installation and configuration complete"
