#!/bin/bash
set -e

VPS_HOST="187.124.17.59"
VPS_USER="root"
SSH_KEY="/home/nesh/.ssh/id_ed25519"
SSH_OPTS="-i $SSH_KEY -o StrictHostKeyChecking=no -o BatchMode=yes"

LOCAL_BIN="/home/nesh/repos/Applications/entaprenua/zclint/target/release/zclint"
REMOTE_BIN="/usr/local/bin/zclint"

echo "Installing zclint to VPS..."

scp $SSH_OPTS "$LOCAL_BIN" $VPS_USER@$VPS_HOST:$REMOTE_BIN

ssh $SSH_OPTS $VPS_USER@$VPS_HOST "chmod +x $REMOTE_BIN"

ssh $SSH_OPTS $VPS_USER@$VPS_HOST "$REMOTE_BIN --version"

echo "✓ zclint installed to $REMOTE_BIN"