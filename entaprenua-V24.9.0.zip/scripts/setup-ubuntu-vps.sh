#!/bin/bash
set -e

# =============================================================================
# Entaprenua — Full VPS Provisioning Script
# =============================================================================
# Idempotent. Run on a fresh Ubuntu 24.04 VM to install everything:
#   Java 21, Node.js 22, PostgreSQL 16, Redis, Typesense 30.2, OpenResty,
#   Cloudflare Origin CA SSL, nginx reverse proxy, systemd services.
#
# USAGE:
#   ssh root@<vps-ip> 'bash -s' < setup-ubuntu-vps.sh
#
# ENVIRONMENT VARIABLES:
#   APP_USER          — system user for running services (default: martinmunene018)
#   APP_PASSWORD      — linux password for APP_USER (default: auto)
#   DB_PASSWORD       — PostgreSQL password for APP_USER (default: @martoh2551#)
#   TYPESENSE_API_KEY — Typesense admin key (default: from .env)
#   REDIS_HOST        — Redis bind address (default: 127.0.0.1)
#   REDIS_PORT        — Redis port (default: 6379)
#   SKIP_OPENRESTY    — set to 1 to skip nginx/SSL (default: 0)
#   SKIP_TYPESENSE    — set to 1 to skip Typesense (default: 0)
#   SKIP_REDIS        — set to 1 to skip Redis (default: 0)
# =============================================================================

# ── Configurable defaults ───────────────────────────────────────────────
APP_USER="${APP_USER:-martinmunene018}"
APP_PASSWORD="${APP_PASSWORD:-nesh}"
DB_PASSWORD="${DB_PASSWORD:-@martoh2551#}"
DB_NAME="${DB_NAME:-entaprenua}"
REDIS_HOST="${REDIS_HOST:-127.0.0.1}"
REDIS_PORT="${REDIS_PORT:-6379}"
TYPESENSE_API_KEY="${TYPESENSE_API_KEY:-GDR1urLtgBEA4ma2QX3IsC1Ans4LG77ZDeOgGUI80KuPqTwN}"
TYPESENSE_VERSION="${TYPESENSE_VERSION:-30.2}"
SKIP_OPENRESTY="${SKIP_OPENRESTY:-0}"
SKIP_TYPESENSE="${SKIP_TYPESENSE:-0}"
SKIP_REDIS="${SKIP_REDIS:-0}"
APP_HOME="/home/$APP_USER"

# ── Helpers ─────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "  ${GREEN}➜${NC} $1"; }
ok()    { echo -e "  ${GREEN}✓${NC} $1"; }
warn()  { echo -e "  ${YELLOW}⚠${NC} $1"; }
err()   { echo -e "  ${RED}✗${NC} $1"; }
step()  { echo ""; echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"; echo " $1"; echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"; }
banner(){ echo ""; echo "▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀"; }

need_sudo() {
    if [ "$(id -u)" -ne 0 ]; then
        echo "This script must be run as root. Use: ssh root@<ip> 'bash -s' < $0"
        exit 1
    fi
}

has() { command -v "$1" &>/dev/null; }
deb_install() { DEBIAN_FRONTEND=noninteractive apt-get install -y -qq "$@"; }
deb_update()  { apt-get update -qq; }

# ── 0. Prerequisites ────────────────────────────────────────────────────
step "0" "System prerequisites"

need_sudo

deb_update
deb_install curl wget gnupg2 ca-certificates lsb-release rsync unzip openssl

ok "Prerequisites installed"

# ── 1. Create app user ──────────────────────────────────────────────────
step "1" "Application user"

if id "$APP_USER" &>/dev/null; then
    ok "User $APP_USER already exists"
else
    useradd -m -s /bin/bash "$APP_USER"
    echo "$APP_USER:$APP_PASSWORD" | chpasswd
    usermod -aG sudo "$APP_USER"
    ok "User $APP_USER created with sudo"
fi

# Enable lingering so systemctl --user services survive logout/reboot
loginctl enable-linger "$APP_USER" 2>/dev/null || true
ok "User lingering enabled for $APP_USER"

# Ensure home dir exists
mkdir -p "$APP_HOME/.ssh"
chmod 700 "$APP_HOME/.ssh"
chown -R "$APP_USER:$APP_USER" "$APP_HOME"

# ── 2. Java 21 ──────────────────────────────────────────────────────────
step "2" "Java 21"

if has java && java -version 2>&1 | grep -q "21"; then
    ok "Java 21 already installed ($(java -version 2>&1 | head -1))"
else
    deb_install openjdk-21-jdk
    ok "Java 21 installed ($(java -version 2>&1 | head -1))"
fi

# ── 3. Node.js 22 ───────────────────────────────────────────────────────
step "3" "Node.js 22"

if has node && node -v 2>&1 | grep -q "v22"; then
    ok "Node.js 22 already installed ($(node -v))"
else
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
    deb_install nodejs
    ok "Node.js 22 installed ($(node -v))"
fi

# ── 4. PostgreSQL 16 ────────────────────────────────────────────────────
step "4" "PostgreSQL 16"

deb_install postgresql postgresql-contrib

# Ensure running
systemctl start postgresql
systemctl enable postgresql

# Create role (idempotent)
sudo -u postgres psql -tc \
    "SELECT 1 FROM pg_roles WHERE rolname='$APP_USER'" | grep -q 1 || \
    sudo -u postgres psql -c "CREATE USER \"$APP_USER\" WITH PASSWORD '$DB_PASSWORD';"

# Create database (idempotent)
sudo -u postgres psql -tc \
    "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" | grep -q 1 || \
    sudo -u postgres psql -c "CREATE DATABASE \"$DB_NAME\" OWNER \"$APP_USER\";"

# Extensions (idempotent)
sudo -u postgres psql -d "$DB_NAME" -c "CREATE EXTENSION IF NOT EXISTS citext;"
sudo -u postgres psql -d "$DB_NAME" -c "CREATE EXTENSION IF NOT EXISTS ltree;"

# Fix auth to md5 (idempotent)
PG_HBA=$(find /etc/postgresql -name pg_hba.conf 2>/dev/null | head -1)
if [ -n "$PG_HBA" ]; then
    sed -i 's/^local\s\+all\s\+all\s\+peer/local   all   all   md5/' "$PG_HBA"
    systemctl restart postgresql
fi

# Verify
if PGPASSWORD="$DB_PASSWORD" psql -h localhost -U "$APP_USER" -d "$DB_NAME" -c "SELECT 1;" &>/dev/null; then
    ok "PostgreSQL ready — user=$APP_USER db=$DB_NAME"
else
    err "PostgreSQL connection failed"
fi

# ── 5. Redis ────────────────────────────────────────────────────────────
if [ "$SKIP_REDIS" = "1" ]; then
    step "5" "Redis (skipped)"
else
    step "5" "Redis"

    if has redis-cli && redis-cli ping &>/dev/null; then
        ok "Redis already running ($(redis-cli ping))"
    else
        deb_install redis-server
        sed -i "s/^bind .*/bind $REDIS_HOST/" /etc/redis/redis.conf
        systemctl restart redis-server
        systemctl enable redis-server
        ok "Redis installed and running ($(redis-cli ping))"
    fi
fi

# ── 6. Typesense 30.2 ───────────────────────────────────────────────────
if [ "$SKIP_TYPESENSE" = "1" ]; then
    step "6" "Typesense (skipped)"
else
    step "6" "Typesense $TYPESENSE_VERSION"

    if has typesense-server; then
        ok "Typesense already installed ($(typesense-server --version 2>&1 | head -1))"
    else
        cd /tmp
        curl -fsSL -O "https://dl.typesense.org/releases/$TYPESENSE_VERSION/typesense-server-$TYPESENSE_VERSION-linux-amd64.tar.gz"
        tar -xzf "typesense-server-$TYPESENSE_VERSION-linux-amd64.tar.gz"
        mv typesense-server /usr/local/bin/typesense-server
        rm "typesense-server-$TYPESENSE_VERSION-linux-amd64.tar.gz"
        ok "Typesense binary installed"
    fi

    # Config dirs
    mkdir -p /etc/typesense /var/lib/typesense /var/log/typesense

    # Config file
    tee /etc/typesense/typesense-server.ini > /dev/null << CONF
data-dir = /var/lib/typesense
log-dir = /var/log/typesense
api-key = $TYPESENSE_API_KEY
api-port = 8108
enable-cors = true
CONF

    # Systemd service (idempotent)
    if [ ! -f /etc/systemd/system/typesense-server.service ]; then
        tee /etc/systemd/system/typesense-server.service > /dev/null << SVC
[Unit]
Description=Typesense Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/typesense-server --config /etc/typesense/typesense-server.ini
Restart=on-failure
User=$APP_USER

[Install]
WantedBy=multi-user.target
SVC
    fi

    chown -R "$APP_USER:$APP_USER" /var/lib/typesense /var/log/typesense
    systemctl daemon-reload
    systemctl enable typesense-server
    systemctl restart typesense-server

    sleep 2
    if curl -s http://localhost:8108/health &>/dev/null; then
        ok "Typesense running on :8108"
    else
        warn "Typesense may still be starting (check: systemctl status typesense-server)"
    fi
fi

# ── 7. Application directories ──────────────────────────────────────────
step "7" "Application directories"

mkdir -p /opt/entaprenua/{backend,admin,media}
mkdir -p /var/lib/entaprenua/{stores,platform,temp}
mkdir -p /repos/Apps/entaprenua/db
chown -R "$APP_USER:$APP_USER" /opt/entaprenua /var/lib/entaprenua /repos/Apps
ok "App directories created and owned by $APP_USER"

# ── 8. Systemd service templates ────────────────────────────────────────
step "8" "Systemd service templates"

if [ ! -f /etc/systemd/system/entaprenua-backend.service ]; then
    tee /etc/systemd/system/entaprenua-backend.service > /dev/null << SVC
[Unit]
Description=Entaprenua Backend (Spring Boot)
After=network.target postgresql.service redis.service

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=/opt/entaprenua/backend
ExecStart=/usr/bin/java -jar /opt/entaprenua/backend/entaprenua.jar
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=entaprenua-backend
EnvironmentFile=/opt/entaprenua/backend/.env

[Install]
WantedBy=multi-user.target
SVC
    ok "Backend service created"
else
    ok "Backend service already exists"
fi

if [ ! -f /etc/systemd/system/entaprenua-admin.service ]; then
    tee /etc/systemd/system/entaprenua-admin.service > /dev/null << SVC
[Unit]
Description=Entaprenua Admin (SolidStart)
After=network.target

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=/opt/entaprenua/admin
ExecStart=/usr/bin/node server/index.mjs
Restart=on-failure
RestartSec=10
Environment=PORT=3000
StandardOutput=journal
StandardError=journal
SyslogIdentifier=entaprenua-admin
EnvironmentFile=/opt/entaprenua/admin/.env

[Install]
WantedBy=multi-user.target
SVC
    ok "Admin service created"
else
    ok "Admin service already exists"
fi

systemctl daemon-reload

# ── 9. OpenResty + nginx + SSL ──────────────────────────────────────────
if [ "$SKIP_OPENRESTY" = "1" ]; then
    step "9" "OpenResty (skipped)"
else
    step "9" "OpenResty + Cloudflare SSL"

    # Install OpenResty
    if has openresty; then
        ok "OpenResty already installed ($(openresty -v 2>&1))"
    else
        systemctl stop nginx 2>/dev/null || true
        systemctl disable nginx 2>/dev/null || true
        wget -qO - https://openresty.org/package/pubkey.gpg | apt-key add -
        echo "deb http://openresty.org/package/ubuntu $(lsb_release -sc) main" \
            | tee /etc/apt/sources.list.d/openresty.list
        deb_update
        deb_install openresty
        ok "OpenResty installed ($(openresty -v 2>&1))"
    fi

    # Directories
    mkdir -p /etc/nginx/{lua,sites-available,sites-enabled}
    mkdir -p /etc/ssl/{certs,private}
    chmod 700 /etc/ssl/private

    # Ensure sites-enabled include in main nginx.conf
    NGINX_CONF="/usr/local/openresty/nginx/conf/nginx.conf"
    if ! grep -q "sites-enabled" "$NGINX_CONF"; then
        cp "$NGINX_CONF" "${NGINX_CONF}.bak"
        # Add include after mime.types
        sed -i '/include.*mime.types/a\    include /etc/nginx/sites-enabled/*;' "$NGINX_CONF"
        # Add lua path
        sed -i '/include.*sites-enabled/a\    lua_package_path "/usr/local/openresty/lualib/?.lua;;/etc/nginx/lua/?.lua;";' "$NGINX_CONF"
    fi

    ok "Lua directory created (scripts deployed by deploy-backend.sh)"

    # Main nginx site config
    if [ ! -f /etc/nginx/sites-available/entaprenua.conf ]; then
        tee /etc/nginx/sites-available/entaprenua.conf > /dev/null << 'CONF'
# ── entaprenua.com (admin + API) ──────────────────────────────────────
server {
    listen 80;
    server_name entaprenua.com www.entaprenua.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    http2 on;
    server_name entaprenua.com www.entaprenua.com;

    client_max_body_size 100M;

    ssl_certificate /etc/ssl/certs/cloudflare-origin.pem;
    ssl_certificate_key /etc/ssl/private/cloudflare-origin.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    location /media/ {
        alias /opt/entaprenua/media/;
        expires 7d;
        add_header Cache-Control "public, immutable";
    }

    location /api/ {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /mpesa {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /webhooks {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /oauth {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}

# ── Storefront subdomains (*.entaprenua.com) ──────────────────────────
server {
    listen 80;
    server_name ~^(?<subdomain>.+)\.entaprenua\.com$;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    http2 on;
    server_name ~^(?<subdomain>.+)\.entaprenua\.com$;

    client_max_body_size 100M;

    ssl_certificate /etc/ssl/certs/cloudflare-origin.pem;
    ssl_certificate_key /etc/ssl/private/cloudflare-origin.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    set $store_port 3000;

    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;

    location /api/ {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location / {
        access_by_lua_file /etc/nginx/lua/storefront-lookup.lua;
        proxy_pass http://127.0.0.1:$store_port;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
CONF
    fi

    # Enable site
    rm -f /etc/nginx/sites-enabled/default /etc/nginx/sites-enabled/*.conf
    ln -sf /etc/nginx/sites-available/entaprenua.conf /etc/nginx/sites-enabled/entaprenua.conf

    # Test and start
    if /usr/local/openresty/nginx/sbin/nginx -t 2>&1; then
        systemctl enable openresty
        systemctl restart openresty
        ok "OpenResty running with SSL"
    else
        err "nginx config test failed — check /usr/local/openresty/nginx/sbin/nginx -t"
    fi
fi

# ── 10. Cloudflare Origin CA certs ──────────────────────────────────────
step "10" "Cloudflare Origin CA certs"

CERT_OK=1
[ -f /etc/ssl/certs/cloudflare-origin.pem ] || CERT_OK=0
[ -f /etc/ssl/private/cloudflare-origin.key ] || CERT_OK=0

if [ "$CERT_OK" -eq 1 ]; then
    ok "Cloudflare Origin CA certs already present"
else
    warn "Cloudflare Origin CA certs not found."
    warn "Upload them manually:"
    warn "  scp cloudflare-origin.pem root@<ip>:/etc/ssl/certs/"
    warn "  scp cloudflare-origin.key root@<ip>:/etc/ssl/private/"
    warn "  chmod 644 /etc/ssl/certs/cloudflare-origin.pem"
    warn "  chmod 600 /etc/ssl/private/cloudflare-origin.key"
    warn "Then: systemctl reload openresty"
fi

# ── Summary ─────────────────────────────────────────────────────────────
banner
banner
echo ""
echo "╔═══════════════════════════════════════════════════╗"
echo "║            VPS SETUP COMPLETE                     ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""
echo "  User:         $APP_USER"
echo "  Home:         $APP_HOME"
echo ""
echo "  Java:         $(java -version 2>&1 | head -1)"
echo "  Node.js:      $(node -v 2>/dev/null || echo 'not installed')"
echo "  PostgreSQL:   $(psql --version 2>/dev/null | head -1)"
echo "  Redis:        $(redis-cli ping 2>/dev/null || echo 'not running')"
echo "  Typesense:    $(typesense-server --version 2>/dev/null || echo 'not installed')"
echo "  OpenResty:    $(openresty -v 2>&1 | head -1 || echo 'not installed')"
echo ""
echo "  ── Next Steps ──"
echo "  1. Upload Cloudflare Origin CA certs (if not present)"
echo "     scp cloudflare-origin.pem $APP_USER@<ip>:/tmp/ && sudo mv /tmp/*.pem /etc/ssl/certs/"
echo "  2. Run deploy-backend.sh from your local machine"
echo "  3. Run deploy-frontend.sh from your local machine"
echo "  4. Set Cloudflare SSL/TLS → Full (strict)"
echo "  5. Set Cloudflare DNS → entaprenua.com A 35.x.x.x (Proxied)"
echo ""
echo "═══════════════════════════════════════════════════"
