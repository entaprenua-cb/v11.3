#!/bin/bash

# =============================================================================
# Entaprenua Database Setup Script
# =============================================================================
# Runs tables.sql and mockups/*.sql against a PostgreSQL database.
#
# PREREQUISITES:
#   - PostgreSQL client (psql) installed (local or on VPS)
#   - SSH access to VPS for remote mode
#
# USAGE:
#   ./run-db-local.sh              # Run locally (interactive)
#   ./run-db-local.sh local        # Run locally
#   ./run-db-local.sh remote       # Run on VPS
#
# ENVIRONMENT VARIABLES:
#   DB_HOST     - Database host (default: localhost)
#   DB_PORT     - Database port (default: 5432)
#   DB_USER     - Database user (default: nesh)
#   DB_NAME     - Database name (default: entaprenua)
#   DB_PASSWORD - Database password (default: @martoh2551#)
# =============================================================================
set -e

# Default values (match init-db.sh)
DB_HOST="${DB_HOST:-localhost}"
DB_PORT="${DB_PORT:-5432}"
DB_USER="${DB_USER:-nesh}"
DB_NAME="${DB_NAME:-entaprenua}"
DB_PASSWORD="${DB_PASSWORD:-@martoh2551#}"

# VPS settings for remote mode
VPS_HOST="187.124.17.59"
VPS_USER="root"
SSH_KEY="/home/nesh/.ssh/id_ed25519"
SSH_OPTS="-i $SSH_KEY -o StrictHostKeyChecking=no"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DB_DIR="$(cd "$SCRIPT_DIR/../backend/src/main/resources/db" && pwd)"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info() {
    echo -e "${YELLOW}➜${NC} $1"
}

success() {
    echo -e "${GREEN}✓${NC} $1"
}

error() {
    echo -e "${RED}✗${NC} $1"
}

section() {
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo " $1"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

print_usage() {
    echo "Usage: $0 [local|remote]"
    echo ""
    echo "  local    Run scripts on local database (default)"
    echo "  remote   Run scripts on remote VPS database"
    echo ""
}

run_psql_local() {
    PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" "$@"
}

run_psql_remote() {
    ssh $SSH_OPTS "$VPS_USER@$VPS_HOST" "PGPASSWORD='$DB_PASSWORD' psql -h localhost -p $DB_PORT -U $DB_USER -d $DB_NAME $*"
}

run_psql_remote_stdin() {
    ssh $SSH_OPTS "$VPS_USER@$VPS_HOST" "PGPASSWORD='$DB_PASSWORD' psql -h localhost -p $DB_PORT -U $DB_USER -d $DB_NAME"
}

check_prerequisites() {
    section "CHECKING PREREQUISITES"
    
    info "Mode: $TARGET"
    info "Host: $DB_HOST:$DB_PORT"
    info "User: $DB_USER"
    info "Database: $DB_NAME"
    info "DB Dir: $DB_DIR"
}

test_connection() {
    section "TESTING DATABASE CONNECTION"
    
    if [ "$TARGET" = "remote" ]; then
        info "Connecting to VPS: $VPS_HOST..."
        run_psql_remote -c "SELECT 1;" &>/dev/null && success "Connection successful" || { error "Connection failed"; exit 1; }
    else
        info "Connecting to $DB_HOST:$DB_PORT..."
        run_psql_local -c "SELECT 1;" &>/dev/null && success "Connection successful" || { error "Connection failed"; exit 1; }
    fi
}

run_tables() {
    section "RUNNING tables.sql"
    
    local file="$DB_DIR/tables.sql"
    if [ ! -f "$file" ]; then
        error "tables.sql not found at $file"
        exit 1
    fi
    
    info "Executing tables.sql..."
    
    if [ "$TARGET" = "remote" ]; then
        cat "$file" | run_psql_remote_stdin &>/dev/null && success "tables.sql executed" || { error "Failed to execute tables.sql"; exit 1; }
    else
        run_psql_local -f "$file" &>/dev/null && success "tables.sql executed" || { error "Failed to execute tables.sql"; exit 1; }
    fi
}

run_mockups() {
    section "RUNNING mockups/*.sql"
    
    local mockups_dir="$DB_DIR/mockups"
    if [ ! -d "$mockups_dir" ]; then
        info "No mockups directory found, skipping"
        return
    fi
    
    local files=("$mockups_dir"/*.sql)
    if [ ${#files[@]} -eq 0 ] || [ ! -f "${files[0]}" ]; then
        info "No .sql files found in mockups directory"
        return
    fi
    
    info "Found ${#files[@]} mockup files"
    
    for file in "${files[@]}"; do
        local filename=$(basename "$file")
        info "Executing $filename..."
        
        if [ "$TARGET" = "remote" ]; then
            cat "$file" | run_psql_remote_stdin &>/dev/null && success "  $filename ✓" || error "  $filename ✗"
        else
            run_psql_local -f "$file" &>/dev/null && success "  $filename ✓" || error "  $filename ✗"
        fi
    done
}

run_migrations() {
    section "RUNNING migration/*.sql"
    
    local migration_dir="$DB_DIR/migration"
    if [ ! -d "$migration_dir" ]; then
        info "No migration directory found, skipping"
        return
    fi
    
    local files=("$migration_dir"/*.sql)
    if [ ${#files[@]} -eq 0 ] || [ ! -f "${files[0]}" ]; then
        info "No migration files found"
        return
    fi
    
    info "Found ${#files[@]} migration files"
    
    for file in "${files[@]}"; do
        local filename=$(basename "$file")
        info "Executing $filename..."
        
        if [ "$TARGET" = "remote" ]; then
            cat "$file" | run_psql_remote_stdin &>/dev/null && success "  $filename ✓" || error "  $filename ✗"
        else
            run_psql_local -f "$file" &>/dev/null && success "  $filename ✓" || error "  $filename ✗"
        fi
    done
}

verify() {
    section "VERIFICATION"
    
    info "Checking tables created..."
    local count
    if [ "$TARGET" = "remote" ]; then
        count=$(run_psql_remote -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public';" 2>/dev/null | xargs)
    else
        count=$(run_psql_local -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public';" 2>/dev/null | xargs)
    fi
    success "Created $count tables"
    
    info "Checking records inserted..."
    for table in users stores products categories; do
        local count
        if [ "$TARGET" = "remote" ]; then
            count=$(run_psql_remote -t -c "SELECT COUNT(*) FROM $table;" 2>/dev/null | xargs)
        else
            count=$(run_psql_local -t -c "SELECT COUNT(*) FROM $table;" 2>/dev/null | xargs)
        fi
        if [ -n "$count" ] && [ "$count" != "" ]; then
            success "  $table: $count rows"
        fi
    done
}

summary() {
    section "SUMMARY"
    echo ""
    echo "═══════════════════════════════════════════════════"
    success "DATABASE SETUP COMPLETE"
    echo "═══════════════════════════════════════════════════"
    echo "  Mode:       $TARGET"
    echo "  Host:       $DB_HOST:$DB_PORT"
    echo "  Database:   $DB_NAME"
    echo "  User:       $DB_USER"
    echo "  Tables:     $DB_DIR/tables.sql"
    echo "  Mockups:    $DB_DIR/mockups/*.sql"
    echo "  Migrations: $DB_DIR/migration/*.sql"
    echo "═══════════════════════════════════════════════════"
    echo ""
}

main() {
    TARGET="${1:-local}"
    
    case "$TARGET" in
        local|remote)
            ;;
        -h|--help)
            print_usage
            exit 0
            ;;
        *)
            echo "Error: Invalid target '$TARGET'"
            print_usage
            exit 1
            ;;
    esac
    
    echo ""
    echo "██████╗  █████╗ ███████╗██╗  ██╗    ███████╗███████╗ ██████╗████████╗ ██████╗ ██████╗ "
    echo "██╔══██╗██╔══██╗██╔════╝╚██╗██╔╝    ██╔════╝██╔════╝██╔════╝╚══██╔══╝██╔═══██╗██╔══██╗"
    echo "██████╔╝███████║███████╗ ╚███╔╝     ███████╗█████╗  ██║        ██║   ██║   ██║██████╔╝"
    echo "██╔══██╗██╔══██║╚════██║ ██╔██╗     ╚════██║██╔══╝  ██║        ██║   ██║   ██║██╔══██╗"
    echo "██║  ██║██║  ██║███████║██╔╝ ██╗    ███████║███████╗╚██████╗   ██║   ╚██████╔╝██║  ██║"
    echo "╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚══════╝ ╚═════╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝"
    echo ""
    
    check_prerequisites
    test_connection
    run_tables
    run_mockups
    run_migrations
    verify
    summary
}

main "$@"
