# Deployment Scripts

This directory contains scripts for deploying the Entaprenua platform.

## Scripts Overview

| Script | Purpose |
|--------|---------|
| `setup-vps.sh` | Sets up all prerequisites on a fresh VPS |
| `deploy-backend.sh` | Deploys the backend application |
| `deploy-frontend.sh` | Deploys the CMS builder frontend |

## Config Files

| File | Purpose |
|------|---------|
| `config/entaprenua-backend.service` | Systemd service for backend |
| `config/openresty-env.conf` | OpenResty environment variables |
| `config/openresty-service-override.conf` | OpenResty systemd override |
| `openresty.conf` | OpenResty main nginx.conf |
| `nginx-entaprenua.conf` | Nginx site config with subdomain routing |
| `ssl/cloudflare-origin.pem` | Cloudflare Origin CA certificate |
| `ssl/cloudflare-origin.key` | Cloudflare Origin CA private key |
| `storefront/redis-helpers.lua` | Redis Lua helpers |
| `storefront/storefront-lookup.lua` | Subdomain lookup Lua script |

## Quick Start

### 1. Set Up a Fresh VPS

```bash
export VPS_HOST="your-vps-ip"
export DOMAIN="your-domain.com"
./setup-vps.sh
```

### 2. Configure DNS

Ensure your domain's DNS A record points to the VPS IP.

### 3. Obtain SSL Certificates

```bash
ssh -i ~/.ssh/id_ed25519 root@your-vps-ip
certbot --nginx -d your-domain.com -d "*.your-domain.com"
```

### 4. Deploy Backend

```bash
./deploy-backend.sh
```

## Detailed Guides

- [VPS Setup Guide](../docs/VPS_SETUP.md) - Complete setup documentation
- [Store Persistence](../docs/STORE_PERSISTENCE.md) - Nginx/Lua subdomain routing docs

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `VPS_HOST` | VPS IP address | `187.124.17.59` |
| `VPS_USER` | SSH user | `root` |
| `SSH_KEY` | SSH key path | `~/.ssh/id_ed25519` |
| `DOMAIN` | Domain name | `entaprenua.com` |
| `ADMIN_EMAIL` | Admin email for SSL | `admin@domain.com` |

## What's Deployed

- **Backend**: Spring Boot JAR at `/opt/entaprenua/backend/`
- **Stores**: Built store files at `/var/lib/entaprenua/stores/`
- **Nginx**: OpenResty with Lua subdomain routing at port 80/443
- **Redis**: Subdomain → port cache for dynamic routing

## SSL Certificates

**Recommended**: Use Cloudflare for automatic wildcard SSL.

See [Cloudflare Setup Guide](../docs/CLOUDFLARE_SETUP.md) for full setup.

**Quick Summary**:
1. Create free Cloudflare account
2. Add domain and configure DNS records
3. Update nameservers at your registrar
4. Set SSL/TLS mode to `Full` in Cloudflare

Cloudflare automatically handles certificates for `*.your-domain.com`.
