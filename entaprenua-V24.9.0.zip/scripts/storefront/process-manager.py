#!/usr/bin/env python3
"""
Entaprenua Store Process Manager
Subscribes to Redis 'process:spawn' channel, spawns Node processes,
registers them in Redis, and cleans up idle/expired processes.
"""

import json
import os
import signal
import subprocess
import threading
import time
import redis as redis_module

REDIS_HOST = os.getenv("REDIS_HOST", "127.0.0.1")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))
REDIS_AUTH = os.getenv("REDIS_AUTH", None)
STORES_PATH = os.getenv("STORES_PATH", "/var/lib/entaprenua/stores")
PROCESS_TTL = 300
START_TTL = 30
CLEANUP_INTERVAL = 30
SPAWN_CHANNEL = "process:spawn"
PROCESS_PREFIX = "store:process:"
STORE_ID_PREFIX = "store:id:"


def connect_redis():
    return redis_module.Redis(
        host=REDIS_HOST,
        port=REDIS_PORT,
        password=REDIS_AUTH if REDIS_AUTH else None,
        decode_responses=True,
    )


def spawn_node(payload):
    store_id = payload["storeId"]
    port = payload["port"]
    linked_template_id = payload["linkedTemplateId"]
    api_key = payload.get("apiKey", "")
    env_json = payload.get("env")

    server_path = os.path.join(STORES_PATH, linked_template_id, "server", "index.mjs")
    if not os.path.exists(server_path):
        print(f"[ERROR] Server not found: {server_path}")
        return None

    env = {}
    if api_key:
        env["STORE_API_KEY"] = api_key
    env["PORT"] = str(port)
    if env_json:
        try:
            parsed = json.loads(env_json) if isinstance(env_json, str) else env_json
            for k, v in parsed.items():
                env[k.upper()] = str(v)
        except (json.JSONDecodeError, TypeError) as e:
            print(f"[WARN] Failed to parse env JSON for store {store_id}: {e}")
    env["PROXY_API_BASE_URL"] = "http://localhost:8080"
    env["API_PREFIX"] = "/api/v1"

    print(f"[SPAWN] Starting store {store_id} (template {linked_template_id}) on port {port}")
    log_dir = f"/var/log/entaprenua/stores/{store_id}"
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "store.log")
    log_fd = open(log_path, "a")
    proc = subprocess.Popen(
        ["node", server_path],
        env=env,
        stdout=log_fd,
        stderr=log_fd,
    )
    print(f"[SPAWN] Store {store_id} PID {proc.pid} on port {port} → {log_path}")
    return proc.pid


def register_process(r, store_id, port, pid, linked_template_id, api_key, env, ttl):
    key = f"{PROCESS_PREFIX}{store_id}"

    template_mtime = None
    server_path = os.path.join(STORES_PATH, linked_template_id, "server", "index.mjs")
    try:
        template_mtime = os.path.getmtime(server_path)
    except OSError:
        pass

    data = {
        "port": port,
        "pid": pid,
        "status": "running",
        "linkedTemplateId": linked_template_id,
        "apiKey": api_key,
        "env": env,
        "templateMtime": template_mtime,
    }
    r.setex(key, ttl, json.dumps(data))
    print(f"[REG] Store {store_id} registered with PID {pid} on port {port}")


def get_store_by_id(r, store_id):
    data = r.get(f"{STORE_ID_PREFIX}{store_id}")
    if not data:
        return None
    try:
        return json.loads(data)
    except json.JSONDecodeError:
        return None


def kill_process(pid):
    try:
        os.kill(pid, signal.SIGTERM)
        print(f"[KILL] Sent SIGTERM to PID {pid}")
        time.sleep(0.5)
        try:
            os.kill(pid, 0)
            os.kill(pid, signal.SIGKILL)
            print(f"[KILL] Sent SIGKILL to PID {pid}")
        except ProcessLookupError:
            pass
        return True
    except ProcessLookupError:
        return False


def cleanup_expired(r):
    cursor = 0
    while True:
        cursor, keys = r.scan(cursor=cursor, match=f"{PROCESS_PREFIX}*", count=100)
        for key in keys:
            store_id = key[len(PROCESS_PREFIX):]
            ttl = r.ttl(key)

            # Kill processes whose pid is no longer alive (crashed), even if
            # their TTL is being refreshed by the lookup layer.
            data = r.get(key)
            if data:
                try:
                    entry = json.loads(data)
                    pid = entry.get("pid")
                    if pid:
                        try:
                            os.kill(pid, 0)
                        except ProcessLookupError:
                            r.delete(key)
                            print(f"[CLEANUP] Removed {key} — process {pid} dead")
                            continue
                except (json.JSONDecodeError, OSError):
                    pass

            # Kill processes for stores that are no longer ONLINE
            store = get_store_by_id(r, store_id)
            if store and store.get("status") and store["status"] != "ONLINE":
                data = r.get(key)
                if data:
                    try:
                        entry = json.loads(data)
                        pid = entry.get("pid")
                        if pid:
                            kill_process(pid)
                    except (json.JSONDecodeError, OSError):
                        pass
                r.delete(key)
                print(f"[CLEANUP] Removed {key} — store status is {store['status']}")
                continue

            # Kill processes whose apiKey or env settings have changed
            data = r.get(key)
            if data:
                try:
                    entry = json.loads(data)
                    pid = entry.get("pid")
                    stored_api_key = entry.get("apiKey")
                    stored_env = entry.get("env")

                    current_api_key = None
                    raw = r.get(f"apikey:plain:{store_id}")
                    if raw:
                        current_api_key = json.loads(raw).get("apiKey")

                    current_env = None
                    raw = r.get(f"settings:store:{store_id}:environment")
                    if raw:
                        current_env = json.loads(raw)

                    if stored_api_key != current_api_key or stored_env != current_env:
                        if pid:
                            kill_process(pid)
                        r.delete(key)
                        print(f"[CLEANUP] Removed {key} — env/apiKey changed")
                        continue
                except (json.JSONDecodeError, OSError):
                    pass

            # Kill processes whose template code has been updated
            data = r.get(key)
            if data:
                try:
                    entry = json.loads(data)
                    pid = entry.get("pid")
                    linked_id = entry.get("linkedTemplateId")
                    stored_mtime = entry.get("templateMtime")
                    if stored_mtime is not None and linked_id:
                        server_path = os.path.join(STORES_PATH, linked_id, "server", "index.mjs")
                        if os.path.getmtime(server_path) != stored_mtime:
                            if pid:
                                kill_process(pid)
                            r.delete(key)
                            print(f"[CLEANUP] Removed {key} — template code updated")
                            continue
                except (json.JSONDecodeError, OSError):
                    pass

            # Kill processes whose TTL has expired
            if ttl < 0:
                data = r.get(key)
                if data:
                    try:
                        entry = json.loads(data)
                        pid = entry.get("pid")
                        if pid:
                            kill_process(pid)
                    except (json.JSONDecodeError, OSError):
                        pass
                r.delete(key)
                print(f"[CLEANUP] Removed expired entry: {key}")
        if cursor == 0:
            break


def recover_orphans(r):
    print("[RECOVERY] Checking for orphan processes on startup")
    cursor = 0
    while True:
        cursor, keys = r.scan(cursor=cursor, match=f"{PROCESS_PREFIX}*", count=100)
        for key in keys:
            data = r.get(key)
            if not data:
                continue
            try:
                entry = json.loads(data)
                pid = entry.get("pid")
                if pid:
                    try:
                        os.kill(pid, 0)
                        print(f"[RECOVERY] Process {pid} for {key} still alive — keeping")
                    except ProcessLookupError:
                        print(f"[RECOVERY] Process {pid} for {key} dead — removing")
                        r.delete(key)
            except json.JSONDecodeError:
                r.delete(key)
        if cursor == 0:
            break


def cleanup_loop():
    r = connect_redis()
    print("[CLEANUP] Background cleanup thread started")
    while True:
        time.sleep(CLEANUP_INTERVAL)
        cleanup_expired(r)


def main():
    print("[START] Entaprenua Store Process Manager starting")
    r = connect_redis()
    recover_orphans(r)

    cleanup_thread = threading.Thread(target=cleanup_loop, daemon=True)
    cleanup_thread.start()

    pubsub = r.pubsub()
    pubsub.subscribe(SPAWN_CHANNEL)
    print(f"[START] Subscribed to '{SPAWN_CHANNEL}' channel")

    try:
        for message in pubsub.listen():
            if message["type"] != "message":
                continue

            try:
                payload = json.loads(message["data"])
            except json.JSONDecodeError as e:
                print(f"[ERROR] Invalid spawn message: {e}")
                continue

            store_id = payload.get("storeId")
            if not store_id:
                print("[ERROR] Spawn message missing storeId")
                continue

            pid = spawn_node(payload)
            if pid:
                # If a previous process is registered for this store (e.g. a
                # duplicate-spawn loser, or a stale entry), kill it before the
                # new one overwrites the Redis entry.
                key = f"{PROCESS_PREFIX}{store_id}"
                existing = r.get(key)
                if existing:
                    try:
                        old_entry = json.loads(existing)
                        old_pid = old_entry.get("pid")
                        if old_pid and int(old_pid) != int(pid):
                            kill_process(old_pid)
                    except (json.JSONDecodeError, OSError, ValueError):
                        pass
                register_process(
                    r,
                    store_id,
                    payload["port"],
                    pid,
                    payload["linkedTemplateId"],
                    payload.get("apiKey"),
                    payload.get("env"),
                    PROCESS_TTL,
                )
            else:
                print(f"[ERROR] Failed to spawn store {store_id}")
                key = f"{PROCESS_PREFIX}{store_id}"
                r.delete(key)

    except KeyboardInterrupt:
        print("[STOP] Shutting down")
    finally:
        pubsub.close()


if __name__ == "__main__":
    main()
