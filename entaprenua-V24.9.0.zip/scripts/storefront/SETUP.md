# Storefront Setup

## Prerequisites

- OpenResty with Lua module
- Redis running locally (`127.0.0.1:6379`)
- Python 3 with `redis` package (`pip3 install redis`)
- Node.js (for store processes)
- `entaprenua` system user

## Files

| Local path | VPS destination |
|---|---|
| `scripts/storefront/redis-helpers.lua` | `/etc/nginx/lua/redis-helpers.lua` |
| `scripts/storefront/storefront-lookup.lua` | `/etc/nginx/lua/storefront-lookup.lua` |
| `scripts/storefront/process-manager.py` | `/etc/nginx/lua/process-manager.py` |
| `scripts/storefront/entaprenua-process-manager.service` | `/etc/systemd/system/entaprenua-process-manager.service` |
| `scripts/storefront/nginx-storefronts-dynamic.conf` | `/etc/nginx/sites-available/storefronts` |

## Deploy

```bash
# Sync Lua + Python
rsync -avz --chmod=644 -e "ssh" \
  scripts/storefront/redis-helpers.lua \
  scripts/storefront/storefront-lookup.lua \
  scripts/storefront/process-manager.py \
  vps:/tmp/

ssh vps "sudo mv /tmp/redis-helpers.lua /tmp/storefront-lookup.lua /tmp/process-manager.py /etc/nginx/lua/"

# Install service
rsync -avz --chmod=644 -e "ssh" \
  scripts/storefront/entaprenua-process-manager.service \
  vps:/tmp/

ssh vps "
  sudo mv /tmp/entaprenua-process-manager.service /etc/systemd/system/
  sudo systemctl daemon-reload
  sudo systemctl enable entaprenua-process-manager
  sudo systemctl start entaprenua-process-manager
"

# Reload OpenResty to pick up Lua changes
ssh vps "sudo systemctl reload openresty"
```

## Verify

```bash
# Process manager
ssh vps "sudo systemctl status entaprenua-process-manager"

# Lua scripts exist
ssh vps "ls -la /etc/nginx/lua/"

# Redis keys populated (after backend serves requests)
redis-cli KEYS 'store:domain:*'
redis-cli KEYS 'apikey:plain:*'
redis-cli KEYS 'settings:store:*'
```

## Notes

- The Python process manager must be running **before** any store requests hit OpenResty, otherwise Lua will publish spawn messages that nobody consumes.
- On first request to a cold store, Lua returns 502 while Node starts (1-2s). The client should retry.
- The `entaprenua` system user must have read access to `/var/lib/entaprenua/stores/` where template builds are deployed.
