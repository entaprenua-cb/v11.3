local redis = require "resty.redis"

local _M = {}

local REDIS_HOST = os.getenv("REDIS_HOST") or "127.0.0.1"
local REDIS_PORT = tonumber(os.getenv("REDIS_PORT")) or 6379
local REDIS_AUTH = os.getenv("REDIS_AUTH") or nil
local CONNECT_TIMEOUT = 1000
local READ_TIMEOUT = 1000

local STORE_DOMAIN_PREFIX = "store:domain:"
local STORE_ID_PREFIX = "store:id:"
local STORE_PROCESS_PREFIX = "store:process:"
local PORT_POOL_KEY = "sys:port:pool:next"
local PORT_MIN = 4000
local PORT_MAX = 9999
local SPAWN_CHANNEL = "process:spawn"
local WAIT_TTL = 30
local RUN_TTL = 300

function _M.connect()
    local red = redis:new()
    red:set_timeout(CONNECT_TIMEOUT)

    local ok, err = red:connect(REDIS_HOST, REDIS_PORT)
    if not ok then
        return nil, "Failed to connect: " .. err
    end

    if REDIS_AUTH and REDIS_AUTH ~= "" then
        local ok, err = red:auth(REDIS_AUTH)
        if not ok then
            red:close()
            return nil, "Failed to auth: " .. err
        end
    end

    red:set_timeout(READ_TIMEOUT)
    return red, nil
end

function _M.close(red)
    if red then
        red:close()
    end
end

function _M.get_store_by_domain(red, domain)
    local key = STORE_DOMAIN_PREFIX .. domain
    local value, err = red:get(key)
    if err then
        return nil, "Redis GET error: " .. err
    end
    if value == ngx.null then
        return nil, nil
    end
    local json = require "cjson"
    local ok, data = pcall(json.decode, value)
    if not ok or type(data) ~= "table" then
        return nil, "Invalid store JSON for " .. domain
    end
    return data, nil
end

function _M.get_store_by_id(red, id)
    local key = STORE_ID_PREFIX .. id
    local value, err = red:get(key)
    if err then
        return nil, "Redis GET error: " .. err
    end
    if value == ngx.null then
        return nil, nil
    end
    local json = require "cjson"
    local ok, data = pcall(json.decode, value)
    if not ok or type(data) ~= "table" then
        return nil, "Invalid store JSON for id " .. id
    end
    return data, nil
end

function _M.assign_port(red)
    local port, err = red:incr(PORT_POOL_KEY)
    if err then
        return nil, "INCR error: " .. err
    end
    if port > PORT_MAX then
        red:set(PORT_POOL_KEY, PORT_MIN)
        port = PORT_MIN
    end
    return port, nil
end

function _M.get_process(red, storeId)
    local key = STORE_PROCESS_PREFIX .. storeId
    local value, err = red:get(key)
    if err then
        return nil, "Redis GET error: " .. err
    end
    if value == ngx.null then
        return nil, nil
    end
    local json = require "cjson"
    local ok, data = pcall(json.decode, value)
    if not ok or type(data) ~= "table" then
        return nil, "Invalid process JSON for store " .. storeId
    end
    return data, nil
end

function _M.register_process(red, storeId, data, ttl)
    local key = STORE_PROCESS_PREFIX .. storeId
    local json = require "cjson"
    local encoded, err = json.encode(data)
    if err then
        return nil, "JSON encode error: " .. err
    end
    local ok, err = red:setex(key, ttl, encoded)
    if not ok then
        return nil, "SETEX error: " .. err
    end
    return true, nil
end

-- Atomically claim the process slot for a store. Only one concurrent
-- cold-start request wins the NX claim and becomes the spawner; the rest wait.
-- resty.redis returns "OK" on success but ngx.null on conflict, so normalize
-- to a boolean. Returns (true, nil) if claimed, (false, nil) if already claimed.
function _M.claim_process(red, storeId, data, ttl)
    local key = STORE_PROCESS_PREFIX .. storeId
    local json = require "cjson"
    local encoded, err = json.encode(data)
    if err then
        return nil, "JSON encode error: " .. err
    end
    local ok, err = red:set(key, encoded, "EX", ttl, "NX")
    if err then
        return nil, "SET NX error: " .. err
    end
    return ok == "OK", nil
end

function _M.refresh_process_ttl(red, storeId, ttl)
    local key = STORE_PROCESS_PREFIX .. storeId
    local ok, err = red:expire(key, ttl)
    if err then
        return nil, "EXPIRE error: " .. err
    end
    return ok, nil
end

function _M.delete_process(red, storeId)
    local key = STORE_PROCESS_PREFIX .. storeId
    red:del(key)
end

function _M.publish_spawn(red, storeId, port, linkedTemplateId, apiKey, envJson)
    local json = require "cjson"
    local payload = {
        storeId = storeId,
        port = port,
        linkedTemplateId = linkedTemplateId,
        apiKey = apiKey,
        env = envJson,
    }
    local encoded, err = json.encode(payload)
    if err then
        return nil, "JSON encode error: " .. err
    end
    local ok, err = red:publish(SPAWN_CHANNEL, encoded)
    if err then
        return nil, "PUBLISH error: " .. err
    end
    return ok, nil
end

function _M.get_api_key_for_store(red, storeId)
    local key = "apikey:plain:" .. storeId
    local value, err = red:get(key)
    if err then
        return nil, "Redis GET error: " .. err
    end
    if value == ngx.null then
        return nil, nil
    end
    local json = require "cjson"
    local ok, data = pcall(json.decode, value)
    if not ok or type(data) ~= "table" then
        return nil, "Invalid apikey JSON for store " .. storeId
    end
    return data, nil
end

function _M.get_env_settings(red, storeId)
    local key = "settings:store:" .. storeId .. ":environment"
    local value, err = red:get(key)
    if err then
        return nil, "Redis GET error: " .. err
    end
    if value == ngx.null then
        return nil, nil
    end
    return value, nil
end

return _M
