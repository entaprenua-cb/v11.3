local redis_helpers = require "redis-helpers"

local function normalize_domain(host)
    return host:gsub(":%d+$", "")
end

local WAIT_TTL = 30
local RUN_TTL = 300
local POLL_INTERVAL_MS = 300
local MAX_WAIT_MS = 10000

local function port_ready(port)
    local sock = ngx.socket.tcp()
    sock:settimeout(300)
    local ok, err = sock:connect("127.0.0.1", port)
    if ok then
        sock:close()
        return true
    end
    pcall(sock.close, sock)
    return false
end

-- Poll store:process:{storeId} until status == "running" and the port actually
-- accepts connections. The process-manager registers "running" right after
-- Popen (before the Node server listens), so a TCP probe is required before we
-- hand nginx a port.
-- Returns (port, nil) on success, (nil, "timeout") if still starting,
-- (nil, "gone") if the entry disappeared (spawn failed), or (nil, err).
local function wait_for_running(red, storeId)
    local elapsed = 0
    while elapsed < MAX_WAIT_MS do
        local proc, err = redis_helpers.get_process(red, storeId)
        if err then
            return nil, err
        end
        if not proc then
            return nil, "gone"
        end
        if proc["status"] == "running" and proc["port"] and port_ready(proc["port"]) then
            return proc["port"], nil
        end
        ngx.sleep(POLL_INTERVAL_MS / 1000)
        elapsed = elapsed + POLL_INTERVAL_MS
    end
    return nil, "timeout"
end

local function lookup_store(host)
    local seeded = false
    local domain = normalize_domain(host)
    if not domain or domain == "" then
        return nil, "Empty host"
    end

    ngx.log(ngx.DEBUG, "Looking up store for domain: ", domain)

    local red, err = redis_helpers.connect()
    if not red then
        return nil, err
    end

    local store, err = redis_helpers.get_store_by_domain(red, domain)
    if err then
        redis_helpers.close(red)
        return nil, err
    end
    if not store then
        if not seeded then
            seeded = true
            ngx.location.capture("/api/v1/internal/stores/seed-cache", {
                args = { domain = domain }
            })
        end
        store, err = redis_helpers.get_store_by_domain(red, domain)
        if err then
            redis_helpers.close(red)
            return nil, err
        end
        if not store then
            redis_helpers.close(red)
            ngx.log(ngx.WARN, "Store not found for domain: ", domain)
            return nil, nil
        end
    end

    local storeId = store["id"]
    if not storeId then
        redis_helpers.close(red)
        ngx.log(ngx.ERR, "Store missing id for domain: ", domain)
        return nil, "Store missing id"
    end

    if store["status"] and store["status"] ~= "ONLINE" then
        redis_helpers.close(red)
        ngx.log(ngx.WARN, "Store ", storeId, " is ", store["status"], " — not spawning")
        return nil, nil
    end

    -- Seed cache so API key and env are warm
    if not seeded then
        seeded = true
        ngx.location.capture("/api/v1/internal/stores/seed-cache", {
            args = { domain = domain }
        })
    end

    local linkedTemplateId = store["linkedTemplateId"]
    if linkedTemplateId == ngx.null then
        linkedTemplateId = nil
    end

    -- Check existing process
    local proc, err = redis_helpers.get_process(red, storeId)
    if err then
        redis_helpers.close(red)
        return nil, err
    end

    -- An existing process (running or starting) is only usable if its port
    -- actually accepts connections. The process-manager registers "running"
    -- right after Popen, so a "running" entry may still be booting, and a stale
    -- "running" entry may point at a dead port. wait_for_running polls and
    -- TCP-probes before handing nginx a port; for a healthy process this
    -- returns on the first poll.
    if proc and (proc["status"] == "running" or proc["status"] == "starting") then
        local port, werr = wait_for_running(red, storeId)
        if port then
            redis_helpers.refresh_process_ttl(red, storeId, RUN_TTL)
            redis_helpers.close(red)
            ngx.log(ngx.DEBUG, "Reusing process for store ", storeId, " on port ", port)
            return port, nil
        end
        if werr == "gone" then
            -- Entry vanished (spawn failed) — fall through to spawn a fresh one
        elseif werr == "timeout" then
            redis_helpers.close(red)
            ngx.log(ngx.WARN, "Timed out waiting for store ", storeId, " to start")
            return nil, "timeout"
        else
            redis_helpers.close(red)
            return nil, werr
        end
    end

    -- No running process — trigger spawn
    if not linkedTemplateId then
        if store["isTemplate"] then
            linkedTemplateId = storeId
        else
            redis_helpers.close(red)
            ngx.log(ngx.WARN, "Store ", storeId, " has no linkedTemplateId")
            return nil, "No linked template"
        end
    end

    -- Get API key
    local apiKeyData, err = redis_helpers.get_api_key_for_store(red, storeId)
    if err then
        redis_helpers.close(red)
        return nil, err
    end
    local apiKey = apiKeyData and apiKeyData["apiKey"] or nil

    -- Get environment settings
    local envStr, err = redis_helpers.get_env_settings(red, storeId)
    if err then
        redis_helpers.close(red)
        return nil, err
    end

    local envJson
    if envStr then
        local json = require "cjson"
        envJson = json.decode(envStr)
    end

    -- Assign port
    local port, err = redis_helpers.assign_port(red)
    if err then
        redis_helpers.close(red)
        return nil, err
    end

    -- Atomically claim the process slot. Only the request that wins the NX
    -- claim publishes the spawn; concurrent cold-start requests wait instead
    -- of each spawning a duplicate process.
    local procData = {
        port = port,
        status = "starting",
        linkedTemplateId = linkedTemplateId,
    }
    local claimed, cerr = redis_helpers.claim_process(red, storeId, procData, WAIT_TTL)
    if cerr then
        redis_helpers.close(red)
        return nil, cerr
    end

    if claimed then
        -- Publish spawn request (only the winner does this)
        redis_helpers.publish_spawn(red, storeId, port, linkedTemplateId, apiKey, envJson)
        ngx.log(ngx.INFO, "Triggered spawn for store ", storeId, " on port ", port)
    else
        ngx.log(ngx.INFO, "Spawn already in progress for store ", storeId, " — waiting")
    end

    -- Wait for the spawned process to come up so this cold-start request is
    -- served instead of returning an immediate 502.
    local runningPort, werr = wait_for_running(red, storeId)
    redis_helpers.close(red)
    if runningPort then
        ngx.log(ngx.DEBUG, "Spawn for store ", storeId, " ready on port ", runningPort)
        return runningPort, nil
    end
    if werr ~= "timeout" then
        return nil, werr
    end
    ngx.log(ngx.WARN, "Timed out waiting for spawned store ", storeId)
    return nil, "timeout"
end

local host = ngx.var.host
local port, err = lookup_store(host)

if err then
    if err == "timeout" then
        ngx.log(ngx.WARN, "Store lookup timed out (process not ready): ", host)
        ngx.exit(ngx.HTTP_SERVICE_UNAVAILABLE)
        return
    end
    ngx.log(ngx.ERR, "Store lookup error: ", err)
    ngx.exit(ngx.HTTP_SERVICE_UNAVAILABLE)
    return
end

if not port then
    ngx.log(ngx.WARN, "Store not running: ", host)
    ngx.exit(ngx.HTTP_BAD_GATEWAY)
    return
end

ngx.var.store_port = port
