# Storefront — Process Management & Routing

## Overview

Storefront routing uses OpenResty Lua to dynamically route `*.entaprenua.com` requests to per-store Node.js processes. The system seeds Redis caches on miss via an internal backend subrequest so that the spawn path always has warm data (API key, environment settings, store metadata).

## Files

### `redis-helpers.lua`
OpenResty Lua module for Redis interactions. Provides:
- Connection management (`connect`, `close`)
- Store lookup by domain or ID (`get_store_by_domain`, `get_store_by_id`)
- **Port pool**: `assign_port` — atomic `INCR` on `sys:port:pool:next`, wraps 4000–9999
- **Process registry**: `get_process`, `register_process`, `refresh_process_ttl`, `delete_process` — CRUD for `store:process:<storeId>` keys with TTL
- **Atomic spawn claim**: `claim_process` — `SET key EX <ttl> NX` on `store:process:<storeId>`; only one concurrent cold-start request wins the claim and becomes the spawner, the rest wait instead of spawning duplicates
- **Spawn trigger**: `publish_spawn` — publishes spawn payload to Redis `process:spawn` channel for the Python daemon
- **Lua API key access**: `get_api_key_for_store` — reads `apikey:plain:<storeId>` (plaintext API key, seeded by backend)
- **Lua env access**: `get_env_settings` — reads `settings:store:<storeId>:environment` (cached by backend)

### `storefront-lookup.lua`
Access-by-request Lua script (runs via `access_by_lua_file`). Handles each incoming request:

1. **Normalize domain** from `Host` header
2. **Look up store** via `store:domain:<domain>`
   - Cache miss → calls `seed_once(domain)` which does `ngx.location.capture("/api/v1/internal/stores/seed-cache?domain=...")` → backend populates Redis (only if `store.status == ONLINE`)
   - Retries lookup after seeding
   - `seeded` guard is per-request (local variable, resets every request)
3. **Skip non-ONLINE stores** (e.g. `maintenance`, `suspended`) → 503
4. **Handle template stores**: if `isTemplate == true`, `linkedTemplateId` is set to the store's own `storeId` so the template path resolves correctly; `ngx.null` from Redis JSON is converted to Lua `nil`
5. **Check `store:process:<storeId>`** for a Node process
   - **Existing process (running or starting)**: calls `wait_for_running` — polls every 300ms up to 10s and **TCP-probes** the port (`port_ready`, connects to `127.0.0.1:<port>`) before handing it to nginx. This guards against the process-manager registering "running" before Node actually listens, and against stale "running" entries pointing at dead ports. On success it refreshes the TTL and sets `ngx.var.store_port`.
   - **Missing process**: triggers a spawn — fetches API key + env settings from Redis, assigns a port, then `claim_process` (atomic NX). Only the request that wins the claim publishes to the `process:spawn` channel and registers the 30s "starting" entry; concurrent cold-start requests wait for the same spawn. All then call `wait_for_running`.
   - **Failure**: timeout / errors → **503** (`HTTP_SERVICE_UNAVAILABLE`); no port → **502** (`HTTP_BAD_GATEWAY`)

### `process-manager.py`
Python daemon (runs as `entaprenua-process-manager.service`). Manages Node process lifecycle:
- Subscribes to Redis `process:spawn` channel in the main thread
- On message: spawns `node /var/lib/entaprenua/stores/{linkedTemplateId}/server/index.mjs` with `API_KEY` → `PORT` → user env settings → `PROXY_API_BASE_URL=http://localhost:8080` → `API_PREFIX=/api/v1` (each overrides previous)
- Registers running process in `store:process:<storeId>` with PID, `apiKey`, `env`, and 5-minute TTL
- **Cleanup thread**: background daemon thread runs every 30s, scans `store:process:*` keys and kills processes that are:
  - Whose pid is no longer alive (`os.kill(pid, 0)` fails) — reaps crashed processes even if their TTL is being refreshed
  - For stores no longer `ONLINE` (status changed to `OFFLINE`/`SUSPENDED`)
  - Whose `apiKey` or `env` settings have changed in Redis since spawn
  - Whose template code (server/index.mjs) mtime has changed since spawn (template redeployed)
  - Whose TTL has expired (idle timeout)
- All five checks run on the same 30s interval — any crash, status change, config change, template update, or idle timeout is detected within 30s
- Kill uses `SIGTERM` → 0.5s grace → `SIGKILL` if still alive
- **Duplicate-spawn protection**: before registering a new process, the previous pid for that store is killed, so a lost duplicate spawn can't leak an orphan process
- **Orphan recovery**: on startup, checks all registered PIDs and cleans up dead ones

### `entaprenua-process-manager.service`
Systemd unit for the Python daemon:
```
sudo cp entaprenua-process-manager.service /etc/systemd/system/
sudo systemctl enable entaprenua-process-manager
sudo systemctl start entaprenua-process-manager
```
`PYTHONUNBUFFERED=1` is set via a drop-in (`/etc/systemd/system/entaprenua-process-manager.service.d/env.conf`) so logs flush to journald immediately.

### `nginx-storefronts-dynamic.conf`
OpenResty/Nginx virtual host config for storefront subdomains (`*.entaprenua.com`) and custom domains. Routes:
- `/api/v1/internal/*` → Spring Boot backend directly (**no Lua**, avoids recursion for seed subrequest)
- `/api/*` → Spring Boot backend (`127.0.0.1:8080`)
- `/*` (static + dynamic) → Lua lookup → `proxy_pass http://127.0.0.1:$store_port`

The `/api/v1/internal/` location must appear **before** any Lua-enabled `location /` block in the **deployed** nginx config (`scripts/nginx-entaprenua.conf`).

## Backend

### `SeedStoreCacheController.kt`
Internal endpoint `GET /api/v1/internal/stores/seed-cache` (no auth, no docs). Called by Lua on cache miss. Fetches store by domain and writes the following to Redis:
- `store:domain:<domain>` (store JSON, 30m TTL)
- `apikey:plain:<storeId>` (plaintext API key, 5m TTL)
- `settings:store:<storeId>:environment` (env JSON, 5m TTL)

Only seeds if `store.status == ONLINE`. Returns 204 on success, 404 if not found.

### `StoreContextFilter.kt`
"internal" is added to reserved words so `/internal/...` paths are not treated as store publicIds.

## Redis Keys

| Key | Value | TTL | Written by | Read by |
|---|---|---|---|---|
| `store:domain:<domain>` | Store JSON | 30m | Backend `SeedStoreCacheController`, `StoreRepository` | Lua `storefront-lookup` |
| `store:process:<storeId>` | `{"port","pid","status","linkedTemplateId","apiKey","env","templateMtime"}` | 5m (running) / 30s (starting, via `claim_process` NX) | Lua + Python | Lua, Python (cleanup diff) |
| `sys:port:pool:next` | integer | — | Lua `assign_port` | Lua |
| `apikey:plain:<storeId>` | `{"apiKey","name"}` | 5m | Backend `SeedStoreCacheController`, `StoreApiKeyServiceImpl` | Lua spawn path |
| `settings:store:<storeId>:environment` | content JSON string | 5m | Backend `SeedStoreCacheController`, `StoreSettingsGetService` | Lua spawn path |

## Request Flow (cold start, cache miss)

```
 1. Browser → *.entaprenua.com → nginx
 2. access_by_lua_file → storefront-lookup.lua
 3. GET store:domain:<domain> → nil (cache miss)
 4. seed_once(domain) → ngx.location.capture /api/v1/internal/stores/seed-cache?domain=...
 5.   nginx matches location /api/v1/internal/ (before Lua / block) → proxy to Spring Boot
 6.   SeedStoreCacheController: fetches store, writes store:domain + apikey:plain + settings to Redis
 7.   Returns 204
 8. Lua retries GET store:domain:<domain> → store JSON (has storeId, linkedTemplateId, isTemplate)
 9. Skip if store.status != ONLINE → 503
10. Handle ngx.null → nil for linkedTemplateId; if isTemplate → linkedTemplateId = storeId
11. GET store:process:<storeId> → nil (no process yet)
12. GET apikey:plain:<storeId> → {"apiKey":"sk_live_...","name":"..."}
13. GET settings:store:<storeId>:environment → env JSON
14. INCR sys:port:pool:next → port 4001
15. claim_process → SET store:process:<storeId> {status:"starting", port:4001} EX 30 NX
16.   Winner: PUBLISH process:spawn {storeId, port, linkedTemplateId, apiKey, env}
17.   Losers (NX conflict): skip publishing, go straight to waiting
18. All cold-start requests call wait_for_running: poll store:process:<storeId> every 300ms
19. Python → SUBSCRIBE receives spawn → Popen(["node", path], env={API_KEY, PORT, ...user env, PROXY_API_BASE_URL, API_PREFIX})
20. SET store:process:<storeId> {status:"running", pid:..., port:4001} EX 300
21. wait_for_running: sees "running" + TCP-probe of :4001 succeeds → returns port
22. Refresh TTL → proxy to :4001 → Node handles request → 200 (≤10s)
23. If still not ready after 10s → 503
```

## Important Notes

- The `seeded` guard is a **local** variable in `lookup_store()`, so it resets per request — at most one backend seed call per request.
- `store:domain:<domain>` is the primary store key (no longer uses `store:id:<uuid>`).
- Template stores (`isTemplate == true`, `linkedTemplateId == null`) use their own `storeId` as the template path.
- Cold start no longer returns an immediate 502 — the Lua waits up to 10s for the spawn (polling + TCP probe) and serves the request on the freshly started process. Timeout/errors return 503.
- `claim_process` (NX) ensures concurrent cold-start requests don't spawn duplicate processes; only the winner publishes to the `process:spawn` channel.
- `wait_for_running` TCP-probes (`port_ready`) the target port before returning it, so a "running" entry whose process isn't actually listening (boot in progress, or crashed but not yet reaped) is never handed to nginx.
- The `/api/v1/internal/` nginx location **must** come before the Lua-enabled `location /` to avoid recursive Lua execution.
- VPS nginx config lives at `/etc/nginx/sites-available/nginx-entaprenua.conf`, mirrored in `scripts/nginx-entaprenua.conf`.
